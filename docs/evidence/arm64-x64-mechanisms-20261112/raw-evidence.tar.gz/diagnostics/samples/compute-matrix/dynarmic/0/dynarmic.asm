00007aa3a45ce69b  nop [rax+rax*1], eax
00007aa3a45ce6a0  vmovaps xmm1, [0x00007AA3A41FE010]
00007aa3a45ce6a8  movq xmm1, xmm1
00007aa3a45ce6ac  movaps [r15+0x110], xmm1
00007aa3a45ce6b4  vmovaps xmm1, [0x00007AA3A41FE020]
00007aa3a45ce6bc  movq xmm1, xmm1
00007aa3a45ce6c0  movaps [r15+0x120], xmm1
00007aa3a45ce6c8  mov eax, 0x4204C0
00007aa3a45ce6cd  mov r14, [r13+rax*1]
00007aa3a45ce6d2  movq xmm1, r14
00007aa3a45ce6d7  movaps [r15+0x130], xmm1
00007aa3a45ce6df  vmovaps xmm1, [0x00007AA3A41FE030]
00007aa3a45ce6e7  vpbroadcastq xmm1, xmm1
00007aa3a45ce6ec  movaps [r15+0x140], xmm1
00007aa3a45ce6f4  mov qword ptr [r15+0x40], 0x02
00007aa3a45ce6fc  vmovaps xmm15, [0x00007AA3A41FE040]
00007aa3a45ce704  movq xmm15, xmm15
00007aa3a45ce709  movaps [r15+0x150], xmm15
00007aa3a45ce711  mov qword ptr [r15+0x58], 0x420000
00007aa3a45ce719  vmovaps xmm15, [0x00007AA3A41FE050]
00007aa3a45ce721  vpbroadcastq xmm15, xmm15
00007aa3a45ce726  movaps [r15+0x160], xmm15
00007aa3a45ce72e  mov rax, [r15+0x40]
00007aa3a45ce732  vmovq xmm14, rax
00007aa3a45ce737  vpbroadcastq xmm14, xmm14
00007aa3a45ce73c  movaps [r15+0x170], xmm14
00007aa3a45ce744  mov eax, 0x4204D0
00007aa3a45ce749  movups xmm13, [r13+rax*1]
00007aa3a45ce74f  mov qword ptr [r15+0x40], 0x430518
00007aa3a45ce757  mov qword ptr [r15+0x50], 0x430720
00007aa3a45ce75f  vpmovqd xmm12, xmm13
00007aa3a45ce765  pxor xmm11, xmm11
00007aa3a45ce76a  punpcklqdq xmm12, xmm11
00007aa3a45ce76f  movaps [r15+0x210], xmm12
00007aa3a45ce777  movq xmm12, qword ptr [r15+0x120]
00007aa3a45ce780  movq xmm11, qword ptr [r15+0x130]
00007aa3a45ce789  psubd xmm12, xmm11
00007aa3a45ce78e  movq xmm12, xmm12
00007aa3a45ce793  paddq xmm13, xmm14
00007aa3a45ce798  movaps [r15+0x180], xmm13
00007aa3a45ce7a0  movq xmm14, qword ptr [r15+0x150]
00007aa3a45ce7a9  paddd xmm11, xmm14
00007aa3a45ce7ae  movq xmm11, xmm11
00007aa3a45ce7b3  movq xmm11, xmm11
00007aa3a45ce7b8  movaps [r15+0x130], xmm11
00007aa3a45ce7c0  pmovzxdq xmm12, xmm12
00007aa3a45ce7c6  psllq xmm12, 0x00
00007aa3a45ce7cc  movq xmm14, qword ptr [r15+0x210]
00007aa3a45ce7d5  movq xmm13, qword ptr [r15+0x110]
00007aa3a45ce7de  paddd xmm14, xmm13
00007aa3a45ce7e3  movq xmm14, xmm14
00007aa3a45ce7e8  vcvtuqq2pd xmm12, xmm12
00007aa3a45ce7ee  pmovzxdq xmm14, xmm14
00007aa3a45ce7f4  psllq xmm14, 0x00
00007aa3a45ce7fa  vcvtuqq2pd xmm14, xmm14
00007aa3a45ce800  movaps xmm13, xmm12
00007aa3a45ce804  mulpd xmm13, xmm1
00007aa3a45ce809  vcmppd xmm11, xmm13, xmm13, 0x03
00007aa3a45ce80f  ptest xmm11, xmm11
00007aa3a45ce815  jnz 0x00007AA3A45CE8FF
00007aa3a45ce81b  movaps [r15+0x220], xmm13
00007aa3a45ce823  mov eax, 0x430720
00007aa3a45ce828  movups [r13+rax*1], xmm13
00007aa3a45ce82e  movaps xmm1, xmm14
00007aa3a45ce832  mulpd xmm1, xmm15
00007aa3a45ce837  vcmppd xmm13, xmm1, xmm1, 0x03
00007aa3a45ce83c  ptest xmm13, xmm13
00007aa3a45ce842  jnz 0x00007AA3A45CEA4C
00007aa3a45ce848  movaps [r15+0x210], xmm1
00007aa3a45ce850  mov eax, 0x430518
00007aa3a45ce855  movups [r13+rax*1], xmm1
00007aa3a45ce85b  mov qword ptr [r15+0x48], 0x10
00007aa3a45ce863  xor eax, eax
00007aa3a45ce865  mov r14d, 0x10
00007aa3a45ce86b  mov r12d, 0x200
00007aa3a45ce871  cmp r14, r12
00007aa3a45ce874  cmc
00007aa3a45ce875  lahf
00007aa3a45ce876  seto al
00007aa3a45ce879  mov [r15+0x108], eax
00007aa3a45ce880  mov eax, [r15+0x108]
00007aa3a45ce887  sahf
00007aa3a45ce888  jnz 0x00007AA3A45CE8BA
00007aa3a45ce88a  cmp dword ptr [r15+0x318], 0x00
00007aa3a45ce892  jz 0x00007AA3A45CEFF0
00007aa3a45ce898  nop [rax+rax*1], ax
00007aa3a45ce8a1  nop [rax+rax*1], eax
00007aa3a45ce8a9  mov eax, 0x4101EC
00007aa3a45ce8ae  mov [r15+0x100], rax
00007aa3a45ce8b5  jmp 0x00007AA3A43FE110
00007aa3a45ce8ba  cmp dword ptr [r15+0x318], 0x00
00007aa3a45ce8c2  jz 0x00007AA3A45CEBA0
00007aa3a45ce8c8  nop [rax+rax*1], ax
00007aa3a45ce8d1  nop [rax+rax*1], eax
00007aa3a45ce8d9  mov eax, 0x4101AC
00007aa3a45ce8de  mov [r15+0x100], rax
00007aa3a45ce8e5  jmp 0x00007AA3A43FE110
00007aa3a45ce8ea  int3
00007aa3a45ce8eb  call 0x00007AA3A440DC20
00007aa3a45ce8f0  jmp 0x00007AA3A45CE6D2
00007aa3a45ce8f5  call 0x00007AA3A440C260
00007aa3a45ce8fa  jmp 0x00007AA3A45CE74F
00007aa3a45ce8ff  sub rsp, 0x08
00007aa3a45ce903  push rax
00007aa3a45ce904  push rcx
00007aa3a45ce905  push rdx
00007aa3a45ce906  push rdi
00007aa3a45ce907  push rsi
00007aa3a45ce908  push r8
00007aa3a45ce90a  push r9
00007aa3a45ce90c  push r10
00007aa3a45ce90e  push r11
00007aa3a45ce910  sub rsp, 0xF0
00007aa3a45ce917  vmovaps [rsp], xmm0
00007aa3a45ce91c  vmovaps [rsp+0x10], xmm1
00007aa3a45ce922  vmovaps [rsp+0x20], xmm2
00007aa3a45ce928  vmovaps [rsp+0x30], xmm3
00007aa3a45ce92e  vmovaps [rsp+0x40], xmm4
00007aa3a45ce934  vmovaps [rsp+0x50], xmm5
00007aa3a45ce93a  vmovaps [rsp+0x60], xmm6
00007aa3a45ce940  vmovaps [rsp+0x70], xmm7
00007aa3a45ce946  vmovaps [rsp+0x80], xmm8
00007aa3a45ce94f  vmovaps [rsp+0x90], xmm9
00007aa3a45ce958  vmovaps [rsp+0xA0], xmm10
00007aa3a45ce961  vmovaps [rsp+0xB0], xmm11
00007aa3a45ce96a  vmovaps [rsp+0xC0], xmm12
00007aa3a45ce973  vmovaps [rsp+0xD0], xmm14
00007aa3a45ce97c  vmovaps [rsp+0xE0], xmm15
00007aa3a45ce985  sub rsp, 0x30
00007aa3a45ce989  movaps [rsp], xmm13
00007aa3a45ce98e  movaps [rsp+0x10], xmm12
00007aa3a45ce994  movaps [rsp+0x20], xmm1
00007aa3a45ce999  lea rdi, [rsp]
00007aa3a45ce99d  mov esi, 0x00
00007aa3a45ce9a2  mov rax, 0x5F551B683530
00007aa3a45ce9ac  call rax
00007aa3a45ce9ae  movaps xmm13, [rsp]
00007aa3a45ce9b3  add rsp, 0x30
00007aa3a45ce9b7  vmovaps xmm0, [rsp]
00007aa3a45ce9bc  vmovaps xmm1, [rsp+0x10]
00007aa3a45ce9c2  vmovaps xmm2, [rsp+0x20]
00007aa3a45ce9c8  vmovaps xmm3, [rsp+0x30]
00007aa3a45ce9ce  vmovaps xmm4, [rsp+0x40]
00007aa3a45ce9d4  vmovaps xmm5, [rsp+0x50]
00007aa3a45ce9da  vmovaps xmm6, [rsp+0x60]
00007aa3a45ce9e0  vmovaps xmm7, [rsp+0x70]
00007aa3a45ce9e6  vmovaps xmm8, [rsp+0x80]
00007aa3a45ce9ef  vmovaps xmm9, [rsp+0x90]
00007aa3a45ce9f8  vmovaps xmm10, [rsp+0xA0]
00007aa3a45cea01  vmovaps xmm11, [rsp+0xB0]
00007aa3a45cea0a  vmovaps xmm12, [rsp+0xC0]
00007aa3a45cea13  vmovaps xmm14, [rsp+0xD0]
00007aa3a45cea1c  vmovaps xmm15, [rsp+0xE0]
00007aa3a45cea25  add rsp, 0xF0
00007aa3a45cea2c  pop r11
00007aa3a45cea2e  pop r10
00007aa3a45cea30  pop r9
00007aa3a45cea32  pop r8
00007aa3a45cea34  pop rsi
00007aa3a45cea35  pop rdi
00007aa3a45cea36  pop rdx
00007aa3a45cea37  pop rcx
00007aa3a45cea38  pop rax
00007aa3a45cea39  add rsp, 0x08
00007aa3a45cea3d  jmp 0x00007AA3A45CE81B
00007aa3a45cea42  call 0x00007AA3A440C380
00007aa3a45cea47  jmp 0x00007AA3A45CE82E
00007aa3a45cea4c  sub rsp, 0x08
00007aa3a45cea50  push rax
00007aa3a45cea51  push rcx
00007aa3a45cea52  push rdx
00007aa3a45cea53  push rdi
00007aa3a45cea54  push rsi
00007aa3a45cea55  push r8
00007aa3a45cea57  push r9
00007aa3a45cea59  push r10
00007aa3a45cea5b  push r11
00007aa3a45cea5d  sub rsp, 0xF0
00007aa3a45cea64  vmovaps [rsp], xmm0
00007aa3a45cea69  vmovaps [rsp+0x10], xmm2
00007aa3a45cea6f  vmovaps [rsp+0x20], xmm3
00007aa3a45cea75  vmovaps [rsp+0x30], xmm4
00007aa3a45cea7b  vmovaps [rsp+0x40], xmm5
00007aa3a45cea81  vmovaps [rsp+0x50], xmm6
00007aa3a45cea87  vmovaps [rsp+0x60], xmm7
00007aa3a45cea8d  vmovaps [rsp+0x70], xmm8
00007aa3a45cea93  vmovaps [rsp+0x80], xmm9
00007aa3a45cea9c  vmovaps [rsp+0x90], xmm10
00007aa3a45ceaa5  vmovaps [rsp+0xA0], xmm11
00007aa3a45ceaae  vmovaps [rsp+0xB0], xmm12
00007aa3a45ceab7  vmovaps [rsp+0xC0], xmm13
00007aa3a45ceac0  vmovaps [rsp+0xD0], xmm14
00007aa3a45ceac9  vmovaps [rsp+0xE0], xmm15
00007aa3a45cead2  sub rsp, 0x30
00007aa3a45cead6  movaps [rsp], xmm1
00007aa3a45ceada  movaps [rsp+0x10], xmm14
00007aa3a45ceae0  movaps [rsp+0x20], xmm15
00007aa3a45ceae6  lea rdi, [rsp]
00007aa3a45ceaea  mov esi, 0x00
00007aa3a45ceaef  mov rax, 0x5F551B683530
00007aa3a45ceaf9  call rax
00007aa3a45ceafb  movaps xmm1, [rsp]
00007aa3a45ceaff  add rsp, 0x30
00007aa3a45ceb03  vmovaps xmm0, [rsp]
00007aa3a45ceb08  vmovaps xmm2, [rsp+0x10]
00007aa3a45ceb0e  vmovaps xmm3, [rsp+0x20]
00007aa3a45ceb14  vmovaps xmm4, [rsp+0x30]
00007aa3a45ceb1a  vmovaps xmm5, [rsp+0x40]
00007aa3a45ceb20  vmovaps xmm6, [rsp+0x50]
00007aa3a45ceb26  vmovaps xmm7, [rsp+0x60]
00007aa3a45ceb2c  vmovaps xmm8, [rsp+0x70]
00007aa3a45ceb32  vmovaps xmm9, [rsp+0x80]
00007aa3a45ceb3b  vmovaps xmm10, [rsp+0x90]
00007aa3a45ceb44  vmovaps xmm11, [rsp+0xA0]
00007aa3a45ceb4d  vmovaps xmm12, [rsp+0xB0]
00007aa3a45ceb56  vmovaps xmm13, [rsp+0xC0]
00007aa3a45ceb5f  vmovaps xmm14, [rsp+0xD0]
00007aa3a45ceb68  vmovaps xmm15, [rsp+0xE0]
00007aa3a45ceb71  add rsp, 0xF0
00007aa3a45ceb78  pop r11
00007aa3a45ceb7a  pop r10
00007aa3a45ceb7c  pop r9
00007aa3a45ceb7e  pop r8
00007aa3a45ceb80  pop rsi
00007aa3a45ceb81  pop rdi
00007aa3a45ceb82  pop rdx
00007aa3a45ceb83  pop rcx
00007aa3a45ceb84  pop rax
00007aa3a45ceb85  add rsp, 0x08
00007aa3a45ceb89  jmp 0x00007AA3A45CE848
00007aa3a45ceb8e  call 0x00007AA3A43FF540
00007aa3a45ceb93  jmp 0x00007AA3A45CE85B
00007aa3a45ceb98  int3
00007aa3a45ceb99  nop [rax], eax
00007aa3a45ceba0  movaps xmm1, [r15+0x180]
00007aa3a45ceba8  vpmovqd xmm15, xmm1
00007aa3a45cebae  pxor xmm14, xmm14
00007aa3a45cebb3  punpcklqdq xmm15, xmm14
00007aa3a45cebb8  movaps [r15+0x210], xmm15
00007aa3a45cebc0  movq xmm15, qword ptr [r15+0x120]
00007aa3a45cebc9  movq xmm14, qword ptr [r15+0x130]
00007aa3a45cebd2  psubd xmm15, xmm14
00007aa3a45cebd7  movq xmm15, xmm15
00007aa3a45cebdc  movaps xmm13, [r15+0x170]
00007aa3a45cebe4  paddq xmm1, xmm13
00007aa3a45cebe9  movaps [r15+0x180], xmm1
00007aa3a45cebf1  movq xmm1, qword ptr [r15+0x150]
00007aa3a45cebfa  paddd xmm14, xmm1
00007aa3a45cebff  movq xmm14, xmm14
00007aa3a45cec04  movq xmm14, xmm14
00007aa3a45cec09  movaps [r15+0x130], xmm14
00007aa3a45cec11  pmovzxdq xmm15, xmm15
00007aa3a45cec17  psllq xmm15, 0x00
00007aa3a45cec1d  movq xmm1, qword ptr [r15+0x210]
00007aa3a45cec26  movq xmm14, qword ptr [r15+0x110]
00007aa3a45cec2f  paddd xmm1, xmm14
00007aa3a45cec34  movq xmm1, xmm1
00007aa3a45cec38  vcvtuqq2pd xmm15, xmm15
00007aa3a45cec3e  pmovzxdq xmm1, xmm1
00007aa3a45cec43  psllq xmm1, 0x00
00007aa3a45cec48  vcvtuqq2pd xmm1, xmm1
00007aa3a45cec4e  movaps xmm14, [r15+0x140]
00007aa3a45cec56  movaps xmm13, xmm15
00007aa3a45cec5a  mulpd xmm13, xmm14
00007aa3a45cec5f  vcmppd xmm12, xmm13, xmm13, 0x03
00007aa3a45cec65  ptest xmm12, xmm12
00007aa3a45cec6b  jnz 0x00007AA3A45CED4E
00007aa3a45cec71  movaps [r15+0x220], xmm13
00007aa3a45cec79  mov rax, [r15+0x48]
00007aa3a45cec7d  mov r14, [r15+0x50]
00007aa3a45cec81  lea r12, [r14+rax*1]
00007aa3a45cec85  movups [r13+r12*1], xmm13
00007aa3a45cec8b  movaps xmm15, [r15+0x160]
00007aa3a45cec93  movaps xmm14, xmm1
00007aa3a45cec97  mulpd xmm14, xmm15
00007aa3a45cec9c  vcmppd xmm13, xmm14, xmm14, 0x03
00007aa3a45ceca2  ptest xmm13, xmm13
00007aa3a45ceca8  jnz 0x00007AA3A45CEE9C
00007aa3a45cecae  movaps [r15+0x210], xmm14
00007aa3a45cecb6  mov r14, [r15+0x40]
00007aa3a45cecba  lea r12, [r14+rax*1]
00007aa3a45cecbe  movups [r13+r12*1], xmm14
00007aa3a45cecc4  lea r14, [rax+0x10]
00007aa3a45cecc8  mov [r15+0x48], r14
00007aa3a45ceccc  xor eax, eax
00007aa3a45cecce  mov r12d, 0x200
00007aa3a45cecd4  cmp r14, r12
00007aa3a45cecd7  cmc
00007aa3a45cecd8  lahf
00007aa3a45cecd9  seto al
00007aa3a45cecdc  mov [r15+0x108], eax
00007aa3a45cece3  mov eax, [r15+0x108]
00007aa3a45cecea  sahf
00007aa3a45ceceb  jnz 0x00007AA3A45CED1D
00007aa3a45ceced  cmp dword ptr [r15+0x318], 0x00
00007aa3a45cecf5  jz 0x00007AA3A45CEFF0
00007aa3a45cecfb  nop [rax+rax*1], ax
00007aa3a45ced04  nop [rax+rax*1], eax
00007aa3a45ced0c  mov eax, 0x4101EC
00007aa3a45ced11  mov [r15+0x100], rax
00007aa3a45ced18  jmp 0x00007AA3A43FE110
00007aa3a45ced1d  cmp dword ptr [r15+0x318], 0x00
00007aa3a45ced25  jz 0x00007AA3A45CEBA0
00007aa3a45ced2b  nop [rax+rax*1], ax
00007aa3a45ced34  nop [rax+rax*1], eax
00007aa3a45ced3c  mov eax, 0x4101AC
00007aa3a45ced41  mov [r15+0x100], rax
00007aa3a45ced48  jmp 0x00007AA3A43FE110
00007aa3a45ced4d  int3
00007aa3a45ced4e  sub rsp, 0x08
00007aa3a45ced52  push rax
00007aa3a45ced53  push rcx
00007aa3a45ced54  push rdx
00007aa3a45ced55  push rdi
00007aa3a45ced56  push rsi
00007aa3a45ced57  push r8
00007aa3a45ced59  push r9
00007aa3a45ced5b  push r10
00007aa3a45ced5d  push r11
00007aa3a45ced5f  sub rsp, 0xF0
00007aa3a45ced66  vmovaps [rsp], xmm0
00007aa3a45ced6b  vmovaps [rsp+0x10], xmm1
00007aa3a45ced71  vmovaps [rsp+0x20], xmm2
00007aa3a45ced77  vmovaps [rsp+0x30], xmm3
00007aa3a45ced7d  vmovaps [rsp+0x40], xmm4
00007aa3a45ced83  vmovaps [rsp+0x50], xmm5
00007aa3a45ced89  vmovaps [rsp+0x60], xmm6
00007aa3a45ced8f  vmovaps [rsp+0x70], xmm7
00007aa3a45ced95  vmovaps [rsp+0x80], xmm8
00007aa3a45ced9e  vmovaps [rsp+0x90], xmm9
00007aa3a45ceda7  vmovaps [rsp+0xA0], xmm10
00007aa3a45cedb0  vmovaps [rsp+0xB0], xmm11
00007aa3a45cedb9  vmovaps [rsp+0xC0], xmm12
00007aa3a45cedc2  vmovaps [rsp+0xD0], xmm14
00007aa3a45cedcb  vmovaps [rsp+0xE0], xmm15
00007aa3a45cedd4  sub rsp, 0x30
00007aa3a45cedd8  movaps [rsp], xmm13
00007aa3a45ceddd  movaps [rsp+0x10], xmm15
00007aa3a45cede3  movaps [rsp+0x20], xmm14
00007aa3a45cede9  lea rdi, [rsp]
00007aa3a45ceded  mov esi, 0x00
00007aa3a45cedf2  mov rax, 0x5F551B683530
00007aa3a45cedfc  call rax
00007aa3a45cedfe  movaps xmm13, [rsp]
00007aa3a45cee03  add rsp, 0x30
00007aa3a45cee07  vmovaps xmm0, [rsp]
00007aa3a45cee0c  vmovaps xmm1, [rsp+0x10]
00007aa3a45cee12  vmovaps xmm2, [rsp+0x20]
00007aa3a45cee18  vmovaps xmm3, [rsp+0x30]
00007aa3a45cee1e  vmovaps xmm4, [rsp+0x40]
00007aa3a45cee24  vmovaps xmm5, [rsp+0x50]
00007aa3a45cee2a  vmovaps xmm6, [rsp+0x60]
00007aa3a45cee30  vmovaps xmm7, [rsp+0x70]
00007aa3a45cee36  vmovaps xmm8, [rsp+0x80]
00007aa3a45cee3f  vmovaps xmm9, [rsp+0x90]
00007aa3a45cee48  vmovaps xmm10, [rsp+0xA0]
00007aa3a45cee51  vmovaps xmm11, [rsp+0xB0]
00007aa3a45cee5a  vmovaps xmm12, [rsp+0xC0]
00007aa3a45cee63  vmovaps xmm14, [rsp+0xD0]
00007aa3a45cee6c  vmovaps xmm15, [rsp+0xE0]
00007aa3a45cee75  add rsp, 0xF0
00007aa3a45cee7c  pop r11
00007aa3a45cee7e  pop r10
00007aa3a45cee80  pop r9
00007aa3a45cee82  pop r8
00007aa3a45cee84  pop rsi
00007aa3a45cee85  pop rdi
00007aa3a45cee86  pop rdx
00007aa3a45cee87  pop rcx
00007aa3a45cee88  pop rax
00007aa3a45cee89  add rsp, 0x08
00007aa3a45cee8d  jmp 0x00007AA3A45CEC71
00007aa3a45cee92  call 0x00007AA3A44C2240
00007aa3a45cee97  jmp 0x00007AA3A45CEC8B
00007aa3a45cee9c  sub rsp, 0x08
00007aa3a45ceea0  push rax
00007aa3a45ceea1  push rcx
00007aa3a45ceea2  push rdx
00007aa3a45ceea3  push rdi
00007aa3a45ceea4  push rsi
00007aa3a45ceea5  push r8
00007aa3a45ceea7  push r9
00007aa3a45ceea9  push r10
00007aa3a45ceeab  push r11
00007aa3a45ceead  sub rsp, 0xF0
00007aa3a45ceeb4  vmovaps [rsp], xmm0
00007aa3a45ceeb9  vmovaps [rsp+0x10], xmm1
00007aa3a45ceebf  vmovaps [rsp+0x20], xmm2
00007aa3a45ceec5  vmovaps [rsp+0x30], xmm3
00007aa3a45ceecb  vmovaps [rsp+0x40], xmm4
00007aa3a45ceed1  vmovaps [rsp+0x50], xmm5
00007aa3a45ceed7  vmovaps [rsp+0x60], xmm6
00007aa3a45ceedd  vmovaps [rsp+0x70], xmm7
00007aa3a45ceee3  vmovaps [rsp+0x80], xmm8
00007aa3a45ceeec  vmovaps [rsp+0x90], xmm9
00007aa3a45ceef5  vmovaps [rsp+0xA0], xmm10
00007aa3a45ceefe  vmovaps [rsp+0xB0], xmm11
00007aa3a45cef07  vmovaps [rsp+0xC0], xmm12
00007aa3a45cef10  vmovaps [rsp+0xD0], xmm13
00007aa3a45cef19  vmovaps [rsp+0xE0], xmm15
00007aa3a45cef22  sub rsp, 0x30
00007aa3a45cef26  movaps [rsp], xmm14
00007aa3a45cef2b  movaps [rsp+0x10], xmm1
00007aa3a45cef30  movaps [rsp+0x20], xmm15
00007aa3a45cef36  lea rdi, [rsp]
00007aa3a45cef3a  mov esi, 0x00
00007aa3a45cef3f  mov rax, 0x5F551B683530
00007aa3a45cef49  call rax
00007aa3a45cef4b  movaps xmm14, [rsp]
00007aa3a45cef50  add rsp, 0x30
00007aa3a45cef54  vmovaps xmm0, [rsp]
00007aa3a45cef59  vmovaps xmm1, [rsp+0x10]
00007aa3a45cef5f  vmovaps xmm2, [rsp+0x20]
00007aa3a45cef65  vmovaps xmm3, [rsp+0x30]
00007aa3a45cef6b  vmovaps xmm4, [rsp+0x40]
00007aa3a45cef71  vmovaps xmm5, [rsp+0x50]
00007aa3a45cef77  vmovaps xmm6, [rsp+0x60]
00007aa3a45cef7d  vmovaps xmm7, [rsp+0x70]
00007aa3a45cef83  vmovaps xmm8, [rsp+0x80]
00007aa3a45cef8c  vmovaps xmm9, [rsp+0x90]
00007aa3a45cef95  vmovaps xmm10, [rsp+0xA0]
00007aa3a45cef9e  vmovaps xmm11, [rsp+0xB0]
00007aa3a45cefa7  vmovaps xmm12, [rsp+0xC0]
00007aa3a45cefb0  vmovaps xmm13, [rsp+0xD0]
00007aa3a45cefb9  vmovaps xmm15, [rsp+0xE0]
00007aa3a45cefc2  add rsp, 0xF0
00007aa3a45cefc9  pop r11
00007aa3a45cefcb  pop r10
00007aa3a45cefcd  pop r9
00007aa3a45cefcf  pop r8
00007aa3a45cefd1  pop rsi
00007aa3a45cefd2  pop rdi
00007aa3a45cefd3  pop rdx
00007aa3a45cefd4  pop rcx
00007aa3a45cefd5  pop rax
00007aa3a45cefd6  add rsp, 0x08
00007aa3a45cefda  jmp 0x00007AA3A45CECAE
00007aa3a45cefdf  call 0x00007AA3A44C34C0
00007aa3a45cefe4  jmp 0x00007AA3A45CECC4
00007aa3a45cefe9  int3
00007aa3a45cefea  nop [rax+rax*1], ax
00007aa3a45ceff0  mov rax, [r15+0xF8]
00007aa3a45ceff7  lea r14, [rax-0x150]
00007aa3a45ceffe  mov [r15+0xF8], r14
00007aa3a45cf005  mov rax, [r15+0x50]
00007aa3a45cf009  lea r12, [rax+0x80]
00007aa3a45cf010  movups xmm1, [r13+r12*1]
00007aa3a45cf016  lea r12, [rax+0x90]
00007aa3a45cf01d  movups xmm15, [r13+r12*1]
00007aa3a45cf023  mov qword ptr [r15+0x48], 0x00
00007aa3a45cf02b  lea r12, [rax+0x40]
00007aa3a45cf02f  movups xmm14, [r13+r12*1]
00007aa3a45cf035  lea r12, [rax+0x50]
00007aa3a45cf039  movups xmm13, [r13+r12*1]
00007aa3a45cf03f  lea r12, [r14+0x120]
00007aa3a45cf046  movq xmm12, qword ptr [r15+0x1C0]
00007aa3a45cf04f  movq xmm11, qword ptr [r15+0x1B0]
00007aa3a45cf058  movq r11, xmm12
00007aa3a45cf05d  movq r10, xmm11
00007aa3a45cf062  mov [r13+r12*1], r11
00007aa3a45cf067  lea r12, [r14+0x128]
00007aa3a45cf06e  mov [r13+r12*1], r10
00007aa3a45cf073  vxorps xmm12, xmm12, xmm12
00007aa3a45cf078  vpbroadcastq xmm12, xmm12
00007aa3a45cf07d  lea r12, [r14+0x100]
00007aa3a45cf084  movq xmm11, qword ptr [r15+0x200]
00007aa3a45cf08d  movq xmm10, qword ptr [r15+0x1F0]
00007aa3a45cf096  movq r11, xmm11
00007aa3a45cf09b  movq r10, xmm10
00007aa3a45cf0a0  mov [r13+r12*1], r11
00007aa3a45cf0a5  lea r12, [r14+0x108]
00007aa3a45cf0ac  mov [r13+r12*1], r10
00007aa3a45cf0b1  lea r12, [r14+0xE0]
00007aa3a45cf0b8  movups [r13+r12*1], xmm15
00007aa3a45cf0be  lea r12, [r14+0xF0]
00007aa3a45cf0c5  movups [r13+r12*1], xmm1
00007aa3a45cf0cb  lea r12, [rax+0xC0]
00007aa3a45cf0d2  movups xmm1, [r13+r12*1]
00007aa3a45cf0d8  lea r12, [rax+0xD0]
00007aa3a45cf0df  movups xmm15, [r13+r12*1]
00007aa3a45cf0e5  lea r12, [r14+0x110]
00007aa3a45cf0ec  movq xmm11, qword ptr [r15+0x1E0]
00007aa3a45cf0f5  movq xmm10, qword ptr [r15+0x1D0]
00007aa3a45cf0fe  movq r11, xmm11
00007aa3a45cf103  movq r10, xmm10
00007aa3a45cf108  mov [r13+r12*1], r11
00007aa3a45cf10d  lea r12, [r14+0x118]
00007aa3a45cf114  mov [r13+r12*1], r10
00007aa3a45cf119  movups xmm11, [r13+rax*1]
00007aa3a45cf11f  lea r12, [rax+0x10]
00007aa3a45cf123  movups xmm10, [r13+r12*1]
00007aa3a45cf129  lea r12, [r14+0x130]
00007aa3a45cf130  movq xmm9, qword ptr [r15+0x1A0]
00007aa3a45cf139  movq xmm8, qword ptr [r15+0x190]
00007aa3a45cf142  movq r11, xmm9
00007aa3a45cf147  movq r10, xmm8
00007aa3a45cf14c  mov [r13+r12*1], r11
00007aa3a45cf151  lea r12, [r14+0x138]
00007aa3a45cf158  mov [r13+r12*1], r10
00007aa3a45cf15d  lea r12, [rax+0x140]
00007aa3a45cf164  movups xmm9, [r13+r12*1]
00007aa3a45cf16a  lea r12, [rax+0x150]
00007aa3a45cf171  movups xmm8, [r13+r12*1]
00007aa3a45cf177  lea r12, [r14+0xC0]
00007aa3a45cf17e  movups [r13+r12*1], xmm15
00007aa3a45cf184  lea r12, [r14+0xD0]
00007aa3a45cf18b  movups [r13+r12*1], xmm1
00007aa3a45cf191  lea r12, [rax+0x100]
00007aa3a45cf198  movups xmm1, [r13+r12*1]
00007aa3a45cf19e  lea r12, [rax+0x110]
00007aa3a45cf1a5  movups xmm15, [r13+r12*1]
00007aa3a45cf1ab  lea r12, [r14+0x140]
00007aa3a45cf1b2  mov r11, [r15+0xE8]
00007aa3a45cf1b9  mov [r13+r12*1], r11
00007aa3a45cf1be  lea r12, [rax+0x180]
00007aa3a45cf1c5  movups xmm7, [r13+r12*1]
00007aa3a45cf1cb  lea r12, [rax+0x190]
00007aa3a45cf1d2  movups xmm6, [r13+r12*1]
00007aa3a45cf1d8  lea r12, [rax+0x1C0]
00007aa3a45cf1df  movups xmm5, [r13+r12*1]
00007aa3a45cf1e5  lea r12, [rax+0x1D0]
00007aa3a45cf1ec  movups xmm4, [r13+r12*1]
00007aa3a45cf1f2  lea r12, [r14+0x20]
00007aa3a45cf1f6  movups [r13+r12*1], xmm1
00007aa3a45cf1fc  lea r12, [r14+0x30]
00007aa3a45cf200  movups [r13+r12*1], xmm13
00007aa3a45cf206  lea r12, [rax+0x60]
00007aa3a45cf20a  movups xmm1, [r13+r12*1]
00007aa3a45cf210  lea r12, [rax+0x70]
00007aa3a45cf214  movups xmm13, [r13+r12*1]
00007aa3a45cf21a  lea r12, [rax+0x20]
00007aa3a45cf21e  movups xmm3, [r13+r12*1]
00007aa3a45cf224  lea r12, [rax+0x30]
00007aa3a45cf228  movups xmm2, [r13+r12*1]
00007aa3a45cf22e  movaps [r15+0x1F0], xmm2
00007aa3a45cf236  lea r12, [r14+0x60]
00007aa3a45cf23a  movups [r13+r12*1], xmm11
00007aa3a45cf240  lea r12, [r14+0x70]
00007aa3a45cf244  movups [r13+r12*1], xmm5
00007aa3a45cf24a  lea r12, [rax+0xE0]
00007aa3a45cf251  movups xmm11, [r13+r12*1]
00007aa3a45cf257  lea r12, [rax+0xF0]
00007aa3a45cf25e  movups xmm5, [r13+r12*1]
00007aa3a45cf264  lea r12, [r14+0xA0]
00007aa3a45cf26b  movups [r13+r12*1], xmm13
00007aa3a45cf271  lea r12, [r14+0xB0]
00007aa3a45cf278  movups [r13+r12*1], xmm1
00007aa3a45cf27e  lea r12, [rax+0xA0]
00007aa3a45cf285  movups xmm1, [r13+r12*1]
00007aa3a45cf28b  lea r12, [rax+0xB0]
00007aa3a45cf292  movups xmm13, [r13+r12*1]
00007aa3a45cf298  lea r12, [rax+0x120]
00007aa3a45cf29f  vmovaps [rsp+0x10], xmm1
00007aa3a45cf2a5  movups xmm1, [r13+r12*1]
00007aa3a45cf2ab  lea r12, [rax+0x130]
00007aa3a45cf2b2  vmovaps [rsp+0x20], xmm1
00007aa3a45cf2b8  movups xmm1, [r13+r12*1]
00007aa3a45cf2be  lea r12, [rax+0x160]
00007aa3a45cf2c5  vmovaps [rsp+0x30], xmm1
00007aa3a45cf2cb  movups xmm1, [r13+r12*1]
00007aa3a45cf2d1  lea r12, [rax+0x170]
00007aa3a45cf2d8  vmovaps [rsp+0x40], xmm1
00007aa3a45cf2de  movups xmm1, [r13+r12*1]
00007aa3a45cf2e4  movaps [r15+0x2B0], xmm1
00007aa3a45cf2ec  lea r12, [r14+0x80]
00007aa3a45cf2f3  movups [r13+r12*1], xmm13
00007aa3a45cf2f9  lea r12, [r14+0x90]
00007aa3a45cf300  vmovaps xmm13, [rsp+0x10]
00007aa3a45cf306  movups [r13+r12*1], xmm13
00007aa3a45cf30c  lea r12, [rax+0x1A0]
00007aa3a45cf313  movups xmm13, [r13+r12*1]
00007aa3a45cf319  lea r12, [rax+0x1B0]
00007aa3a45cf320  vmovaps [rsp+0x10], xmm1
00007aa3a45cf326  movups xmm1, [r13+r12*1]
00007aa3a45cf32c  movaps [r15+0x290], xmm13
00007aa3a45cf334  movaps [r15+0x1E0], xmm1
00007aa3a45cf33c  lea r12, [rax+0x1E0]
00007aa3a45cf343  vmovaps [rsp+0x50], xmm1
00007aa3a45cf349  movups xmm1, [r13+r12*1]
00007aa3a45cf34f  lea r12, [rax+0x1F0]
00007aa3a45cf356  vmovaps [rsp+0x60], xmm1
00007aa3a45cf35c  movups xmm1, [r13+r12*1]
00007aa3a45cf362  mov qword ptr [r15+0x50], 0x430920
00007aa3a45cf36a  lea rax, [r14+0x40]
00007aa3a45cf36e  vmovaps [rsp+0x70], xmm1
00007aa3a45cf374  vmovaps xmm1, [rsp+0x40]
00007aa3a45cf37a  movups [r13+rax*1], xmm1
00007aa3a45cf380  lea rax, [r14+0x50]
00007aa3a45cf384  movups [r13+rax*1], xmm10
00007aa3a45cf38a  vmovaps xmm1, [rsp+0x70]
00007aa3a45cf390  movups [r13+r14*1], xmm1
00007aa3a45cf396  lea rax, [r14+0x10]
00007aa3a45cf39a  vmovaps xmm1, [rsp+0x60]
00007aa3a45cf3a0  movups [r13+rax*1], xmm1
00007aa3a45cf3a6  mov rax, [r15+0x40]
00007aa3a45cf3aa  vmovaps [rsp+0x40], xmm3
00007aa3a45cf3b0  vmovaps xmm1, [rsp+0x40]
00007aa3a45cf3b6  por xmm3, xmm1
00007aa3a45cf3ba  vmovaps [rsp+0x40], xmm6
00007aa3a45cf3c0  vmovaps xmm10, [rsp+0x40]
00007aa3a45cf3c6  por xmm6, xmm10
00007aa3a45cf3cb  lea r12, [rax+0x30]
00007aa3a45cf3cf  mov r11, [r13+r12*1]
00007aa3a45cf3d4  lea r12, [rax+0x38]
00007aa3a45cf3d8  mov r10, [r13+r12*1]
00007aa3a45cf3dd  movq xmm10, r11
00007aa3a45cf3e2  vmovaps [rsp+0x40], xmm1
00007aa3a45cf3e8  movq xmm1, r10
00007aa3a45cf3ed  movq xmm10, xmm10
00007aa3a45cf3f2  vmovaps [rsp+0x60], xmm10
00007aa3a45cf3f8  movq xmm10, xmm10
00007aa3a45cf3fd  movaps [r15+0x130], xmm10
00007aa3a45cf405  movq xmm1, xmm1
00007aa3a45cf409  vmovaps [rsp+0x70], xmm1
00007aa3a45cf40f  movq xmm1, xmm1
00007aa3a45cf413  movaps [r15+0x280], xmm1
00007aa3a45cf41b  vmovaps [rsp+0x80], xmm9
00007aa3a45cf424  vmovaps xmm1, [rsp+0x80]
00007aa3a45cf42d  por xmm9, xmm1
00007aa3a45cf432  lea r12, [rax+0x20]
00007aa3a45cf436  mov r11, [r13+r12*1]
00007aa3a45cf43b  lea r12, [rax+0x28]
00007aa3a45cf43f  mov r10, [r13+r12*1]
00007aa3a45cf444  movq xmm1, r11
00007aa3a45cf449  movq xmm10, r10
00007aa3a45cf44e  movq xmm1, xmm1
00007aa3a45cf452  vmovaps [rsp+0x80], xmm1
00007aa3a45cf45b  movq xmm1, xmm1
00007aa3a45cf45f  movaps [r15+0x150], xmm1
00007aa3a45cf467  movq xmm10, xmm10
00007aa3a45cf46c  vmovaps [rsp+0x90], xmm10
00007aa3a45cf475  movq xmm10, xmm10
00007aa3a45cf47a  movaps [r15+0x140], xmm10
00007aa3a45cf482  lea r12, [rax+0x10]
00007aa3a45cf486  mov r11, [r13+r12*1]
00007aa3a45cf48b  lea r12, [rax+0x18]
00007aa3a45cf48f  mov r10, [r13+r12*1]
00007aa3a45cf494  movq xmm1, r11
00007aa3a45cf499  movq xmm10, r10
00007aa3a45cf49e  movq xmm1, xmm1
00007aa3a45cf4a2  vmovaps [rsp+0xA0], xmm1
00007aa3a45cf4ab  movq xmm1, xmm1
00007aa3a45cf4af  movaps [r15+0x170], xmm1
00007aa3a45cf4b7  movq xmm10, xmm10
00007aa3a45cf4bc  vmovaps [rsp+0xB0], xmm10
00007aa3a45cf4c5  movq xmm10, xmm10
00007aa3a45cf4ca  movaps [r15+0x160], xmm10
00007aa3a45cf4d2  mov r12, [r13+rax*1]
00007aa3a45cf4d7  vmovq xmm1, r12
00007aa3a45cf4dc  vpbroadcastq xmm1, xmm1
00007aa3a45cf4e1  lea r12, [rax+0x08]
00007aa3a45cf4e5  mov rax, [r13+r12*1]
00007aa3a45cf4ea  movq xmm10, rax
00007aa3a45cf4ef  movaps [r15+0x230], xmm10
00007aa3a45cf4f7  lea rax, [r14+0x50]
00007aa3a45cf4fb  movups xmm10, [r13+rax*1]
00007aa3a45cf501  lea rax, [r14+0x60]
00007aa3a45cf505  vmovaps [rsp+0xC0], xmm1
00007aa3a45cf50e  movups xmm1, [r13+rax*1]
00007aa3a45cf514  lea rax, [r14+0x30]
00007aa3a45cf518  vmovaps [rsp+0xD0], xmm1
00007aa3a45cf521  movups xmm1, [r13+rax*1]
00007aa3a45cf527  mov qword ptr [r15+0x60], 0x430920
00007aa3a45cf52f  mov qword ptr [r15+0x58], 0x40
00007aa3a45cf537  vmovaps [rsp+0xE0], xmm1
00007aa3a45cf540  vmovaps [rsp+0xF0], xmm15
00007aa3a45cf549  vmovaps xmm15, [rsp+0xC0]
00007aa3a45cf552  vmovaps [rsp+0xC0], xmm14
00007aa3a45cf55b  vmovaps xmm14, [rsp+0x40]
00007aa3a45cf561  vmovaps [rsp+0x40], xmm13
00007aa3a45cf567  movaps xmm1, xmm15
00007aa3a45cf56b  mulpd xmm1, xmm14
00007aa3a45cf570  vcmppd xmm13, xmm1, xmm1, 0x03
00007aa3a45cf575  ptest xmm13, xmm13
00007aa3a45cf57b  jnz 0x00007AA3A45D0682
00007aa3a45cf581  movq xmm14, qword ptr [r15+0x230]
00007aa3a45cf58a  vmovaps [rsp+0x100], xmm14
00007aa3a45cf593  vpermilpd xmm14, xmm14, 0x00
00007aa3a45cf599  vmovaps [rsp+0x110], xmm1
00007aa3a45cf5a2  vmovaps xmm1, [rsp+0xE0]
00007aa3a45cf5ab  vmovaps [rsp+0xE0], xmm15
00007aa3a45cf5b4  movaps xmm13, xmm1
00007aa3a45cf5b8  mulpd xmm13, xmm14
00007aa3a45cf5bd  vcmppd xmm15, xmm13, xmm13, 0x03
00007aa3a45cf5c3  ptest xmm15, xmm15
00007aa3a45cf5c9  jnz 0x00007AA3A45D07C4
00007aa3a45cf5cf  vxorps xmm1, xmm1, xmm1
00007aa3a45cf5d3  vpbroadcastq xmm1, xmm1
00007aa3a45cf5d8  vmovaps xmm14, [rsp+0xE0]
00007aa3a45cf5e1  vmovaps [rsp+0xE0], xmm1
00007aa3a45cf5ea  vmovaps xmm1, [rsp+0xD0]
00007aa3a45cf5f3  vmovaps [rsp+0xD0], xmm13
00007aa3a45cf5fc  movaps xmm15, xmm14
00007aa3a45cf600  mulpd xmm15, xmm1
00007aa3a45cf605  vcmppd xmm13, xmm15, xmm15, 0x03
00007aa3a45cf60b  ptest xmm13, xmm13
00007aa3a45cf611  jnz 0x00007AA3A45D0907
00007aa3a45cf617  movaps xmm1, xmm14
00007aa3a45cf61b  mulpd xmm1, xmm10
00007aa3a45cf620  vcmppd xmm13, xmm1, xmm1, 0x03
00007aa3a45cf625  ptest xmm13, xmm13
00007aa3a45cf62b  jnz 0x00007AA3A45D0A4A
00007aa3a45cf631  movaps xmm13, xmm14
00007aa3a45cf635  mulpd xmm13, xmm2
00007aa3a45cf63a  vcmppd xmm10, xmm13, xmm13, 0x03
00007aa3a45cf640  ptest xmm10, xmm10
00007aa3a45cf646  jnz 0x00007AA3A45D0B8C
00007aa3a45cf64c  vmovaps [rsp+0x120], xmm7
00007aa3a45cf655  vmovaps xmm14, [rsp+0x120]
00007aa3a45cf65e  por xmm7, xmm14
00007aa3a45cf663  vmovaps xmm14, [rsp+0xC0]
00007aa3a45cf66c  vmovaps xmm10, [rsp+0xC0]
00007aa3a45cf675  por xmm14, xmm10
00007aa3a45cf67a  vmovaps xmm2, [rsp+0x100]
00007aa3a45cf683  vpermilpd xmm2, xmm2, 0x00
00007aa3a45cf689  vmovaps [rsp+0xC0], xmm1
00007aa3a45cf692  vmovaps [rsp+0x120], xmm15
00007aa3a45cf69b  movaps xmm1, xmm10
00007aa3a45cf69f  mulpd xmm1, xmm2
00007aa3a45cf6a3  vcmppd xmm15, xmm1, xmm1, 0x03
00007aa3a45cf6a8  ptest xmm15, xmm15
00007aa3a45cf6ae  jnz 0x00007AA3A45D0CCF
00007aa3a45cf6b4  xor eax, eax
00007aa3a45cf6b6  mov r12d, 0x40
00007aa3a45cf6bc  mov r11d, 0x200
00007aa3a45cf6c2  cmp r12, r11
00007aa3a45cf6c5  cmc
00007aa3a45cf6c6  lahf
00007aa3a45cf6c7  seto al
00007aa3a45cf6ca  mov [r15+0x108], eax
00007aa3a45cf6d1  vmovaps xmm10, [rsp+0x110]
00007aa3a45cf6da  vmovaps xmm2, [rsp+0xE0]
00007aa3a45cf6e3  vmovaps [rsp+0xE0], xmm1
00007aa3a45cf6ec  movaps xmm15, xmm10
00007aa3a45cf6f0  addpd xmm15, xmm2
00007aa3a45cf6f5  vcmppd xmm1, xmm15, xmm15, 0x03
00007aa3a45cf6fb  ptest xmm1, xmm1
00007aa3a45cf700  jnz 0x00007AA3A45D0E10
00007aa3a45cf706  vmovaps xmm10, [rsp+0x120]
00007aa3a45cf70f  vmovaps [rsp+0x110], xmm15
00007aa3a45cf718  movaps xmm1, xmm10
00007aa3a45cf71c  addpd xmm1, xmm12
00007aa3a45cf721  vcmppd xmm15, xmm1, xmm1, 0x03
00007aa3a45cf726  ptest xmm15, xmm15
00007aa3a45cf72c  jnz 0x00007AA3A45D0F53
00007aa3a45cf732  vmovaps xmm10, [rsp+0xC0]
00007aa3a45cf73b  vmovaps [rsp+0xC0], xmm1
00007aa3a45cf744  movaps xmm15, xmm10
00007aa3a45cf748  addpd xmm15, xmm12
00007aa3a45cf74d  vcmppd xmm1, xmm15, xmm15, 0x03
00007aa3a45cf753  ptest xmm1, xmm1
00007aa3a45cf758  jnz 0x00007AA3A45D1095
00007aa3a45cf75e  vmovaps xmm1, [rsp+0x30]
00007aa3a45cf764  vmovaps xmm12, [rsp+0x30]
00007aa3a45cf76a  por xmm1, xmm12
00007aa3a45cf76f  vmovaps xmm12, [rsp+0x20]
00007aa3a45cf775  vmovaps xmm10, [rsp+0x20]
00007aa3a45cf77b  por xmm12, xmm10
00007aa3a45cf780  vmovaps [rsp+0x20], xmm5
00007aa3a45cf786  vmovaps xmm10, [rsp+0x20]
00007aa3a45cf78c  por xmm5, xmm10
00007aa3a45cf791  vmovaps [rsp+0x20], xmm11
00007aa3a45cf797  vmovaps xmm10, [rsp+0x20]
00007aa3a45cf79d  por xmm11, xmm10
00007aa3a45cf7a2  vmovaps [rsp+0x20], xmm4
00007aa3a45cf7a8  vmovaps xmm10, [rsp+0x20]
00007aa3a45cf7ae  por xmm4, xmm10
00007aa3a45cf7b3  vmovaps [rsp+0x20], xmm8
00007aa3a45cf7b9  vmovaps xmm10, [rsp+0x20]
00007aa3a45cf7bf  por xmm8, xmm10
00007aa3a45cf7c4  vmovaps xmm10, [rsp+0xF0]
00007aa3a45cf7cd  vmovaps [rsp+0x20], xmm1
00007aa3a45cf7d3  vmovaps xmm1, [rsp+0xF0]
00007aa3a45cf7dc  por xmm10, xmm1
00007aa3a45cf7e1  lea rax, [r14+0xA0]
00007aa3a45cf7e8  movups xmm1, [r13+rax*1]
00007aa3a45cf7ee  lea rax, [r14+0xB0]
00007aa3a45cf7f5  vmovaps [rsp+0x30], xmm1
00007aa3a45cf7fb  movups xmm1, [r13+rax*1]
00007aa3a45cf801  vmovaps [rsp+0xF0], xmm1
00007aa3a45cf80a  vmovaps [rsp+0x120], xmm15
00007aa3a45cf813  movaps xmm1, xmm13
00007aa3a45cf817  addpd xmm1, xmm2
00007aa3a45cf81b  vcmppd xmm15, xmm1, xmm1, 0x03
00007aa3a45cf820  ptest xmm15, xmm15
00007aa3a45cf826  jnz 0x00007AA3A45D11ED
00007aa3a45cf82c  lea rax, [r14+0xF0]
00007aa3a45cf833  movups xmm15, [r13+rax*1]
00007aa3a45cf839  vmovaps xmm2, [rsp+0xC0]
00007aa3a45cf842  vmovaps [rsp+0xC0], xmm1
00007aa3a45cf84b  vmovaps xmm1, [rsp+0xE0]
00007aa3a45cf854  vmovaps [rsp+0xE0], xmm15
00007aa3a45cf85d  movaps xmm13, xmm2
00007aa3a45cf861  addpd xmm13, xmm1
00007aa3a45cf866  vcmppd xmm15, xmm13, xmm13, 0x03
00007aa3a45cf86c  ptest xmm15, xmm15
00007aa3a45cf872  jnz 0x00007AA3A45D1338
00007aa3a45cf878  vmovaps xmm15, [rsp+0x120]
00007aa3a45cf881  vmovaps xmm2, [rsp+0xD0]
00007aa3a45cf88a  vmovaps [rsp+0xD0], xmm14
00007aa3a45cf893  movaps xmm1, xmm15
00007aa3a45cf897  addpd xmm1, xmm2
00007aa3a45cf89b  vcmppd xmm14, xmm1, xmm1, 0x03
00007aa3a45cf8a0  ptest xmm14, xmm14
00007aa3a45cf8a6  jnz 0x00007AA3A45D147A
00007aa3a45cf8ac  vmovaps xmm15, [rsp+0x100]
00007aa3a45cf8b5  vpermilpd xmm15, xmm15, 0x00
00007aa3a45cf8bb  vmovaps xmm2, [rsp+0xF0]
00007aa3a45cf8c4  vmovaps [rsp+0xF0], xmm1
00007aa3a45cf8cd  movaps xmm14, xmm2
00007aa3a45cf8d1  mulpd xmm14, xmm15
00007aa3a45cf8d6  vcmppd xmm1, xmm14, xmm14, 0x03
00007aa3a45cf8dc  ptest xmm1, xmm1
00007aa3a45cf8e1  jnz 0x00007AA3A45D15BB
00007aa3a45cf8e7  vmovaps xmm1, [rsp+0xA0]
00007aa3a45cf8f0  vpermilpd xmm1, xmm1, 0x00
00007aa3a45cf8f6  vmovaps xmm2, [rsp+0xE0]
00007aa3a45cf8ff  vmovaps [rsp+0xE0], xmm14
00007aa3a45cf908  movaps xmm15, xmm2
00007aa3a45cf90c  mulpd xmm15, xmm1
00007aa3a45cf911  vcmppd xmm14, xmm15, xmm15, 0x03
00007aa3a45cf917  ptest xmm14, xmm14
00007aa3a45cf91d  jnz 0x00007AA3A45D16FE
00007aa3a45cf923  lea rax, [r14+0xE0]
00007aa3a45cf92a  movups xmm1, [r13+rax*1]
00007aa3a45cf930  vmovaps xmm14, [rsp+0x100]
00007aa3a45cf939  vpermilpd xmm14, xmm14, 0x00
00007aa3a45cf93f  vmovaps [rsp+0x100], xmm1
00007aa3a45cf948  vmovaps xmm1, [rsp+0x30]
00007aa3a45cf94e  vmovaps [rsp+0x30], xmm15
00007aa3a45cf954  movaps xmm2, xmm1
00007aa3a45cf957  mulpd xmm2, xmm14
00007aa3a45cf95c  vcmppd xmm15, xmm2, xmm2, 0x03
00007aa3a45cf961  ptest xmm15, xmm15
00007aa3a45cf967  jnz 0x00007AA3A45D184A
00007aa3a45cf96d  vmovaps [rsp+0x120], xmm10
00007aa3a45cf976  vmovaps xmm1, [rsp+0x120]
00007aa3a45cf97f  por xmm10, xmm1
00007aa3a45cf984  movaps [r15+0x300], xmm10
00007aa3a45cf98c  vmovaps [rsp+0x120], xmm8
00007aa3a45cf995  vmovaps xmm1, [rsp+0x120]
00007aa3a45cf99e  por xmm8, xmm1
00007aa3a45cf9a3  movaps [r15+0x190], xmm8
00007aa3a45cf9ab  vmovaps xmm1, [rsp+0xA0]
00007aa3a45cf9b4  vpermilpd xmm1, xmm1, 0x00
00007aa3a45cf9ba  vmovaps xmm14, [rsp+0x100]
00007aa3a45cf9c3  vmovaps [rsp+0x100], xmm13
00007aa3a45cf9cc  movaps xmm15, xmm14
00007aa3a45cf9d0  mulpd xmm15, xmm1
00007aa3a45cf9d5  vcmppd xmm13, xmm15, xmm15, 0x03
00007aa3a45cf9db  ptest xmm13, xmm13
00007aa3a45cf9e1  jnz 0x00007AA3A45D198B
00007aa3a45cf9e7  lea rax, [r14+0x90]
00007aa3a45cf9ee  movups xmm1, [r13+rax*1]
00007aa3a45cf9f4  vmovaps [rsp+0x120], xmm4
00007aa3a45cf9fd  vmovaps xmm14, [rsp+0x120]
00007aa3a45cfa06  por xmm4, xmm14
00007aa3a45cfa0b  movaps [r15+0x1C0], xmm4
00007aa3a45cfa13  vmovaps [rsp+0x120], xmm11
00007aa3a45cfa1c  vmovaps xmm14, [rsp+0x120]
00007aa3a45cfa25  por xmm11, xmm14
00007aa3a45cfa2a  movaps [r15+0x200], xmm11
00007aa3a45cfa32  vmovaps [rsp+0x120], xmm5
00007aa3a45cfa3b  vmovaps xmm14, [rsp+0x120]
00007aa3a45cfa44  por xmm5, xmm14
00007aa3a45cfa49  movaps [r15+0x2D0], xmm5
00007aa3a45cfa51  vmovaps [rsp+0x120], xmm12
00007aa3a45cfa5a  vmovaps xmm14, [rsp+0x120]
00007aa3a45cfa63  por xmm12, xmm14
00007aa3a45cfa68  movaps [r15+0x2E0], xmm12
00007aa3a45cfa70  vmovaps xmm13, [rsp+0x110]
00007aa3a45cfa79  vmovaps [rsp+0x110], xmm1
00007aa3a45cfa82  vmovaps xmm1, [rsp+0xE0]
00007aa3a45cfa8b  vmovaps [rsp+0xE0], xmm15
00007aa3a45cfa94  movaps xmm14, xmm13
00007aa3a45cfa98  addpd xmm14, xmm1
00007aa3a45cfa9d  vcmppd xmm15, xmm14, xmm14, 0x03
00007aa3a45cfaa3  ptest xmm15, xmm15
00007aa3a45cfaa9  jnz 0x00007AA3A45D1AD8
00007aa3a45cfaaf  vmovaps xmm1, [rsp+0xA0]
00007aa3a45cfab8  vpermilpd xmm1, xmm1, 0x00
00007aa3a45cfabe  vmovaps xmm13, [rsp+0x110]
00007aa3a45cfac7  vmovaps [rsp+0x110], xmm14
00007aa3a45cfad0  movaps xmm15, xmm13
00007aa3a45cfad4  mulpd xmm15, xmm1
00007aa3a45cfad9  vcmppd xmm14, xmm15, xmm15, 0x03
00007aa3a45cfadf  ptest xmm14, xmm14
00007aa3a45cfae5  jnz 0x00007AA3A45D1C1B
00007aa3a45cfaeb  lea rax, [r14+0x80]
00007aa3a45cfaf2  movups xmm1, [r13+rax*1]
00007aa3a45cfaf8  vmovaps xmm13, [rsp+0xC0]
00007aa3a45cfb01  vmovaps [rsp+0xC0], xmm1
00007aa3a45cfb0a  movaps xmm14, xmm13
00007aa3a45cfb0e  addpd xmm14, xmm2
00007aa3a45cfb13  vcmppd xmm1, xmm14, xmm14, 0x03
00007aa3a45cfb19  ptest xmm1, xmm1
00007aa3a45cfb1e  jnz 0x00007AA3A45D1D68
00007aa3a45cfb24  vmovaps xmm13, [rsp+0x100]
00007aa3a45cfb2d  vmovaps xmm2, [rsp+0x30]
00007aa3a45cfb33  vmovaps [rsp+0x30], xmm15
00007aa3a45cfb39  movaps xmm1, xmm13
00007aa3a45cfb3d  addpd xmm1, xmm2
00007aa3a45cfb41  vcmppd xmm15, xmm1, xmm1, 0x03
00007aa3a45cfb46  ptest xmm15, xmm15
00007aa3a45cfb4c  jnz 0x00007AA3A45D1EAB
00007aa3a45cfb52  vmovaps xmm15, [rsp+0x20]
00007aa3a45cfb58  vmovaps xmm13, [rsp+0x20]
00007aa3a45cfb5e  por xmm15, xmm13
00007aa3a45cfb63  movaps [r15+0x2F0], xmm15
00007aa3a45cfb6b  vmovaps xmm13, [rsp+0xA0]
00007aa3a45cfb74  vpermilpd xmm13, xmm13, 0x00
00007aa3a45cfb7a  vmovaps [rsp+0x20], xmm1
00007aa3a45cfb80  vmovaps xmm1, [rsp+0xC0]
00007aa3a45cfb89  vmovaps [rsp+0xA0], xmm15
00007aa3a45cfb92  movaps xmm2, xmm1
00007aa3a45cfb95  mulpd xmm2, xmm13
00007aa3a45cfb9a  vcmppd xmm15, xmm2, xmm2, 0x03
00007aa3a45cfb9f  ptest xmm15, xmm15
00007aa3a45cfba5  jnz 0x00007AA3A45D1FEC
00007aa3a45cfbab  lea rax, [r14+0xD0]
00007aa3a45cfbb2  movups xmm1, [r13+rax*1]
00007aa3a45cfbb8  vmovaps xmm13, [rsp+0xF0]
00007aa3a45cfbc1  vmovaps [rsp+0xC0], xmm1
00007aa3a45cfbca  vmovaps xmm1, [rsp+0xE0]
00007aa3a45cfbd3  vmovaps [rsp+0xE0], xmm14
00007aa3a45cfbdc  movaps xmm15, xmm13
00007aa3a45cfbe0  addpd xmm15, xmm1
00007aa3a45cfbe5  vcmppd xmm14, xmm15, xmm15, 0x03
00007aa3a45cfbeb  ptest xmm14, xmm14
00007aa3a45cfbf1  jnz 0x00007AA3A45D2137
00007aa3a45cfbf7  vmovaps xmm1, [rsp+0xB0]
00007aa3a45cfc00  vpermilpd xmm1, xmm1, 0x00
00007aa3a45cfc06  movaps xmm14, xmm11
00007aa3a45cfc0a  mulpd xmm14, xmm1
00007aa3a45cfc0f  vcmppd xmm13, xmm14, xmm14, 0x03
00007aa3a45cfc15  ptest xmm13, xmm13
00007aa3a45cfc1b  jnz 0x00007AA3A45D227A
00007aa3a45cfc21  movaps [r15+0x260], xmm14
00007aa3a45cfc29  vxorps xmm1, xmm1, xmm1
00007aa3a45cfc2d  vpbroadcastq xmm1, xmm1
00007aa3a45cfc32  movaps [r15+0x1B0], xmm1
00007aa3a45cfc3a  vmovaps xmm1, [rsp+0xB0]
00007aa3a45cfc43  vpermilpd xmm1, xmm1, 0x00
00007aa3a45cfc49  vmovaps xmm11, [rsp+0xC0]
00007aa3a45cfc52  vmovaps [rsp+0xC0], xmm15
00007aa3a45cfc5b  movaps xmm13, xmm11
00007aa3a45cfc5f  mulpd xmm13, xmm1
00007aa3a45cfc64  vcmppd xmm15, xmm13, xmm13, 0x03
00007aa3a45cfc6a  ptest xmm15, xmm15
00007aa3a45cfc70  jnz 0x00007AA3A45D23BD
00007aa3a45cfc76  lea rax, [r14+0xC0]
00007aa3a45cfc7d  movups xmm1, [r13+rax*1]
00007aa3a45cfc83  vmovaps xmm11, [rsp+0x110]
00007aa3a45cfc8c  vmovaps [rsp+0xF0], xmm1
00007aa3a45cfc95  vmovaps xmm1, [rsp+0x30]
00007aa3a45cfc9b  vmovaps [rsp+0x30], xmm14
00007aa3a45cfca1  movaps xmm15, xmm11
00007aa3a45cfca5  addpd xmm15, xmm1
00007aa3a45cfcaa  vcmppd xmm14, xmm15, xmm15, 0x03
00007aa3a45cfcb0  ptest xmm14, xmm14
00007aa3a45cfcb6  jnz 0x00007AA3A45D250A
00007aa3a45cfcbc  vmovaps [rsp+0x100], xmm9
00007aa3a45cfcc5  vmovaps xmm1, [rsp+0x100]
00007aa3a45cfcce  por xmm9, xmm1
00007aa3a45cfcd3  movaps [r15+0x270], xmm9
00007aa3a45cfcdb  vmovaps [rsp+0x100], xmm6
00007aa3a45cfce4  vmovaps xmm1, [rsp+0x100]
00007aa3a45cfced  por xmm6, xmm1
00007aa3a45cfcf1  movaps [r15+0x1A0], xmm6
00007aa3a45cfcf9  vmovaps xmm14, [rsp+0xB0]
00007aa3a45cfd02  vpermilpd xmm14, xmm14, 0x00
00007aa3a45cfd08  vmovaps xmm6, [rsp+0xF0]
00007aa3a45cfd11  vmovaps [rsp+0xF0], xmm1
00007aa3a45cfd1a  movaps xmm11, xmm6
00007aa3a45cfd1e  mulpd xmm11, xmm14
00007aa3a45cfd23  vcmppd xmm1, xmm11, xmm11, 0x03
00007aa3a45cfd29  ptest xmm1, xmm1
00007aa3a45cfd2e  jnz 0x00007AA3A45D264D
00007aa3a45cfd34  lea rax, [r14+0x20]
00007aa3a45cfd38  movups xmm1, [r13+rax*1]
00007aa3a45cfd3e  movaps [r15+0x110], xmm1
00007aa3a45cfd46  vmovaps xmm6, [rsp+0xE0]
00007aa3a45cfd4f  vmovaps [rsp+0xE0], xmm1
00007aa3a45cfd58  movaps xmm14, xmm6
00007aa3a45cfd5c  addpd xmm14, xmm2
00007aa3a45cfd61  vcmppd xmm1, xmm14, xmm14, 0x03
00007aa3a45cfd67  ptest xmm1, xmm1
00007aa3a45cfd6c  jnz 0x00007AA3A45D279A
00007aa3a45cfd72  vmovaps xmm1, [rsp+0xB0]
00007aa3a45cfd7b  vpermilpd xmm1, xmm1, 0x00
00007aa3a45cfd81  movaps xmm6, xmm5
00007aa3a45cfd84  mulpd xmm6, xmm1
00007aa3a45cfd88  vcmppd xmm2, xmm6, xmm6, 0x03
00007aa3a45cfd8d  ptest xmm2, xmm2
00007aa3a45cfd92  jnz 0x00007AA3A45D28DC
00007aa3a45cfd98  vmovaps xmm5, [rsp+0x20]
00007aa3a45cfd9e  movaps xmm1, xmm5
00007aa3a45cfda1  addpd xmm1, xmm13
00007aa3a45cfda6  vcmppd xmm2, xmm1, xmm1, 0x03
00007aa3a45cfdab  ptest xmm2, xmm2
00007aa3a45cfdb0  jnz 0x00007AA3A45D2A1C
00007aa3a45cfdb6  vmovaps xmm13, [rsp+0x80]
00007aa3a45cfdbf  vpermilpd xmm13, xmm13, 0x00
00007aa3a45cfdc5  vmovaps xmm2, [rsp+0xE0]
00007aa3a45cfdce  vmovaps [rsp+0x20], xmm1
00007aa3a45cfdd4  movaps xmm5, xmm2
00007aa3a45cfdd7  mulpd xmm5, xmm13
00007aa3a45cfddc  vcmppd xmm1, xmm5, xmm5, 0x03
00007aa3a45cfde1  ptest xmm1, xmm1
00007aa3a45cfde6  jnz 0x00007AA3A45D2B5D
00007aa3a45cfdec  vmovaps xmm1, [rsp+0x80]
00007aa3a45cfdf5  vpermilpd xmm1, xmm1, 0x00
00007aa3a45cfdfb  movaps xmm13, xmm10
00007aa3a45cfdff  mulpd xmm13, xmm1
00007aa3a45cfe04  vcmppd xmm2, xmm13, xmm13, 0x03
00007aa3a45cfe0a  ptest xmm2, xmm2
00007aa3a45cfe0f  jnz 0x00007AA3A45D2C9E
00007aa3a45cfe15  vmovaps xmm10, [rsp+0x30]
00007aa3a45cfe1b  movaps xmm1, xmm15
00007aa3a45cfe1f  addpd xmm1, xmm10
00007aa3a45cfe24  vcmppd xmm2, xmm1, xmm1, 0x03
00007aa3a45cfe29  ptest xmm2, xmm2
00007aa3a45cfe2e  jnz 0x00007AA3A45D2DE1
00007aa3a45cfe34  vmovaps xmm10, [rsp+0xC0]
00007aa3a45cfe3d  movaps xmm15, xmm10
00007aa3a45cfe41  addpd xmm15, xmm11
00007aa3a45cfe46  vcmppd xmm2, xmm15, xmm15, 0x03
00007aa3a45cfe4c  ptest xmm2, xmm2
00007aa3a45cfe51  jnz 0x00007AA3A45D2F23
00007aa3a45cfe57  vmovaps xmm11, [rsp+0x80]
00007aa3a45cfe60  vpermilpd xmm11, xmm11, 0x00
00007aa3a45cfe66  movaps xmm10, xmm12
00007aa3a45cfe6a  mulpd xmm10, xmm11
00007aa3a45cfe6f  vcmppd xmm2, xmm10, xmm10, 0x03
00007aa3a45cfe75  ptest xmm2, xmm2
00007aa3a45cfe7a  jnz 0x00007AA3A45D3067
00007aa3a45cfe80  vmovaps xmm12, [rsp+0x80]
00007aa3a45cfe89  vpermilpd xmm12, xmm12, 0x00
00007aa3a45cfe8f  vmovaps xmm2, [rsp+0xA0]
00007aa3a45cfe98  vmovaps [rsp+0x30], xmm1
00007aa3a45cfe9e  movaps xmm11, xmm2
00007aa3a45cfea2  mulpd xmm11, xmm12
00007aa3a45cfea7  vcmppd xmm1, xmm11, xmm11, 0x03
00007aa3a45cfead  ptest xmm1, xmm1
00007aa3a45cfeb2  jnz 0x00007AA3A45D31AB
00007aa3a45cfeb8  movaps xmm1, xmm14
00007aa3a45cfebc  addpd xmm1, xmm6
00007aa3a45cfec0  vcmppd xmm12, xmm1, xmm1, 0x03
00007aa3a45cfec5  ptest xmm12, xmm12
00007aa3a45cfecb  jnz 0x00007AA3A45D32EE
00007aa3a45cfed1  vmovaps xmm12, [rsp+0x20]
00007aa3a45cfed7  movaps xmm14, xmm12
00007aa3a45cfedb  addpd xmm14, xmm5
00007aa3a45cfee0  vcmppd xmm6, xmm14, xmm14, 0x03
00007aa3a45cfee6  ptest xmm6, xmm6
00007aa3a45cfeeb  jnz 0x00007AA3A45D342F
00007aa3a45cfef1  vmovaps xmm12, [rsp+0x90]
00007aa3a45cfefa  vpermilpd xmm12, xmm12, 0x00
00007aa3a45cff00  movaps xmm6, xmm9
00007aa3a45cff04  mulpd xmm6, xmm12
00007aa3a45cff09  vcmppd xmm5, xmm6, xmm6, 0x03
00007aa3a45cff0e  ptest xmm5, xmm5
00007aa3a45cff13  jnz 0x00007AA3A45D3572
00007aa3a45cff19  movaps xmm12, xmm15
00007aa3a45cff1d  addpd xmm12, xmm13
00007aa3a45cff22  vcmppd xmm9, xmm12, xmm12, 0x03
00007aa3a45cff28  ptest xmm9, xmm9
00007aa3a45cff2e  jnz 0x00007AA3A45D36B4
00007aa3a45cff34  vmovaps xmm13, [rsp+0x30]
00007aa3a45cff3a  movaps xmm15, xmm13
00007aa3a45cff3e  addpd xmm15, xmm10
00007aa3a45cff43  vcmppd xmm9, xmm15, xmm15, 0x03
00007aa3a45cff49  ptest xmm9, xmm9
00007aa3a45cff4f  jnz 0x00007AA3A45D37F8
00007aa3a45cff55  vmovaps xmm13, [rsp+0xD0]
00007aa3a45cff5e  vmovaps xmm10, [rsp+0xD0]
00007aa3a45cff67  por xmm13, xmm10
00007aa3a45cff6c  movaps [r15+0x250], xmm13
00007aa3a45cff74  vmovaps [rsp+0x20], xmm7
00007aa3a45cff7a  vmovaps xmm13, [rsp+0x20]
00007aa3a45cff80  por xmm7, xmm13
00007aa3a45cff85  movaps [r15+0x2A0], xmm7
00007aa3a45cff8d  vmovaps [rsp+0x20], xmm3
00007aa3a45cff93  vmovaps xmm13, [rsp+0x20]
00007aa3a45cff99  por xmm3, xmm13
00007aa3a45cff9e  movaps [r15+0x1D0], xmm3
00007aa3a45cffa6  lea rax, [r14+0x40]
00007aa3a45cffaa  movups xmm13, [r13+rax*1]
00007aa3a45cffb0  movaps [r15+0x2C0], xmm13
00007aa3a45cffb8  vmovaps xmm10, [rsp+0x90]
00007aa3a45cffc1  vpermilpd xmm10, xmm10, 0x00
00007aa3a45cffc7  movaps xmm9, xmm8
00007aa3a45cffcb  mulpd xmm9, xmm10
00007aa3a45cffd0  vcmppd xmm5, xmm9, xmm9, 0x03
00007aa3a45cffd6  ptest xmm5, xmm5
00007aa3a45cffdb  jnz 0x00007AA3A45D3946
00007aa3a45cffe1  movaps xmm10, xmm1
00007aa3a45cffe5  addpd xmm10, xmm11
00007aa3a45cffea  vcmppd xmm8, xmm10, xmm10, 0x03
00007aa3a45cfff0  ptest xmm8, xmm8
00007aa3a45cfff6  jnz 0x00007AA3A45D3A8A
00007aa3a45cfffc  movaps xmm1, xmm14
00007aa3a45d0000  addpd xmm1, xmm6
00007aa3a45d0004  vcmppd xmm11, xmm1, xmm1, 0x03
00007aa3a45d0009  ptest xmm11, xmm11
00007aa3a45d000f  jnz 0x00007AA3A45D3BCD
00007aa3a45d0015  vmovaps xmm14, [rsp+0x90]
00007aa3a45d001e  vpermilpd xmm14, xmm14, 0x00
00007aa3a45d0024  movaps xmm11, xmm13
00007aa3a45d0028  mulpd xmm11, xmm14
00007aa3a45d002d  vcmppd xmm8, xmm11, xmm11, 0x03
00007aa3a45d0033  ptest xmm8, xmm8
00007aa3a45d0039  jnz 0x00007AA3A45D3D0E
00007aa3a45d003f  vmovaps xmm14, [rsp+0x90]
00007aa3a45d0048  vpermilpd xmm14, xmm14, 0x00
00007aa3a45d004e  vmovaps xmm8, [rsp+0x10]
00007aa3a45d0054  movaps xmm13, xmm8
00007aa3a45d0058  mulpd xmm13, xmm14
00007aa3a45d005d  vcmppd xmm6, xmm13, xmm13, 0x03
00007aa3a45d0063  ptest xmm6, xmm6
00007aa3a45d0068  jnz 0x00007AA3A45D3E52
00007aa3a45d006e  vmovaps xmm14, [rsp+0x60]
00007aa3a45d0074  vpermilpd xmm14, xmm14, 0x00
00007aa3a45d007a  movaps xmm8, xmm7
00007aa3a45d007e  mulpd xmm8, xmm14
00007aa3a45d0083  vcmppd xmm6, xmm8, xmm8, 0x03
00007aa3a45d0089  ptest xmm6, xmm6
00007aa3a45d008e  jnz 0x00007AA3A45D3F96
00007aa3a45d0094  movaps xmm14, xmm12
00007aa3a45d0098  addpd xmm14, xmm9
00007aa3a45d009d  vcmppd xmm7, xmm14, xmm14, 0x03
00007aa3a45d00a3  ptest xmm7, xmm7
00007aa3a45d00a8  jnz 0x00007AA3A45D40D9
00007aa3a45d00ae  vmovaps xmm12, [rsp+0x60]
00007aa3a45d00b4  vpermilpd xmm12, xmm12, 0x00
00007aa3a45d00ba  vmovaps xmm7, [rsp+0xF0]
00007aa3a45d00c3  movaps xmm9, xmm7
00007aa3a45d00c7  mulpd xmm9, xmm12
00007aa3a45d00cc  vcmppd xmm6, xmm9, xmm9, 0x03
00007aa3a45d00d2  ptest xmm6, xmm6
00007aa3a45d00d7  jnz 0x00007AA3A45D421D
00007aa3a45d00dd  movaps xmm12, xmm15
00007aa3a45d00e1  addpd xmm12, xmm11
00007aa3a45d00e6  vcmppd xmm7, xmm12, xmm12, 0x03
00007aa3a45d00ec  ptest xmm7, xmm7
00007aa3a45d00f1  jnz 0x00007AA3A45D4360
00007aa3a45d00f7  vmovaps xmm15, [rsp+0x60]
00007aa3a45d00fd  vpermilpd xmm15, xmm15, 0x00
00007aa3a45d0103  vmovaps xmm7, [rsp+0x40]
00007aa3a45d0109  movaps xmm11, xmm7
00007aa3a45d010d  mulpd xmm11, xmm15
00007aa3a45d0112  vcmppd xmm6, xmm11, xmm11, 0x03
00007aa3a45d0118  ptest xmm6, xmm6
00007aa3a45d011d  jnz 0x00007AA3A45D44A4
00007aa3a45d0123  movaps xmm15, xmm10
00007aa3a45d0127  addpd xmm15, xmm13
00007aa3a45d012c  vcmppd xmm7, xmm15, xmm15, 0x03
00007aa3a45d0132  ptest xmm7, xmm7
00007aa3a45d0137  jnz 0x00007AA3A45D45E7
00007aa3a45d013d  vmovaps xmm13, [rsp+0x60]
00007aa3a45d0143  vpermilpd xmm13, xmm13, 0x00
00007aa3a45d0149  vmovaps xmm7, [rsp+0x50]
00007aa3a45d014f  movaps xmm10, xmm7
00007aa3a45d0153  mulpd xmm10, xmm13
00007aa3a45d0158  vcmppd xmm6, xmm10, xmm10, 0x03
00007aa3a45d015e  ptest xmm6, xmm6
00007aa3a45d0163  jnz 0x00007AA3A45D472B
00007aa3a45d0169  movaps xmm13, xmm1
00007aa3a45d016d  addpd xmm13, xmm8
00007aa3a45d0172  vcmppd xmm7, xmm13, xmm13, 0x03
00007aa3a45d0178  ptest xmm7, xmm7
00007aa3a45d017d  jnz 0x00007AA3A45D486E
00007aa3a45d0183  lea rax, [r14+0x70]
00007aa3a45d0187  movups xmm1, [r13+rax*1]
00007aa3a45d018d  movaps [r15+0x240], xmm1
00007aa3a45d0195  movaps xmm8, xmm14
00007aa3a45d0199  addpd xmm8, xmm9
00007aa3a45d019e  vcmppd xmm7, xmm8, xmm8, 0x03
00007aa3a45d01a4  ptest xmm7, xmm7
00007aa3a45d01a9  jnz 0x00007AA3A45D49BB
00007aa3a45d01af  movaps [r15+0x170], xmm8
00007aa3a45d01b7  vmovaps xmm14, [rsp+0x70]
00007aa3a45d01bd  vpermilpd xmm14, xmm14, 0x00
00007aa3a45d01c3  movaps xmm9, xmm1
00007aa3a45d01c7  mulpd xmm9, xmm14
00007aa3a45d01cc  vcmppd xmm7, xmm9, xmm9, 0x03
00007aa3a45d01d2  ptest xmm7, xmm7
00007aa3a45d01d7  jnz 0x00007AA3A45D4AFF
00007aa3a45d01dd  vmovaps xmm1, [rsp+0x70]
00007aa3a45d01e3  vpermilpd xmm1, xmm1, 0x00
00007aa3a45d01e9  movaps xmm14, xmm4
00007aa3a45d01ed  mulpd xmm14, xmm1
00007aa3a45d01f2  vcmppd xmm7, xmm14, xmm14, 0x03
00007aa3a45d01f8  ptest xmm7, xmm7
00007aa3a45d01fd  jnz 0x00007AA3A45D4C42
00007aa3a45d0203  movaps [r15+0x180], xmm14
00007aa3a45d020b  movaps xmm1, xmm12
00007aa3a45d020f  addpd xmm1, xmm11
00007aa3a45d0214  vcmppd xmm7, xmm1, xmm1, 0x03
00007aa3a45d0219  ptest xmm7, xmm7
00007aa3a45d021e  jnz 0x00007AA3A45D4D84
00007aa3a45d0224  movaps [r15+0x210], xmm1
00007aa3a45d022c  movups xmm12, [r13+r14*1]
00007aa3a45d0232  lea rax, [r14+0x10]
00007aa3a45d0236  movups xmm11, [r13+rax*1]
00007aa3a45d023c  movaps [r15+0x230], xmm11
00007aa3a45d0244  movaps xmm7, xmm15
00007aa3a45d0248  addpd xmm7, xmm10
00007aa3a45d024d  vcmppd xmm6, xmm7, xmm7, 0x03
00007aa3a45d0252  ptest xmm6, xmm6
00007aa3a45d0257  jnz 0x00007AA3A45D4EDA
00007aa3a45d025d  movaps [r15+0x130], xmm7
00007aa3a45d0265  vmovaps xmm15, [rsp+0x70]
00007aa3a45d026b  vpermilpd xmm15, xmm15, 0x00
00007aa3a45d0271  movaps xmm10, xmm11
00007aa3a45d0275  mulpd xmm10, xmm15
00007aa3a45d027a  vcmppd xmm6, xmm10, xmm10, 0x03
00007aa3a45d0280  ptest xmm6, xmm6
00007aa3a45d0285  jnz 0x00007AA3A45D501C
00007aa3a45d028b  movaps [r15+0x220], xmm10
00007aa3a45d0293  vmovaps xmm15, [rsp+0x70]
00007aa3a45d0299  vpermilpd xmm15, xmm15, 0x00
00007aa3a45d029f  movaps xmm11, xmm12
00007aa3a45d02a3  mulpd xmm11, xmm15
00007aa3a45d02a8  vcmppd xmm6, xmm11, xmm11, 0x03
00007aa3a45d02ae  ptest xmm6, xmm6
00007aa3a45d02b3  jnz 0x00007AA3A45D5160
00007aa3a45d02b9  movaps xmm15, xmm13
00007aa3a45d02bd  addpd xmm15, xmm9
00007aa3a45d02c2  vcmppd xmm12, xmm15, xmm15, 0x03
00007aa3a45d02c8  ptest xmm12, xmm12
00007aa3a45d02ce  jnz 0x00007AA3A45D52A4
00007aa3a45d02d4  movaps [r15+0x140], xmm15
00007aa3a45d02dc  movaps xmm13, xmm8
00007aa3a45d02e0  addpd xmm13, xmm14
00007aa3a45d02e5  vcmppd xmm12, xmm13, xmm13, 0x03
00007aa3a45d02eb  ptest xmm12, xmm12
00007aa3a45d02f1  jnz 0x00007AA3A45D53E8
00007aa3a45d02f7  movaps [r15+0x150], xmm13
00007aa3a45d02ff  movaps xmm14, xmm1
00007aa3a45d0303  addpd xmm14, xmm10
00007aa3a45d0308  vcmppd xmm12, xmm14, xmm14, 0x03
00007aa3a45d030e  ptest xmm12, xmm12
00007aa3a45d0314  jnz 0x00007AA3A45D552C
00007aa3a45d031a  movaps [r15+0x160], xmm14
00007aa3a45d0322  movaps xmm1, xmm7
00007aa3a45d0325  addpd xmm1, xmm11
00007aa3a45d032a  vcmppd xmm12, xmm1, xmm1, 0x03
00007aa3a45d032f  ptest xmm12, xmm12
00007aa3a45d0335  jnz 0x00007AA3A45D566F
00007aa3a45d033b  movaps [r15+0x120], xmm1
00007aa3a45d0343  mov eax, 0x430920
00007aa3a45d0348  movups [r13+rax*1], xmm15
00007aa3a45d034e  mov eax, 0x430930
00007aa3a45d0353  movups [r13+rax*1], xmm13
00007aa3a45d0359  mov eax, 0x430940
00007aa3a45d035e  movups [r13+rax*1], xmm14
00007aa3a45d0364  mov eax, 0x430950
00007aa3a45d0369  movups [r13+rax*1], xmm1
00007aa3a45d036f  mov eax, [r15+0x108]
00007aa3a45d0376  sahf
00007aa3a45d0377  jnz 0x00007AA3A45D03A9
00007aa3a45d0379  cmp dword ptr [r15+0x318], 0x00
00007aa3a45d0381  jz 0x00007AA3A45DB900
00007aa3a45d0387  nop [rax+rax*1], ax
00007aa3a45d0390  nop [rax+rax*1], eax
00007aa3a45d0398  mov eax, 0x410444
00007aa3a45d039d  mov [r15+0x100], rax
00007aa3a45d03a4  jmp 0x00007AA3A43FE110
00007aa3a45d03a9  cmp dword ptr [r15+0x318], 0x00
00007aa3a45d03b1  jz 0x00007AA3A45D57E0
00007aa3a45d03b7  nop [rax+rax*1], ax
00007aa3a45d03c0  nop [rax+rax*1], eax
00007aa3a45d03c8  mov eax, 0x410278
00007aa3a45d03cd  mov [r15+0x100], rax
00007aa3a45d03d4  jmp 0x00007AA3A43FE110
00007aa3a45d03d9  int3
00007aa3a45d03da  call 0x00007AA3A44B52F0
00007aa3a45d03df  jmp 0x00007AA3A45CF016
00007aa3a45d03e4  call 0x00007AA3A44C4620
00007aa3a45d03e9  jmp 0x00007AA3A45CF023
00007aa3a45d03ee  call 0x00007AA3A44C33A0
00007aa3a45d03f3  jmp 0x00007AA3A45CF035
00007aa3a45d03f8  call 0x00007AA3A44C2120
00007aa3a45d03fd  jmp 0x00007AA3A45CF03F
00007aa3a45d0402  call 0x00007AA3A44C0860
00007aa3a45d0407  jmp 0x00007AA3A45CF067
00007aa3a45d040c  call 0x00007AA3A44BF5F0
00007aa3a45d0411  jmp 0x00007AA3A45CF073
00007aa3a45d0416  call 0x00007AA3A44C0860
00007aa3a45d041b  jmp 0x00007AA3A45CF0A5
00007aa3a45d0420  call 0x00007AA3A44BF5F0
00007aa3a45d0425  jmp 0x00007AA3A45CF0B1
00007aa3a45d042a  call 0x00007AA3A44C4740
00007aa3a45d042f  jmp 0x00007AA3A45CF0BE
00007aa3a45d0434  call 0x00007AA3A44B5400
00007aa3a45d0439  jmp 0x00007AA3A45CF0CB
00007aa3a45d043e  call 0x00007AA3A44B52F0
00007aa3a45d0443  jmp 0x00007AA3A45CF0D8
00007aa3a45d0448  call 0x00007AA3A44C4620
00007aa3a45d044d  jmp 0x00007AA3A45CF0E5
00007aa3a45d0452  call 0x00007AA3A44C0860
00007aa3a45d0457  jmp 0x00007AA3A45CF10D
00007aa3a45d045c  call 0x00007AA3A44BF5F0
00007aa3a45d0461  jmp 0x00007AA3A45CF119
00007aa3a45d0466  call 0x00007AA3A4409D70
00007aa3a45d046b  jmp 0x00007AA3A45CF11F
00007aa3a45d0470  call 0x00007AA3A44BE9C0
00007aa3a45d0475  jmp 0x00007AA3A45CF129
00007aa3a45d047a  call 0x00007AA3A44C0860
00007aa3a45d047f  jmp 0x00007AA3A45CF151
00007aa3a45d0484  call 0x00007AA3A44BF5F0
00007aa3a45d0489  jmp 0x00007AA3A45CF15D
00007aa3a45d048e  call 0x00007AA3A44BD750
00007aa3a45d0493  jmp 0x00007AA3A45CF16A
00007aa3a45d0498  call 0x00007AA3A44BC4E0
00007aa3a45d049d  jmp 0x00007AA3A45CF177
00007aa3a45d04a2  call 0x00007AA3A44C4740
00007aa3a45d04a7  jmp 0x00007AA3A45CF184
00007aa3a45d04ac  call 0x00007AA3A44B5400
00007aa3a45d04b1  jmp 0x00007AA3A45CF191
00007aa3a45d04b6  call 0x00007AA3A44B52F0
00007aa3a45d04bb  jmp 0x00007AA3A45CF19E
00007aa3a45d04c0  call 0x00007AA3A44C4620
00007aa3a45d04c5  jmp 0x00007AA3A45CF1AB
00007aa3a45d04ca  call 0x00007AA3A44C0860
00007aa3a45d04cf  jmp 0x00007AA3A45CF1BE
00007aa3a45d04d4  call 0x00007AA3A44BB270
00007aa3a45d04d9  jmp 0x00007AA3A45CF1CB
00007aa3a45d04de  call 0x00007AA3A44BA000
00007aa3a45d04e3  jmp 0x00007AA3A45CF1D8
00007aa3a45d04e8  call 0x00007AA3A44B8D90
00007aa3a45d04ed  jmp 0x00007AA3A45CF1E5
00007aa3a45d04f2  call 0x00007AA3A44B8A20
00007aa3a45d04f7  jmp 0x00007AA3A45CF1F2
00007aa3a45d04fc  call 0x00007AA3A44B5400
00007aa3a45d0501  jmp 0x00007AA3A45CF1FC
00007aa3a45d0506  call 0x00007AA3A44C2240
00007aa3a45d050b  jmp 0x00007AA3A45CF206
00007aa3a45d0510  call 0x00007AA3A44B52F0
00007aa3a45d0515  jmp 0x00007AA3A45CF210
00007aa3a45d051a  call 0x00007AA3A44C2120
00007aa3a45d051f  jmp 0x00007AA3A45CF21A
00007aa3a45d0524  call 0x00007AA3A44B77B0
00007aa3a45d0529  jmp 0x00007AA3A45CF224
00007aa3a45d052e  call 0x00007AA3A44B6550
00007aa3a45d0533  jmp 0x00007AA3A45CF22E
00007aa3a45d0538  call 0x00007AA3A44BFD50
00007aa3a45d053d  jmp 0x00007AA3A45CF240
00007aa3a45d0542  call 0x00007AA3A44B8EA0
00007aa3a45d0547  jmp 0x00007AA3A45CF24A
00007aa3a45d054c  call 0x00007AA3A44BFC30
00007aa3a45d0551  jmp 0x00007AA3A45CF257
00007aa3a45d0556  call 0x00007AA3A44B8D90
00007aa3a45d055b  jmp 0x00007AA3A45CF264
00007aa3a45d0560  call 0x00007AA3A44C2240
00007aa3a45d0565  jmp 0x00007AA3A45CF271
00007aa3a45d056a  call 0x00007AA3A44B5400
00007aa3a45d056f  jmp 0x00007AA3A45CF27E
00007aa3a45d0574  call 0x00007AA3A44B52F0
00007aa3a45d0579  jmp 0x00007AA3A45CF28B
00007aa3a45d057e  call 0x00007AA3A44C2120
00007aa3a45d0583  jmp 0x00007AA3A45CF298
00007aa3a45d0588  call 0x00007AA3A44B52F0
00007aa3a45d058d  jmp 0x00007AA3A45CF2AB
00007aa3a45d0592  call 0x00007AA3A44B52F0
00007aa3a45d0597  jmp 0x00007AA3A45CF2BE
00007aa3a45d059c  call 0x00007AA3A44B52F0
00007aa3a45d05a1  jmp 0x00007AA3A45CF2D1
00007aa3a45d05a6  call 0x00007AA3A44B52F0
00007aa3a45d05ab  jmp 0x00007AA3A45CF2E4
00007aa3a45d05b0  call 0x00007AA3A44C2240
00007aa3a45d05b5  jmp 0x00007AA3A45CF2F9
00007aa3a45d05ba  call 0x00007AA3A44C2240
00007aa3a45d05bf  jmp 0x00007AA3A45CF30C
00007aa3a45d05c4  call 0x00007AA3A44C2120
00007aa3a45d05c9  jmp 0x00007AA3A45CF319
00007aa3a45d05ce  call 0x00007AA3A44B52F0
00007aa3a45d05d3  jmp 0x00007AA3A45CF32C
00007aa3a45d05d8  call 0x00007AA3A44B52F0
00007aa3a45d05dd  jmp 0x00007AA3A45CF34F
00007aa3a45d05e2  call 0x00007AA3A44B52F0
00007aa3a45d05e7  jmp 0x00007AA3A45CF362
00007aa3a45d05ec  call 0x00007AA3A43FF540
00007aa3a45d05f1  jmp 0x00007AA3A45CF380
00007aa3a45d05f6  call 0x00007AA3A4408C20
00007aa3a45d05fb  jmp 0x00007AA3A45CF38A
00007aa3a45d0600  call 0x00007AA3A44D6600
00007aa3a45d0605  jmp 0x00007AA3A45CF396
00007aa3a45d060a  call 0x00007AA3A43FF540
00007aa3a45d060f  jmp 0x00007AA3A45CF3A6
00007aa3a45d0614  call 0x00007AA3A44C0370
00007aa3a45d0619  jmp 0x00007AA3A45CF3D4
00007aa3a45d061e  call 0x00007AA3A44BF100
00007aa3a45d0623  jmp 0x00007AA3A45CF3DD
00007aa3a45d0628  call 0x00007AA3A44C0370
00007aa3a45d062d  jmp 0x00007AA3A45CF43B
00007aa3a45d0632  call 0x00007AA3A44BF100
00007aa3a45d0637  jmp 0x00007AA3A45CF444
00007aa3a45d063c  call 0x00007AA3A44C0370
00007aa3a45d0641  jmp 0x00007AA3A45CF48B
00007aa3a45d0646  call 0x00007AA3A44BF100
00007aa3a45d064b  jmp 0x00007AA3A45CF494
00007aa3a45d0650  call 0x00007AA3A440B720
00007aa3a45d0655  jmp 0x00007AA3A45CF4D7
00007aa3a45d065a  call 0x00007AA3A44B47C0
00007aa3a45d065f  jmp 0x00007AA3A45CF4EA
00007aa3a45d0664  call 0x00007AA3A4408B00
00007aa3a45d0669  jmp 0x00007AA3A45CF501
00007aa3a45d066e  call 0x00007AA3A43FF430
00007aa3a45d0673  jmp 0x00007AA3A45CF514
00007aa3a45d0678  call 0x00007AA3A43FF430
00007aa3a45d067d  jmp 0x00007AA3A45CF527
00007aa3a45d0682  sub rsp, 0x08
00007aa3a45d0686  push rax
00007aa3a45d0687  push rcx
00007aa3a45d0688  push rdx
00007aa3a45d0689  push rdi
00007aa3a45d068a  push rsi
00007aa3a45d068b  push r8
00007aa3a45d068d  push r9
00007aa3a45d068f  push r10
00007aa3a45d0691  push r11
00007aa3a45d0693  sub rsp, 0xF0
00007aa3a45d069a  vmovaps [rsp], xmm0
00007aa3a45d069f  vmovaps [rsp+0x10], xmm2
00007aa3a45d06a5  vmovaps [rsp+0x20], xmm3
00007aa3a45d06ab  vmovaps [rsp+0x30], xmm4
00007aa3a45d06b1  vmovaps [rsp+0x40], xmm5
00007aa3a45d06b7  vmovaps [rsp+0x50], xmm6
00007aa3a45d06bd  vmovaps [rsp+0x60], xmm7
00007aa3a45d06c3  vmovaps [rsp+0x70], xmm8
00007aa3a45d06c9  vmovaps [rsp+0x80], xmm9
00007aa3a45d06d2  vmovaps [rsp+0x90], xmm10
00007aa3a45d06db  vmovaps [rsp+0xA0], xmm11
00007aa3a45d06e4  vmovaps [rsp+0xB0], xmm12
00007aa3a45d06ed  vmovaps [rsp+0xC0], xmm13
00007aa3a45d06f6  vmovaps [rsp+0xD0], xmm14
00007aa3a45d06ff  vmovaps [rsp+0xE0], xmm15
00007aa3a45d0708  sub rsp, 0x30
00007aa3a45d070c  movaps [rsp], xmm1
00007aa3a45d0710  movaps [rsp+0x10], xmm15
00007aa3a45d0716  movaps [rsp+0x20], xmm14
00007aa3a45d071c  lea rdi, [rsp]
00007aa3a45d0720  mov esi, 0x00
00007aa3a45d0725  mov rax, 0x5F551B683530
00007aa3a45d072f  call rax
00007aa3a45d0731  movaps xmm1, [rsp]
00007aa3a45d0735  add rsp, 0x30
00007aa3a45d0739  vmovaps xmm0, [rsp]
00007aa3a45d073e  vmovaps xmm2, [rsp+0x10]
00007aa3a45d0744  vmovaps xmm3, [rsp+0x20]
00007aa3a45d074a  vmovaps xmm4, [rsp+0x30]
00007aa3a45d0750  vmovaps xmm5, [rsp+0x40]
00007aa3a45d0756  vmovaps xmm6, [rsp+0x50]
00007aa3a45d075c  vmovaps xmm7, [rsp+0x60]
00007aa3a45d0762  vmovaps xmm8, [rsp+0x70]
00007aa3a45d0768  vmovaps xmm9, [rsp+0x80]
00007aa3a45d0771  vmovaps xmm10, [rsp+0x90]
00007aa3a45d077a  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d0783  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d078c  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d0795  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d079e  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d07a7  add rsp, 0xF0
00007aa3a45d07ae  pop r11
00007aa3a45d07b0  pop r10
00007aa3a45d07b2  pop r9
00007aa3a45d07b4  pop r8
00007aa3a45d07b6  pop rsi
00007aa3a45d07b7  pop rdi
00007aa3a45d07b8  pop rdx
00007aa3a45d07b9  pop rcx
00007aa3a45d07ba  pop rax
00007aa3a45d07bb  add rsp, 0x08
00007aa3a45d07bf  jmp 0x00007AA3A45CF581
00007aa3a45d07c4  sub rsp, 0x08
00007aa3a45d07c8  push rax
00007aa3a45d07c9  push rcx
00007aa3a45d07ca  push rdx
00007aa3a45d07cb  push rdi
00007aa3a45d07cc  push rsi
00007aa3a45d07cd  push r8
00007aa3a45d07cf  push r9
00007aa3a45d07d1  push r10
00007aa3a45d07d3  push r11
00007aa3a45d07d5  sub rsp, 0xF0
00007aa3a45d07dc  vmovaps [rsp], xmm0
00007aa3a45d07e1  vmovaps [rsp+0x10], xmm1
00007aa3a45d07e7  vmovaps [rsp+0x20], xmm2
00007aa3a45d07ed  vmovaps [rsp+0x30], xmm3
00007aa3a45d07f3  vmovaps [rsp+0x40], xmm4
00007aa3a45d07f9  vmovaps [rsp+0x50], xmm5
00007aa3a45d07ff  vmovaps [rsp+0x60], xmm6
00007aa3a45d0805  vmovaps [rsp+0x70], xmm7
00007aa3a45d080b  vmovaps [rsp+0x80], xmm8
00007aa3a45d0814  vmovaps [rsp+0x90], xmm9
00007aa3a45d081d  vmovaps [rsp+0xA0], xmm10
00007aa3a45d0826  vmovaps [rsp+0xB0], xmm11
00007aa3a45d082f  vmovaps [rsp+0xC0], xmm12
00007aa3a45d0838  vmovaps [rsp+0xD0], xmm14
00007aa3a45d0841  vmovaps [rsp+0xE0], xmm15
00007aa3a45d084a  sub rsp, 0x30
00007aa3a45d084e  movaps [rsp], xmm13
00007aa3a45d0853  movaps [rsp+0x10], xmm1
00007aa3a45d0858  movaps [rsp+0x20], xmm14
00007aa3a45d085e  lea rdi, [rsp]
00007aa3a45d0862  mov esi, 0x00
00007aa3a45d0867  mov rax, 0x5F551B683530
00007aa3a45d0871  call rax
00007aa3a45d0873  movaps xmm13, [rsp]
00007aa3a45d0878  add rsp, 0x30
00007aa3a45d087c  vmovaps xmm0, [rsp]
00007aa3a45d0881  vmovaps xmm1, [rsp+0x10]
00007aa3a45d0887  vmovaps xmm2, [rsp+0x20]
00007aa3a45d088d  vmovaps xmm3, [rsp+0x30]
00007aa3a45d0893  vmovaps xmm4, [rsp+0x40]
00007aa3a45d0899  vmovaps xmm5, [rsp+0x50]
00007aa3a45d089f  vmovaps xmm6, [rsp+0x60]
00007aa3a45d08a5  vmovaps xmm7, [rsp+0x70]
00007aa3a45d08ab  vmovaps xmm8, [rsp+0x80]
00007aa3a45d08b4  vmovaps xmm9, [rsp+0x90]
00007aa3a45d08bd  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d08c6  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d08cf  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d08d8  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d08e1  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d08ea  add rsp, 0xF0
00007aa3a45d08f1  pop r11
00007aa3a45d08f3  pop r10
00007aa3a45d08f5  pop r9
00007aa3a45d08f7  pop r8
00007aa3a45d08f9  pop rsi
00007aa3a45d08fa  pop rdi
00007aa3a45d08fb  pop rdx
00007aa3a45d08fc  pop rcx
00007aa3a45d08fd  pop rax
00007aa3a45d08fe  add rsp, 0x08
00007aa3a45d0902  jmp 0x00007AA3A45CF5CF
00007aa3a45d0907  sub rsp, 0x08
00007aa3a45d090b  push rax
00007aa3a45d090c  push rcx
00007aa3a45d090d  push rdx
00007aa3a45d090e  push rdi
00007aa3a45d090f  push rsi
00007aa3a45d0910  push r8
00007aa3a45d0912  push r9
00007aa3a45d0914  push r10
00007aa3a45d0916  push r11
00007aa3a45d0918  sub rsp, 0xF0
00007aa3a45d091f  vmovaps [rsp], xmm0
00007aa3a45d0924  vmovaps [rsp+0x10], xmm1
00007aa3a45d092a  vmovaps [rsp+0x20], xmm2
00007aa3a45d0930  vmovaps [rsp+0x30], xmm3
00007aa3a45d0936  vmovaps [rsp+0x40], xmm4
00007aa3a45d093c  vmovaps [rsp+0x50], xmm5
00007aa3a45d0942  vmovaps [rsp+0x60], xmm6
00007aa3a45d0948  vmovaps [rsp+0x70], xmm7
00007aa3a45d094e  vmovaps [rsp+0x80], xmm8
00007aa3a45d0957  vmovaps [rsp+0x90], xmm9
00007aa3a45d0960  vmovaps [rsp+0xA0], xmm10
00007aa3a45d0969  vmovaps [rsp+0xB0], xmm11
00007aa3a45d0972  vmovaps [rsp+0xC0], xmm12
00007aa3a45d097b  vmovaps [rsp+0xD0], xmm13
00007aa3a45d0984  vmovaps [rsp+0xE0], xmm14
00007aa3a45d098d  sub rsp, 0x30
00007aa3a45d0991  movaps [rsp], xmm15
00007aa3a45d0996  movaps [rsp+0x10], xmm14
00007aa3a45d099c  movaps [rsp+0x20], xmm1
00007aa3a45d09a1  lea rdi, [rsp]
00007aa3a45d09a5  mov esi, 0x00
00007aa3a45d09aa  mov rax, 0x5F551B683530
00007aa3a45d09b4  call rax
00007aa3a45d09b6  movaps xmm15, [rsp]
00007aa3a45d09bb  add rsp, 0x30
00007aa3a45d09bf  vmovaps xmm0, [rsp]
00007aa3a45d09c4  vmovaps xmm1, [rsp+0x10]
00007aa3a45d09ca  vmovaps xmm2, [rsp+0x20]
00007aa3a45d09d0  vmovaps xmm3, [rsp+0x30]
00007aa3a45d09d6  vmovaps xmm4, [rsp+0x40]
00007aa3a45d09dc  vmovaps xmm5, [rsp+0x50]
00007aa3a45d09e2  vmovaps xmm6, [rsp+0x60]
00007aa3a45d09e8  vmovaps xmm7, [rsp+0x70]
00007aa3a45d09ee  vmovaps xmm8, [rsp+0x80]
00007aa3a45d09f7  vmovaps xmm9, [rsp+0x90]
00007aa3a45d0a00  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d0a09  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d0a12  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d0a1b  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d0a24  vmovaps xmm14, [rsp+0xE0]
00007aa3a45d0a2d  add rsp, 0xF0
00007aa3a45d0a34  pop r11
00007aa3a45d0a36  pop r10
00007aa3a45d0a38  pop r9
00007aa3a45d0a3a  pop r8
00007aa3a45d0a3c  pop rsi
00007aa3a45d0a3d  pop rdi
00007aa3a45d0a3e  pop rdx
00007aa3a45d0a3f  pop rcx
00007aa3a45d0a40  pop rax
00007aa3a45d0a41  add rsp, 0x08
00007aa3a45d0a45  jmp 0x00007AA3A45CF617
00007aa3a45d0a4a  sub rsp, 0x08
00007aa3a45d0a4e  push rax
00007aa3a45d0a4f  push rcx
00007aa3a45d0a50  push rdx
00007aa3a45d0a51  push rdi
00007aa3a45d0a52  push rsi
00007aa3a45d0a53  push r8
00007aa3a45d0a55  push r9
00007aa3a45d0a57  push r10
00007aa3a45d0a59  push r11
00007aa3a45d0a5b  sub rsp, 0xF0
00007aa3a45d0a62  vmovaps [rsp], xmm0
00007aa3a45d0a67  vmovaps [rsp+0x10], xmm2
00007aa3a45d0a6d  vmovaps [rsp+0x20], xmm3
00007aa3a45d0a73  vmovaps [rsp+0x30], xmm4
00007aa3a45d0a79  vmovaps [rsp+0x40], xmm5
00007aa3a45d0a7f  vmovaps [rsp+0x50], xmm6
00007aa3a45d0a85  vmovaps [rsp+0x60], xmm7
00007aa3a45d0a8b  vmovaps [rsp+0x70], xmm8
00007aa3a45d0a91  vmovaps [rsp+0x80], xmm9
00007aa3a45d0a9a  vmovaps [rsp+0x90], xmm10
00007aa3a45d0aa3  vmovaps [rsp+0xA0], xmm11
00007aa3a45d0aac  vmovaps [rsp+0xB0], xmm12
00007aa3a45d0ab5  vmovaps [rsp+0xC0], xmm13
00007aa3a45d0abe  vmovaps [rsp+0xD0], xmm14
00007aa3a45d0ac7  vmovaps [rsp+0xE0], xmm15
00007aa3a45d0ad0  sub rsp, 0x30
00007aa3a45d0ad4  movaps [rsp], xmm1
00007aa3a45d0ad8  movaps [rsp+0x10], xmm14
00007aa3a45d0ade  movaps [rsp+0x20], xmm10
00007aa3a45d0ae4  lea rdi, [rsp]
00007aa3a45d0ae8  mov esi, 0x00
00007aa3a45d0aed  mov rax, 0x5F551B683530
00007aa3a45d0af7  call rax
00007aa3a45d0af9  movaps xmm1, [rsp]
00007aa3a45d0afd  add rsp, 0x30
00007aa3a45d0b01  vmovaps xmm0, [rsp]
00007aa3a45d0b06  vmovaps xmm2, [rsp+0x10]
00007aa3a45d0b0c  vmovaps xmm3, [rsp+0x20]
00007aa3a45d0b12  vmovaps xmm4, [rsp+0x30]
00007aa3a45d0b18  vmovaps xmm5, [rsp+0x40]
00007aa3a45d0b1e  vmovaps xmm6, [rsp+0x50]
00007aa3a45d0b24  vmovaps xmm7, [rsp+0x60]
00007aa3a45d0b2a  vmovaps xmm8, [rsp+0x70]
00007aa3a45d0b30  vmovaps xmm9, [rsp+0x80]
00007aa3a45d0b39  vmovaps xmm10, [rsp+0x90]
00007aa3a45d0b42  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d0b4b  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d0b54  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d0b5d  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d0b66  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d0b6f  add rsp, 0xF0
00007aa3a45d0b76  pop r11
00007aa3a45d0b78  pop r10
00007aa3a45d0b7a  pop r9
00007aa3a45d0b7c  pop r8
00007aa3a45d0b7e  pop rsi
00007aa3a45d0b7f  pop rdi
00007aa3a45d0b80  pop rdx
00007aa3a45d0b81  pop rcx
00007aa3a45d0b82  pop rax
00007aa3a45d0b83  add rsp, 0x08
00007aa3a45d0b87  jmp 0x00007AA3A45CF631
00007aa3a45d0b8c  sub rsp, 0x08
00007aa3a45d0b90  push rax
00007aa3a45d0b91  push rcx
00007aa3a45d0b92  push rdx
00007aa3a45d0b93  push rdi
00007aa3a45d0b94  push rsi
00007aa3a45d0b95  push r8
00007aa3a45d0b97  push r9
00007aa3a45d0b99  push r10
00007aa3a45d0b9b  push r11
00007aa3a45d0b9d  sub rsp, 0xF0
00007aa3a45d0ba4  vmovaps [rsp], xmm0
00007aa3a45d0ba9  vmovaps [rsp+0x10], xmm1
00007aa3a45d0baf  vmovaps [rsp+0x20], xmm2
00007aa3a45d0bb5  vmovaps [rsp+0x30], xmm3
00007aa3a45d0bbb  vmovaps [rsp+0x40], xmm4
00007aa3a45d0bc1  vmovaps [rsp+0x50], xmm5
00007aa3a45d0bc7  vmovaps [rsp+0x60], xmm6
00007aa3a45d0bcd  vmovaps [rsp+0x70], xmm7
00007aa3a45d0bd3  vmovaps [rsp+0x80], xmm8
00007aa3a45d0bdc  vmovaps [rsp+0x90], xmm9
00007aa3a45d0be5  vmovaps [rsp+0xA0], xmm10
00007aa3a45d0bee  vmovaps [rsp+0xB0], xmm11
00007aa3a45d0bf7  vmovaps [rsp+0xC0], xmm12
00007aa3a45d0c00  vmovaps [rsp+0xD0], xmm14
00007aa3a45d0c09  vmovaps [rsp+0xE0], xmm15
00007aa3a45d0c12  sub rsp, 0x30
00007aa3a45d0c16  movaps [rsp], xmm13
00007aa3a45d0c1b  movaps [rsp+0x10], xmm14
00007aa3a45d0c21  movaps [rsp+0x20], xmm2
00007aa3a45d0c26  lea rdi, [rsp]
00007aa3a45d0c2a  mov esi, 0x00
00007aa3a45d0c2f  mov rax, 0x5F551B683530
00007aa3a45d0c39  call rax
00007aa3a45d0c3b  movaps xmm13, [rsp]
00007aa3a45d0c40  add rsp, 0x30
00007aa3a45d0c44  vmovaps xmm0, [rsp]
00007aa3a45d0c49  vmovaps xmm1, [rsp+0x10]
00007aa3a45d0c4f  vmovaps xmm2, [rsp+0x20]
00007aa3a45d0c55  vmovaps xmm3, [rsp+0x30]
00007aa3a45d0c5b  vmovaps xmm4, [rsp+0x40]
00007aa3a45d0c61  vmovaps xmm5, [rsp+0x50]
00007aa3a45d0c67  vmovaps xmm6, [rsp+0x60]
00007aa3a45d0c6d  vmovaps xmm7, [rsp+0x70]
00007aa3a45d0c73  vmovaps xmm8, [rsp+0x80]
00007aa3a45d0c7c  vmovaps xmm9, [rsp+0x90]
00007aa3a45d0c85  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d0c8e  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d0c97  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d0ca0  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d0ca9  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d0cb2  add rsp, 0xF0
00007aa3a45d0cb9  pop r11
00007aa3a45d0cbb  pop r10
00007aa3a45d0cbd  pop r9
00007aa3a45d0cbf  pop r8
00007aa3a45d0cc1  pop rsi
00007aa3a45d0cc2  pop rdi
00007aa3a45d0cc3  pop rdx
00007aa3a45d0cc4  pop rcx
00007aa3a45d0cc5  pop rax
00007aa3a45d0cc6  add rsp, 0x08
00007aa3a45d0cca  jmp 0x00007AA3A45CF64C
00007aa3a45d0ccf  sub rsp, 0x08
00007aa3a45d0cd3  push rax
00007aa3a45d0cd4  push rcx
00007aa3a45d0cd5  push rdx
00007aa3a45d0cd6  push rdi
00007aa3a45d0cd7  push rsi
00007aa3a45d0cd8  push r8
00007aa3a45d0cda  push r9
00007aa3a45d0cdc  push r10
00007aa3a45d0cde  push r11
00007aa3a45d0ce0  sub rsp, 0xF0
00007aa3a45d0ce7  vmovaps [rsp], xmm0
00007aa3a45d0cec  vmovaps [rsp+0x10], xmm2
00007aa3a45d0cf2  vmovaps [rsp+0x20], xmm3
00007aa3a45d0cf8  vmovaps [rsp+0x30], xmm4
00007aa3a45d0cfe  vmovaps [rsp+0x40], xmm5
00007aa3a45d0d04  vmovaps [rsp+0x50], xmm6
00007aa3a45d0d0a  vmovaps [rsp+0x60], xmm7
00007aa3a45d0d10  vmovaps [rsp+0x70], xmm8
00007aa3a45d0d16  vmovaps [rsp+0x80], xmm9
00007aa3a45d0d1f  vmovaps [rsp+0x90], xmm10
00007aa3a45d0d28  vmovaps [rsp+0xA0], xmm11
00007aa3a45d0d31  vmovaps [rsp+0xB0], xmm12
00007aa3a45d0d3a  vmovaps [rsp+0xC0], xmm13
00007aa3a45d0d43  vmovaps [rsp+0xD0], xmm14
00007aa3a45d0d4c  vmovaps [rsp+0xE0], xmm15
00007aa3a45d0d55  sub rsp, 0x30
00007aa3a45d0d59  movaps [rsp], xmm1
00007aa3a45d0d5d  movaps [rsp+0x10], xmm10
00007aa3a45d0d63  movaps [rsp+0x20], xmm2
00007aa3a45d0d68  lea rdi, [rsp]
00007aa3a45d0d6c  mov esi, 0x00
00007aa3a45d0d71  mov rax, 0x5F551B683530
00007aa3a45d0d7b  call rax
00007aa3a45d0d7d  movaps xmm1, [rsp]
00007aa3a45d0d81  add rsp, 0x30
00007aa3a45d0d85  vmovaps xmm0, [rsp]
00007aa3a45d0d8a  vmovaps xmm2, [rsp+0x10]
00007aa3a45d0d90  vmovaps xmm3, [rsp+0x20]
00007aa3a45d0d96  vmovaps xmm4, [rsp+0x30]
00007aa3a45d0d9c  vmovaps xmm5, [rsp+0x40]
00007aa3a45d0da2  vmovaps xmm6, [rsp+0x50]
00007aa3a45d0da8  vmovaps xmm7, [rsp+0x60]
00007aa3a45d0dae  vmovaps xmm8, [rsp+0x70]
00007aa3a45d0db4  vmovaps xmm9, [rsp+0x80]
00007aa3a45d0dbd  vmovaps xmm10, [rsp+0x90]
00007aa3a45d0dc6  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d0dcf  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d0dd8  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d0de1  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d0dea  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d0df3  add rsp, 0xF0
00007aa3a45d0dfa  pop r11
00007aa3a45d0dfc  pop r10
00007aa3a45d0dfe  pop r9
00007aa3a45d0e00  pop r8
00007aa3a45d0e02  pop rsi
00007aa3a45d0e03  pop rdi
00007aa3a45d0e04  pop rdx
00007aa3a45d0e05  pop rcx
00007aa3a45d0e06  pop rax
00007aa3a45d0e07  add rsp, 0x08
00007aa3a45d0e0b  jmp 0x00007AA3A45CF6B4
00007aa3a45d0e10  sub rsp, 0x08
00007aa3a45d0e14  push rax
00007aa3a45d0e15  push rcx
00007aa3a45d0e16  push rdx
00007aa3a45d0e17  push rdi
00007aa3a45d0e18  push rsi
00007aa3a45d0e19  push r8
00007aa3a45d0e1b  push r9
00007aa3a45d0e1d  push r10
00007aa3a45d0e1f  push r11
00007aa3a45d0e21  sub rsp, 0xF0
00007aa3a45d0e28  vmovaps [rsp], xmm0
00007aa3a45d0e2d  vmovaps [rsp+0x10], xmm1
00007aa3a45d0e33  vmovaps [rsp+0x20], xmm2
00007aa3a45d0e39  vmovaps [rsp+0x30], xmm3
00007aa3a45d0e3f  vmovaps [rsp+0x40], xmm4
00007aa3a45d0e45  vmovaps [rsp+0x50], xmm5
00007aa3a45d0e4b  vmovaps [rsp+0x60], xmm6
00007aa3a45d0e51  vmovaps [rsp+0x70], xmm7
00007aa3a45d0e57  vmovaps [rsp+0x80], xmm8
00007aa3a45d0e60  vmovaps [rsp+0x90], xmm9
00007aa3a45d0e69  vmovaps [rsp+0xA0], xmm10
00007aa3a45d0e72  vmovaps [rsp+0xB0], xmm11
00007aa3a45d0e7b  vmovaps [rsp+0xC0], xmm12
00007aa3a45d0e84  vmovaps [rsp+0xD0], xmm13
00007aa3a45d0e8d  vmovaps [rsp+0xE0], xmm14
00007aa3a45d0e96  sub rsp, 0x30
00007aa3a45d0e9a  movaps [rsp], xmm15
00007aa3a45d0e9f  movaps [rsp+0x10], xmm10
00007aa3a45d0ea5  movaps [rsp+0x20], xmm2
00007aa3a45d0eaa  lea rdi, [rsp]
00007aa3a45d0eae  mov esi, 0x00
00007aa3a45d0eb3  mov rax, 0x5F551B683530
00007aa3a45d0ebd  call rax
00007aa3a45d0ebf  movaps xmm15, [rsp]
00007aa3a45d0ec4  add rsp, 0x30
00007aa3a45d0ec8  vmovaps xmm0, [rsp]
00007aa3a45d0ecd  vmovaps xmm1, [rsp+0x10]
00007aa3a45d0ed3  vmovaps xmm2, [rsp+0x20]
00007aa3a45d0ed9  vmovaps xmm3, [rsp+0x30]
00007aa3a45d0edf  vmovaps xmm4, [rsp+0x40]
00007aa3a45d0ee5  vmovaps xmm5, [rsp+0x50]
00007aa3a45d0eeb  vmovaps xmm6, [rsp+0x60]
00007aa3a45d0ef1  vmovaps xmm7, [rsp+0x70]
00007aa3a45d0ef7  vmovaps xmm8, [rsp+0x80]
00007aa3a45d0f00  vmovaps xmm9, [rsp+0x90]
00007aa3a45d0f09  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d0f12  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d0f1b  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d0f24  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d0f2d  vmovaps xmm14, [rsp+0xE0]
00007aa3a45d0f36  add rsp, 0xF0
00007aa3a45d0f3d  pop r11
00007aa3a45d0f3f  pop r10
00007aa3a45d0f41  pop r9
00007aa3a45d0f43  pop r8
00007aa3a45d0f45  pop rsi
00007aa3a45d0f46  pop rdi
00007aa3a45d0f47  pop rdx
00007aa3a45d0f48  pop rcx
00007aa3a45d0f49  pop rax
00007aa3a45d0f4a  add rsp, 0x08
00007aa3a45d0f4e  jmp 0x00007AA3A45CF706
00007aa3a45d0f53  sub rsp, 0x08
00007aa3a45d0f57  push rax
00007aa3a45d0f58  push rcx
00007aa3a45d0f59  push rdx
00007aa3a45d0f5a  push rdi
00007aa3a45d0f5b  push rsi
00007aa3a45d0f5c  push r8
00007aa3a45d0f5e  push r9
00007aa3a45d0f60  push r10
00007aa3a45d0f62  push r11
00007aa3a45d0f64  sub rsp, 0xF0
00007aa3a45d0f6b  vmovaps [rsp], xmm0
00007aa3a45d0f70  vmovaps [rsp+0x10], xmm2
00007aa3a45d0f76  vmovaps [rsp+0x20], xmm3
00007aa3a45d0f7c  vmovaps [rsp+0x30], xmm4
00007aa3a45d0f82  vmovaps [rsp+0x40], xmm5
00007aa3a45d0f88  vmovaps [rsp+0x50], xmm6
00007aa3a45d0f8e  vmovaps [rsp+0x60], xmm7
00007aa3a45d0f94  vmovaps [rsp+0x70], xmm8
00007aa3a45d0f9a  vmovaps [rsp+0x80], xmm9
00007aa3a45d0fa3  vmovaps [rsp+0x90], xmm10
00007aa3a45d0fac  vmovaps [rsp+0xA0], xmm11
00007aa3a45d0fb5  vmovaps [rsp+0xB0], xmm12
00007aa3a45d0fbe  vmovaps [rsp+0xC0], xmm13
00007aa3a45d0fc7  vmovaps [rsp+0xD0], xmm14
00007aa3a45d0fd0  vmovaps [rsp+0xE0], xmm15
00007aa3a45d0fd9  sub rsp, 0x30
00007aa3a45d0fdd  movaps [rsp], xmm1
00007aa3a45d0fe1  movaps [rsp+0x10], xmm10
00007aa3a45d0fe7  movaps [rsp+0x20], xmm12
00007aa3a45d0fed  lea rdi, [rsp]
00007aa3a45d0ff1  mov esi, 0x00
00007aa3a45d0ff6  mov rax, 0x5F551B683530
00007aa3a45d1000  call rax
00007aa3a45d1002  movaps xmm1, [rsp]
00007aa3a45d1006  add rsp, 0x30
00007aa3a45d100a  vmovaps xmm0, [rsp]
00007aa3a45d100f  vmovaps xmm2, [rsp+0x10]
00007aa3a45d1015  vmovaps xmm3, [rsp+0x20]
00007aa3a45d101b  vmovaps xmm4, [rsp+0x30]
00007aa3a45d1021  vmovaps xmm5, [rsp+0x40]
00007aa3a45d1027  vmovaps xmm6, [rsp+0x50]
00007aa3a45d102d  vmovaps xmm7, [rsp+0x60]
00007aa3a45d1033  vmovaps xmm8, [rsp+0x70]
00007aa3a45d1039  vmovaps xmm9, [rsp+0x80]
00007aa3a45d1042  vmovaps xmm10, [rsp+0x90]
00007aa3a45d104b  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d1054  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d105d  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d1066  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d106f  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d1078  add rsp, 0xF0
00007aa3a45d107f  pop r11
00007aa3a45d1081  pop r10
00007aa3a45d1083  pop r9
00007aa3a45d1085  pop r8
00007aa3a45d1087  pop rsi
00007aa3a45d1088  pop rdi
00007aa3a45d1089  pop rdx
00007aa3a45d108a  pop rcx
00007aa3a45d108b  pop rax
00007aa3a45d108c  add rsp, 0x08
00007aa3a45d1090  jmp 0x00007AA3A45CF732
00007aa3a45d1095  sub rsp, 0x08
00007aa3a45d1099  push rax
00007aa3a45d109a  push rcx
00007aa3a45d109b  push rdx
00007aa3a45d109c  push rdi
00007aa3a45d109d  push rsi
00007aa3a45d109e  push r8
00007aa3a45d10a0  push r9
00007aa3a45d10a2  push r10
00007aa3a45d10a4  push r11
00007aa3a45d10a6  sub rsp, 0xF0
00007aa3a45d10ad  vmovaps [rsp], xmm0
00007aa3a45d10b2  vmovaps [rsp+0x10], xmm1
00007aa3a45d10b8  vmovaps [rsp+0x20], xmm2
00007aa3a45d10be  vmovaps [rsp+0x30], xmm3
00007aa3a45d10c4  vmovaps [rsp+0x40], xmm4
00007aa3a45d10ca  vmovaps [rsp+0x50], xmm5
00007aa3a45d10d0  vmovaps [rsp+0x60], xmm6
00007aa3a45d10d6  vmovaps [rsp+0x70], xmm7
00007aa3a45d10dc  vmovaps [rsp+0x80], xmm8
00007aa3a45d10e5  vmovaps [rsp+0x90], xmm9
00007aa3a45d10ee  vmovaps [rsp+0xA0], xmm10
00007aa3a45d10f7  vmovaps [rsp+0xB0], xmm11
00007aa3a45d1100  vmovaps [rsp+0xC0], xmm12
00007aa3a45d1109  vmovaps [rsp+0xD0], xmm13
00007aa3a45d1112  vmovaps [rsp+0xE0], xmm14
00007aa3a45d111b  sub rsp, 0x30
00007aa3a45d111f  movaps [rsp], xmm15
00007aa3a45d1124  movaps [rsp+0x10], xmm10
00007aa3a45d112a  movaps [rsp+0x20], xmm12
00007aa3a45d1130  lea rdi, [rsp]
00007aa3a45d1134  mov esi, 0x00
00007aa3a45d1139  mov rax, 0x5F551B683530
00007aa3a45d1143  call rax
00007aa3a45d1145  movaps xmm15, [rsp]
00007aa3a45d114a  add rsp, 0x30
00007aa3a45d114e  vmovaps xmm0, [rsp]
00007aa3a45d1153  vmovaps xmm1, [rsp+0x10]
00007aa3a45d1159  vmovaps xmm2, [rsp+0x20]
00007aa3a45d115f  vmovaps xmm3, [rsp+0x30]
00007aa3a45d1165  vmovaps xmm4, [rsp+0x40]
00007aa3a45d116b  vmovaps xmm5, [rsp+0x50]
00007aa3a45d1171  vmovaps xmm6, [rsp+0x60]
00007aa3a45d1177  vmovaps xmm7, [rsp+0x70]
00007aa3a45d117d  vmovaps xmm8, [rsp+0x80]
00007aa3a45d1186  vmovaps xmm9, [rsp+0x90]
00007aa3a45d118f  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d1198  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d11a1  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d11aa  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d11b3  vmovaps xmm14, [rsp+0xE0]
00007aa3a45d11bc  add rsp, 0xF0
00007aa3a45d11c3  pop r11
00007aa3a45d11c5  pop r10
00007aa3a45d11c7  pop r9
00007aa3a45d11c9  pop r8
00007aa3a45d11cb  pop rsi
00007aa3a45d11cc  pop rdi
00007aa3a45d11cd  pop rdx
00007aa3a45d11ce  pop rcx
00007aa3a45d11cf  pop rax
00007aa3a45d11d0  add rsp, 0x08
00007aa3a45d11d4  jmp 0x00007AA3A45CF75E
00007aa3a45d11d9  call 0x00007AA3A43FF430
00007aa3a45d11de  jmp 0x00007AA3A45CF7EE
00007aa3a45d11e3  call 0x00007AA3A43FF430
00007aa3a45d11e8  jmp 0x00007AA3A45CF801
00007aa3a45d11ed  sub rsp, 0x08
00007aa3a45d11f1  push rax
00007aa3a45d11f2  push rcx
00007aa3a45d11f3  push rdx
00007aa3a45d11f4  push rdi
00007aa3a45d11f5  push rsi
00007aa3a45d11f6  push r8
00007aa3a45d11f8  push r9
00007aa3a45d11fa  push r10
00007aa3a45d11fc  push r11
00007aa3a45d11fe  sub rsp, 0xF0
00007aa3a45d1205  vmovaps [rsp], xmm0
00007aa3a45d120a  vmovaps [rsp+0x10], xmm2
00007aa3a45d1210  vmovaps [rsp+0x20], xmm3
00007aa3a45d1216  vmovaps [rsp+0x30], xmm4
00007aa3a45d121c  vmovaps [rsp+0x40], xmm5
00007aa3a45d1222  vmovaps [rsp+0x50], xmm6
00007aa3a45d1228  vmovaps [rsp+0x60], xmm7
00007aa3a45d122e  vmovaps [rsp+0x70], xmm8
00007aa3a45d1234  vmovaps [rsp+0x80], xmm9
00007aa3a45d123d  vmovaps [rsp+0x90], xmm10
00007aa3a45d1246  vmovaps [rsp+0xA0], xmm11
00007aa3a45d124f  vmovaps [rsp+0xB0], xmm12
00007aa3a45d1258  vmovaps [rsp+0xC0], xmm13
00007aa3a45d1261  vmovaps [rsp+0xD0], xmm14
00007aa3a45d126a  vmovaps [rsp+0xE0], xmm15
00007aa3a45d1273  sub rsp, 0x30
00007aa3a45d1277  movaps [rsp], xmm1
00007aa3a45d127b  movaps [rsp+0x10], xmm13
00007aa3a45d1281  movaps [rsp+0x20], xmm2
00007aa3a45d1286  lea rdi, [rsp]
00007aa3a45d128a  mov esi, 0x00
00007aa3a45d128f  mov rax, 0x5F551B683530
00007aa3a45d1299  call rax
00007aa3a45d129b  movaps xmm1, [rsp]
00007aa3a45d129f  add rsp, 0x30
00007aa3a45d12a3  vmovaps xmm0, [rsp]
00007aa3a45d12a8  vmovaps xmm2, [rsp+0x10]
00007aa3a45d12ae  vmovaps xmm3, [rsp+0x20]
00007aa3a45d12b4  vmovaps xmm4, [rsp+0x30]
00007aa3a45d12ba  vmovaps xmm5, [rsp+0x40]
00007aa3a45d12c0  vmovaps xmm6, [rsp+0x50]
00007aa3a45d12c6  vmovaps xmm7, [rsp+0x60]
00007aa3a45d12cc  vmovaps xmm8, [rsp+0x70]
00007aa3a45d12d2  vmovaps xmm9, [rsp+0x80]
00007aa3a45d12db  vmovaps xmm10, [rsp+0x90]
00007aa3a45d12e4  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d12ed  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d12f6  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d12ff  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d1308  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d1311  add rsp, 0xF0
00007aa3a45d1318  pop r11
00007aa3a45d131a  pop r10
00007aa3a45d131c  pop r9
00007aa3a45d131e  pop r8
00007aa3a45d1320  pop rsi
00007aa3a45d1321  pop rdi
00007aa3a45d1322  pop rdx
00007aa3a45d1323  pop rcx
00007aa3a45d1324  pop rax
00007aa3a45d1325  add rsp, 0x08
00007aa3a45d1329  jmp 0x00007AA3A45CF82C
00007aa3a45d132e  call 0x00007AA3A440E760
00007aa3a45d1333  jmp 0x00007AA3A45CF839
00007aa3a45d1338  sub rsp, 0x08
00007aa3a45d133c  push rax
00007aa3a45d133d  push rcx
00007aa3a45d133e  push rdx
00007aa3a45d133f  push rdi
00007aa3a45d1340  push rsi
00007aa3a45d1341  push r8
00007aa3a45d1343  push r9
00007aa3a45d1345  push r10
00007aa3a45d1347  push r11
00007aa3a45d1349  sub rsp, 0xF0
00007aa3a45d1350  vmovaps [rsp], xmm0
00007aa3a45d1355  vmovaps [rsp+0x10], xmm1
00007aa3a45d135b  vmovaps [rsp+0x20], xmm2
00007aa3a45d1361  vmovaps [rsp+0x30], xmm3
00007aa3a45d1367  vmovaps [rsp+0x40], xmm4
00007aa3a45d136d  vmovaps [rsp+0x50], xmm5
00007aa3a45d1373  vmovaps [rsp+0x60], xmm6
00007aa3a45d1379  vmovaps [rsp+0x70], xmm7
00007aa3a45d137f  vmovaps [rsp+0x80], xmm8
00007aa3a45d1388  vmovaps [rsp+0x90], xmm9
00007aa3a45d1391  vmovaps [rsp+0xA0], xmm10
00007aa3a45d139a  vmovaps [rsp+0xB0], xmm11
00007aa3a45d13a3  vmovaps [rsp+0xC0], xmm12
00007aa3a45d13ac  vmovaps [rsp+0xD0], xmm14
00007aa3a45d13b5  vmovaps [rsp+0xE0], xmm15
00007aa3a45d13be  sub rsp, 0x30
00007aa3a45d13c2  movaps [rsp], xmm13
00007aa3a45d13c7  movaps [rsp+0x10], xmm2
00007aa3a45d13cc  movaps [rsp+0x20], xmm1
00007aa3a45d13d1  lea rdi, [rsp]
00007aa3a45d13d5  mov esi, 0x00
00007aa3a45d13da  mov rax, 0x5F551B683530
00007aa3a45d13e4  call rax
00007aa3a45d13e6  movaps xmm13, [rsp]
00007aa3a45d13eb  add rsp, 0x30
00007aa3a45d13ef  vmovaps xmm0, [rsp]
00007aa3a45d13f4  vmovaps xmm1, [rsp+0x10]
00007aa3a45d13fa  vmovaps xmm2, [rsp+0x20]
00007aa3a45d1400  vmovaps xmm3, [rsp+0x30]
00007aa3a45d1406  vmovaps xmm4, [rsp+0x40]
00007aa3a45d140c  vmovaps xmm5, [rsp+0x50]
00007aa3a45d1412  vmovaps xmm6, [rsp+0x60]
00007aa3a45d1418  vmovaps xmm7, [rsp+0x70]
00007aa3a45d141e  vmovaps xmm8, [rsp+0x80]
00007aa3a45d1427  vmovaps xmm9, [rsp+0x90]
00007aa3a45d1430  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d1439  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d1442  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d144b  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d1454  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d145d  add rsp, 0xF0
00007aa3a45d1464  pop r11
00007aa3a45d1466  pop r10
00007aa3a45d1468  pop r9
00007aa3a45d146a  pop r8
00007aa3a45d146c  pop rsi
00007aa3a45d146d  pop rdi
00007aa3a45d146e  pop rdx
00007aa3a45d146f  pop rcx
00007aa3a45d1470  pop rax
00007aa3a45d1471  add rsp, 0x08
00007aa3a45d1475  jmp 0x00007AA3A45CF878
00007aa3a45d147a  sub rsp, 0x08
00007aa3a45d147e  push rax
00007aa3a45d147f  push rcx
00007aa3a45d1480  push rdx
00007aa3a45d1481  push rdi
00007aa3a45d1482  push rsi
00007aa3a45d1483  push r8
00007aa3a45d1485  push r9
00007aa3a45d1487  push r10
00007aa3a45d1489  push r11
00007aa3a45d148b  sub rsp, 0xF0
00007aa3a45d1492  vmovaps [rsp], xmm0
00007aa3a45d1497  vmovaps [rsp+0x10], xmm2
00007aa3a45d149d  vmovaps [rsp+0x20], xmm3
00007aa3a45d14a3  vmovaps [rsp+0x30], xmm4
00007aa3a45d14a9  vmovaps [rsp+0x40], xmm5
00007aa3a45d14af  vmovaps [rsp+0x50], xmm6
00007aa3a45d14b5  vmovaps [rsp+0x60], xmm7
00007aa3a45d14bb  vmovaps [rsp+0x70], xmm8
00007aa3a45d14c1  vmovaps [rsp+0x80], xmm9
00007aa3a45d14ca  vmovaps [rsp+0x90], xmm10
00007aa3a45d14d3  vmovaps [rsp+0xA0], xmm11
00007aa3a45d14dc  vmovaps [rsp+0xB0], xmm12
00007aa3a45d14e5  vmovaps [rsp+0xC0], xmm13
00007aa3a45d14ee  vmovaps [rsp+0xD0], xmm14
00007aa3a45d14f7  vmovaps [rsp+0xE0], xmm15
00007aa3a45d1500  sub rsp, 0x30
00007aa3a45d1504  movaps [rsp], xmm1
00007aa3a45d1508  movaps [rsp+0x10], xmm15
00007aa3a45d150e  movaps [rsp+0x20], xmm2
00007aa3a45d1513  lea rdi, [rsp]
00007aa3a45d1517  mov esi, 0x00
00007aa3a45d151c  mov rax, 0x5F551B683530
00007aa3a45d1526  call rax
00007aa3a45d1528  movaps xmm1, [rsp]
00007aa3a45d152c  add rsp, 0x30
00007aa3a45d1530  vmovaps xmm0, [rsp]
00007aa3a45d1535  vmovaps xmm2, [rsp+0x10]
00007aa3a45d153b  vmovaps xmm3, [rsp+0x20]
00007aa3a45d1541  vmovaps xmm4, [rsp+0x30]
00007aa3a45d1547  vmovaps xmm5, [rsp+0x40]
00007aa3a45d154d  vmovaps xmm6, [rsp+0x50]
00007aa3a45d1553  vmovaps xmm7, [rsp+0x60]
00007aa3a45d1559  vmovaps xmm8, [rsp+0x70]
00007aa3a45d155f  vmovaps xmm9, [rsp+0x80]
00007aa3a45d1568  vmovaps xmm10, [rsp+0x90]
00007aa3a45d1571  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d157a  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d1583  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d158c  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d1595  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d159e  add rsp, 0xF0
00007aa3a45d15a5  pop r11
00007aa3a45d15a7  pop r10
00007aa3a45d15a9  pop r9
00007aa3a45d15ab  pop r8
00007aa3a45d15ad  pop rsi
00007aa3a45d15ae  pop rdi
00007aa3a45d15af  pop rdx
00007aa3a45d15b0  pop rcx
00007aa3a45d15b1  pop rax
00007aa3a45d15b2  add rsp, 0x08
00007aa3a45d15b6  jmp 0x00007AA3A45CF8AC
00007aa3a45d15bb  sub rsp, 0x08
00007aa3a45d15bf  push rax
00007aa3a45d15c0  push rcx
00007aa3a45d15c1  push rdx
00007aa3a45d15c2  push rdi
00007aa3a45d15c3  push rsi
00007aa3a45d15c4  push r8
00007aa3a45d15c6  push r9
00007aa3a45d15c8  push r10
00007aa3a45d15ca  push r11
00007aa3a45d15cc  sub rsp, 0xF0
00007aa3a45d15d3  vmovaps [rsp], xmm0
00007aa3a45d15d8  vmovaps [rsp+0x10], xmm1
00007aa3a45d15de  vmovaps [rsp+0x20], xmm2
00007aa3a45d15e4  vmovaps [rsp+0x30], xmm3
00007aa3a45d15ea  vmovaps [rsp+0x40], xmm4
00007aa3a45d15f0  vmovaps [rsp+0x50], xmm5
00007aa3a45d15f6  vmovaps [rsp+0x60], xmm6
00007aa3a45d15fc  vmovaps [rsp+0x70], xmm7
00007aa3a45d1602  vmovaps [rsp+0x80], xmm8
00007aa3a45d160b  vmovaps [rsp+0x90], xmm9
00007aa3a45d1614  vmovaps [rsp+0xA0], xmm10
00007aa3a45d161d  vmovaps [rsp+0xB0], xmm11
00007aa3a45d1626  vmovaps [rsp+0xC0], xmm12
00007aa3a45d162f  vmovaps [rsp+0xD0], xmm13
00007aa3a45d1638  vmovaps [rsp+0xE0], xmm15
00007aa3a45d1641  sub rsp, 0x30
00007aa3a45d1645  movaps [rsp], xmm14
00007aa3a45d164a  movaps [rsp+0x10], xmm2
00007aa3a45d164f  movaps [rsp+0x20], xmm15
00007aa3a45d1655  lea rdi, [rsp]
00007aa3a45d1659  mov esi, 0x00
00007aa3a45d165e  mov rax, 0x5F551B683530
00007aa3a45d1668  call rax
00007aa3a45d166a  movaps xmm14, [rsp]
00007aa3a45d166f  add rsp, 0x30
00007aa3a45d1673  vmovaps xmm0, [rsp]
00007aa3a45d1678  vmovaps xmm1, [rsp+0x10]
00007aa3a45d167e  vmovaps xmm2, [rsp+0x20]
00007aa3a45d1684  vmovaps xmm3, [rsp+0x30]
00007aa3a45d168a  vmovaps xmm4, [rsp+0x40]
00007aa3a45d1690  vmovaps xmm5, [rsp+0x50]
00007aa3a45d1696  vmovaps xmm6, [rsp+0x60]
00007aa3a45d169c  vmovaps xmm7, [rsp+0x70]
00007aa3a45d16a2  vmovaps xmm8, [rsp+0x80]
00007aa3a45d16ab  vmovaps xmm9, [rsp+0x90]
00007aa3a45d16b4  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d16bd  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d16c6  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d16cf  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d16d8  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d16e1  add rsp, 0xF0
00007aa3a45d16e8  pop r11
00007aa3a45d16ea  pop r10
00007aa3a45d16ec  pop r9
00007aa3a45d16ee  pop r8
00007aa3a45d16f0  pop rsi
00007aa3a45d16f1  pop rdi
00007aa3a45d16f2  pop rdx
00007aa3a45d16f3  pop rcx
00007aa3a45d16f4  pop rax
00007aa3a45d16f5  add rsp, 0x08
00007aa3a45d16f9  jmp 0x00007AA3A45CF8E7
00007aa3a45d16fe  sub rsp, 0x08
00007aa3a45d1702  push rax
00007aa3a45d1703  push rcx
00007aa3a45d1704  push rdx
00007aa3a45d1705  push rdi
00007aa3a45d1706  push rsi
00007aa3a45d1707  push r8
00007aa3a45d1709  push r9
00007aa3a45d170b  push r10
00007aa3a45d170d  push r11
00007aa3a45d170f  sub rsp, 0xF0
00007aa3a45d1716  vmovaps [rsp], xmm0
00007aa3a45d171b  vmovaps [rsp+0x10], xmm1
00007aa3a45d1721  vmovaps [rsp+0x20], xmm2
00007aa3a45d1727  vmovaps [rsp+0x30], xmm3
00007aa3a45d172d  vmovaps [rsp+0x40], xmm4
00007aa3a45d1733  vmovaps [rsp+0x50], xmm5
00007aa3a45d1739  vmovaps [rsp+0x60], xmm6
00007aa3a45d173f  vmovaps [rsp+0x70], xmm7
00007aa3a45d1745  vmovaps [rsp+0x80], xmm8
00007aa3a45d174e  vmovaps [rsp+0x90], xmm9
00007aa3a45d1757  vmovaps [rsp+0xA0], xmm10
00007aa3a45d1760  vmovaps [rsp+0xB0], xmm11
00007aa3a45d1769  vmovaps [rsp+0xC0], xmm12
00007aa3a45d1772  vmovaps [rsp+0xD0], xmm13
00007aa3a45d177b  vmovaps [rsp+0xE0], xmm14
00007aa3a45d1784  sub rsp, 0x30
00007aa3a45d1788  movaps [rsp], xmm15
00007aa3a45d178d  movaps [rsp+0x10], xmm2
00007aa3a45d1792  movaps [rsp+0x20], xmm1
00007aa3a45d1797  lea rdi, [rsp]
00007aa3a45d179b  mov esi, 0x00
00007aa3a45d17a0  mov rax, 0x5F551B683530
00007aa3a45d17aa  call rax
00007aa3a45d17ac  movaps xmm15, [rsp]
00007aa3a45d17b1  add rsp, 0x30
00007aa3a45d17b5  vmovaps xmm0, [rsp]
00007aa3a45d17ba  vmovaps xmm1, [rsp+0x10]
00007aa3a45d17c0  vmovaps xmm2, [rsp+0x20]
00007aa3a45d17c6  vmovaps xmm3, [rsp+0x30]
00007aa3a45d17cc  vmovaps xmm4, [rsp+0x40]
00007aa3a45d17d2  vmovaps xmm5, [rsp+0x50]
00007aa3a45d17d8  vmovaps xmm6, [rsp+0x60]
00007aa3a45d17de  vmovaps xmm7, [rsp+0x70]
00007aa3a45d17e4  vmovaps xmm8, [rsp+0x80]
00007aa3a45d17ed  vmovaps xmm9, [rsp+0x90]
00007aa3a45d17f6  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d17ff  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d1808  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d1811  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d181a  vmovaps xmm14, [rsp+0xE0]
00007aa3a45d1823  add rsp, 0xF0
00007aa3a45d182a  pop r11
00007aa3a45d182c  pop r10
00007aa3a45d182e  pop r9
00007aa3a45d1830  pop r8
00007aa3a45d1832  pop rsi
00007aa3a45d1833  pop rdi
00007aa3a45d1834  pop rdx
00007aa3a45d1835  pop rcx
00007aa3a45d1836  pop rax
00007aa3a45d1837  add rsp, 0x08
00007aa3a45d183b  jmp 0x00007AA3A45CF923
00007aa3a45d1840  call 0x00007AA3A43FF430
00007aa3a45d1845  jmp 0x00007AA3A45CF930
00007aa3a45d184a  sub rsp, 0x08
00007aa3a45d184e  push rax
00007aa3a45d184f  push rcx
00007aa3a45d1850  push rdx
00007aa3a45d1851  push rdi
00007aa3a45d1852  push rsi
00007aa3a45d1853  push r8
00007aa3a45d1855  push r9
00007aa3a45d1857  push r10
00007aa3a45d1859  push r11
00007aa3a45d185b  sub rsp, 0xF0
00007aa3a45d1862  vmovaps [rsp], xmm0
00007aa3a45d1867  vmovaps [rsp+0x10], xmm1
00007aa3a45d186d  vmovaps [rsp+0x20], xmm3
00007aa3a45d1873  vmovaps [rsp+0x30], xmm4
00007aa3a45d1879  vmovaps [rsp+0x40], xmm5
00007aa3a45d187f  vmovaps [rsp+0x50], xmm6
00007aa3a45d1885  vmovaps [rsp+0x60], xmm7
00007aa3a45d188b  vmovaps [rsp+0x70], xmm8
00007aa3a45d1891  vmovaps [rsp+0x80], xmm9
00007aa3a45d189a  vmovaps [rsp+0x90], xmm10
00007aa3a45d18a3  vmovaps [rsp+0xA0], xmm11
00007aa3a45d18ac  vmovaps [rsp+0xB0], xmm12
00007aa3a45d18b5  vmovaps [rsp+0xC0], xmm13
00007aa3a45d18be  vmovaps [rsp+0xD0], xmm14
00007aa3a45d18c7  vmovaps [rsp+0xE0], xmm15
00007aa3a45d18d0  sub rsp, 0x30
00007aa3a45d18d4  movaps [rsp], xmm2
00007aa3a45d18d8  movaps [rsp+0x10], xmm1
00007aa3a45d18dd  movaps [rsp+0x20], xmm14
00007aa3a45d18e3  lea rdi, [rsp]
00007aa3a45d18e7  mov esi, 0x00
00007aa3a45d18ec  mov rax, 0x5F551B683530
00007aa3a45d18f6  call rax
00007aa3a45d18f8  movaps xmm2, [rsp]
00007aa3a45d18fc  add rsp, 0x30
00007aa3a45d1900  vmovaps xmm0, [rsp]
00007aa3a45d1905  vmovaps xmm1, [rsp+0x10]
00007aa3a45d190b  vmovaps xmm3, [rsp+0x20]
00007aa3a45d1911  vmovaps xmm4, [rsp+0x30]
00007aa3a45d1917  vmovaps xmm5, [rsp+0x40]
00007aa3a45d191d  vmovaps xmm6, [rsp+0x50]
00007aa3a45d1923  vmovaps xmm7, [rsp+0x60]
00007aa3a45d1929  vmovaps xmm8, [rsp+0x70]
00007aa3a45d192f  vmovaps xmm9, [rsp+0x80]
00007aa3a45d1938  vmovaps xmm10, [rsp+0x90]
00007aa3a45d1941  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d194a  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d1953  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d195c  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d1965  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d196e  add rsp, 0xF0
00007aa3a45d1975  pop r11
00007aa3a45d1977  pop r10
00007aa3a45d1979  pop r9
00007aa3a45d197b  pop r8
00007aa3a45d197d  pop rsi
00007aa3a45d197e  pop rdi
00007aa3a45d197f  pop rdx
00007aa3a45d1980  pop rcx
00007aa3a45d1981  pop rax
00007aa3a45d1982  add rsp, 0x08
00007aa3a45d1986  jmp 0x00007AA3A45CF96D
00007aa3a45d198b  sub rsp, 0x08
00007aa3a45d198f  push rax
00007aa3a45d1990  push rcx
00007aa3a45d1991  push rdx
00007aa3a45d1992  push rdi
00007aa3a45d1993  push rsi
00007aa3a45d1994  push r8
00007aa3a45d1996  push r9
00007aa3a45d1998  push r10
00007aa3a45d199a  push r11
00007aa3a45d199c  sub rsp, 0xF0
00007aa3a45d19a3  vmovaps [rsp], xmm0
00007aa3a45d19a8  vmovaps [rsp+0x10], xmm1
00007aa3a45d19ae  vmovaps [rsp+0x20], xmm2
00007aa3a45d19b4  vmovaps [rsp+0x30], xmm3
00007aa3a45d19ba  vmovaps [rsp+0x40], xmm4
00007aa3a45d19c0  vmovaps [rsp+0x50], xmm5
00007aa3a45d19c6  vmovaps [rsp+0x60], xmm6
00007aa3a45d19cc  vmovaps [rsp+0x70], xmm7
00007aa3a45d19d2  vmovaps [rsp+0x80], xmm8
00007aa3a45d19db  vmovaps [rsp+0x90], xmm9
00007aa3a45d19e4  vmovaps [rsp+0xA0], xmm10
00007aa3a45d19ed  vmovaps [rsp+0xB0], xmm11
00007aa3a45d19f6  vmovaps [rsp+0xC0], xmm12
00007aa3a45d19ff  vmovaps [rsp+0xD0], xmm13
00007aa3a45d1a08  vmovaps [rsp+0xE0], xmm14
00007aa3a45d1a11  sub rsp, 0x30
00007aa3a45d1a15  movaps [rsp], xmm15
00007aa3a45d1a1a  movaps [rsp+0x10], xmm14
00007aa3a45d1a20  movaps [rsp+0x20], xmm1
00007aa3a45d1a25  lea rdi, [rsp]
00007aa3a45d1a29  mov esi, 0x00
00007aa3a45d1a2e  mov rax, 0x5F551B683530
00007aa3a45d1a38  call rax
00007aa3a45d1a3a  movaps xmm15, [rsp]
00007aa3a45d1a3f  add rsp, 0x30
00007aa3a45d1a43  vmovaps xmm0, [rsp]
00007aa3a45d1a48  vmovaps xmm1, [rsp+0x10]
00007aa3a45d1a4e  vmovaps xmm2, [rsp+0x20]
00007aa3a45d1a54  vmovaps xmm3, [rsp+0x30]
00007aa3a45d1a5a  vmovaps xmm4, [rsp+0x40]
00007aa3a45d1a60  vmovaps xmm5, [rsp+0x50]
00007aa3a45d1a66  vmovaps xmm6, [rsp+0x60]
00007aa3a45d1a6c  vmovaps xmm7, [rsp+0x70]
00007aa3a45d1a72  vmovaps xmm8, [rsp+0x80]
00007aa3a45d1a7b  vmovaps xmm9, [rsp+0x90]
00007aa3a45d1a84  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d1a8d  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d1a96  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d1a9f  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d1aa8  vmovaps xmm14, [rsp+0xE0]
00007aa3a45d1ab1  add rsp, 0xF0
00007aa3a45d1ab8  pop r11
00007aa3a45d1aba  pop r10
00007aa3a45d1abc  pop r9
00007aa3a45d1abe  pop r8
00007aa3a45d1ac0  pop rsi
00007aa3a45d1ac1  pop rdi
00007aa3a45d1ac2  pop rdx
00007aa3a45d1ac3  pop rcx
00007aa3a45d1ac4  pop rax
00007aa3a45d1ac5  add rsp, 0x08
00007aa3a45d1ac9  jmp 0x00007AA3A45CF9E7
00007aa3a45d1ace  call 0x00007AA3A43FF430
00007aa3a45d1ad3  jmp 0x00007AA3A45CF9F4
00007aa3a45d1ad8  sub rsp, 0x08
00007aa3a45d1adc  push rax
00007aa3a45d1add  push rcx
00007aa3a45d1ade  push rdx
00007aa3a45d1adf  push rdi
00007aa3a45d1ae0  push rsi
00007aa3a45d1ae1  push r8
00007aa3a45d1ae3  push r9
00007aa3a45d1ae5  push r10
00007aa3a45d1ae7  push r11
00007aa3a45d1ae9  sub rsp, 0xF0
00007aa3a45d1af0  vmovaps [rsp], xmm0
00007aa3a45d1af5  vmovaps [rsp+0x10], xmm1
00007aa3a45d1afb  vmovaps [rsp+0x20], xmm2
00007aa3a45d1b01  vmovaps [rsp+0x30], xmm3
00007aa3a45d1b07  vmovaps [rsp+0x40], xmm4
00007aa3a45d1b0d  vmovaps [rsp+0x50], xmm5
00007aa3a45d1b13  vmovaps [rsp+0x60], xmm6
00007aa3a45d1b19  vmovaps [rsp+0x70], xmm7
00007aa3a45d1b1f  vmovaps [rsp+0x80], xmm8
00007aa3a45d1b28  vmovaps [rsp+0x90], xmm9
00007aa3a45d1b31  vmovaps [rsp+0xA0], xmm10
00007aa3a45d1b3a  vmovaps [rsp+0xB0], xmm11
00007aa3a45d1b43  vmovaps [rsp+0xC0], xmm12
00007aa3a45d1b4c  vmovaps [rsp+0xD0], xmm13
00007aa3a45d1b55  vmovaps [rsp+0xE0], xmm15
00007aa3a45d1b5e  sub rsp, 0x30
00007aa3a45d1b62  movaps [rsp], xmm14
00007aa3a45d1b67  movaps [rsp+0x10], xmm13
00007aa3a45d1b6d  movaps [rsp+0x20], xmm1
00007aa3a45d1b72  lea rdi, [rsp]
00007aa3a45d1b76  mov esi, 0x00
00007aa3a45d1b7b  mov rax, 0x5F551B683530
00007aa3a45d1b85  call rax
00007aa3a45d1b87  movaps xmm14, [rsp]
00007aa3a45d1b8c  add rsp, 0x30
00007aa3a45d1b90  vmovaps xmm0, [rsp]
00007aa3a45d1b95  vmovaps xmm1, [rsp+0x10]
00007aa3a45d1b9b  vmovaps xmm2, [rsp+0x20]
00007aa3a45d1ba1  vmovaps xmm3, [rsp+0x30]
00007aa3a45d1ba7  vmovaps xmm4, [rsp+0x40]
00007aa3a45d1bad  vmovaps xmm5, [rsp+0x50]
00007aa3a45d1bb3  vmovaps xmm6, [rsp+0x60]
00007aa3a45d1bb9  vmovaps xmm7, [rsp+0x70]
00007aa3a45d1bbf  vmovaps xmm8, [rsp+0x80]
00007aa3a45d1bc8  vmovaps xmm9, [rsp+0x90]
00007aa3a45d1bd1  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d1bda  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d1be3  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d1bec  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d1bf5  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d1bfe  add rsp, 0xF0
00007aa3a45d1c05  pop r11
00007aa3a45d1c07  pop r10
00007aa3a45d1c09  pop r9
00007aa3a45d1c0b  pop r8
00007aa3a45d1c0d  pop rsi
00007aa3a45d1c0e  pop rdi
00007aa3a45d1c0f  pop rdx
00007aa3a45d1c10  pop rcx
00007aa3a45d1c11  pop rax
00007aa3a45d1c12  add rsp, 0x08
00007aa3a45d1c16  jmp 0x00007AA3A45CFAAF
00007aa3a45d1c1b  sub rsp, 0x08
00007aa3a45d1c1f  push rax
00007aa3a45d1c20  push rcx
00007aa3a45d1c21  push rdx
00007aa3a45d1c22  push rdi
00007aa3a45d1c23  push rsi
00007aa3a45d1c24  push r8
00007aa3a45d1c26  push r9
00007aa3a45d1c28  push r10
00007aa3a45d1c2a  push r11
00007aa3a45d1c2c  sub rsp, 0xF0
00007aa3a45d1c33  vmovaps [rsp], xmm0
00007aa3a45d1c38  vmovaps [rsp+0x10], xmm1
00007aa3a45d1c3e  vmovaps [rsp+0x20], xmm2
00007aa3a45d1c44  vmovaps [rsp+0x30], xmm3
00007aa3a45d1c4a  vmovaps [rsp+0x40], xmm4
00007aa3a45d1c50  vmovaps [rsp+0x50], xmm5
00007aa3a45d1c56  vmovaps [rsp+0x60], xmm6
00007aa3a45d1c5c  vmovaps [rsp+0x70], xmm7
00007aa3a45d1c62  vmovaps [rsp+0x80], xmm8
00007aa3a45d1c6b  vmovaps [rsp+0x90], xmm9
00007aa3a45d1c74  vmovaps [rsp+0xA0], xmm10
00007aa3a45d1c7d  vmovaps [rsp+0xB0], xmm11
00007aa3a45d1c86  vmovaps [rsp+0xC0], xmm12
00007aa3a45d1c8f  vmovaps [rsp+0xD0], xmm13
00007aa3a45d1c98  vmovaps [rsp+0xE0], xmm14
00007aa3a45d1ca1  sub rsp, 0x30
00007aa3a45d1ca5  movaps [rsp], xmm15
00007aa3a45d1caa  movaps [rsp+0x10], xmm13
00007aa3a45d1cb0  movaps [rsp+0x20], xmm1
00007aa3a45d1cb5  lea rdi, [rsp]
00007aa3a45d1cb9  mov esi, 0x00
00007aa3a45d1cbe  mov rax, 0x5F551B683530
00007aa3a45d1cc8  call rax
00007aa3a45d1cca  movaps xmm15, [rsp]
00007aa3a45d1ccf  add rsp, 0x30
00007aa3a45d1cd3  vmovaps xmm0, [rsp]
00007aa3a45d1cd8  vmovaps xmm1, [rsp+0x10]
00007aa3a45d1cde  vmovaps xmm2, [rsp+0x20]
00007aa3a45d1ce4  vmovaps xmm3, [rsp+0x30]
00007aa3a45d1cea  vmovaps xmm4, [rsp+0x40]
00007aa3a45d1cf0  vmovaps xmm5, [rsp+0x50]
00007aa3a45d1cf6  vmovaps xmm6, [rsp+0x60]
00007aa3a45d1cfc  vmovaps xmm7, [rsp+0x70]
00007aa3a45d1d02  vmovaps xmm8, [rsp+0x80]
00007aa3a45d1d0b  vmovaps xmm9, [rsp+0x90]
00007aa3a45d1d14  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d1d1d  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d1d26  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d1d2f  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d1d38  vmovaps xmm14, [rsp+0xE0]
00007aa3a45d1d41  add rsp, 0xF0
00007aa3a45d1d48  pop r11
00007aa3a45d1d4a  pop r10
00007aa3a45d1d4c  pop r9
00007aa3a45d1d4e  pop r8
00007aa3a45d1d50  pop rsi
00007aa3a45d1d51  pop rdi
00007aa3a45d1d52  pop rdx
00007aa3a45d1d53  pop rcx
00007aa3a45d1d54  pop rax
00007aa3a45d1d55  add rsp, 0x08
00007aa3a45d1d59  jmp 0x00007AA3A45CFAEB
00007aa3a45d1d5e  call 0x00007AA3A43FF430
00007aa3a45d1d63  jmp 0x00007AA3A45CFAF8
00007aa3a45d1d68  sub rsp, 0x08
00007aa3a45d1d6c  push rax
00007aa3a45d1d6d  push rcx
00007aa3a45d1d6e  push rdx
00007aa3a45d1d6f  push rdi
00007aa3a45d1d70  push rsi
00007aa3a45d1d71  push r8
00007aa3a45d1d73  push r9
00007aa3a45d1d75  push r10
00007aa3a45d1d77  push r11
00007aa3a45d1d79  sub rsp, 0xF0
00007aa3a45d1d80  vmovaps [rsp], xmm0
00007aa3a45d1d85  vmovaps [rsp+0x10], xmm1
00007aa3a45d1d8b  vmovaps [rsp+0x20], xmm2
00007aa3a45d1d91  vmovaps [rsp+0x30], xmm3
00007aa3a45d1d97  vmovaps [rsp+0x40], xmm4
00007aa3a45d1d9d  vmovaps [rsp+0x50], xmm5
00007aa3a45d1da3  vmovaps [rsp+0x60], xmm6
00007aa3a45d1da9  vmovaps [rsp+0x70], xmm7
00007aa3a45d1daf  vmovaps [rsp+0x80], xmm8
00007aa3a45d1db8  vmovaps [rsp+0x90], xmm9
00007aa3a45d1dc1  vmovaps [rsp+0xA0], xmm10
00007aa3a45d1dca  vmovaps [rsp+0xB0], xmm11
00007aa3a45d1dd3  vmovaps [rsp+0xC0], xmm12
00007aa3a45d1ddc  vmovaps [rsp+0xD0], xmm13
00007aa3a45d1de5  vmovaps [rsp+0xE0], xmm15
00007aa3a45d1dee  sub rsp, 0x30
00007aa3a45d1df2  movaps [rsp], xmm14
00007aa3a45d1df7  movaps [rsp+0x10], xmm13
00007aa3a45d1dfd  movaps [rsp+0x20], xmm2
00007aa3a45d1e02  lea rdi, [rsp]
00007aa3a45d1e06  mov esi, 0x00
00007aa3a45d1e0b  mov rax, 0x5F551B683530
00007aa3a45d1e15  call rax
00007aa3a45d1e17  movaps xmm14, [rsp]
00007aa3a45d1e1c  add rsp, 0x30
00007aa3a45d1e20  vmovaps xmm0, [rsp]
00007aa3a45d1e25  vmovaps xmm1, [rsp+0x10]
00007aa3a45d1e2b  vmovaps xmm2, [rsp+0x20]
00007aa3a45d1e31  vmovaps xmm3, [rsp+0x30]
00007aa3a45d1e37  vmovaps xmm4, [rsp+0x40]
00007aa3a45d1e3d  vmovaps xmm5, [rsp+0x50]
00007aa3a45d1e43  vmovaps xmm6, [rsp+0x60]
00007aa3a45d1e49  vmovaps xmm7, [rsp+0x70]
00007aa3a45d1e4f  vmovaps xmm8, [rsp+0x80]
00007aa3a45d1e58  vmovaps xmm9, [rsp+0x90]
00007aa3a45d1e61  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d1e6a  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d1e73  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d1e7c  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d1e85  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d1e8e  add rsp, 0xF0
00007aa3a45d1e95  pop r11
00007aa3a45d1e97  pop r10
00007aa3a45d1e99  pop r9
00007aa3a45d1e9b  pop r8
00007aa3a45d1e9d  pop rsi
00007aa3a45d1e9e  pop rdi
00007aa3a45d1e9f  pop rdx
00007aa3a45d1ea0  pop rcx
00007aa3a45d1ea1  pop rax
00007aa3a45d1ea2  add rsp, 0x08
00007aa3a45d1ea6  jmp 0x00007AA3A45CFB24
00007aa3a45d1eab  sub rsp, 0x08
00007aa3a45d1eaf  push rax
00007aa3a45d1eb0  push rcx
00007aa3a45d1eb1  push rdx
00007aa3a45d1eb2  push rdi
00007aa3a45d1eb3  push rsi
00007aa3a45d1eb4  push r8
00007aa3a45d1eb6  push r9
00007aa3a45d1eb8  push r10
00007aa3a45d1eba  push r11
00007aa3a45d1ebc  sub rsp, 0xF0
00007aa3a45d1ec3  vmovaps [rsp], xmm0
00007aa3a45d1ec8  vmovaps [rsp+0x10], xmm2
00007aa3a45d1ece  vmovaps [rsp+0x20], xmm3
00007aa3a45d1ed4  vmovaps [rsp+0x30], xmm4
00007aa3a45d1eda  vmovaps [rsp+0x40], xmm5
00007aa3a45d1ee0  vmovaps [rsp+0x50], xmm6
00007aa3a45d1ee6  vmovaps [rsp+0x60], xmm7
00007aa3a45d1eec  vmovaps [rsp+0x70], xmm8
00007aa3a45d1ef2  vmovaps [rsp+0x80], xmm9
00007aa3a45d1efb  vmovaps [rsp+0x90], xmm10
00007aa3a45d1f04  vmovaps [rsp+0xA0], xmm11
00007aa3a45d1f0d  vmovaps [rsp+0xB0], xmm12
00007aa3a45d1f16  vmovaps [rsp+0xC0], xmm13
00007aa3a45d1f1f  vmovaps [rsp+0xD0], xmm14
00007aa3a45d1f28  vmovaps [rsp+0xE0], xmm15
00007aa3a45d1f31  sub rsp, 0x30
00007aa3a45d1f35  movaps [rsp], xmm1
00007aa3a45d1f39  movaps [rsp+0x10], xmm13
00007aa3a45d1f3f  movaps [rsp+0x20], xmm2
00007aa3a45d1f44  lea rdi, [rsp]
00007aa3a45d1f48  mov esi, 0x00
00007aa3a45d1f4d  mov rax, 0x5F551B683530
00007aa3a45d1f57  call rax
00007aa3a45d1f59  movaps xmm1, [rsp]
00007aa3a45d1f5d  add rsp, 0x30
00007aa3a45d1f61  vmovaps xmm0, [rsp]
00007aa3a45d1f66  vmovaps xmm2, [rsp+0x10]
00007aa3a45d1f6c  vmovaps xmm3, [rsp+0x20]
00007aa3a45d1f72  vmovaps xmm4, [rsp+0x30]
00007aa3a45d1f78  vmovaps xmm5, [rsp+0x40]
00007aa3a45d1f7e  vmovaps xmm6, [rsp+0x50]
00007aa3a45d1f84  vmovaps xmm7, [rsp+0x60]
00007aa3a45d1f8a  vmovaps xmm8, [rsp+0x70]
00007aa3a45d1f90  vmovaps xmm9, [rsp+0x80]
00007aa3a45d1f99  vmovaps xmm10, [rsp+0x90]
00007aa3a45d1fa2  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d1fab  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d1fb4  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d1fbd  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d1fc6  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d1fcf  add rsp, 0xF0
00007aa3a45d1fd6  pop r11
00007aa3a45d1fd8  pop r10
00007aa3a45d1fda  pop r9
00007aa3a45d1fdc  pop r8
00007aa3a45d1fde  pop rsi
00007aa3a45d1fdf  pop rdi
00007aa3a45d1fe0  pop rdx
00007aa3a45d1fe1  pop rcx
00007aa3a45d1fe2  pop rax
00007aa3a45d1fe3  add rsp, 0x08
00007aa3a45d1fe7  jmp 0x00007AA3A45CFB52
00007aa3a45d1fec  sub rsp, 0x08
00007aa3a45d1ff0  push rax
00007aa3a45d1ff1  push rcx
00007aa3a45d1ff2  push rdx
00007aa3a45d1ff3  push rdi
00007aa3a45d1ff4  push rsi
00007aa3a45d1ff5  push r8
00007aa3a45d1ff7  push r9
00007aa3a45d1ff9  push r10
00007aa3a45d1ffb  push r11
00007aa3a45d1ffd  sub rsp, 0xF0
00007aa3a45d2004  vmovaps [rsp], xmm0
00007aa3a45d2009  vmovaps [rsp+0x10], xmm1
00007aa3a45d200f  vmovaps [rsp+0x20], xmm3
00007aa3a45d2015  vmovaps [rsp+0x30], xmm4
00007aa3a45d201b  vmovaps [rsp+0x40], xmm5
00007aa3a45d2021  vmovaps [rsp+0x50], xmm6
00007aa3a45d2027  vmovaps [rsp+0x60], xmm7
00007aa3a45d202d  vmovaps [rsp+0x70], xmm8
00007aa3a45d2033  vmovaps [rsp+0x80], xmm9
00007aa3a45d203c  vmovaps [rsp+0x90], xmm10
00007aa3a45d2045  vmovaps [rsp+0xA0], xmm11
00007aa3a45d204e  vmovaps [rsp+0xB0], xmm12
00007aa3a45d2057  vmovaps [rsp+0xC0], xmm13
00007aa3a45d2060  vmovaps [rsp+0xD0], xmm14
00007aa3a45d2069  vmovaps [rsp+0xE0], xmm15
00007aa3a45d2072  sub rsp, 0x30
00007aa3a45d2076  movaps [rsp], xmm2
00007aa3a45d207a  movaps [rsp+0x10], xmm1
00007aa3a45d207f  movaps [rsp+0x20], xmm13
00007aa3a45d2085  lea rdi, [rsp]
00007aa3a45d2089  mov esi, 0x00
00007aa3a45d208e  mov rax, 0x5F551B683530
00007aa3a45d2098  call rax
00007aa3a45d209a  movaps xmm2, [rsp]
00007aa3a45d209e  add rsp, 0x30
00007aa3a45d20a2  vmovaps xmm0, [rsp]
00007aa3a45d20a7  vmovaps xmm1, [rsp+0x10]
00007aa3a45d20ad  vmovaps xmm3, [rsp+0x20]
00007aa3a45d20b3  vmovaps xmm4, [rsp+0x30]
00007aa3a45d20b9  vmovaps xmm5, [rsp+0x40]
00007aa3a45d20bf  vmovaps xmm6, [rsp+0x50]
00007aa3a45d20c5  vmovaps xmm7, [rsp+0x60]
00007aa3a45d20cb  vmovaps xmm8, [rsp+0x70]
00007aa3a45d20d1  vmovaps xmm9, [rsp+0x80]
00007aa3a45d20da  vmovaps xmm10, [rsp+0x90]
00007aa3a45d20e3  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d20ec  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d20f5  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d20fe  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d2107  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d2110  add rsp, 0xF0
00007aa3a45d2117  pop r11
00007aa3a45d2119  pop r10
00007aa3a45d211b  pop r9
00007aa3a45d211d  pop r8
00007aa3a45d211f  pop rsi
00007aa3a45d2120  pop rdi
00007aa3a45d2121  pop rdx
00007aa3a45d2122  pop rcx
00007aa3a45d2123  pop rax
00007aa3a45d2124  add rsp, 0x08
00007aa3a45d2128  jmp 0x00007AA3A45CFBAB
00007aa3a45d212d  call 0x00007AA3A43FF430
00007aa3a45d2132  jmp 0x00007AA3A45CFBB8
00007aa3a45d2137  sub rsp, 0x08
00007aa3a45d213b  push rax
00007aa3a45d213c  push rcx
00007aa3a45d213d  push rdx
00007aa3a45d213e  push rdi
00007aa3a45d213f  push rsi
00007aa3a45d2140  push r8
00007aa3a45d2142  push r9
00007aa3a45d2144  push r10
00007aa3a45d2146  push r11
00007aa3a45d2148  sub rsp, 0xF0
00007aa3a45d214f  vmovaps [rsp], xmm0
00007aa3a45d2154  vmovaps [rsp+0x10], xmm1
00007aa3a45d215a  vmovaps [rsp+0x20], xmm2
00007aa3a45d2160  vmovaps [rsp+0x30], xmm3
00007aa3a45d2166  vmovaps [rsp+0x40], xmm4
00007aa3a45d216c  vmovaps [rsp+0x50], xmm5
00007aa3a45d2172  vmovaps [rsp+0x60], xmm6
00007aa3a45d2178  vmovaps [rsp+0x70], xmm7
00007aa3a45d217e  vmovaps [rsp+0x80], xmm8
00007aa3a45d2187  vmovaps [rsp+0x90], xmm9
00007aa3a45d2190  vmovaps [rsp+0xA0], xmm10
00007aa3a45d2199  vmovaps [rsp+0xB0], xmm11
00007aa3a45d21a2  vmovaps [rsp+0xC0], xmm12
00007aa3a45d21ab  vmovaps [rsp+0xD0], xmm13
00007aa3a45d21b4  vmovaps [rsp+0xE0], xmm14
00007aa3a45d21bd  sub rsp, 0x30
00007aa3a45d21c1  movaps [rsp], xmm15
00007aa3a45d21c6  movaps [rsp+0x10], xmm13
00007aa3a45d21cc  movaps [rsp+0x20], xmm1
00007aa3a45d21d1  lea rdi, [rsp]
00007aa3a45d21d5  mov esi, 0x00
00007aa3a45d21da  mov rax, 0x5F551B683530
00007aa3a45d21e4  call rax
00007aa3a45d21e6  movaps xmm15, [rsp]
00007aa3a45d21eb  add rsp, 0x30
00007aa3a45d21ef  vmovaps xmm0, [rsp]
00007aa3a45d21f4  vmovaps xmm1, [rsp+0x10]
00007aa3a45d21fa  vmovaps xmm2, [rsp+0x20]
00007aa3a45d2200  vmovaps xmm3, [rsp+0x30]
00007aa3a45d2206  vmovaps xmm4, [rsp+0x40]
00007aa3a45d220c  vmovaps xmm5, [rsp+0x50]
00007aa3a45d2212  vmovaps xmm6, [rsp+0x60]
00007aa3a45d2218  vmovaps xmm7, [rsp+0x70]
00007aa3a45d221e  vmovaps xmm8, [rsp+0x80]
00007aa3a45d2227  vmovaps xmm9, [rsp+0x90]
00007aa3a45d2230  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d2239  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d2242  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d224b  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d2254  vmovaps xmm14, [rsp+0xE0]
00007aa3a45d225d  add rsp, 0xF0
00007aa3a45d2264  pop r11
00007aa3a45d2266  pop r10
00007aa3a45d2268  pop r9
00007aa3a45d226a  pop r8
00007aa3a45d226c  pop rsi
00007aa3a45d226d  pop rdi
00007aa3a45d226e  pop rdx
00007aa3a45d226f  pop rcx
00007aa3a45d2270  pop rax
00007aa3a45d2271  add rsp, 0x08
00007aa3a45d2275  jmp 0x00007AA3A45CFBF7
00007aa3a45d227a  sub rsp, 0x08
00007aa3a45d227e  push rax
00007aa3a45d227f  push rcx
00007aa3a45d2280  push rdx
00007aa3a45d2281  push rdi
00007aa3a45d2282  push rsi
00007aa3a45d2283  push r8
00007aa3a45d2285  push r9
00007aa3a45d2287  push r10
00007aa3a45d2289  push r11
00007aa3a45d228b  sub rsp, 0xF0
00007aa3a45d2292  vmovaps [rsp], xmm0
00007aa3a45d2297  vmovaps [rsp+0x10], xmm1
00007aa3a45d229d  vmovaps [rsp+0x20], xmm2
00007aa3a45d22a3  vmovaps [rsp+0x30], xmm3
00007aa3a45d22a9  vmovaps [rsp+0x40], xmm4
00007aa3a45d22af  vmovaps [rsp+0x50], xmm5
00007aa3a45d22b5  vmovaps [rsp+0x60], xmm6
00007aa3a45d22bb  vmovaps [rsp+0x70], xmm7
00007aa3a45d22c1  vmovaps [rsp+0x80], xmm8
00007aa3a45d22ca  vmovaps [rsp+0x90], xmm9
00007aa3a45d22d3  vmovaps [rsp+0xA0], xmm10
00007aa3a45d22dc  vmovaps [rsp+0xB0], xmm11
00007aa3a45d22e5  vmovaps [rsp+0xC0], xmm12
00007aa3a45d22ee  vmovaps [rsp+0xD0], xmm13
00007aa3a45d22f7  vmovaps [rsp+0xE0], xmm15
00007aa3a45d2300  sub rsp, 0x30
00007aa3a45d2304  movaps [rsp], xmm14
00007aa3a45d2309  movaps [rsp+0x10], xmm11
00007aa3a45d230f  movaps [rsp+0x20], xmm1
00007aa3a45d2314  lea rdi, [rsp]
00007aa3a45d2318  mov esi, 0x00
00007aa3a45d231d  mov rax, 0x5F551B683530
00007aa3a45d2327  call rax
00007aa3a45d2329  movaps xmm14, [rsp]
00007aa3a45d232e  add rsp, 0x30
00007aa3a45d2332  vmovaps xmm0, [rsp]
00007aa3a45d2337  vmovaps xmm1, [rsp+0x10]
00007aa3a45d233d  vmovaps xmm2, [rsp+0x20]
00007aa3a45d2343  vmovaps xmm3, [rsp+0x30]
00007aa3a45d2349  vmovaps xmm4, [rsp+0x40]
00007aa3a45d234f  vmovaps xmm5, [rsp+0x50]
00007aa3a45d2355  vmovaps xmm6, [rsp+0x60]
00007aa3a45d235b  vmovaps xmm7, [rsp+0x70]
00007aa3a45d2361  vmovaps xmm8, [rsp+0x80]
00007aa3a45d236a  vmovaps xmm9, [rsp+0x90]
00007aa3a45d2373  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d237c  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d2385  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d238e  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d2397  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d23a0  add rsp, 0xF0
00007aa3a45d23a7  pop r11
00007aa3a45d23a9  pop r10
00007aa3a45d23ab  pop r9
00007aa3a45d23ad  pop r8
00007aa3a45d23af  pop rsi
00007aa3a45d23b0  pop rdi
00007aa3a45d23b1  pop rdx
00007aa3a45d23b2  pop rcx
00007aa3a45d23b3  pop rax
00007aa3a45d23b4  add rsp, 0x08
00007aa3a45d23b8  jmp 0x00007AA3A45CFC21
00007aa3a45d23bd  sub rsp, 0x08
00007aa3a45d23c1  push rax
00007aa3a45d23c2  push rcx
00007aa3a45d23c3  push rdx
00007aa3a45d23c4  push rdi
00007aa3a45d23c5  push rsi
00007aa3a45d23c6  push r8
00007aa3a45d23c8  push r9
00007aa3a45d23ca  push r10
00007aa3a45d23cc  push r11
00007aa3a45d23ce  sub rsp, 0xF0
00007aa3a45d23d5  vmovaps [rsp], xmm0
00007aa3a45d23da  vmovaps [rsp+0x10], xmm1
00007aa3a45d23e0  vmovaps [rsp+0x20], xmm2
00007aa3a45d23e6  vmovaps [rsp+0x30], xmm3
00007aa3a45d23ec  vmovaps [rsp+0x40], xmm4
00007aa3a45d23f2  vmovaps [rsp+0x50], xmm5
00007aa3a45d23f8  vmovaps [rsp+0x60], xmm6
00007aa3a45d23fe  vmovaps [rsp+0x70], xmm7
00007aa3a45d2404  vmovaps [rsp+0x80], xmm8
00007aa3a45d240d  vmovaps [rsp+0x90], xmm9
00007aa3a45d2416  vmovaps [rsp+0xA0], xmm10
00007aa3a45d241f  vmovaps [rsp+0xB0], xmm11
00007aa3a45d2428  vmovaps [rsp+0xC0], xmm12
00007aa3a45d2431  vmovaps [rsp+0xD0], xmm14
00007aa3a45d243a  vmovaps [rsp+0xE0], xmm15
00007aa3a45d2443  sub rsp, 0x30
00007aa3a45d2447  movaps [rsp], xmm13
00007aa3a45d244c  movaps [rsp+0x10], xmm11
00007aa3a45d2452  movaps [rsp+0x20], xmm1
00007aa3a45d2457  lea rdi, [rsp]
00007aa3a45d245b  mov esi, 0x00
00007aa3a45d2460  mov rax, 0x5F551B683530
00007aa3a45d246a  call rax
00007aa3a45d246c  movaps xmm13, [rsp]
00007aa3a45d2471  add rsp, 0x30
00007aa3a45d2475  vmovaps xmm0, [rsp]
00007aa3a45d247a  vmovaps xmm1, [rsp+0x10]
00007aa3a45d2480  vmovaps xmm2, [rsp+0x20]
00007aa3a45d2486  vmovaps xmm3, [rsp+0x30]
00007aa3a45d248c  vmovaps xmm4, [rsp+0x40]
00007aa3a45d2492  vmovaps xmm5, [rsp+0x50]
00007aa3a45d2498  vmovaps xmm6, [rsp+0x60]
00007aa3a45d249e  vmovaps xmm7, [rsp+0x70]
00007aa3a45d24a4  vmovaps xmm8, [rsp+0x80]
00007aa3a45d24ad  vmovaps xmm9, [rsp+0x90]
00007aa3a45d24b6  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d24bf  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d24c8  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d24d1  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d24da  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d24e3  add rsp, 0xF0
00007aa3a45d24ea  pop r11
00007aa3a45d24ec  pop r10
00007aa3a45d24ee  pop r9
00007aa3a45d24f0  pop r8
00007aa3a45d24f2  pop rsi
00007aa3a45d24f3  pop rdi
00007aa3a45d24f4  pop rdx
00007aa3a45d24f5  pop rcx
00007aa3a45d24f6  pop rax
00007aa3a45d24f7  add rsp, 0x08
00007aa3a45d24fb  jmp 0x00007AA3A45CFC76
00007aa3a45d2500  call 0x00007AA3A43FF430
00007aa3a45d2505  jmp 0x00007AA3A45CFC83
00007aa3a45d250a  sub rsp, 0x08
00007aa3a45d250e  push rax
00007aa3a45d250f  push rcx
00007aa3a45d2510  push rdx
00007aa3a45d2511  push rdi
00007aa3a45d2512  push rsi
00007aa3a45d2513  push r8
00007aa3a45d2515  push r9
00007aa3a45d2517  push r10
00007aa3a45d2519  push r11
00007aa3a45d251b  sub rsp, 0xF0
00007aa3a45d2522  vmovaps [rsp], xmm0
00007aa3a45d2527  vmovaps [rsp+0x10], xmm1
00007aa3a45d252d  vmovaps [rsp+0x20], xmm2
00007aa3a45d2533  vmovaps [rsp+0x30], xmm3
00007aa3a45d2539  vmovaps [rsp+0x40], xmm4
00007aa3a45d253f  vmovaps [rsp+0x50], xmm5
00007aa3a45d2545  vmovaps [rsp+0x60], xmm6
00007aa3a45d254b  vmovaps [rsp+0x70], xmm7
00007aa3a45d2551  vmovaps [rsp+0x80], xmm8
00007aa3a45d255a  vmovaps [rsp+0x90], xmm9
00007aa3a45d2563  vmovaps [rsp+0xA0], xmm10
00007aa3a45d256c  vmovaps [rsp+0xB0], xmm11
00007aa3a45d2575  vmovaps [rsp+0xC0], xmm12
00007aa3a45d257e  vmovaps [rsp+0xD0], xmm13
00007aa3a45d2587  vmovaps [rsp+0xE0], xmm14
00007aa3a45d2590  sub rsp, 0x30
00007aa3a45d2594  movaps [rsp], xmm15
00007aa3a45d2599  movaps [rsp+0x10], xmm11
00007aa3a45d259f  movaps [rsp+0x20], xmm1
00007aa3a45d25a4  lea rdi, [rsp]
00007aa3a45d25a8  mov esi, 0x00
00007aa3a45d25ad  mov rax, 0x5F551B683530
00007aa3a45d25b7  call rax
00007aa3a45d25b9  movaps xmm15, [rsp]
00007aa3a45d25be  add rsp, 0x30
00007aa3a45d25c2  vmovaps xmm0, [rsp]
00007aa3a45d25c7  vmovaps xmm1, [rsp+0x10]
00007aa3a45d25cd  vmovaps xmm2, [rsp+0x20]
00007aa3a45d25d3  vmovaps xmm3, [rsp+0x30]
00007aa3a45d25d9  vmovaps xmm4, [rsp+0x40]
00007aa3a45d25df  vmovaps xmm5, [rsp+0x50]
00007aa3a45d25e5  vmovaps xmm6, [rsp+0x60]
00007aa3a45d25eb  vmovaps xmm7, [rsp+0x70]
00007aa3a45d25f1  vmovaps xmm8, [rsp+0x80]
00007aa3a45d25fa  vmovaps xmm9, [rsp+0x90]
00007aa3a45d2603  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d260c  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d2615  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d261e  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d2627  vmovaps xmm14, [rsp+0xE0]
00007aa3a45d2630  add rsp, 0xF0
00007aa3a45d2637  pop r11
00007aa3a45d2639  pop r10
00007aa3a45d263b  pop r9
00007aa3a45d263d  pop r8
00007aa3a45d263f  pop rsi
00007aa3a45d2640  pop rdi
00007aa3a45d2641  pop rdx
00007aa3a45d2642  pop rcx
00007aa3a45d2643  pop rax
00007aa3a45d2644  add rsp, 0x08
00007aa3a45d2648  jmp 0x00007AA3A45CFCBC
00007aa3a45d264d  sub rsp, 0x08
00007aa3a45d2651  push rax
00007aa3a45d2652  push rcx
00007aa3a45d2653  push rdx
00007aa3a45d2654  push rdi
00007aa3a45d2655  push rsi
00007aa3a45d2656  push r8
00007aa3a45d2658  push r9
00007aa3a45d265a  push r10
00007aa3a45d265c  push r11
00007aa3a45d265e  sub rsp, 0xF0
00007aa3a45d2665  vmovaps [rsp], xmm0
00007aa3a45d266a  vmovaps [rsp+0x10], xmm1
00007aa3a45d2670  vmovaps [rsp+0x20], xmm2
00007aa3a45d2676  vmovaps [rsp+0x30], xmm3
00007aa3a45d267c  vmovaps [rsp+0x40], xmm4
00007aa3a45d2682  vmovaps [rsp+0x50], xmm5
00007aa3a45d2688  vmovaps [rsp+0x60], xmm6
00007aa3a45d268e  vmovaps [rsp+0x70], xmm7
00007aa3a45d2694  vmovaps [rsp+0x80], xmm8
00007aa3a45d269d  vmovaps [rsp+0x90], xmm9
00007aa3a45d26a6  vmovaps [rsp+0xA0], xmm10
00007aa3a45d26af  vmovaps [rsp+0xB0], xmm12
00007aa3a45d26b8  vmovaps [rsp+0xC0], xmm13
00007aa3a45d26c1  vmovaps [rsp+0xD0], xmm14
00007aa3a45d26ca  vmovaps [rsp+0xE0], xmm15
00007aa3a45d26d3  sub rsp, 0x30
00007aa3a45d26d7  movaps [rsp], xmm11
00007aa3a45d26dc  movaps [rsp+0x10], xmm6
00007aa3a45d26e1  movaps [rsp+0x20], xmm14
00007aa3a45d26e7  lea rdi, [rsp]
00007aa3a45d26eb  mov esi, 0x00
00007aa3a45d26f0  mov rax, 0x5F551B683530
00007aa3a45d26fa  call rax
00007aa3a45d26fc  movaps xmm11, [rsp]
00007aa3a45d2701  add rsp, 0x30
00007aa3a45d2705  vmovaps xmm0, [rsp]
00007aa3a45d270a  vmovaps xmm1, [rsp+0x10]
00007aa3a45d2710  vmovaps xmm2, [rsp+0x20]
00007aa3a45d2716  vmovaps xmm3, [rsp+0x30]
00007aa3a45d271c  vmovaps xmm4, [rsp+0x40]
00007aa3a45d2722  vmovaps xmm5, [rsp+0x50]
00007aa3a45d2728  vmovaps xmm6, [rsp+0x60]
00007aa3a45d272e  vmovaps xmm7, [rsp+0x70]
00007aa3a45d2734  vmovaps xmm8, [rsp+0x80]
00007aa3a45d273d  vmovaps xmm9, [rsp+0x90]
00007aa3a45d2746  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d274f  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d2758  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d2761  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d276a  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d2773  add rsp, 0xF0
00007aa3a45d277a  pop r11
00007aa3a45d277c  pop r10
00007aa3a45d277e  pop r9
00007aa3a45d2780  pop r8
00007aa3a45d2782  pop rsi
00007aa3a45d2783  pop rdi
00007aa3a45d2784  pop rdx
00007aa3a45d2785  pop rcx
00007aa3a45d2786  pop rax
00007aa3a45d2787  add rsp, 0x08
00007aa3a45d278b  jmp 0x00007AA3A45CFD34
00007aa3a45d2790  call 0x00007AA3A43FF430
00007aa3a45d2795  jmp 0x00007AA3A45CFD3E
00007aa3a45d279a  sub rsp, 0x08
00007aa3a45d279e  push rax
00007aa3a45d279f  push rcx
00007aa3a45d27a0  push rdx
00007aa3a45d27a1  push rdi
00007aa3a45d27a2  push rsi
00007aa3a45d27a3  push r8
00007aa3a45d27a5  push r9
00007aa3a45d27a7  push r10
00007aa3a45d27a9  push r11
00007aa3a45d27ab  sub rsp, 0xF0
00007aa3a45d27b2  vmovaps [rsp], xmm0
00007aa3a45d27b7  vmovaps [rsp+0x10], xmm1
00007aa3a45d27bd  vmovaps [rsp+0x20], xmm2
00007aa3a45d27c3  vmovaps [rsp+0x30], xmm3
00007aa3a45d27c9  vmovaps [rsp+0x40], xmm4
00007aa3a45d27cf  vmovaps [rsp+0x50], xmm5
00007aa3a45d27d5  vmovaps [rsp+0x60], xmm6
00007aa3a45d27db  vmovaps [rsp+0x70], xmm7
00007aa3a45d27e1  vmovaps [rsp+0x80], xmm8
00007aa3a45d27ea  vmovaps [rsp+0x90], xmm9
00007aa3a45d27f3  vmovaps [rsp+0xA0], xmm10
00007aa3a45d27fc  vmovaps [rsp+0xB0], xmm11
00007aa3a45d2805  vmovaps [rsp+0xC0], xmm12
00007aa3a45d280e  vmovaps [rsp+0xD0], xmm13
00007aa3a45d2817  vmovaps [rsp+0xE0], xmm15
00007aa3a45d2820  sub rsp, 0x30
00007aa3a45d2824  movaps [rsp], xmm14
00007aa3a45d2829  movaps [rsp+0x10], xmm6
00007aa3a45d282e  movaps [rsp+0x20], xmm2
00007aa3a45d2833  lea rdi, [rsp]
00007aa3a45d2837  mov esi, 0x00
00007aa3a45d283c  mov rax, 0x5F551B683530
00007aa3a45d2846  call rax
00007aa3a45d2848  movaps xmm14, [rsp]
00007aa3a45d284d  add rsp, 0x30
00007aa3a45d2851  vmovaps xmm0, [rsp]
00007aa3a45d2856  vmovaps xmm1, [rsp+0x10]
00007aa3a45d285c  vmovaps xmm2, [rsp+0x20]
00007aa3a45d2862  vmovaps xmm3, [rsp+0x30]
00007aa3a45d2868  vmovaps xmm4, [rsp+0x40]
00007aa3a45d286e  vmovaps xmm5, [rsp+0x50]
00007aa3a45d2874  vmovaps xmm6, [rsp+0x60]
00007aa3a45d287a  vmovaps xmm7, [rsp+0x70]
00007aa3a45d2880  vmovaps xmm8, [rsp+0x80]
00007aa3a45d2889  vmovaps xmm9, [rsp+0x90]
00007aa3a45d2892  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d289b  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d28a4  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d28ad  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d28b6  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d28bf  add rsp, 0xF0
00007aa3a45d28c6  pop r11
00007aa3a45d28c8  pop r10
00007aa3a45d28ca  pop r9
00007aa3a45d28cc  pop r8
00007aa3a45d28ce  pop rsi
00007aa3a45d28cf  pop rdi
00007aa3a45d28d0  pop rdx
00007aa3a45d28d1  pop rcx
00007aa3a45d28d2  pop rax
00007aa3a45d28d3  add rsp, 0x08
00007aa3a45d28d7  jmp 0x00007AA3A45CFD72
00007aa3a45d28dc  sub rsp, 0x08
00007aa3a45d28e0  push rax
00007aa3a45d28e1  push rcx
00007aa3a45d28e2  push rdx
00007aa3a45d28e3  push rdi
00007aa3a45d28e4  push rsi
00007aa3a45d28e5  push r8
00007aa3a45d28e7  push r9
00007aa3a45d28e9  push r10
00007aa3a45d28eb  push r11
00007aa3a45d28ed  sub rsp, 0xF0
00007aa3a45d28f4  vmovaps [rsp], xmm0
00007aa3a45d28f9  vmovaps [rsp+0x10], xmm1
00007aa3a45d28ff  vmovaps [rsp+0x20], xmm2
00007aa3a45d2905  vmovaps [rsp+0x30], xmm3
00007aa3a45d290b  vmovaps [rsp+0x40], xmm4
00007aa3a45d2911  vmovaps [rsp+0x50], xmm5
00007aa3a45d2917  vmovaps [rsp+0x60], xmm7
00007aa3a45d291d  vmovaps [rsp+0x70], xmm8
00007aa3a45d2923  vmovaps [rsp+0x80], xmm9
00007aa3a45d292c  vmovaps [rsp+0x90], xmm10
00007aa3a45d2935  vmovaps [rsp+0xA0], xmm11
00007aa3a45d293e  vmovaps [rsp+0xB0], xmm12
00007aa3a45d2947  vmovaps [rsp+0xC0], xmm13
00007aa3a45d2950  vmovaps [rsp+0xD0], xmm14
00007aa3a45d2959  vmovaps [rsp+0xE0], xmm15
00007aa3a45d2962  sub rsp, 0x30
00007aa3a45d2966  movaps [rsp], xmm6
00007aa3a45d296a  movaps [rsp+0x10], xmm5
00007aa3a45d296f  movaps [rsp+0x20], xmm1
00007aa3a45d2974  lea rdi, [rsp]
00007aa3a45d2978  mov esi, 0x00
00007aa3a45d297d  mov rax, 0x5F551B683530
00007aa3a45d2987  call rax
00007aa3a45d2989  movaps xmm6, [rsp]
00007aa3a45d298d  add rsp, 0x30
00007aa3a45d2991  vmovaps xmm0, [rsp]
00007aa3a45d2996  vmovaps xmm1, [rsp+0x10]
00007aa3a45d299c  vmovaps xmm2, [rsp+0x20]
00007aa3a45d29a2  vmovaps xmm3, [rsp+0x30]
00007aa3a45d29a8  vmovaps xmm4, [rsp+0x40]
00007aa3a45d29ae  vmovaps xmm5, [rsp+0x50]
00007aa3a45d29b4  vmovaps xmm7, [rsp+0x60]
00007aa3a45d29ba  vmovaps xmm8, [rsp+0x70]
00007aa3a45d29c0  vmovaps xmm9, [rsp+0x80]
00007aa3a45d29c9  vmovaps xmm10, [rsp+0x90]
00007aa3a45d29d2  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d29db  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d29e4  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d29ed  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d29f6  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d29ff  add rsp, 0xF0
00007aa3a45d2a06  pop r11
00007aa3a45d2a08  pop r10
00007aa3a45d2a0a  pop r9
00007aa3a45d2a0c  pop r8
00007aa3a45d2a0e  pop rsi
00007aa3a45d2a0f  pop rdi
00007aa3a45d2a10  pop rdx
00007aa3a45d2a11  pop rcx
00007aa3a45d2a12  pop rax
00007aa3a45d2a13  add rsp, 0x08
00007aa3a45d2a17  jmp 0x00007AA3A45CFD98
00007aa3a45d2a1c  sub rsp, 0x08
00007aa3a45d2a20  push rax
00007aa3a45d2a21  push rcx
00007aa3a45d2a22  push rdx
00007aa3a45d2a23  push rdi
00007aa3a45d2a24  push rsi
00007aa3a45d2a25  push r8
00007aa3a45d2a27  push r9
00007aa3a45d2a29  push r10
00007aa3a45d2a2b  push r11
00007aa3a45d2a2d  sub rsp, 0xF0
00007aa3a45d2a34  vmovaps [rsp], xmm0
00007aa3a45d2a39  vmovaps [rsp+0x10], xmm2
00007aa3a45d2a3f  vmovaps [rsp+0x20], xmm3
00007aa3a45d2a45  vmovaps [rsp+0x30], xmm4
00007aa3a45d2a4b  vmovaps [rsp+0x40], xmm5
00007aa3a45d2a51  vmovaps [rsp+0x50], xmm6
00007aa3a45d2a57  vmovaps [rsp+0x60], xmm7
00007aa3a45d2a5d  vmovaps [rsp+0x70], xmm8
00007aa3a45d2a63  vmovaps [rsp+0x80], xmm9
00007aa3a45d2a6c  vmovaps [rsp+0x90], xmm10
00007aa3a45d2a75  vmovaps [rsp+0xA0], xmm11
00007aa3a45d2a7e  vmovaps [rsp+0xB0], xmm12
00007aa3a45d2a87  vmovaps [rsp+0xC0], xmm13
00007aa3a45d2a90  vmovaps [rsp+0xD0], xmm14
00007aa3a45d2a99  vmovaps [rsp+0xE0], xmm15
00007aa3a45d2aa2  sub rsp, 0x30
00007aa3a45d2aa6  movaps [rsp], xmm1
00007aa3a45d2aaa  movaps [rsp+0x10], xmm5
00007aa3a45d2aaf  movaps [rsp+0x20], xmm13
00007aa3a45d2ab5  lea rdi, [rsp]
00007aa3a45d2ab9  mov esi, 0x00
00007aa3a45d2abe  mov rax, 0x5F551B683530
00007aa3a45d2ac8  call rax
00007aa3a45d2aca  movaps xmm1, [rsp]
00007aa3a45d2ace  add rsp, 0x30
00007aa3a45d2ad2  vmovaps xmm0, [rsp]
00007aa3a45d2ad7  vmovaps xmm2, [rsp+0x10]
00007aa3a45d2add  vmovaps xmm3, [rsp+0x20]
00007aa3a45d2ae3  vmovaps xmm4, [rsp+0x30]
00007aa3a45d2ae9  vmovaps xmm5, [rsp+0x40]
00007aa3a45d2aef  vmovaps xmm6, [rsp+0x50]
00007aa3a45d2af5  vmovaps xmm7, [rsp+0x60]
00007aa3a45d2afb  vmovaps xmm8, [rsp+0x70]
00007aa3a45d2b01  vmovaps xmm9, [rsp+0x80]
00007aa3a45d2b0a  vmovaps xmm10, [rsp+0x90]
00007aa3a45d2b13  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d2b1c  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d2b25  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d2b2e  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d2b37  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d2b40  add rsp, 0xF0
00007aa3a45d2b47  pop r11
00007aa3a45d2b49  pop r10
00007aa3a45d2b4b  pop r9
00007aa3a45d2b4d  pop r8
00007aa3a45d2b4f  pop rsi
00007aa3a45d2b50  pop rdi
00007aa3a45d2b51  pop rdx
00007aa3a45d2b52  pop rcx
00007aa3a45d2b53  pop rax
00007aa3a45d2b54  add rsp, 0x08
00007aa3a45d2b58  jmp 0x00007AA3A45CFDB6
00007aa3a45d2b5d  sub rsp, 0x08
00007aa3a45d2b61  push rax
00007aa3a45d2b62  push rcx
00007aa3a45d2b63  push rdx
00007aa3a45d2b64  push rdi
00007aa3a45d2b65  push rsi
00007aa3a45d2b66  push r8
00007aa3a45d2b68  push r9
00007aa3a45d2b6a  push r10
00007aa3a45d2b6c  push r11
00007aa3a45d2b6e  sub rsp, 0xF0
00007aa3a45d2b75  vmovaps [rsp], xmm0
00007aa3a45d2b7a  vmovaps [rsp+0x10], xmm1
00007aa3a45d2b80  vmovaps [rsp+0x20], xmm2
00007aa3a45d2b86  vmovaps [rsp+0x30], xmm3
00007aa3a45d2b8c  vmovaps [rsp+0x40], xmm4
00007aa3a45d2b92  vmovaps [rsp+0x50], xmm6
00007aa3a45d2b98  vmovaps [rsp+0x60], xmm7
00007aa3a45d2b9e  vmovaps [rsp+0x70], xmm8
00007aa3a45d2ba4  vmovaps [rsp+0x80], xmm9
00007aa3a45d2bad  vmovaps [rsp+0x90], xmm10
00007aa3a45d2bb6  vmovaps [rsp+0xA0], xmm11
00007aa3a45d2bbf  vmovaps [rsp+0xB0], xmm12
00007aa3a45d2bc8  vmovaps [rsp+0xC0], xmm13
00007aa3a45d2bd1  vmovaps [rsp+0xD0], xmm14
00007aa3a45d2bda  vmovaps [rsp+0xE0], xmm15
00007aa3a45d2be3  sub rsp, 0x30
00007aa3a45d2be7  movaps [rsp], xmm5
00007aa3a45d2beb  movaps [rsp+0x10], xmm2
00007aa3a45d2bf0  movaps [rsp+0x20], xmm13
00007aa3a45d2bf6  lea rdi, [rsp]
00007aa3a45d2bfa  mov esi, 0x00
00007aa3a45d2bff  mov rax, 0x5F551B683530
00007aa3a45d2c09  call rax
00007aa3a45d2c0b  movaps xmm5, [rsp]
00007aa3a45d2c0f  add rsp, 0x30
00007aa3a45d2c13  vmovaps xmm0, [rsp]
00007aa3a45d2c18  vmovaps xmm1, [rsp+0x10]
00007aa3a45d2c1e  vmovaps xmm2, [rsp+0x20]
00007aa3a45d2c24  vmovaps xmm3, [rsp+0x30]
00007aa3a45d2c2a  vmovaps xmm4, [rsp+0x40]
00007aa3a45d2c30  vmovaps xmm6, [rsp+0x50]
00007aa3a45d2c36  vmovaps xmm7, [rsp+0x60]
00007aa3a45d2c3c  vmovaps xmm8, [rsp+0x70]
00007aa3a45d2c42  vmovaps xmm9, [rsp+0x80]
00007aa3a45d2c4b  vmovaps xmm10, [rsp+0x90]
00007aa3a45d2c54  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d2c5d  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d2c66  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d2c6f  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d2c78  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d2c81  add rsp, 0xF0
00007aa3a45d2c88  pop r11
00007aa3a45d2c8a  pop r10
00007aa3a45d2c8c  pop r9
00007aa3a45d2c8e  pop r8
00007aa3a45d2c90  pop rsi
00007aa3a45d2c91  pop rdi
00007aa3a45d2c92  pop rdx
00007aa3a45d2c93  pop rcx
00007aa3a45d2c94  pop rax
00007aa3a45d2c95  add rsp, 0x08
00007aa3a45d2c99  jmp 0x00007AA3A45CFDEC
00007aa3a45d2c9e  sub rsp, 0x08
00007aa3a45d2ca2  push rax
00007aa3a45d2ca3  push rcx
00007aa3a45d2ca4  push rdx
00007aa3a45d2ca5  push rdi
00007aa3a45d2ca6  push rsi
00007aa3a45d2ca7  push r8
00007aa3a45d2ca9  push r9
00007aa3a45d2cab  push r10
00007aa3a45d2cad  push r11
00007aa3a45d2caf  sub rsp, 0xF0
00007aa3a45d2cb6  vmovaps [rsp], xmm0
00007aa3a45d2cbb  vmovaps [rsp+0x10], xmm1
00007aa3a45d2cc1  vmovaps [rsp+0x20], xmm2
00007aa3a45d2cc7  vmovaps [rsp+0x30], xmm3
00007aa3a45d2ccd  vmovaps [rsp+0x40], xmm4
00007aa3a45d2cd3  vmovaps [rsp+0x50], xmm5
00007aa3a45d2cd9  vmovaps [rsp+0x60], xmm6
00007aa3a45d2cdf  vmovaps [rsp+0x70], xmm7
00007aa3a45d2ce5  vmovaps [rsp+0x80], xmm8
00007aa3a45d2cee  vmovaps [rsp+0x90], xmm9
00007aa3a45d2cf7  vmovaps [rsp+0xA0], xmm10
00007aa3a45d2d00  vmovaps [rsp+0xB0], xmm11
00007aa3a45d2d09  vmovaps [rsp+0xC0], xmm12
00007aa3a45d2d12  vmovaps [rsp+0xD0], xmm14
00007aa3a45d2d1b  vmovaps [rsp+0xE0], xmm15
00007aa3a45d2d24  sub rsp, 0x30
00007aa3a45d2d28  movaps [rsp], xmm13
00007aa3a45d2d2d  movaps [rsp+0x10], xmm10
00007aa3a45d2d33  movaps [rsp+0x20], xmm1
00007aa3a45d2d38  lea rdi, [rsp]
00007aa3a45d2d3c  mov esi, 0x00
00007aa3a45d2d41  mov rax, 0x5F551B683530
00007aa3a45d2d4b  call rax
00007aa3a45d2d4d  movaps xmm13, [rsp]
00007aa3a45d2d52  add rsp, 0x30
00007aa3a45d2d56  vmovaps xmm0, [rsp]
00007aa3a45d2d5b  vmovaps xmm1, [rsp+0x10]
00007aa3a45d2d61  vmovaps xmm2, [rsp+0x20]
00007aa3a45d2d67  vmovaps xmm3, [rsp+0x30]
00007aa3a45d2d6d  vmovaps xmm4, [rsp+0x40]
00007aa3a45d2d73  vmovaps xmm5, [rsp+0x50]
00007aa3a45d2d79  vmovaps xmm6, [rsp+0x60]
00007aa3a45d2d7f  vmovaps xmm7, [rsp+0x70]
00007aa3a45d2d85  vmovaps xmm8, [rsp+0x80]
00007aa3a45d2d8e  vmovaps xmm9, [rsp+0x90]
00007aa3a45d2d97  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d2da0  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d2da9  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d2db2  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d2dbb  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d2dc4  add rsp, 0xF0
00007aa3a45d2dcb  pop r11
00007aa3a45d2dcd  pop r10
00007aa3a45d2dcf  pop r9
00007aa3a45d2dd1  pop r8
00007aa3a45d2dd3  pop rsi
00007aa3a45d2dd4  pop rdi
00007aa3a45d2dd5  pop rdx
00007aa3a45d2dd6  pop rcx
00007aa3a45d2dd7  pop rax
00007aa3a45d2dd8  add rsp, 0x08
00007aa3a45d2ddc  jmp 0x00007AA3A45CFE15
00007aa3a45d2de1  sub rsp, 0x08
00007aa3a45d2de5  push rax
00007aa3a45d2de6  push rcx
00007aa3a45d2de7  push rdx
00007aa3a45d2de8  push rdi
00007aa3a45d2de9  push rsi
00007aa3a45d2dea  push r8
00007aa3a45d2dec  push r9
00007aa3a45d2dee  push r10
00007aa3a45d2df0  push r11
00007aa3a45d2df2  sub rsp, 0xF0
00007aa3a45d2df9  vmovaps [rsp], xmm0
00007aa3a45d2dfe  vmovaps [rsp+0x10], xmm2
00007aa3a45d2e04  vmovaps [rsp+0x20], xmm3
00007aa3a45d2e0a  vmovaps [rsp+0x30], xmm4
00007aa3a45d2e10  vmovaps [rsp+0x40], xmm5
00007aa3a45d2e16  vmovaps [rsp+0x50], xmm6
00007aa3a45d2e1c  vmovaps [rsp+0x60], xmm7
00007aa3a45d2e22  vmovaps [rsp+0x70], xmm8
00007aa3a45d2e28  vmovaps [rsp+0x80], xmm9
00007aa3a45d2e31  vmovaps [rsp+0x90], xmm10
00007aa3a45d2e3a  vmovaps [rsp+0xA0], xmm11
00007aa3a45d2e43  vmovaps [rsp+0xB0], xmm12
00007aa3a45d2e4c  vmovaps [rsp+0xC0], xmm13
00007aa3a45d2e55  vmovaps [rsp+0xD0], xmm14
00007aa3a45d2e5e  vmovaps [rsp+0xE0], xmm15
00007aa3a45d2e67  sub rsp, 0x30
00007aa3a45d2e6b  movaps [rsp], xmm1
00007aa3a45d2e6f  movaps [rsp+0x10], xmm15
00007aa3a45d2e75  movaps [rsp+0x20], xmm10
00007aa3a45d2e7b  lea rdi, [rsp]
00007aa3a45d2e7f  mov esi, 0x00
00007aa3a45d2e84  mov rax, 0x5F551B683530
00007aa3a45d2e8e  call rax
00007aa3a45d2e90  movaps xmm1, [rsp]
00007aa3a45d2e94  add rsp, 0x30
00007aa3a45d2e98  vmovaps xmm0, [rsp]
00007aa3a45d2e9d  vmovaps xmm2, [rsp+0x10]
00007aa3a45d2ea3  vmovaps xmm3, [rsp+0x20]
00007aa3a45d2ea9  vmovaps xmm4, [rsp+0x30]
00007aa3a45d2eaf  vmovaps xmm5, [rsp+0x40]
00007aa3a45d2eb5  vmovaps xmm6, [rsp+0x50]
00007aa3a45d2ebb  vmovaps xmm7, [rsp+0x60]
00007aa3a45d2ec1  vmovaps xmm8, [rsp+0x70]
00007aa3a45d2ec7  vmovaps xmm9, [rsp+0x80]
00007aa3a45d2ed0  vmovaps xmm10, [rsp+0x90]
00007aa3a45d2ed9  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d2ee2  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d2eeb  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d2ef4  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d2efd  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d2f06  add rsp, 0xF0
00007aa3a45d2f0d  pop r11
00007aa3a45d2f0f  pop r10
00007aa3a45d2f11  pop r9
00007aa3a45d2f13  pop r8
00007aa3a45d2f15  pop rsi
00007aa3a45d2f16  pop rdi
00007aa3a45d2f17  pop rdx
00007aa3a45d2f18  pop rcx
00007aa3a45d2f19  pop rax
00007aa3a45d2f1a  add rsp, 0x08
00007aa3a45d2f1e  jmp 0x00007AA3A45CFE34
00007aa3a45d2f23  sub rsp, 0x08
00007aa3a45d2f27  push rax
00007aa3a45d2f28  push rcx
00007aa3a45d2f29  push rdx
00007aa3a45d2f2a  push rdi
00007aa3a45d2f2b  push rsi
00007aa3a45d2f2c  push r8
00007aa3a45d2f2e  push r9
00007aa3a45d2f30  push r10
00007aa3a45d2f32  push r11
00007aa3a45d2f34  sub rsp, 0xF0
00007aa3a45d2f3b  vmovaps [rsp], xmm0
00007aa3a45d2f40  vmovaps [rsp+0x10], xmm1
00007aa3a45d2f46  vmovaps [rsp+0x20], xmm2
00007aa3a45d2f4c  vmovaps [rsp+0x30], xmm3
00007aa3a45d2f52  vmovaps [rsp+0x40], xmm4
00007aa3a45d2f58  vmovaps [rsp+0x50], xmm5
00007aa3a45d2f5e  vmovaps [rsp+0x60], xmm6
00007aa3a45d2f64  vmovaps [rsp+0x70], xmm7
00007aa3a45d2f6a  vmovaps [rsp+0x80], xmm8
00007aa3a45d2f73  vmovaps [rsp+0x90], xmm9
00007aa3a45d2f7c  vmovaps [rsp+0xA0], xmm10
00007aa3a45d2f85  vmovaps [rsp+0xB0], xmm11
00007aa3a45d2f8e  vmovaps [rsp+0xC0], xmm12
00007aa3a45d2f97  vmovaps [rsp+0xD0], xmm13
00007aa3a45d2fa0  vmovaps [rsp+0xE0], xmm14
00007aa3a45d2fa9  sub rsp, 0x30
00007aa3a45d2fad  movaps [rsp], xmm15
00007aa3a45d2fb2  movaps [rsp+0x10], xmm10
00007aa3a45d2fb8  movaps [rsp+0x20], xmm11
00007aa3a45d2fbe  lea rdi, [rsp]
00007aa3a45d2fc2  mov esi, 0x00
00007aa3a45d2fc7  mov rax, 0x5F551B683530
00007aa3a45d2fd1  call rax
00007aa3a45d2fd3  movaps xmm15, [rsp]
00007aa3a45d2fd8  add rsp, 0x30
00007aa3a45d2fdc  vmovaps xmm0, [rsp]
00007aa3a45d2fe1  vmovaps xmm1, [rsp+0x10]
00007aa3a45d2fe7  vmovaps xmm2, [rsp+0x20]
00007aa3a45d2fed  vmovaps xmm3, [rsp+0x30]
00007aa3a45d2ff3  vmovaps xmm4, [rsp+0x40]
00007aa3a45d2ff9  vmovaps xmm5, [rsp+0x50]
00007aa3a45d2fff  vmovaps xmm6, [rsp+0x60]
00007aa3a45d3005  vmovaps xmm7, [rsp+0x70]
00007aa3a45d300b  vmovaps xmm8, [rsp+0x80]
00007aa3a45d3014  vmovaps xmm9, [rsp+0x90]
00007aa3a45d301d  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d3026  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d302f  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d3038  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d3041  vmovaps xmm14, [rsp+0xE0]
00007aa3a45d304a  add rsp, 0xF0
00007aa3a45d3051  pop r11
00007aa3a45d3053  pop r10
00007aa3a45d3055  pop r9
00007aa3a45d3057  pop r8
00007aa3a45d3059  pop rsi
00007aa3a45d305a  pop rdi
00007aa3a45d305b  pop rdx
00007aa3a45d305c  pop rcx
00007aa3a45d305d  pop rax
00007aa3a45d305e  add rsp, 0x08
00007aa3a45d3062  jmp 0x00007AA3A45CFE57
00007aa3a45d3067  sub rsp, 0x08
00007aa3a45d306b  push rax
00007aa3a45d306c  push rcx
00007aa3a45d306d  push rdx
00007aa3a45d306e  push rdi
00007aa3a45d306f  push rsi
00007aa3a45d3070  push r8
00007aa3a45d3072  push r9
00007aa3a45d3074  push r10
00007aa3a45d3076  push r11
00007aa3a45d3078  sub rsp, 0xF0
00007aa3a45d307f  vmovaps [rsp], xmm0
00007aa3a45d3084  vmovaps [rsp+0x10], xmm1
00007aa3a45d308a  vmovaps [rsp+0x20], xmm2
00007aa3a45d3090  vmovaps [rsp+0x30], xmm3
00007aa3a45d3096  vmovaps [rsp+0x40], xmm4
00007aa3a45d309c  vmovaps [rsp+0x50], xmm5
00007aa3a45d30a2  vmovaps [rsp+0x60], xmm6
00007aa3a45d30a8  vmovaps [rsp+0x70], xmm7
00007aa3a45d30ae  vmovaps [rsp+0x80], xmm8
00007aa3a45d30b7  vmovaps [rsp+0x90], xmm9
00007aa3a45d30c0  vmovaps [rsp+0xA0], xmm11
00007aa3a45d30c9  vmovaps [rsp+0xB0], xmm12
00007aa3a45d30d2  vmovaps [rsp+0xC0], xmm13
00007aa3a45d30db  vmovaps [rsp+0xD0], xmm14
00007aa3a45d30e4  vmovaps [rsp+0xE0], xmm15
00007aa3a45d30ed  sub rsp, 0x30
00007aa3a45d30f1  movaps [rsp], xmm10
00007aa3a45d30f6  movaps [rsp+0x10], xmm12
00007aa3a45d30fc  movaps [rsp+0x20], xmm11
00007aa3a45d3102  lea rdi, [rsp]
00007aa3a45d3106  mov esi, 0x00
00007aa3a45d310b  mov rax, 0x5F551B683530
00007aa3a45d3115  call rax
00007aa3a45d3117  movaps xmm10, [rsp]
00007aa3a45d311c  add rsp, 0x30
00007aa3a45d3120  vmovaps xmm0, [rsp]
00007aa3a45d3125  vmovaps xmm1, [rsp+0x10]
00007aa3a45d312b  vmovaps xmm2, [rsp+0x20]
00007aa3a45d3131  vmovaps xmm3, [rsp+0x30]
00007aa3a45d3137  vmovaps xmm4, [rsp+0x40]
00007aa3a45d313d  vmovaps xmm5, [rsp+0x50]
00007aa3a45d3143  vmovaps xmm6, [rsp+0x60]
00007aa3a45d3149  vmovaps xmm7, [rsp+0x70]
00007aa3a45d314f  vmovaps xmm8, [rsp+0x80]
00007aa3a45d3158  vmovaps xmm9, [rsp+0x90]
00007aa3a45d3161  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d316a  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d3173  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d317c  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d3185  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d318e  add rsp, 0xF0
00007aa3a45d3195  pop r11
00007aa3a45d3197  pop r10
00007aa3a45d3199  pop r9
00007aa3a45d319b  pop r8
00007aa3a45d319d  pop rsi
00007aa3a45d319e  pop rdi
00007aa3a45d319f  pop rdx
00007aa3a45d31a0  pop rcx
00007aa3a45d31a1  pop rax
00007aa3a45d31a2  add rsp, 0x08
00007aa3a45d31a6  jmp 0x00007AA3A45CFE80
00007aa3a45d31ab  sub rsp, 0x08
00007aa3a45d31af  push rax
00007aa3a45d31b0  push rcx
00007aa3a45d31b1  push rdx
00007aa3a45d31b2  push rdi
00007aa3a45d31b3  push rsi
00007aa3a45d31b4  push r8
00007aa3a45d31b6  push r9
00007aa3a45d31b8  push r10
00007aa3a45d31ba  push r11
00007aa3a45d31bc  sub rsp, 0xF0
00007aa3a45d31c3  vmovaps [rsp], xmm0
00007aa3a45d31c8  vmovaps [rsp+0x10], xmm1
00007aa3a45d31ce  vmovaps [rsp+0x20], xmm2
00007aa3a45d31d4  vmovaps [rsp+0x30], xmm3
00007aa3a45d31da  vmovaps [rsp+0x40], xmm4
00007aa3a45d31e0  vmovaps [rsp+0x50], xmm5
00007aa3a45d31e6  vmovaps [rsp+0x60], xmm6
00007aa3a45d31ec  vmovaps [rsp+0x70], xmm7
00007aa3a45d31f2  vmovaps [rsp+0x80], xmm8
00007aa3a45d31fb  vmovaps [rsp+0x90], xmm9
00007aa3a45d3204  vmovaps [rsp+0xA0], xmm10
00007aa3a45d320d  vmovaps [rsp+0xB0], xmm12
00007aa3a45d3216  vmovaps [rsp+0xC0], xmm13
00007aa3a45d321f  vmovaps [rsp+0xD0], xmm14
00007aa3a45d3228  vmovaps [rsp+0xE0], xmm15
00007aa3a45d3231  sub rsp, 0x30
00007aa3a45d3235  movaps [rsp], xmm11
00007aa3a45d323a  movaps [rsp+0x10], xmm2
00007aa3a45d323f  movaps [rsp+0x20], xmm12
00007aa3a45d3245  lea rdi, [rsp]
00007aa3a45d3249  mov esi, 0x00
00007aa3a45d324e  mov rax, 0x5F551B683530
00007aa3a45d3258  call rax
00007aa3a45d325a  movaps xmm11, [rsp]
00007aa3a45d325f  add rsp, 0x30
00007aa3a45d3263  vmovaps xmm0, [rsp]
00007aa3a45d3268  vmovaps xmm1, [rsp+0x10]
00007aa3a45d326e  vmovaps xmm2, [rsp+0x20]
00007aa3a45d3274  vmovaps xmm3, [rsp+0x30]
00007aa3a45d327a  vmovaps xmm4, [rsp+0x40]
00007aa3a45d3280  vmovaps xmm5, [rsp+0x50]
00007aa3a45d3286  vmovaps xmm6, [rsp+0x60]
00007aa3a45d328c  vmovaps xmm7, [rsp+0x70]
00007aa3a45d3292  vmovaps xmm8, [rsp+0x80]
00007aa3a45d329b  vmovaps xmm9, [rsp+0x90]
00007aa3a45d32a4  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d32ad  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d32b6  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d32bf  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d32c8  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d32d1  add rsp, 0xF0
00007aa3a45d32d8  pop r11
00007aa3a45d32da  pop r10
00007aa3a45d32dc  pop r9
00007aa3a45d32de  pop r8
00007aa3a45d32e0  pop rsi
00007aa3a45d32e1  pop rdi
00007aa3a45d32e2  pop rdx
00007aa3a45d32e3  pop rcx
00007aa3a45d32e4  pop rax
00007aa3a45d32e5  add rsp, 0x08
00007aa3a45d32e9  jmp 0x00007AA3A45CFEB8
00007aa3a45d32ee  sub rsp, 0x08
00007aa3a45d32f2  push rax
00007aa3a45d32f3  push rcx
00007aa3a45d32f4  push rdx
00007aa3a45d32f5  push rdi
00007aa3a45d32f6  push rsi
00007aa3a45d32f7  push r8
00007aa3a45d32f9  push r9
00007aa3a45d32fb  push r10
00007aa3a45d32fd  push r11
00007aa3a45d32ff  sub rsp, 0xF0
00007aa3a45d3306  vmovaps [rsp], xmm0
00007aa3a45d330b  vmovaps [rsp+0x10], xmm2
00007aa3a45d3311  vmovaps [rsp+0x20], xmm3
00007aa3a45d3317  vmovaps [rsp+0x30], xmm4
00007aa3a45d331d  vmovaps [rsp+0x40], xmm5
00007aa3a45d3323  vmovaps [rsp+0x50], xmm6
00007aa3a45d3329  vmovaps [rsp+0x60], xmm7
00007aa3a45d332f  vmovaps [rsp+0x70], xmm8
00007aa3a45d3335  vmovaps [rsp+0x80], xmm9
00007aa3a45d333e  vmovaps [rsp+0x90], xmm10
00007aa3a45d3347  vmovaps [rsp+0xA0], xmm11
00007aa3a45d3350  vmovaps [rsp+0xB0], xmm12
00007aa3a45d3359  vmovaps [rsp+0xC0], xmm13
00007aa3a45d3362  vmovaps [rsp+0xD0], xmm14
00007aa3a45d336b  vmovaps [rsp+0xE0], xmm15
00007aa3a45d3374  sub rsp, 0x30
00007aa3a45d3378  movaps [rsp], xmm1
00007aa3a45d337c  movaps [rsp+0x10], xmm14
00007aa3a45d3382  movaps [rsp+0x20], xmm6
00007aa3a45d3387  lea rdi, [rsp]
00007aa3a45d338b  mov esi, 0x00
00007aa3a45d3390  mov rax, 0x5F551B683530
00007aa3a45d339a  call rax
00007aa3a45d339c  movaps xmm1, [rsp]
00007aa3a45d33a0  add rsp, 0x30
00007aa3a45d33a4  vmovaps xmm0, [rsp]
00007aa3a45d33a9  vmovaps xmm2, [rsp+0x10]
00007aa3a45d33af  vmovaps xmm3, [rsp+0x20]
00007aa3a45d33b5  vmovaps xmm4, [rsp+0x30]
00007aa3a45d33bb  vmovaps xmm5, [rsp+0x40]
00007aa3a45d33c1  vmovaps xmm6, [rsp+0x50]
00007aa3a45d33c7  vmovaps xmm7, [rsp+0x60]
00007aa3a45d33cd  vmovaps xmm8, [rsp+0x70]
00007aa3a45d33d3  vmovaps xmm9, [rsp+0x80]
00007aa3a45d33dc  vmovaps xmm10, [rsp+0x90]
00007aa3a45d33e5  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d33ee  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d33f7  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d3400  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d3409  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d3412  add rsp, 0xF0
00007aa3a45d3419  pop r11
00007aa3a45d341b  pop r10
00007aa3a45d341d  pop r9
00007aa3a45d341f  pop r8
00007aa3a45d3421  pop rsi
00007aa3a45d3422  pop rdi
00007aa3a45d3423  pop rdx
00007aa3a45d3424  pop rcx
00007aa3a45d3425  pop rax
00007aa3a45d3426  add rsp, 0x08
00007aa3a45d342a  jmp 0x00007AA3A45CFED1
00007aa3a45d342f  sub rsp, 0x08
00007aa3a45d3433  push rax
00007aa3a45d3434  push rcx
00007aa3a45d3435  push rdx
00007aa3a45d3436  push rdi
00007aa3a45d3437  push rsi
00007aa3a45d3438  push r8
00007aa3a45d343a  push r9
00007aa3a45d343c  push r10
00007aa3a45d343e  push r11
00007aa3a45d3440  sub rsp, 0xF0
00007aa3a45d3447  vmovaps [rsp], xmm0
00007aa3a45d344c  vmovaps [rsp+0x10], xmm1
00007aa3a45d3452  vmovaps [rsp+0x20], xmm2
00007aa3a45d3458  vmovaps [rsp+0x30], xmm3
00007aa3a45d345e  vmovaps [rsp+0x40], xmm4
00007aa3a45d3464  vmovaps [rsp+0x50], xmm5
00007aa3a45d346a  vmovaps [rsp+0x60], xmm6
00007aa3a45d3470  vmovaps [rsp+0x70], xmm7
00007aa3a45d3476  vmovaps [rsp+0x80], xmm8
00007aa3a45d347f  vmovaps [rsp+0x90], xmm9
00007aa3a45d3488  vmovaps [rsp+0xA0], xmm10
00007aa3a45d3491  vmovaps [rsp+0xB0], xmm11
00007aa3a45d349a  vmovaps [rsp+0xC0], xmm12
00007aa3a45d34a3  vmovaps [rsp+0xD0], xmm13
00007aa3a45d34ac  vmovaps [rsp+0xE0], xmm15
00007aa3a45d34b5  sub rsp, 0x30
00007aa3a45d34b9  movaps [rsp], xmm14
00007aa3a45d34be  movaps [rsp+0x10], xmm12
00007aa3a45d34c4  movaps [rsp+0x20], xmm5
00007aa3a45d34c9  lea rdi, [rsp]
00007aa3a45d34cd  mov esi, 0x00
00007aa3a45d34d2  mov rax, 0x5F551B683530
00007aa3a45d34dc  call rax
00007aa3a45d34de  movaps xmm14, [rsp]
00007aa3a45d34e3  add rsp, 0x30
00007aa3a45d34e7  vmovaps xmm0, [rsp]
00007aa3a45d34ec  vmovaps xmm1, [rsp+0x10]
00007aa3a45d34f2  vmovaps xmm2, [rsp+0x20]
00007aa3a45d34f8  vmovaps xmm3, [rsp+0x30]
00007aa3a45d34fe  vmovaps xmm4, [rsp+0x40]
00007aa3a45d3504  vmovaps xmm5, [rsp+0x50]
00007aa3a45d350a  vmovaps xmm6, [rsp+0x60]
00007aa3a45d3510  vmovaps xmm7, [rsp+0x70]
00007aa3a45d3516  vmovaps xmm8, [rsp+0x80]
00007aa3a45d351f  vmovaps xmm9, [rsp+0x90]
00007aa3a45d3528  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d3531  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d353a  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d3543  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d354c  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d3555  add rsp, 0xF0
00007aa3a45d355c  pop r11
00007aa3a45d355e  pop r10
00007aa3a45d3560  pop r9
00007aa3a45d3562  pop r8
00007aa3a45d3564  pop rsi
00007aa3a45d3565  pop rdi
00007aa3a45d3566  pop rdx
00007aa3a45d3567  pop rcx
00007aa3a45d3568  pop rax
00007aa3a45d3569  add rsp, 0x08
00007aa3a45d356d  jmp 0x00007AA3A45CFEF1
00007aa3a45d3572  sub rsp, 0x08
00007aa3a45d3576  push rax
00007aa3a45d3577  push rcx
00007aa3a45d3578  push rdx
00007aa3a45d3579  push rdi
00007aa3a45d357a  push rsi
00007aa3a45d357b  push r8
00007aa3a45d357d  push r9
00007aa3a45d357f  push r10
00007aa3a45d3581  push r11
00007aa3a45d3583  sub rsp, 0xF0
00007aa3a45d358a  vmovaps [rsp], xmm0
00007aa3a45d358f  vmovaps [rsp+0x10], xmm1
00007aa3a45d3595  vmovaps [rsp+0x20], xmm2
00007aa3a45d359b  vmovaps [rsp+0x30], xmm3
00007aa3a45d35a1  vmovaps [rsp+0x40], xmm4
00007aa3a45d35a7  vmovaps [rsp+0x50], xmm5
00007aa3a45d35ad  vmovaps [rsp+0x60], xmm7
00007aa3a45d35b3  vmovaps [rsp+0x70], xmm8
00007aa3a45d35b9  vmovaps [rsp+0x80], xmm9
00007aa3a45d35c2  vmovaps [rsp+0x90], xmm10
00007aa3a45d35cb  vmovaps [rsp+0xA0], xmm11
00007aa3a45d35d4  vmovaps [rsp+0xB0], xmm12
00007aa3a45d35dd  vmovaps [rsp+0xC0], xmm13
00007aa3a45d35e6  vmovaps [rsp+0xD0], xmm14
00007aa3a45d35ef  vmovaps [rsp+0xE0], xmm15
00007aa3a45d35f8  sub rsp, 0x30
00007aa3a45d35fc  movaps [rsp], xmm6
00007aa3a45d3600  movaps [rsp+0x10], xmm9
00007aa3a45d3606  movaps [rsp+0x20], xmm12
00007aa3a45d360c  lea rdi, [rsp]
00007aa3a45d3610  mov esi, 0x00
00007aa3a45d3615  mov rax, 0x5F551B683530
00007aa3a45d361f  call rax
00007aa3a45d3621  movaps xmm6, [rsp]
00007aa3a45d3625  add rsp, 0x30
00007aa3a45d3629  vmovaps xmm0, [rsp]
00007aa3a45d362e  vmovaps xmm1, [rsp+0x10]
00007aa3a45d3634  vmovaps xmm2, [rsp+0x20]
00007aa3a45d363a  vmovaps xmm3, [rsp+0x30]
00007aa3a45d3640  vmovaps xmm4, [rsp+0x40]
00007aa3a45d3646  vmovaps xmm5, [rsp+0x50]
00007aa3a45d364c  vmovaps xmm7, [rsp+0x60]
00007aa3a45d3652  vmovaps xmm8, [rsp+0x70]
00007aa3a45d3658  vmovaps xmm9, [rsp+0x80]
00007aa3a45d3661  vmovaps xmm10, [rsp+0x90]
00007aa3a45d366a  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d3673  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d367c  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d3685  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d368e  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d3697  add rsp, 0xF0
00007aa3a45d369e  pop r11
00007aa3a45d36a0  pop r10
00007aa3a45d36a2  pop r9
00007aa3a45d36a4  pop r8
00007aa3a45d36a6  pop rsi
00007aa3a45d36a7  pop rdi
00007aa3a45d36a8  pop rdx
00007aa3a45d36a9  pop rcx
00007aa3a45d36aa  pop rax
00007aa3a45d36ab  add rsp, 0x08
00007aa3a45d36af  jmp 0x00007AA3A45CFF19
00007aa3a45d36b4  sub rsp, 0x08
00007aa3a45d36b8  push rax
00007aa3a45d36b9  push rcx
00007aa3a45d36ba  push rdx
00007aa3a45d36bb  push rdi
00007aa3a45d36bc  push rsi
00007aa3a45d36bd  push r8
00007aa3a45d36bf  push r9
00007aa3a45d36c1  push r10
00007aa3a45d36c3  push r11
00007aa3a45d36c5  sub rsp, 0xF0
00007aa3a45d36cc  vmovaps [rsp], xmm0
00007aa3a45d36d1  vmovaps [rsp+0x10], xmm1
00007aa3a45d36d7  vmovaps [rsp+0x20], xmm2
00007aa3a45d36dd  vmovaps [rsp+0x30], xmm3
00007aa3a45d36e3  vmovaps [rsp+0x40], xmm4
00007aa3a45d36e9  vmovaps [rsp+0x50], xmm5
00007aa3a45d36ef  vmovaps [rsp+0x60], xmm6
00007aa3a45d36f5  vmovaps [rsp+0x70], xmm7
00007aa3a45d36fb  vmovaps [rsp+0x80], xmm8
00007aa3a45d3704  vmovaps [rsp+0x90], xmm9
00007aa3a45d370d  vmovaps [rsp+0xA0], xmm10
00007aa3a45d3716  vmovaps [rsp+0xB0], xmm11
00007aa3a45d371f  vmovaps [rsp+0xC0], xmm13
00007aa3a45d3728  vmovaps [rsp+0xD0], xmm14
00007aa3a45d3731  vmovaps [rsp+0xE0], xmm15
00007aa3a45d373a  sub rsp, 0x30
00007aa3a45d373e  movaps [rsp], xmm12
00007aa3a45d3743  movaps [rsp+0x10], xmm15
00007aa3a45d3749  movaps [rsp+0x20], xmm13
00007aa3a45d374f  lea rdi, [rsp]
00007aa3a45d3753  mov esi, 0x00
00007aa3a45d3758  mov rax, 0x5F551B683530
00007aa3a45d3762  call rax
00007aa3a45d3764  movaps xmm12, [rsp]
00007aa3a45d3769  add rsp, 0x30
00007aa3a45d376d  vmovaps xmm0, [rsp]
00007aa3a45d3772  vmovaps xmm1, [rsp+0x10]
00007aa3a45d3778  vmovaps xmm2, [rsp+0x20]
00007aa3a45d377e  vmovaps xmm3, [rsp+0x30]
00007aa3a45d3784  vmovaps xmm4, [rsp+0x40]
00007aa3a45d378a  vmovaps xmm5, [rsp+0x50]
00007aa3a45d3790  vmovaps xmm6, [rsp+0x60]
00007aa3a45d3796  vmovaps xmm7, [rsp+0x70]
00007aa3a45d379c  vmovaps xmm8, [rsp+0x80]
00007aa3a45d37a5  vmovaps xmm9, [rsp+0x90]
00007aa3a45d37ae  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d37b7  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d37c0  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d37c9  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d37d2  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d37db  add rsp, 0xF0
00007aa3a45d37e2  pop r11
00007aa3a45d37e4  pop r10
00007aa3a45d37e6  pop r9
00007aa3a45d37e8  pop r8
00007aa3a45d37ea  pop rsi
00007aa3a45d37eb  pop rdi
00007aa3a45d37ec  pop rdx
00007aa3a45d37ed  pop rcx
00007aa3a45d37ee  pop rax
00007aa3a45d37ef  add rsp, 0x08
00007aa3a45d37f3  jmp 0x00007AA3A45CFF34
00007aa3a45d37f8  sub rsp, 0x08
00007aa3a45d37fc  push rax
00007aa3a45d37fd  push rcx
00007aa3a45d37fe  push rdx
00007aa3a45d37ff  push rdi
00007aa3a45d3800  push rsi
00007aa3a45d3801  push r8
00007aa3a45d3803  push r9
00007aa3a45d3805  push r10
00007aa3a45d3807  push r11
00007aa3a45d3809  sub rsp, 0xF0
00007aa3a45d3810  vmovaps [rsp], xmm0
00007aa3a45d3815  vmovaps [rsp+0x10], xmm1
00007aa3a45d381b  vmovaps [rsp+0x20], xmm2
00007aa3a45d3821  vmovaps [rsp+0x30], xmm3
00007aa3a45d3827  vmovaps [rsp+0x40], xmm4
00007aa3a45d382d  vmovaps [rsp+0x50], xmm5
00007aa3a45d3833  vmovaps [rsp+0x60], xmm6
00007aa3a45d3839  vmovaps [rsp+0x70], xmm7
00007aa3a45d383f  vmovaps [rsp+0x80], xmm8
00007aa3a45d3848  vmovaps [rsp+0x90], xmm9
00007aa3a45d3851  vmovaps [rsp+0xA0], xmm10
00007aa3a45d385a  vmovaps [rsp+0xB0], xmm11
00007aa3a45d3863  vmovaps [rsp+0xC0], xmm12
00007aa3a45d386c  vmovaps [rsp+0xD0], xmm13
00007aa3a45d3875  vmovaps [rsp+0xE0], xmm14
00007aa3a45d387e  sub rsp, 0x30
00007aa3a45d3882  movaps [rsp], xmm15
00007aa3a45d3887  movaps [rsp+0x10], xmm13
00007aa3a45d388d  movaps [rsp+0x20], xmm10
00007aa3a45d3893  lea rdi, [rsp]
00007aa3a45d3897  mov esi, 0x00
00007aa3a45d389c  mov rax, 0x5F551B683530
00007aa3a45d38a6  call rax
00007aa3a45d38a8  movaps xmm15, [rsp]
00007aa3a45d38ad  add rsp, 0x30
00007aa3a45d38b1  vmovaps xmm0, [rsp]
00007aa3a45d38b6  vmovaps xmm1, [rsp+0x10]
00007aa3a45d38bc  vmovaps xmm2, [rsp+0x20]
00007aa3a45d38c2  vmovaps xmm3, [rsp+0x30]
00007aa3a45d38c8  vmovaps xmm4, [rsp+0x40]
00007aa3a45d38ce  vmovaps xmm5, [rsp+0x50]
00007aa3a45d38d4  vmovaps xmm6, [rsp+0x60]
00007aa3a45d38da  vmovaps xmm7, [rsp+0x70]
00007aa3a45d38e0  vmovaps xmm8, [rsp+0x80]
00007aa3a45d38e9  vmovaps xmm9, [rsp+0x90]
00007aa3a45d38f2  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d38fb  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d3904  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d390d  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d3916  vmovaps xmm14, [rsp+0xE0]
00007aa3a45d391f  add rsp, 0xF0
00007aa3a45d3926  pop r11
00007aa3a45d3928  pop r10
00007aa3a45d392a  pop r9
00007aa3a45d392c  pop r8
00007aa3a45d392e  pop rsi
00007aa3a45d392f  pop rdi
00007aa3a45d3930  pop rdx
00007aa3a45d3931  pop rcx
00007aa3a45d3932  pop rax
00007aa3a45d3933  add rsp, 0x08
00007aa3a45d3937  jmp 0x00007AA3A45CFF55
00007aa3a45d393c  call 0x00007AA3A440C260
00007aa3a45d3941  jmp 0x00007AA3A45CFFB0
00007aa3a45d3946  sub rsp, 0x08
00007aa3a45d394a  push rax
00007aa3a45d394b  push rcx
00007aa3a45d394c  push rdx
00007aa3a45d394d  push rdi
00007aa3a45d394e  push rsi
00007aa3a45d394f  push r8
00007aa3a45d3951  push r9
00007aa3a45d3953  push r10
00007aa3a45d3955  push r11
00007aa3a45d3957  sub rsp, 0xF0
00007aa3a45d395e  vmovaps [rsp], xmm0
00007aa3a45d3963  vmovaps [rsp+0x10], xmm1
00007aa3a45d3969  vmovaps [rsp+0x20], xmm2
00007aa3a45d396f  vmovaps [rsp+0x30], xmm3
00007aa3a45d3975  vmovaps [rsp+0x40], xmm4
00007aa3a45d397b  vmovaps [rsp+0x50], xmm5
00007aa3a45d3981  vmovaps [rsp+0x60], xmm6
00007aa3a45d3987  vmovaps [rsp+0x70], xmm7
00007aa3a45d398d  vmovaps [rsp+0x80], xmm8
00007aa3a45d3996  vmovaps [rsp+0x90], xmm10
00007aa3a45d399f  vmovaps [rsp+0xA0], xmm11
00007aa3a45d39a8  vmovaps [rsp+0xB0], xmm12
00007aa3a45d39b1  vmovaps [rsp+0xC0], xmm13
00007aa3a45d39ba  vmovaps [rsp+0xD0], xmm14
00007aa3a45d39c3  vmovaps [rsp+0xE0], xmm15
00007aa3a45d39cc  sub rsp, 0x30
00007aa3a45d39d0  movaps [rsp], xmm9
00007aa3a45d39d5  movaps [rsp+0x10], xmm8
00007aa3a45d39db  movaps [rsp+0x20], xmm10
00007aa3a45d39e1  lea rdi, [rsp]
00007aa3a45d39e5  mov esi, 0x00
00007aa3a45d39ea  mov rax, 0x5F551B683530
00007aa3a45d39f4  call rax
00007aa3a45d39f6  movaps xmm9, [rsp]
00007aa3a45d39fb  add rsp, 0x30
00007aa3a45d39ff  vmovaps xmm0, [rsp]
00007aa3a45d3a04  vmovaps xmm1, [rsp+0x10]
00007aa3a45d3a0a  vmovaps xmm2, [rsp+0x20]
00007aa3a45d3a10  vmovaps xmm3, [rsp+0x30]
00007aa3a45d3a16  vmovaps xmm4, [rsp+0x40]
00007aa3a45d3a1c  vmovaps xmm5, [rsp+0x50]
00007aa3a45d3a22  vmovaps xmm6, [rsp+0x60]
00007aa3a45d3a28  vmovaps xmm7, [rsp+0x70]
00007aa3a45d3a2e  vmovaps xmm8, [rsp+0x80]
00007aa3a45d3a37  vmovaps xmm10, [rsp+0x90]
00007aa3a45d3a40  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d3a49  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d3a52  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d3a5b  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d3a64  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d3a6d  add rsp, 0xF0
00007aa3a45d3a74  pop r11
00007aa3a45d3a76  pop r10
00007aa3a45d3a78  pop r9
00007aa3a45d3a7a  pop r8
00007aa3a45d3a7c  pop rsi
00007aa3a45d3a7d  pop rdi
00007aa3a45d3a7e  pop rdx
00007aa3a45d3a7f  pop rcx
00007aa3a45d3a80  pop rax
00007aa3a45d3a81  add rsp, 0x08
00007aa3a45d3a85  jmp 0x00007AA3A45CFFE1
00007aa3a45d3a8a  sub rsp, 0x08
00007aa3a45d3a8e  push rax
00007aa3a45d3a8f  push rcx
00007aa3a45d3a90  push rdx
00007aa3a45d3a91  push rdi
00007aa3a45d3a92  push rsi
00007aa3a45d3a93  push r8
00007aa3a45d3a95  push r9
00007aa3a45d3a97  push r10
00007aa3a45d3a99  push r11
00007aa3a45d3a9b  sub rsp, 0xF0
00007aa3a45d3aa2  vmovaps [rsp], xmm0
00007aa3a45d3aa7  vmovaps [rsp+0x10], xmm1
00007aa3a45d3aad  vmovaps [rsp+0x20], xmm2
00007aa3a45d3ab3  vmovaps [rsp+0x30], xmm3
00007aa3a45d3ab9  vmovaps [rsp+0x40], xmm4
00007aa3a45d3abf  vmovaps [rsp+0x50], xmm5
00007aa3a45d3ac5  vmovaps [rsp+0x60], xmm6
00007aa3a45d3acb  vmovaps [rsp+0x70], xmm7
00007aa3a45d3ad1  vmovaps [rsp+0x80], xmm8
00007aa3a45d3ada  vmovaps [rsp+0x90], xmm9
00007aa3a45d3ae3  vmovaps [rsp+0xA0], xmm11
00007aa3a45d3aec  vmovaps [rsp+0xB0], xmm12
00007aa3a45d3af5  vmovaps [rsp+0xC0], xmm13
00007aa3a45d3afe  vmovaps [rsp+0xD0], xmm14
00007aa3a45d3b07  vmovaps [rsp+0xE0], xmm15
00007aa3a45d3b10  sub rsp, 0x30
00007aa3a45d3b14  movaps [rsp], xmm10
00007aa3a45d3b19  movaps [rsp+0x10], xmm1
00007aa3a45d3b1e  movaps [rsp+0x20], xmm11
00007aa3a45d3b24  lea rdi, [rsp]
00007aa3a45d3b28  mov esi, 0x00
00007aa3a45d3b2d  mov rax, 0x5F551B683530
00007aa3a45d3b37  call rax
00007aa3a45d3b39  movaps xmm10, [rsp]
00007aa3a45d3b3e  add rsp, 0x30
00007aa3a45d3b42  vmovaps xmm0, [rsp]
00007aa3a45d3b47  vmovaps xmm1, [rsp+0x10]
00007aa3a45d3b4d  vmovaps xmm2, [rsp+0x20]
00007aa3a45d3b53  vmovaps xmm3, [rsp+0x30]
00007aa3a45d3b59  vmovaps xmm4, [rsp+0x40]
00007aa3a45d3b5f  vmovaps xmm5, [rsp+0x50]
00007aa3a45d3b65  vmovaps xmm6, [rsp+0x60]
00007aa3a45d3b6b  vmovaps xmm7, [rsp+0x70]
00007aa3a45d3b71  vmovaps xmm8, [rsp+0x80]
00007aa3a45d3b7a  vmovaps xmm9, [rsp+0x90]
00007aa3a45d3b83  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d3b8c  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d3b95  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d3b9e  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d3ba7  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d3bb0  add rsp, 0xF0
00007aa3a45d3bb7  pop r11
00007aa3a45d3bb9  pop r10
00007aa3a45d3bbb  pop r9
00007aa3a45d3bbd  pop r8
00007aa3a45d3bbf  pop rsi
00007aa3a45d3bc0  pop rdi
00007aa3a45d3bc1  pop rdx
00007aa3a45d3bc2  pop rcx
00007aa3a45d3bc3  pop rax
00007aa3a45d3bc4  add rsp, 0x08
00007aa3a45d3bc8  jmp 0x00007AA3A45CFFFC
00007aa3a45d3bcd  sub rsp, 0x08
00007aa3a45d3bd1  push rax
00007aa3a45d3bd2  push rcx
00007aa3a45d3bd3  push rdx
00007aa3a45d3bd4  push rdi
00007aa3a45d3bd5  push rsi
00007aa3a45d3bd6  push r8
00007aa3a45d3bd8  push r9
00007aa3a45d3bda  push r10
00007aa3a45d3bdc  push r11
00007aa3a45d3bde  sub rsp, 0xF0
00007aa3a45d3be5  vmovaps [rsp], xmm0
00007aa3a45d3bea  vmovaps [rsp+0x10], xmm2
00007aa3a45d3bf0  vmovaps [rsp+0x20], xmm3
00007aa3a45d3bf6  vmovaps [rsp+0x30], xmm4
00007aa3a45d3bfc  vmovaps [rsp+0x40], xmm5
00007aa3a45d3c02  vmovaps [rsp+0x50], xmm6
00007aa3a45d3c08  vmovaps [rsp+0x60], xmm7
00007aa3a45d3c0e  vmovaps [rsp+0x70], xmm8
00007aa3a45d3c14  vmovaps [rsp+0x80], xmm9
00007aa3a45d3c1d  vmovaps [rsp+0x90], xmm10
00007aa3a45d3c26  vmovaps [rsp+0xA0], xmm11
00007aa3a45d3c2f  vmovaps [rsp+0xB0], xmm12
00007aa3a45d3c38  vmovaps [rsp+0xC0], xmm13
00007aa3a45d3c41  vmovaps [rsp+0xD0], xmm14
00007aa3a45d3c4a  vmovaps [rsp+0xE0], xmm15
00007aa3a45d3c53  sub rsp, 0x30
00007aa3a45d3c57  movaps [rsp], xmm1
00007aa3a45d3c5b  movaps [rsp+0x10], xmm14
00007aa3a45d3c61  movaps [rsp+0x20], xmm6
00007aa3a45d3c66  lea rdi, [rsp]
00007aa3a45d3c6a  mov esi, 0x00
00007aa3a45d3c6f  mov rax, 0x5F551B683530
00007aa3a45d3c79  call rax
00007aa3a45d3c7b  movaps xmm1, [rsp]
00007aa3a45d3c7f  add rsp, 0x30
00007aa3a45d3c83  vmovaps xmm0, [rsp]
00007aa3a45d3c88  vmovaps xmm2, [rsp+0x10]
00007aa3a45d3c8e  vmovaps xmm3, [rsp+0x20]
00007aa3a45d3c94  vmovaps xmm4, [rsp+0x30]
00007aa3a45d3c9a  vmovaps xmm5, [rsp+0x40]
00007aa3a45d3ca0  vmovaps xmm6, [rsp+0x50]
00007aa3a45d3ca6  vmovaps xmm7, [rsp+0x60]
00007aa3a45d3cac  vmovaps xmm8, [rsp+0x70]
00007aa3a45d3cb2  vmovaps xmm9, [rsp+0x80]
00007aa3a45d3cbb  vmovaps xmm10, [rsp+0x90]
00007aa3a45d3cc4  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d3ccd  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d3cd6  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d3cdf  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d3ce8  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d3cf1  add rsp, 0xF0
00007aa3a45d3cf8  pop r11
00007aa3a45d3cfa  pop r10
00007aa3a45d3cfc  pop r9
00007aa3a45d3cfe  pop r8
00007aa3a45d3d00  pop rsi
00007aa3a45d3d01  pop rdi
00007aa3a45d3d02  pop rdx
00007aa3a45d3d03  pop rcx
00007aa3a45d3d04  pop rax
00007aa3a45d3d05  add rsp, 0x08
00007aa3a45d3d09  jmp 0x00007AA3A45D0015
00007aa3a45d3d0e  sub rsp, 0x08
00007aa3a45d3d12  push rax
00007aa3a45d3d13  push rcx
00007aa3a45d3d14  push rdx
00007aa3a45d3d15  push rdi
00007aa3a45d3d16  push rsi
00007aa3a45d3d17  push r8
00007aa3a45d3d19  push r9
00007aa3a45d3d1b  push r10
00007aa3a45d3d1d  push r11
00007aa3a45d3d1f  sub rsp, 0xF0
00007aa3a45d3d26  vmovaps [rsp], xmm0
00007aa3a45d3d2b  vmovaps [rsp+0x10], xmm1
00007aa3a45d3d31  vmovaps [rsp+0x20], xmm2
00007aa3a45d3d37  vmovaps [rsp+0x30], xmm3
00007aa3a45d3d3d  vmovaps [rsp+0x40], xmm4
00007aa3a45d3d43  vmovaps [rsp+0x50], xmm5
00007aa3a45d3d49  vmovaps [rsp+0x60], xmm6
00007aa3a45d3d4f  vmovaps [rsp+0x70], xmm7
00007aa3a45d3d55  vmovaps [rsp+0x80], xmm8
00007aa3a45d3d5e  vmovaps [rsp+0x90], xmm9
00007aa3a45d3d67  vmovaps [rsp+0xA0], xmm10
00007aa3a45d3d70  vmovaps [rsp+0xB0], xmm12
00007aa3a45d3d79  vmovaps [rsp+0xC0], xmm13
00007aa3a45d3d82  vmovaps [rsp+0xD0], xmm14
00007aa3a45d3d8b  vmovaps [rsp+0xE0], xmm15
00007aa3a45d3d94  sub rsp, 0x30
00007aa3a45d3d98  movaps [rsp], xmm11
00007aa3a45d3d9d  movaps [rsp+0x10], xmm13
00007aa3a45d3da3  movaps [rsp+0x20], xmm14
00007aa3a45d3da9  lea rdi, [rsp]
00007aa3a45d3dad  mov esi, 0x00
00007aa3a45d3db2  mov rax, 0x5F551B683530
00007aa3a45d3dbc  call rax
00007aa3a45d3dbe  movaps xmm11, [rsp]
00007aa3a45d3dc3  add rsp, 0x30
00007aa3a45d3dc7  vmovaps xmm0, [rsp]
00007aa3a45d3dcc  vmovaps xmm1, [rsp+0x10]
00007aa3a45d3dd2  vmovaps xmm2, [rsp+0x20]
00007aa3a45d3dd8  vmovaps xmm3, [rsp+0x30]
00007aa3a45d3dde  vmovaps xmm4, [rsp+0x40]
00007aa3a45d3de4  vmovaps xmm5, [rsp+0x50]
00007aa3a45d3dea  vmovaps xmm6, [rsp+0x60]
00007aa3a45d3df0  vmovaps xmm7, [rsp+0x70]
00007aa3a45d3df6  vmovaps xmm8, [rsp+0x80]
00007aa3a45d3dff  vmovaps xmm9, [rsp+0x90]
00007aa3a45d3e08  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d3e11  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d3e1a  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d3e23  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d3e2c  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d3e35  add rsp, 0xF0
00007aa3a45d3e3c  pop r11
00007aa3a45d3e3e  pop r10
00007aa3a45d3e40  pop r9
00007aa3a45d3e42  pop r8
00007aa3a45d3e44  pop rsi
00007aa3a45d3e45  pop rdi
00007aa3a45d3e46  pop rdx
00007aa3a45d3e47  pop rcx
00007aa3a45d3e48  pop rax
00007aa3a45d3e49  add rsp, 0x08
00007aa3a45d3e4d  jmp 0x00007AA3A45D003F
00007aa3a45d3e52  sub rsp, 0x08
00007aa3a45d3e56  push rax
00007aa3a45d3e57  push rcx
00007aa3a45d3e58  push rdx
00007aa3a45d3e59  push rdi
00007aa3a45d3e5a  push rsi
00007aa3a45d3e5b  push r8
00007aa3a45d3e5d  push r9
00007aa3a45d3e5f  push r10
00007aa3a45d3e61  push r11
00007aa3a45d3e63  sub rsp, 0xF0
00007aa3a45d3e6a  vmovaps [rsp], xmm0
00007aa3a45d3e6f  vmovaps [rsp+0x10], xmm1
00007aa3a45d3e75  vmovaps [rsp+0x20], xmm2
00007aa3a45d3e7b  vmovaps [rsp+0x30], xmm3
00007aa3a45d3e81  vmovaps [rsp+0x40], xmm4
00007aa3a45d3e87  vmovaps [rsp+0x50], xmm5
00007aa3a45d3e8d  vmovaps [rsp+0x60], xmm6
00007aa3a45d3e93  vmovaps [rsp+0x70], xmm7
00007aa3a45d3e99  vmovaps [rsp+0x80], xmm8
00007aa3a45d3ea2  vmovaps [rsp+0x90], xmm9
00007aa3a45d3eab  vmovaps [rsp+0xA0], xmm10
00007aa3a45d3eb4  vmovaps [rsp+0xB0], xmm11
00007aa3a45d3ebd  vmovaps [rsp+0xC0], xmm12
00007aa3a45d3ec6  vmovaps [rsp+0xD0], xmm14
00007aa3a45d3ecf  vmovaps [rsp+0xE0], xmm15
00007aa3a45d3ed8  sub rsp, 0x30
00007aa3a45d3edc  movaps [rsp], xmm13
00007aa3a45d3ee1  movaps [rsp+0x10], xmm8
00007aa3a45d3ee7  movaps [rsp+0x20], xmm14
00007aa3a45d3eed  lea rdi, [rsp]
00007aa3a45d3ef1  mov esi, 0x00
00007aa3a45d3ef6  mov rax, 0x5F551B683530
00007aa3a45d3f00  call rax
00007aa3a45d3f02  movaps xmm13, [rsp]
00007aa3a45d3f07  add rsp, 0x30
00007aa3a45d3f0b  vmovaps xmm0, [rsp]
00007aa3a45d3f10  vmovaps xmm1, [rsp+0x10]
00007aa3a45d3f16  vmovaps xmm2, [rsp+0x20]
00007aa3a45d3f1c  vmovaps xmm3, [rsp+0x30]
00007aa3a45d3f22  vmovaps xmm4, [rsp+0x40]
00007aa3a45d3f28  vmovaps xmm5, [rsp+0x50]
00007aa3a45d3f2e  vmovaps xmm6, [rsp+0x60]
00007aa3a45d3f34  vmovaps xmm7, [rsp+0x70]
00007aa3a45d3f3a  vmovaps xmm8, [rsp+0x80]
00007aa3a45d3f43  vmovaps xmm9, [rsp+0x90]
00007aa3a45d3f4c  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d3f55  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d3f5e  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d3f67  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d3f70  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d3f79  add rsp, 0xF0
00007aa3a45d3f80  pop r11
00007aa3a45d3f82  pop r10
00007aa3a45d3f84  pop r9
00007aa3a45d3f86  pop r8
00007aa3a45d3f88  pop rsi
00007aa3a45d3f89  pop rdi
00007aa3a45d3f8a  pop rdx
00007aa3a45d3f8b  pop rcx
00007aa3a45d3f8c  pop rax
00007aa3a45d3f8d  add rsp, 0x08
00007aa3a45d3f91  jmp 0x00007AA3A45D006E
00007aa3a45d3f96  sub rsp, 0x08
00007aa3a45d3f9a  push rax
00007aa3a45d3f9b  push rcx
00007aa3a45d3f9c  push rdx
00007aa3a45d3f9d  push rdi
00007aa3a45d3f9e  push rsi
00007aa3a45d3f9f  push r8
00007aa3a45d3fa1  push r9
00007aa3a45d3fa3  push r10
00007aa3a45d3fa5  push r11
00007aa3a45d3fa7  sub rsp, 0xF0
00007aa3a45d3fae  vmovaps [rsp], xmm0
00007aa3a45d3fb3  vmovaps [rsp+0x10], xmm1
00007aa3a45d3fb9  vmovaps [rsp+0x20], xmm2
00007aa3a45d3fbf  vmovaps [rsp+0x30], xmm3
00007aa3a45d3fc5  vmovaps [rsp+0x40], xmm4
00007aa3a45d3fcb  vmovaps [rsp+0x50], xmm5
00007aa3a45d3fd1  vmovaps [rsp+0x60], xmm6
00007aa3a45d3fd7  vmovaps [rsp+0x70], xmm7
00007aa3a45d3fdd  vmovaps [rsp+0x80], xmm9
00007aa3a45d3fe6  vmovaps [rsp+0x90], xmm10
00007aa3a45d3fef  vmovaps [rsp+0xA0], xmm11
00007aa3a45d3ff8  vmovaps [rsp+0xB0], xmm12
00007aa3a45d4001  vmovaps [rsp+0xC0], xmm13
00007aa3a45d400a  vmovaps [rsp+0xD0], xmm14
00007aa3a45d4013  vmovaps [rsp+0xE0], xmm15
00007aa3a45d401c  sub rsp, 0x30
00007aa3a45d4020  movaps [rsp], xmm8
00007aa3a45d4025  movaps [rsp+0x10], xmm7
00007aa3a45d402a  movaps [rsp+0x20], xmm14
00007aa3a45d4030  lea rdi, [rsp]
00007aa3a45d4034  mov esi, 0x00
00007aa3a45d4039  mov rax, 0x5F551B683530
00007aa3a45d4043  call rax
00007aa3a45d4045  movaps xmm8, [rsp]
00007aa3a45d404a  add rsp, 0x30
00007aa3a45d404e  vmovaps xmm0, [rsp]
00007aa3a45d4053  vmovaps xmm1, [rsp+0x10]
00007aa3a45d4059  vmovaps xmm2, [rsp+0x20]
00007aa3a45d405f  vmovaps xmm3, [rsp+0x30]
00007aa3a45d4065  vmovaps xmm4, [rsp+0x40]
00007aa3a45d406b  vmovaps xmm5, [rsp+0x50]
00007aa3a45d4071  vmovaps xmm6, [rsp+0x60]
00007aa3a45d4077  vmovaps xmm7, [rsp+0x70]
00007aa3a45d407d  vmovaps xmm9, [rsp+0x80]
00007aa3a45d4086  vmovaps xmm10, [rsp+0x90]
00007aa3a45d408f  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d4098  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d40a1  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d40aa  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d40b3  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d40bc  add rsp, 0xF0
00007aa3a45d40c3  pop r11
00007aa3a45d40c5  pop r10
00007aa3a45d40c7  pop r9
00007aa3a45d40c9  pop r8
00007aa3a45d40cb  pop rsi
00007aa3a45d40cc  pop rdi
00007aa3a45d40cd  pop rdx
00007aa3a45d40ce  pop rcx
00007aa3a45d40cf  pop rax
00007aa3a45d40d0  add rsp, 0x08
00007aa3a45d40d4  jmp 0x00007AA3A45D0094
00007aa3a45d40d9  sub rsp, 0x08
00007aa3a45d40dd  push rax
00007aa3a45d40de  push rcx
00007aa3a45d40df  push rdx
00007aa3a45d40e0  push rdi
00007aa3a45d40e1  push rsi
00007aa3a45d40e2  push r8
00007aa3a45d40e4  push r9
00007aa3a45d40e6  push r10
00007aa3a45d40e8  push r11
00007aa3a45d40ea  sub rsp, 0xF0
00007aa3a45d40f1  vmovaps [rsp], xmm0
00007aa3a45d40f6  vmovaps [rsp+0x10], xmm1
00007aa3a45d40fc  vmovaps [rsp+0x20], xmm2
00007aa3a45d4102  vmovaps [rsp+0x30], xmm3
00007aa3a45d4108  vmovaps [rsp+0x40], xmm4
00007aa3a45d410e  vmovaps [rsp+0x50], xmm5
00007aa3a45d4114  vmovaps [rsp+0x60], xmm6
00007aa3a45d411a  vmovaps [rsp+0x70], xmm7
00007aa3a45d4120  vmovaps [rsp+0x80], xmm8
00007aa3a45d4129  vmovaps [rsp+0x90], xmm9
00007aa3a45d4132  vmovaps [rsp+0xA0], xmm10
00007aa3a45d413b  vmovaps [rsp+0xB0], xmm11
00007aa3a45d4144  vmovaps [rsp+0xC0], xmm12
00007aa3a45d414d  vmovaps [rsp+0xD0], xmm13
00007aa3a45d4156  vmovaps [rsp+0xE0], xmm15
00007aa3a45d415f  sub rsp, 0x30
00007aa3a45d4163  movaps [rsp], xmm14
00007aa3a45d4168  movaps [rsp+0x10], xmm12
00007aa3a45d416e  movaps [rsp+0x20], xmm9
00007aa3a45d4174  lea rdi, [rsp]
00007aa3a45d4178  mov esi, 0x00
00007aa3a45d417d  mov rax, 0x5F551B683530
00007aa3a45d4187  call rax
00007aa3a45d4189  movaps xmm14, [rsp]
00007aa3a45d418e  add rsp, 0x30
00007aa3a45d4192  vmovaps xmm0, [rsp]
00007aa3a45d4197  vmovaps xmm1, [rsp+0x10]
00007aa3a45d419d  vmovaps xmm2, [rsp+0x20]
00007aa3a45d41a3  vmovaps xmm3, [rsp+0x30]
00007aa3a45d41a9  vmovaps xmm4, [rsp+0x40]
00007aa3a45d41af  vmovaps xmm5, [rsp+0x50]
00007aa3a45d41b5  vmovaps xmm6, [rsp+0x60]
00007aa3a45d41bb  vmovaps xmm7, [rsp+0x70]
00007aa3a45d41c1  vmovaps xmm8, [rsp+0x80]
00007aa3a45d41ca  vmovaps xmm9, [rsp+0x90]
00007aa3a45d41d3  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d41dc  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d41e5  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d41ee  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d41f7  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d4200  add rsp, 0xF0
00007aa3a45d4207  pop r11
00007aa3a45d4209  pop r10
00007aa3a45d420b  pop r9
00007aa3a45d420d  pop r8
00007aa3a45d420f  pop rsi
00007aa3a45d4210  pop rdi
00007aa3a45d4211  pop rdx
00007aa3a45d4212  pop rcx
00007aa3a45d4213  pop rax
00007aa3a45d4214  add rsp, 0x08
00007aa3a45d4218  jmp 0x00007AA3A45D00AE
00007aa3a45d421d  sub rsp, 0x08
00007aa3a45d4221  push rax
00007aa3a45d4222  push rcx
00007aa3a45d4223  push rdx
00007aa3a45d4224  push rdi
00007aa3a45d4225  push rsi
00007aa3a45d4226  push r8
00007aa3a45d4228  push r9
00007aa3a45d422a  push r10
00007aa3a45d422c  push r11
00007aa3a45d422e  sub rsp, 0xF0
00007aa3a45d4235  vmovaps [rsp], xmm0
00007aa3a45d423a  vmovaps [rsp+0x10], xmm1
00007aa3a45d4240  vmovaps [rsp+0x20], xmm2
00007aa3a45d4246  vmovaps [rsp+0x30], xmm3
00007aa3a45d424c  vmovaps [rsp+0x40], xmm4
00007aa3a45d4252  vmovaps [rsp+0x50], xmm5
00007aa3a45d4258  vmovaps [rsp+0x60], xmm6
00007aa3a45d425e  vmovaps [rsp+0x70], xmm7
00007aa3a45d4264  vmovaps [rsp+0x80], xmm8
00007aa3a45d426d  vmovaps [rsp+0x90], xmm10
00007aa3a45d4276  vmovaps [rsp+0xA0], xmm11
00007aa3a45d427f  vmovaps [rsp+0xB0], xmm12
00007aa3a45d4288  vmovaps [rsp+0xC0], xmm13
00007aa3a45d4291  vmovaps [rsp+0xD0], xmm14
00007aa3a45d429a  vmovaps [rsp+0xE0], xmm15
00007aa3a45d42a3  sub rsp, 0x30
00007aa3a45d42a7  movaps [rsp], xmm9
00007aa3a45d42ac  movaps [rsp+0x10], xmm7
00007aa3a45d42b1  movaps [rsp+0x20], xmm12
00007aa3a45d42b7  lea rdi, [rsp]
00007aa3a45d42bb  mov esi, 0x00
00007aa3a45d42c0  mov rax, 0x5F551B683530
00007aa3a45d42ca  call rax
00007aa3a45d42cc  movaps xmm9, [rsp]
00007aa3a45d42d1  add rsp, 0x30
00007aa3a45d42d5  vmovaps xmm0, [rsp]
00007aa3a45d42da  vmovaps xmm1, [rsp+0x10]
00007aa3a45d42e0  vmovaps xmm2, [rsp+0x20]
00007aa3a45d42e6  vmovaps xmm3, [rsp+0x30]
00007aa3a45d42ec  vmovaps xmm4, [rsp+0x40]
00007aa3a45d42f2  vmovaps xmm5, [rsp+0x50]
00007aa3a45d42f8  vmovaps xmm6, [rsp+0x60]
00007aa3a45d42fe  vmovaps xmm7, [rsp+0x70]
00007aa3a45d4304  vmovaps xmm8, [rsp+0x80]
00007aa3a45d430d  vmovaps xmm10, [rsp+0x90]
00007aa3a45d4316  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d431f  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d4328  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d4331  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d433a  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d4343  add rsp, 0xF0
00007aa3a45d434a  pop r11
00007aa3a45d434c  pop r10
00007aa3a45d434e  pop r9
00007aa3a45d4350  pop r8
00007aa3a45d4352  pop rsi
00007aa3a45d4353  pop rdi
00007aa3a45d4354  pop rdx
00007aa3a45d4355  pop rcx
00007aa3a45d4356  pop rax
00007aa3a45d4357  add rsp, 0x08
00007aa3a45d435b  jmp 0x00007AA3A45D00DD
00007aa3a45d4360  sub rsp, 0x08
00007aa3a45d4364  push rax
00007aa3a45d4365  push rcx
00007aa3a45d4366  push rdx
00007aa3a45d4367  push rdi
00007aa3a45d4368  push rsi
00007aa3a45d4369  push r8
00007aa3a45d436b  push r9
00007aa3a45d436d  push r10
00007aa3a45d436f  push r11
00007aa3a45d4371  sub rsp, 0xF0
00007aa3a45d4378  vmovaps [rsp], xmm0
00007aa3a45d437d  vmovaps [rsp+0x10], xmm1
00007aa3a45d4383  vmovaps [rsp+0x20], xmm2
00007aa3a45d4389  vmovaps [rsp+0x30], xmm3
00007aa3a45d438f  vmovaps [rsp+0x40], xmm4
00007aa3a45d4395  vmovaps [rsp+0x50], xmm5
00007aa3a45d439b  vmovaps [rsp+0x60], xmm6
00007aa3a45d43a1  vmovaps [rsp+0x70], xmm7
00007aa3a45d43a7  vmovaps [rsp+0x80], xmm8
00007aa3a45d43b0  vmovaps [rsp+0x90], xmm9
00007aa3a45d43b9  vmovaps [rsp+0xA0], xmm10
00007aa3a45d43c2  vmovaps [rsp+0xB0], xmm11
00007aa3a45d43cb  vmovaps [rsp+0xC0], xmm13
00007aa3a45d43d4  vmovaps [rsp+0xD0], xmm14
00007aa3a45d43dd  vmovaps [rsp+0xE0], xmm15
00007aa3a45d43e6  sub rsp, 0x30
00007aa3a45d43ea  movaps [rsp], xmm12
00007aa3a45d43ef  movaps [rsp+0x10], xmm15
00007aa3a45d43f5  movaps [rsp+0x20], xmm11
00007aa3a45d43fb  lea rdi, [rsp]
00007aa3a45d43ff  mov esi, 0x00
00007aa3a45d4404  mov rax, 0x5F551B683530
00007aa3a45d440e  call rax
00007aa3a45d4410  movaps xmm12, [rsp]
00007aa3a45d4415  add rsp, 0x30
00007aa3a45d4419  vmovaps xmm0, [rsp]
00007aa3a45d441e  vmovaps xmm1, [rsp+0x10]
00007aa3a45d4424  vmovaps xmm2, [rsp+0x20]
00007aa3a45d442a  vmovaps xmm3, [rsp+0x30]
00007aa3a45d4430  vmovaps xmm4, [rsp+0x40]
00007aa3a45d4436  vmovaps xmm5, [rsp+0x50]
00007aa3a45d443c  vmovaps xmm6, [rsp+0x60]
00007aa3a45d4442  vmovaps xmm7, [rsp+0x70]
00007aa3a45d4448  vmovaps xmm8, [rsp+0x80]
00007aa3a45d4451  vmovaps xmm9, [rsp+0x90]
00007aa3a45d445a  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d4463  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d446c  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d4475  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d447e  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d4487  add rsp, 0xF0
00007aa3a45d448e  pop r11
00007aa3a45d4490  pop r10
00007aa3a45d4492  pop r9
00007aa3a45d4494  pop r8
00007aa3a45d4496  pop rsi
00007aa3a45d4497  pop rdi
00007aa3a45d4498  pop rdx
00007aa3a45d4499  pop rcx
00007aa3a45d449a  pop rax
00007aa3a45d449b  add rsp, 0x08
00007aa3a45d449f  jmp 0x00007AA3A45D00F7
00007aa3a45d44a4  sub rsp, 0x08
00007aa3a45d44a8  push rax
00007aa3a45d44a9  push rcx
00007aa3a45d44aa  push rdx
00007aa3a45d44ab  push rdi
00007aa3a45d44ac  push rsi
00007aa3a45d44ad  push r8
00007aa3a45d44af  push r9
00007aa3a45d44b1  push r10
00007aa3a45d44b3  push r11
00007aa3a45d44b5  sub rsp, 0xF0
00007aa3a45d44bc  vmovaps [rsp], xmm0
00007aa3a45d44c1  vmovaps [rsp+0x10], xmm1
00007aa3a45d44c7  vmovaps [rsp+0x20], xmm2
00007aa3a45d44cd  vmovaps [rsp+0x30], xmm3
00007aa3a45d44d3  vmovaps [rsp+0x40], xmm4
00007aa3a45d44d9  vmovaps [rsp+0x50], xmm5
00007aa3a45d44df  vmovaps [rsp+0x60], xmm6
00007aa3a45d44e5  vmovaps [rsp+0x70], xmm7
00007aa3a45d44eb  vmovaps [rsp+0x80], xmm8
00007aa3a45d44f4  vmovaps [rsp+0x90], xmm9
00007aa3a45d44fd  vmovaps [rsp+0xA0], xmm10
00007aa3a45d4506  vmovaps [rsp+0xB0], xmm12
00007aa3a45d450f  vmovaps [rsp+0xC0], xmm13
00007aa3a45d4518  vmovaps [rsp+0xD0], xmm14
00007aa3a45d4521  vmovaps [rsp+0xE0], xmm15
00007aa3a45d452a  sub rsp, 0x30
00007aa3a45d452e  movaps [rsp], xmm11
00007aa3a45d4533  movaps [rsp+0x10], xmm7
00007aa3a45d4538  movaps [rsp+0x20], xmm15
00007aa3a45d453e  lea rdi, [rsp]
00007aa3a45d4542  mov esi, 0x00
00007aa3a45d4547  mov rax, 0x5F551B683530
00007aa3a45d4551  call rax
00007aa3a45d4553  movaps xmm11, [rsp]
00007aa3a45d4558  add rsp, 0x30
00007aa3a45d455c  vmovaps xmm0, [rsp]
00007aa3a45d4561  vmovaps xmm1, [rsp+0x10]
00007aa3a45d4567  vmovaps xmm2, [rsp+0x20]
00007aa3a45d456d  vmovaps xmm3, [rsp+0x30]
00007aa3a45d4573  vmovaps xmm4, [rsp+0x40]
00007aa3a45d4579  vmovaps xmm5, [rsp+0x50]
00007aa3a45d457f  vmovaps xmm6, [rsp+0x60]
00007aa3a45d4585  vmovaps xmm7, [rsp+0x70]
00007aa3a45d458b  vmovaps xmm8, [rsp+0x80]
00007aa3a45d4594  vmovaps xmm9, [rsp+0x90]
00007aa3a45d459d  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d45a6  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d45af  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d45b8  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d45c1  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d45ca  add rsp, 0xF0
00007aa3a45d45d1  pop r11
00007aa3a45d45d3  pop r10
00007aa3a45d45d5  pop r9
00007aa3a45d45d7  pop r8
00007aa3a45d45d9  pop rsi
00007aa3a45d45da  pop rdi
00007aa3a45d45db  pop rdx
00007aa3a45d45dc  pop rcx
00007aa3a45d45dd  pop rax
00007aa3a45d45de  add rsp, 0x08
00007aa3a45d45e2  jmp 0x00007AA3A45D0123
00007aa3a45d45e7  sub rsp, 0x08
00007aa3a45d45eb  push rax
00007aa3a45d45ec  push rcx
00007aa3a45d45ed  push rdx
00007aa3a45d45ee  push rdi
00007aa3a45d45ef  push rsi
00007aa3a45d45f0  push r8
00007aa3a45d45f2  push r9
00007aa3a45d45f4  push r10
00007aa3a45d45f6  push r11
00007aa3a45d45f8  sub rsp, 0xF0
00007aa3a45d45ff  vmovaps [rsp], xmm0
00007aa3a45d4604  vmovaps [rsp+0x10], xmm1
00007aa3a45d460a  vmovaps [rsp+0x20], xmm2
00007aa3a45d4610  vmovaps [rsp+0x30], xmm3
00007aa3a45d4616  vmovaps [rsp+0x40], xmm4
00007aa3a45d461c  vmovaps [rsp+0x50], xmm5
00007aa3a45d4622  vmovaps [rsp+0x60], xmm6
00007aa3a45d4628  vmovaps [rsp+0x70], xmm7
00007aa3a45d462e  vmovaps [rsp+0x80], xmm8
00007aa3a45d4637  vmovaps [rsp+0x90], xmm9
00007aa3a45d4640  vmovaps [rsp+0xA0], xmm10
00007aa3a45d4649  vmovaps [rsp+0xB0], xmm11
00007aa3a45d4652  vmovaps [rsp+0xC0], xmm12
00007aa3a45d465b  vmovaps [rsp+0xD0], xmm13
00007aa3a45d4664  vmovaps [rsp+0xE0], xmm14
00007aa3a45d466d  sub rsp, 0x30
00007aa3a45d4671  movaps [rsp], xmm15
00007aa3a45d4676  movaps [rsp+0x10], xmm10
00007aa3a45d467c  movaps [rsp+0x20], xmm13
00007aa3a45d4682  lea rdi, [rsp]
00007aa3a45d4686  mov esi, 0x00
00007aa3a45d468b  mov rax, 0x5F551B683530
00007aa3a45d4695  call rax
00007aa3a45d4697  movaps xmm15, [rsp]
00007aa3a45d469c  add rsp, 0x30
00007aa3a45d46a0  vmovaps xmm0, [rsp]
00007aa3a45d46a5  vmovaps xmm1, [rsp+0x10]
00007aa3a45d46ab  vmovaps xmm2, [rsp+0x20]
00007aa3a45d46b1  vmovaps xmm3, [rsp+0x30]
00007aa3a45d46b7  vmovaps xmm4, [rsp+0x40]
00007aa3a45d46bd  vmovaps xmm5, [rsp+0x50]
00007aa3a45d46c3  vmovaps xmm6, [rsp+0x60]
00007aa3a45d46c9  vmovaps xmm7, [rsp+0x70]
00007aa3a45d46cf  vmovaps xmm8, [rsp+0x80]
00007aa3a45d46d8  vmovaps xmm9, [rsp+0x90]
00007aa3a45d46e1  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d46ea  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d46f3  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d46fc  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d4705  vmovaps xmm14, [rsp+0xE0]
00007aa3a45d470e  add rsp, 0xF0
00007aa3a45d4715  pop r11
00007aa3a45d4717  pop r10
00007aa3a45d4719  pop r9
00007aa3a45d471b  pop r8
00007aa3a45d471d  pop rsi
00007aa3a45d471e  pop rdi
00007aa3a45d471f  pop rdx
00007aa3a45d4720  pop rcx
00007aa3a45d4721  pop rax
00007aa3a45d4722  add rsp, 0x08
00007aa3a45d4726  jmp 0x00007AA3A45D013D
00007aa3a45d472b  sub rsp, 0x08
00007aa3a45d472f  push rax
00007aa3a45d4730  push rcx
00007aa3a45d4731  push rdx
00007aa3a45d4732  push rdi
00007aa3a45d4733  push rsi
00007aa3a45d4734  push r8
00007aa3a45d4736  push r9
00007aa3a45d4738  push r10
00007aa3a45d473a  push r11
00007aa3a45d473c  sub rsp, 0xF0
00007aa3a45d4743  vmovaps [rsp], xmm0
00007aa3a45d4748  vmovaps [rsp+0x10], xmm1
00007aa3a45d474e  vmovaps [rsp+0x20], xmm2
00007aa3a45d4754  vmovaps [rsp+0x30], xmm3
00007aa3a45d475a  vmovaps [rsp+0x40], xmm4
00007aa3a45d4760  vmovaps [rsp+0x50], xmm5
00007aa3a45d4766  vmovaps [rsp+0x60], xmm6
00007aa3a45d476c  vmovaps [rsp+0x70], xmm7
00007aa3a45d4772  vmovaps [rsp+0x80], xmm8
00007aa3a45d477b  vmovaps [rsp+0x90], xmm9
00007aa3a45d4784  vmovaps [rsp+0xA0], xmm11
00007aa3a45d478d  vmovaps [rsp+0xB0], xmm12
00007aa3a45d4796  vmovaps [rsp+0xC0], xmm13
00007aa3a45d479f  vmovaps [rsp+0xD0], xmm14
00007aa3a45d47a8  vmovaps [rsp+0xE0], xmm15
00007aa3a45d47b1  sub rsp, 0x30
00007aa3a45d47b5  movaps [rsp], xmm10
00007aa3a45d47ba  movaps [rsp+0x10], xmm7
00007aa3a45d47bf  movaps [rsp+0x20], xmm13
00007aa3a45d47c5  lea rdi, [rsp]
00007aa3a45d47c9  mov esi, 0x00
00007aa3a45d47ce  mov rax, 0x5F551B683530
00007aa3a45d47d8  call rax
00007aa3a45d47da  movaps xmm10, [rsp]
00007aa3a45d47df  add rsp, 0x30
00007aa3a45d47e3  vmovaps xmm0, [rsp]
00007aa3a45d47e8  vmovaps xmm1, [rsp+0x10]
00007aa3a45d47ee  vmovaps xmm2, [rsp+0x20]
00007aa3a45d47f4  vmovaps xmm3, [rsp+0x30]
00007aa3a45d47fa  vmovaps xmm4, [rsp+0x40]
00007aa3a45d4800  vmovaps xmm5, [rsp+0x50]
00007aa3a45d4806  vmovaps xmm6, [rsp+0x60]
00007aa3a45d480c  vmovaps xmm7, [rsp+0x70]
00007aa3a45d4812  vmovaps xmm8, [rsp+0x80]
00007aa3a45d481b  vmovaps xmm9, [rsp+0x90]
00007aa3a45d4824  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d482d  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d4836  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d483f  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d4848  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d4851  add rsp, 0xF0
00007aa3a45d4858  pop r11
00007aa3a45d485a  pop r10
00007aa3a45d485c  pop r9
00007aa3a45d485e  pop r8
00007aa3a45d4860  pop rsi
00007aa3a45d4861  pop rdi
00007aa3a45d4862  pop rdx
00007aa3a45d4863  pop rcx
00007aa3a45d4864  pop rax
00007aa3a45d4865  add rsp, 0x08
00007aa3a45d4869  jmp 0x00007AA3A45D0169
00007aa3a45d486e  sub rsp, 0x08
00007aa3a45d4872  push rax
00007aa3a45d4873  push rcx
00007aa3a45d4874  push rdx
00007aa3a45d4875  push rdi
00007aa3a45d4876  push rsi
00007aa3a45d4877  push r8
00007aa3a45d4879  push r9
00007aa3a45d487b  push r10
00007aa3a45d487d  push r11
00007aa3a45d487f  sub rsp, 0xF0
00007aa3a45d4886  vmovaps [rsp], xmm0
00007aa3a45d488b  vmovaps [rsp+0x10], xmm1
00007aa3a45d4891  vmovaps [rsp+0x20], xmm2
00007aa3a45d4897  vmovaps [rsp+0x30], xmm3
00007aa3a45d489d  vmovaps [rsp+0x40], xmm4
00007aa3a45d48a3  vmovaps [rsp+0x50], xmm5
00007aa3a45d48a9  vmovaps [rsp+0x60], xmm6
00007aa3a45d48af  vmovaps [rsp+0x70], xmm7
00007aa3a45d48b5  vmovaps [rsp+0x80], xmm8
00007aa3a45d48be  vmovaps [rsp+0x90], xmm9
00007aa3a45d48c7  vmovaps [rsp+0xA0], xmm10
00007aa3a45d48d0  vmovaps [rsp+0xB0], xmm11
00007aa3a45d48d9  vmovaps [rsp+0xC0], xmm12
00007aa3a45d48e2  vmovaps [rsp+0xD0], xmm14
00007aa3a45d48eb  vmovaps [rsp+0xE0], xmm15
00007aa3a45d48f4  sub rsp, 0x30
00007aa3a45d48f8  movaps [rsp], xmm13
00007aa3a45d48fd  movaps [rsp+0x10], xmm1
00007aa3a45d4902  movaps [rsp+0x20], xmm8
00007aa3a45d4908  lea rdi, [rsp]
00007aa3a45d490c  mov esi, 0x00
00007aa3a45d4911  mov rax, 0x5F551B683530
00007aa3a45d491b  call rax
00007aa3a45d491d  movaps xmm13, [rsp]
00007aa3a45d4922  add rsp, 0x30
00007aa3a45d4926  vmovaps xmm0, [rsp]
00007aa3a45d492b  vmovaps xmm1, [rsp+0x10]
00007aa3a45d4931  vmovaps xmm2, [rsp+0x20]
00007aa3a45d4937  vmovaps xmm3, [rsp+0x30]
00007aa3a45d493d  vmovaps xmm4, [rsp+0x40]
00007aa3a45d4943  vmovaps xmm5, [rsp+0x50]
00007aa3a45d4949  vmovaps xmm6, [rsp+0x60]
00007aa3a45d494f  vmovaps xmm7, [rsp+0x70]
00007aa3a45d4955  vmovaps xmm8, [rsp+0x80]
00007aa3a45d495e  vmovaps xmm9, [rsp+0x90]
00007aa3a45d4967  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d4970  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d4979  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d4982  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d498b  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d4994  add rsp, 0xF0
00007aa3a45d499b  pop r11
00007aa3a45d499d  pop r10
00007aa3a45d499f  pop r9
00007aa3a45d49a1  pop r8
00007aa3a45d49a3  pop rsi
00007aa3a45d49a4  pop rdi
00007aa3a45d49a5  pop rdx
00007aa3a45d49a6  pop rcx
00007aa3a45d49a7  pop rax
00007aa3a45d49a8  add rsp, 0x08
00007aa3a45d49ac  jmp 0x00007AA3A45D0183
00007aa3a45d49b1  call 0x00007AA3A43FF430
00007aa3a45d49b6  jmp 0x00007AA3A45D018D
00007aa3a45d49bb  sub rsp, 0x08
00007aa3a45d49bf  push rax
00007aa3a45d49c0  push rcx
00007aa3a45d49c1  push rdx
00007aa3a45d49c2  push rdi
00007aa3a45d49c3  push rsi
00007aa3a45d49c4  push r8
00007aa3a45d49c6  push r9
00007aa3a45d49c8  push r10
00007aa3a45d49ca  push r11
00007aa3a45d49cc  sub rsp, 0xF0
00007aa3a45d49d3  vmovaps [rsp], xmm0
00007aa3a45d49d8  vmovaps [rsp+0x10], xmm1
00007aa3a45d49de  vmovaps [rsp+0x20], xmm2
00007aa3a45d49e4  vmovaps [rsp+0x30], xmm3
00007aa3a45d49ea  vmovaps [rsp+0x40], xmm4
00007aa3a45d49f0  vmovaps [rsp+0x50], xmm5
00007aa3a45d49f6  vmovaps [rsp+0x60], xmm6
00007aa3a45d49fc  vmovaps [rsp+0x70], xmm7
00007aa3a45d4a02  vmovaps [rsp+0x80], xmm9
00007aa3a45d4a0b  vmovaps [rsp+0x90], xmm10
00007aa3a45d4a14  vmovaps [rsp+0xA0], xmm11
00007aa3a45d4a1d  vmovaps [rsp+0xB0], xmm12
00007aa3a45d4a26  vmovaps [rsp+0xC0], xmm13
00007aa3a45d4a2f  vmovaps [rsp+0xD0], xmm14
00007aa3a45d4a38  vmovaps [rsp+0xE0], xmm15
00007aa3a45d4a41  sub rsp, 0x30
00007aa3a45d4a45  movaps [rsp], xmm8
00007aa3a45d4a4a  movaps [rsp+0x10], xmm14
00007aa3a45d4a50  movaps [rsp+0x20], xmm9
00007aa3a45d4a56  lea rdi, [rsp]
00007aa3a45d4a5a  mov esi, 0x00
00007aa3a45d4a5f  mov rax, 0x5F551B683530
00007aa3a45d4a69  call rax
00007aa3a45d4a6b  movaps xmm8, [rsp]
00007aa3a45d4a70  add rsp, 0x30
00007aa3a45d4a74  vmovaps xmm0, [rsp]
00007aa3a45d4a79  vmovaps xmm1, [rsp+0x10]
00007aa3a45d4a7f  vmovaps xmm2, [rsp+0x20]
00007aa3a45d4a85  vmovaps xmm3, [rsp+0x30]
00007aa3a45d4a8b  vmovaps xmm4, [rsp+0x40]
00007aa3a45d4a91  vmovaps xmm5, [rsp+0x50]
00007aa3a45d4a97  vmovaps xmm6, [rsp+0x60]
00007aa3a45d4a9d  vmovaps xmm7, [rsp+0x70]
00007aa3a45d4aa3  vmovaps xmm9, [rsp+0x80]
00007aa3a45d4aac  vmovaps xmm10, [rsp+0x90]
00007aa3a45d4ab5  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d4abe  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d4ac7  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d4ad0  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d4ad9  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d4ae2  add rsp, 0xF0
00007aa3a45d4ae9  pop r11
00007aa3a45d4aeb  pop r10
00007aa3a45d4aed  pop r9
00007aa3a45d4aef  pop r8
00007aa3a45d4af1  pop rsi
00007aa3a45d4af2  pop rdi
00007aa3a45d4af3  pop rdx
00007aa3a45d4af4  pop rcx
00007aa3a45d4af5  pop rax
00007aa3a45d4af6  add rsp, 0x08
00007aa3a45d4afa  jmp 0x00007AA3A45D01AF
00007aa3a45d4aff  sub rsp, 0x08
00007aa3a45d4b03  push rax
00007aa3a45d4b04  push rcx
00007aa3a45d4b05  push rdx
00007aa3a45d4b06  push rdi
00007aa3a45d4b07  push rsi
00007aa3a45d4b08  push r8
00007aa3a45d4b0a  push r9
00007aa3a45d4b0c  push r10
00007aa3a45d4b0e  push r11
00007aa3a45d4b10  sub rsp, 0xF0
00007aa3a45d4b17  vmovaps [rsp], xmm0
00007aa3a45d4b1c  vmovaps [rsp+0x10], xmm1
00007aa3a45d4b22  vmovaps [rsp+0x20], xmm2
00007aa3a45d4b28  vmovaps [rsp+0x30], xmm3
00007aa3a45d4b2e  vmovaps [rsp+0x40], xmm4
00007aa3a45d4b34  vmovaps [rsp+0x50], xmm5
00007aa3a45d4b3a  vmovaps [rsp+0x60], xmm6
00007aa3a45d4b40  vmovaps [rsp+0x70], xmm7
00007aa3a45d4b46  vmovaps [rsp+0x80], xmm8
00007aa3a45d4b4f  vmovaps [rsp+0x90], xmm10
00007aa3a45d4b58  vmovaps [rsp+0xA0], xmm11
00007aa3a45d4b61  vmovaps [rsp+0xB0], xmm12
00007aa3a45d4b6a  vmovaps [rsp+0xC0], xmm13
00007aa3a45d4b73  vmovaps [rsp+0xD0], xmm14
00007aa3a45d4b7c  vmovaps [rsp+0xE0], xmm15
00007aa3a45d4b85  sub rsp, 0x30
00007aa3a45d4b89  movaps [rsp], xmm9
00007aa3a45d4b8e  movaps [rsp+0x10], xmm1
00007aa3a45d4b93  movaps [rsp+0x20], xmm14
00007aa3a45d4b99  lea rdi, [rsp]
00007aa3a45d4b9d  mov esi, 0x00
00007aa3a45d4ba2  mov rax, 0x5F551B683530
00007aa3a45d4bac  call rax
00007aa3a45d4bae  movaps xmm9, [rsp]
00007aa3a45d4bb3  add rsp, 0x30
00007aa3a45d4bb7  vmovaps xmm0, [rsp]
00007aa3a45d4bbc  vmovaps xmm1, [rsp+0x10]
00007aa3a45d4bc2  vmovaps xmm2, [rsp+0x20]
00007aa3a45d4bc8  vmovaps xmm3, [rsp+0x30]
00007aa3a45d4bce  vmovaps xmm4, [rsp+0x40]
00007aa3a45d4bd4  vmovaps xmm5, [rsp+0x50]
00007aa3a45d4bda  vmovaps xmm6, [rsp+0x60]
00007aa3a45d4be0  vmovaps xmm7, [rsp+0x70]
00007aa3a45d4be6  vmovaps xmm8, [rsp+0x80]
00007aa3a45d4bef  vmovaps xmm10, [rsp+0x90]
00007aa3a45d4bf8  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d4c01  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d4c0a  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d4c13  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d4c1c  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d4c25  add rsp, 0xF0
00007aa3a45d4c2c  pop r11
00007aa3a45d4c2e  pop r10
00007aa3a45d4c30  pop r9
00007aa3a45d4c32  pop r8
00007aa3a45d4c34  pop rsi
00007aa3a45d4c35  pop rdi
00007aa3a45d4c36  pop rdx
00007aa3a45d4c37  pop rcx
00007aa3a45d4c38  pop rax
00007aa3a45d4c39  add rsp, 0x08
00007aa3a45d4c3d  jmp 0x00007AA3A45D01DD
00007aa3a45d4c42  sub rsp, 0x08
00007aa3a45d4c46  push rax
00007aa3a45d4c47  push rcx
00007aa3a45d4c48  push rdx
00007aa3a45d4c49  push rdi
00007aa3a45d4c4a  push rsi
00007aa3a45d4c4b  push r8
00007aa3a45d4c4d  push r9
00007aa3a45d4c4f  push r10
00007aa3a45d4c51  push r11
00007aa3a45d4c53  sub rsp, 0xF0
00007aa3a45d4c5a  vmovaps [rsp], xmm0
00007aa3a45d4c5f  vmovaps [rsp+0x10], xmm1
00007aa3a45d4c65  vmovaps [rsp+0x20], xmm2
00007aa3a45d4c6b  vmovaps [rsp+0x30], xmm3
00007aa3a45d4c71  vmovaps [rsp+0x40], xmm4
00007aa3a45d4c77  vmovaps [rsp+0x50], xmm5
00007aa3a45d4c7d  vmovaps [rsp+0x60], xmm6
00007aa3a45d4c83  vmovaps [rsp+0x70], xmm7
00007aa3a45d4c89  vmovaps [rsp+0x80], xmm8
00007aa3a45d4c92  vmovaps [rsp+0x90], xmm9
00007aa3a45d4c9b  vmovaps [rsp+0xA0], xmm10
00007aa3a45d4ca4  vmovaps [rsp+0xB0], xmm11
00007aa3a45d4cad  vmovaps [rsp+0xC0], xmm12
00007aa3a45d4cb6  vmovaps [rsp+0xD0], xmm13
00007aa3a45d4cbf  vmovaps [rsp+0xE0], xmm15
00007aa3a45d4cc8  sub rsp, 0x30
00007aa3a45d4ccc  movaps [rsp], xmm14
00007aa3a45d4cd1  movaps [rsp+0x10], xmm4
00007aa3a45d4cd6  movaps [rsp+0x20], xmm1
00007aa3a45d4cdb  lea rdi, [rsp]
00007aa3a45d4cdf  mov esi, 0x00
00007aa3a45d4ce4  mov rax, 0x5F551B683530
00007aa3a45d4cee  call rax
00007aa3a45d4cf0  movaps xmm14, [rsp]
00007aa3a45d4cf5  add rsp, 0x30
00007aa3a45d4cf9  vmovaps xmm0, [rsp]
00007aa3a45d4cfe  vmovaps xmm1, [rsp+0x10]
00007aa3a45d4d04  vmovaps xmm2, [rsp+0x20]
00007aa3a45d4d0a  vmovaps xmm3, [rsp+0x30]
00007aa3a45d4d10  vmovaps xmm4, [rsp+0x40]
00007aa3a45d4d16  vmovaps xmm5, [rsp+0x50]
00007aa3a45d4d1c  vmovaps xmm6, [rsp+0x60]
00007aa3a45d4d22  vmovaps xmm7, [rsp+0x70]
00007aa3a45d4d28  vmovaps xmm8, [rsp+0x80]
00007aa3a45d4d31  vmovaps xmm9, [rsp+0x90]
00007aa3a45d4d3a  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d4d43  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d4d4c  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d4d55  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d4d5e  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d4d67  add rsp, 0xF0
00007aa3a45d4d6e  pop r11
00007aa3a45d4d70  pop r10
00007aa3a45d4d72  pop r9
00007aa3a45d4d74  pop r8
00007aa3a45d4d76  pop rsi
00007aa3a45d4d77  pop rdi
00007aa3a45d4d78  pop rdx
00007aa3a45d4d79  pop rcx
00007aa3a45d4d7a  pop rax
00007aa3a45d4d7b  add rsp, 0x08
00007aa3a45d4d7f  jmp 0x00007AA3A45D0203
00007aa3a45d4d84  sub rsp, 0x08
00007aa3a45d4d88  push rax
00007aa3a45d4d89  push rcx
00007aa3a45d4d8a  push rdx
00007aa3a45d4d8b  push rdi
00007aa3a45d4d8c  push rsi
00007aa3a45d4d8d  push r8
00007aa3a45d4d8f  push r9
00007aa3a45d4d91  push r10
00007aa3a45d4d93  push r11
00007aa3a45d4d95  sub rsp, 0xF0
00007aa3a45d4d9c  vmovaps [rsp], xmm0
00007aa3a45d4da1  vmovaps [rsp+0x10], xmm2
00007aa3a45d4da7  vmovaps [rsp+0x20], xmm3
00007aa3a45d4dad  vmovaps [rsp+0x30], xmm4
00007aa3a45d4db3  vmovaps [rsp+0x40], xmm5
00007aa3a45d4db9  vmovaps [rsp+0x50], xmm6
00007aa3a45d4dbf  vmovaps [rsp+0x60], xmm7
00007aa3a45d4dc5  vmovaps [rsp+0x70], xmm8
00007aa3a45d4dcb  vmovaps [rsp+0x80], xmm9
00007aa3a45d4dd4  vmovaps [rsp+0x90], xmm10
00007aa3a45d4ddd  vmovaps [rsp+0xA0], xmm11
00007aa3a45d4de6  vmovaps [rsp+0xB0], xmm12
00007aa3a45d4def  vmovaps [rsp+0xC0], xmm13
00007aa3a45d4df8  vmovaps [rsp+0xD0], xmm14
00007aa3a45d4e01  vmovaps [rsp+0xE0], xmm15
00007aa3a45d4e0a  sub rsp, 0x30
00007aa3a45d4e0e  movaps [rsp], xmm1
00007aa3a45d4e12  movaps [rsp+0x10], xmm12
00007aa3a45d4e18  movaps [rsp+0x20], xmm11
00007aa3a45d4e1e  lea rdi, [rsp]
00007aa3a45d4e22  mov esi, 0x00
00007aa3a45d4e27  mov rax, 0x5F551B683530
00007aa3a45d4e31  call rax
00007aa3a45d4e33  movaps xmm1, [rsp]
00007aa3a45d4e37  add rsp, 0x30
00007aa3a45d4e3b  vmovaps xmm0, [rsp]
00007aa3a45d4e40  vmovaps xmm2, [rsp+0x10]
00007aa3a45d4e46  vmovaps xmm3, [rsp+0x20]
00007aa3a45d4e4c  vmovaps xmm4, [rsp+0x30]
00007aa3a45d4e52  vmovaps xmm5, [rsp+0x40]
00007aa3a45d4e58  vmovaps xmm6, [rsp+0x50]
00007aa3a45d4e5e  vmovaps xmm7, [rsp+0x60]
00007aa3a45d4e64  vmovaps xmm8, [rsp+0x70]
00007aa3a45d4e6a  vmovaps xmm9, [rsp+0x80]
00007aa3a45d4e73  vmovaps xmm10, [rsp+0x90]
00007aa3a45d4e7c  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d4e85  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d4e8e  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d4e97  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d4ea0  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d4ea9  add rsp, 0xF0
00007aa3a45d4eb0  pop r11
00007aa3a45d4eb2  pop r10
00007aa3a45d4eb4  pop r9
00007aa3a45d4eb6  pop r8
00007aa3a45d4eb8  pop rsi
00007aa3a45d4eb9  pop rdi
00007aa3a45d4eba  pop rdx
00007aa3a45d4ebb  pop rcx
00007aa3a45d4ebc  pop rax
00007aa3a45d4ebd  add rsp, 0x08
00007aa3a45d4ec1  jmp 0x00007AA3A45D0224
00007aa3a45d4ec6  call 0x00007AA3A44E20A0
00007aa3a45d4ecb  jmp 0x00007AA3A45D0232
00007aa3a45d4ed0  call 0x00007AA3A4409D70
00007aa3a45d4ed5  jmp 0x00007AA3A45D023C
00007aa3a45d4eda  sub rsp, 0x08
00007aa3a45d4ede  push rax
00007aa3a45d4edf  push rcx
00007aa3a45d4ee0  push rdx
00007aa3a45d4ee1  push rdi
00007aa3a45d4ee2  push rsi
00007aa3a45d4ee3  push r8
00007aa3a45d4ee5  push r9
00007aa3a45d4ee7  push r10
00007aa3a45d4ee9  push r11
00007aa3a45d4eeb  sub rsp, 0xF0
00007aa3a45d4ef2  vmovaps [rsp], xmm0
00007aa3a45d4ef7  vmovaps [rsp+0x10], xmm1
00007aa3a45d4efd  vmovaps [rsp+0x20], xmm2
00007aa3a45d4f03  vmovaps [rsp+0x30], xmm3
00007aa3a45d4f09  vmovaps [rsp+0x40], xmm4
00007aa3a45d4f0f  vmovaps [rsp+0x50], xmm5
00007aa3a45d4f15  vmovaps [rsp+0x60], xmm6
00007aa3a45d4f1b  vmovaps [rsp+0x70], xmm8
00007aa3a45d4f21  vmovaps [rsp+0x80], xmm9
00007aa3a45d4f2a  vmovaps [rsp+0x90], xmm10
00007aa3a45d4f33  vmovaps [rsp+0xA0], xmm11
00007aa3a45d4f3c  vmovaps [rsp+0xB0], xmm12
00007aa3a45d4f45  vmovaps [rsp+0xC0], xmm13
00007aa3a45d4f4e  vmovaps [rsp+0xD0], xmm14
00007aa3a45d4f57  vmovaps [rsp+0xE0], xmm15
00007aa3a45d4f60  sub rsp, 0x30
00007aa3a45d4f64  movaps [rsp], xmm7
00007aa3a45d4f68  movaps [rsp+0x10], xmm15
00007aa3a45d4f6e  movaps [rsp+0x20], xmm10
00007aa3a45d4f74  lea rdi, [rsp]
00007aa3a45d4f78  mov esi, 0x00
00007aa3a45d4f7d  mov rax, 0x5F551B683530
00007aa3a45d4f87  call rax
00007aa3a45d4f89  movaps xmm7, [rsp]
00007aa3a45d4f8d  add rsp, 0x30
00007aa3a45d4f91  vmovaps xmm0, [rsp]
00007aa3a45d4f96  vmovaps xmm1, [rsp+0x10]
00007aa3a45d4f9c  vmovaps xmm2, [rsp+0x20]
00007aa3a45d4fa2  vmovaps xmm3, [rsp+0x30]
00007aa3a45d4fa8  vmovaps xmm4, [rsp+0x40]
00007aa3a45d4fae  vmovaps xmm5, [rsp+0x50]
00007aa3a45d4fb4  vmovaps xmm6, [rsp+0x60]
00007aa3a45d4fba  vmovaps xmm8, [rsp+0x70]
00007aa3a45d4fc0  vmovaps xmm9, [rsp+0x80]
00007aa3a45d4fc9  vmovaps xmm10, [rsp+0x90]
00007aa3a45d4fd2  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d4fdb  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d4fe4  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d4fed  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d4ff6  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d4fff  add rsp, 0xF0
00007aa3a45d5006  pop r11
00007aa3a45d5008  pop r10
00007aa3a45d500a  pop r9
00007aa3a45d500c  pop r8
00007aa3a45d500e  pop rsi
00007aa3a45d500f  pop rdi
00007aa3a45d5010  pop rdx
00007aa3a45d5011  pop rcx
00007aa3a45d5012  pop rax
00007aa3a45d5013  add rsp, 0x08
00007aa3a45d5017  jmp 0x00007AA3A45D025D
00007aa3a45d501c  sub rsp, 0x08
00007aa3a45d5020  push rax
00007aa3a45d5021  push rcx
00007aa3a45d5022  push rdx
00007aa3a45d5023  push rdi
00007aa3a45d5024  push rsi
00007aa3a45d5025  push r8
00007aa3a45d5027  push r9
00007aa3a45d5029  push r10
00007aa3a45d502b  push r11
00007aa3a45d502d  sub rsp, 0xF0
00007aa3a45d5034  vmovaps [rsp], xmm0
00007aa3a45d5039  vmovaps [rsp+0x10], xmm1
00007aa3a45d503f  vmovaps [rsp+0x20], xmm2
00007aa3a45d5045  vmovaps [rsp+0x30], xmm3
00007aa3a45d504b  vmovaps [rsp+0x40], xmm4
00007aa3a45d5051  vmovaps [rsp+0x50], xmm5
00007aa3a45d5057  vmovaps [rsp+0x60], xmm6
00007aa3a45d505d  vmovaps [rsp+0x70], xmm7
00007aa3a45d5063  vmovaps [rsp+0x80], xmm8
00007aa3a45d506c  vmovaps [rsp+0x90], xmm9
00007aa3a45d5075  vmovaps [rsp+0xA0], xmm11
00007aa3a45d507e  vmovaps [rsp+0xB0], xmm12
00007aa3a45d5087  vmovaps [rsp+0xC0], xmm13
00007aa3a45d5090  vmovaps [rsp+0xD0], xmm14
00007aa3a45d5099  vmovaps [rsp+0xE0], xmm15
00007aa3a45d50a2  sub rsp, 0x30
00007aa3a45d50a6  movaps [rsp], xmm10
00007aa3a45d50ab  movaps [rsp+0x10], xmm11
00007aa3a45d50b1  movaps [rsp+0x20], xmm15
00007aa3a45d50b7  lea rdi, [rsp]
00007aa3a45d50bb  mov esi, 0x00
00007aa3a45d50c0  mov rax, 0x5F551B683530
00007aa3a45d50ca  call rax
00007aa3a45d50cc  movaps xmm10, [rsp]
00007aa3a45d50d1  add rsp, 0x30
00007aa3a45d50d5  vmovaps xmm0, [rsp]
00007aa3a45d50da  vmovaps xmm1, [rsp+0x10]
00007aa3a45d50e0  vmovaps xmm2, [rsp+0x20]
00007aa3a45d50e6  vmovaps xmm3, [rsp+0x30]
00007aa3a45d50ec  vmovaps xmm4, [rsp+0x40]
00007aa3a45d50f2  vmovaps xmm5, [rsp+0x50]
00007aa3a45d50f8  vmovaps xmm6, [rsp+0x60]
00007aa3a45d50fe  vmovaps xmm7, [rsp+0x70]
00007aa3a45d5104  vmovaps xmm8, [rsp+0x80]
00007aa3a45d510d  vmovaps xmm9, [rsp+0x90]
00007aa3a45d5116  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d511f  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d5128  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d5131  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d513a  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d5143  add rsp, 0xF0
00007aa3a45d514a  pop r11
00007aa3a45d514c  pop r10
00007aa3a45d514e  pop r9
00007aa3a45d5150  pop r8
00007aa3a45d5152  pop rsi
00007aa3a45d5153  pop rdi
00007aa3a45d5154  pop rdx
00007aa3a45d5155  pop rcx
00007aa3a45d5156  pop rax
00007aa3a45d5157  add rsp, 0x08
00007aa3a45d515b  jmp 0x00007AA3A45D028B
00007aa3a45d5160  sub rsp, 0x08
00007aa3a45d5164  push rax
00007aa3a45d5165  push rcx
00007aa3a45d5166  push rdx
00007aa3a45d5167  push rdi
00007aa3a45d5168  push rsi
00007aa3a45d5169  push r8
00007aa3a45d516b  push r9
00007aa3a45d516d  push r10
00007aa3a45d516f  push r11
00007aa3a45d5171  sub rsp, 0xF0
00007aa3a45d5178  vmovaps [rsp], xmm0
00007aa3a45d517d  vmovaps [rsp+0x10], xmm1
00007aa3a45d5183  vmovaps [rsp+0x20], xmm2
00007aa3a45d5189  vmovaps [rsp+0x30], xmm3
00007aa3a45d518f  vmovaps [rsp+0x40], xmm4
00007aa3a45d5195  vmovaps [rsp+0x50], xmm5
00007aa3a45d519b  vmovaps [rsp+0x60], xmm6
00007aa3a45d51a1  vmovaps [rsp+0x70], xmm7
00007aa3a45d51a7  vmovaps [rsp+0x80], xmm8
00007aa3a45d51b0  vmovaps [rsp+0x90], xmm9
00007aa3a45d51b9  vmovaps [rsp+0xA0], xmm10
00007aa3a45d51c2  vmovaps [rsp+0xB0], xmm12
00007aa3a45d51cb  vmovaps [rsp+0xC0], xmm13
00007aa3a45d51d4  vmovaps [rsp+0xD0], xmm14
00007aa3a45d51dd  vmovaps [rsp+0xE0], xmm15
00007aa3a45d51e6  sub rsp, 0x30
00007aa3a45d51ea  movaps [rsp], xmm11
00007aa3a45d51ef  movaps [rsp+0x10], xmm12
00007aa3a45d51f5  movaps [rsp+0x20], xmm15
00007aa3a45d51fb  lea rdi, [rsp]
00007aa3a45d51ff  mov esi, 0x00
00007aa3a45d5204  mov rax, 0x5F551B683530
00007aa3a45d520e  call rax
00007aa3a45d5210  movaps xmm11, [rsp]
00007aa3a45d5215  add rsp, 0x30
00007aa3a45d5219  vmovaps xmm0, [rsp]
00007aa3a45d521e  vmovaps xmm1, [rsp+0x10]
00007aa3a45d5224  vmovaps xmm2, [rsp+0x20]
00007aa3a45d522a  vmovaps xmm3, [rsp+0x30]
00007aa3a45d5230  vmovaps xmm4, [rsp+0x40]
00007aa3a45d5236  vmovaps xmm5, [rsp+0x50]
00007aa3a45d523c  vmovaps xmm6, [rsp+0x60]
00007aa3a45d5242  vmovaps xmm7, [rsp+0x70]
00007aa3a45d5248  vmovaps xmm8, [rsp+0x80]
00007aa3a45d5251  vmovaps xmm9, [rsp+0x90]
00007aa3a45d525a  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d5263  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d526c  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d5275  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d527e  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d5287  add rsp, 0xF0
00007aa3a45d528e  pop r11
00007aa3a45d5290  pop r10
00007aa3a45d5292  pop r9
00007aa3a45d5294  pop r8
00007aa3a45d5296  pop rsi
00007aa3a45d5297  pop rdi
00007aa3a45d5298  pop rdx
00007aa3a45d5299  pop rcx
00007aa3a45d529a  pop rax
00007aa3a45d529b  add rsp, 0x08
00007aa3a45d529f  jmp 0x00007AA3A45D02B9
00007aa3a45d52a4  sub rsp, 0x08
00007aa3a45d52a8  push rax
00007aa3a45d52a9  push rcx
00007aa3a45d52aa  push rdx
00007aa3a45d52ab  push rdi
00007aa3a45d52ac  push rsi
00007aa3a45d52ad  push r8
00007aa3a45d52af  push r9
00007aa3a45d52b1  push r10
00007aa3a45d52b3  push r11
00007aa3a45d52b5  sub rsp, 0xF0
00007aa3a45d52bc  vmovaps [rsp], xmm0
00007aa3a45d52c1  vmovaps [rsp+0x10], xmm1
00007aa3a45d52c7  vmovaps [rsp+0x20], xmm2
00007aa3a45d52cd  vmovaps [rsp+0x30], xmm3
00007aa3a45d52d3  vmovaps [rsp+0x40], xmm4
00007aa3a45d52d9  vmovaps [rsp+0x50], xmm5
00007aa3a45d52df  vmovaps [rsp+0x60], xmm6
00007aa3a45d52e5  vmovaps [rsp+0x70], xmm7
00007aa3a45d52eb  vmovaps [rsp+0x80], xmm8
00007aa3a45d52f4  vmovaps [rsp+0x90], xmm9
00007aa3a45d52fd  vmovaps [rsp+0xA0], xmm10
00007aa3a45d5306  vmovaps [rsp+0xB0], xmm11
00007aa3a45d530f  vmovaps [rsp+0xC0], xmm12
00007aa3a45d5318  vmovaps [rsp+0xD0], xmm13
00007aa3a45d5321  vmovaps [rsp+0xE0], xmm14
00007aa3a45d532a  sub rsp, 0x30
00007aa3a45d532e  movaps [rsp], xmm15
00007aa3a45d5333  movaps [rsp+0x10], xmm13
00007aa3a45d5339  movaps [rsp+0x20], xmm9
00007aa3a45d533f  lea rdi, [rsp]
00007aa3a45d5343  mov esi, 0x00
00007aa3a45d5348  mov rax, 0x5F551B683530
00007aa3a45d5352  call rax
00007aa3a45d5354  movaps xmm15, [rsp]
00007aa3a45d5359  add rsp, 0x30
00007aa3a45d535d  vmovaps xmm0, [rsp]
00007aa3a45d5362  vmovaps xmm1, [rsp+0x10]
00007aa3a45d5368  vmovaps xmm2, [rsp+0x20]
00007aa3a45d536e  vmovaps xmm3, [rsp+0x30]
00007aa3a45d5374  vmovaps xmm4, [rsp+0x40]
00007aa3a45d537a  vmovaps xmm5, [rsp+0x50]
00007aa3a45d5380  vmovaps xmm6, [rsp+0x60]
00007aa3a45d5386  vmovaps xmm7, [rsp+0x70]
00007aa3a45d538c  vmovaps xmm8, [rsp+0x80]
00007aa3a45d5395  vmovaps xmm9, [rsp+0x90]
00007aa3a45d539e  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d53a7  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d53b0  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d53b9  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d53c2  vmovaps xmm14, [rsp+0xE0]
00007aa3a45d53cb  add rsp, 0xF0
00007aa3a45d53d2  pop r11
00007aa3a45d53d4  pop r10
00007aa3a45d53d6  pop r9
00007aa3a45d53d8  pop r8
00007aa3a45d53da  pop rsi
00007aa3a45d53db  pop rdi
00007aa3a45d53dc  pop rdx
00007aa3a45d53dd  pop rcx
00007aa3a45d53de  pop rax
00007aa3a45d53df  add rsp, 0x08
00007aa3a45d53e3  jmp 0x00007AA3A45D02D4
00007aa3a45d53e8  sub rsp, 0x08
00007aa3a45d53ec  push rax
00007aa3a45d53ed  push rcx
00007aa3a45d53ee  push rdx
00007aa3a45d53ef  push rdi
00007aa3a45d53f0  push rsi
00007aa3a45d53f1  push r8
00007aa3a45d53f3  push r9
00007aa3a45d53f5  push r10
00007aa3a45d53f7  push r11
00007aa3a45d53f9  sub rsp, 0xF0
00007aa3a45d5400  vmovaps [rsp], xmm0
00007aa3a45d5405  vmovaps [rsp+0x10], xmm1
00007aa3a45d540b  vmovaps [rsp+0x20], xmm2
00007aa3a45d5411  vmovaps [rsp+0x30], xmm3
00007aa3a45d5417  vmovaps [rsp+0x40], xmm4
00007aa3a45d541d  vmovaps [rsp+0x50], xmm5
00007aa3a45d5423  vmovaps [rsp+0x60], xmm6
00007aa3a45d5429  vmovaps [rsp+0x70], xmm7
00007aa3a45d542f  vmovaps [rsp+0x80], xmm8
00007aa3a45d5438  vmovaps [rsp+0x90], xmm9
00007aa3a45d5441  vmovaps [rsp+0xA0], xmm10
00007aa3a45d544a  vmovaps [rsp+0xB0], xmm11
00007aa3a45d5453  vmovaps [rsp+0xC0], xmm12
00007aa3a45d545c  vmovaps [rsp+0xD0], xmm14
00007aa3a45d5465  vmovaps [rsp+0xE0], xmm15
00007aa3a45d546e  sub rsp, 0x30
00007aa3a45d5472  movaps [rsp], xmm13
00007aa3a45d5477  movaps [rsp+0x10], xmm8
00007aa3a45d547d  movaps [rsp+0x20], xmm14
00007aa3a45d5483  lea rdi, [rsp]
00007aa3a45d5487  mov esi, 0x00
00007aa3a45d548c  mov rax, 0x5F551B683530
00007aa3a45d5496  call rax
00007aa3a45d5498  movaps xmm13, [rsp]
00007aa3a45d549d  add rsp, 0x30
00007aa3a45d54a1  vmovaps xmm0, [rsp]
00007aa3a45d54a6  vmovaps xmm1, [rsp+0x10]
00007aa3a45d54ac  vmovaps xmm2, [rsp+0x20]
00007aa3a45d54b2  vmovaps xmm3, [rsp+0x30]
00007aa3a45d54b8  vmovaps xmm4, [rsp+0x40]
00007aa3a45d54be  vmovaps xmm5, [rsp+0x50]
00007aa3a45d54c4  vmovaps xmm6, [rsp+0x60]
00007aa3a45d54ca  vmovaps xmm7, [rsp+0x70]
00007aa3a45d54d0  vmovaps xmm8, [rsp+0x80]
00007aa3a45d54d9  vmovaps xmm9, [rsp+0x90]
00007aa3a45d54e2  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d54eb  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d54f4  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d54fd  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d5506  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d550f  add rsp, 0xF0
00007aa3a45d5516  pop r11
00007aa3a45d5518  pop r10
00007aa3a45d551a  pop r9
00007aa3a45d551c  pop r8
00007aa3a45d551e  pop rsi
00007aa3a45d551f  pop rdi
00007aa3a45d5520  pop rdx
00007aa3a45d5521  pop rcx
00007aa3a45d5522  pop rax
00007aa3a45d5523  add rsp, 0x08
00007aa3a45d5527  jmp 0x00007AA3A45D02F7
00007aa3a45d552c  sub rsp, 0x08
00007aa3a45d5530  push rax
00007aa3a45d5531  push rcx
00007aa3a45d5532  push rdx
00007aa3a45d5533  push rdi
00007aa3a45d5534  push rsi
00007aa3a45d5535  push r8
00007aa3a45d5537  push r9
00007aa3a45d5539  push r10
00007aa3a45d553b  push r11
00007aa3a45d553d  sub rsp, 0xF0
00007aa3a45d5544  vmovaps [rsp], xmm0
00007aa3a45d5549  vmovaps [rsp+0x10], xmm1
00007aa3a45d554f  vmovaps [rsp+0x20], xmm2
00007aa3a45d5555  vmovaps [rsp+0x30], xmm3
00007aa3a45d555b  vmovaps [rsp+0x40], xmm4
00007aa3a45d5561  vmovaps [rsp+0x50], xmm5
00007aa3a45d5567  vmovaps [rsp+0x60], xmm6
00007aa3a45d556d  vmovaps [rsp+0x70], xmm7
00007aa3a45d5573  vmovaps [rsp+0x80], xmm8
00007aa3a45d557c  vmovaps [rsp+0x90], xmm9
00007aa3a45d5585  vmovaps [rsp+0xA0], xmm10
00007aa3a45d558e  vmovaps [rsp+0xB0], xmm11
00007aa3a45d5597  vmovaps [rsp+0xC0], xmm12
00007aa3a45d55a0  vmovaps [rsp+0xD0], xmm13
00007aa3a45d55a9  vmovaps [rsp+0xE0], xmm15
00007aa3a45d55b2  sub rsp, 0x30
00007aa3a45d55b6  movaps [rsp], xmm14
00007aa3a45d55bb  movaps [rsp+0x10], xmm1
00007aa3a45d55c0  movaps [rsp+0x20], xmm10
00007aa3a45d55c6  lea rdi, [rsp]
00007aa3a45d55ca  mov esi, 0x00
00007aa3a45d55cf  mov rax, 0x5F551B683530
00007aa3a45d55d9  call rax
00007aa3a45d55db  movaps xmm14, [rsp]
00007aa3a45d55e0  add rsp, 0x30
00007aa3a45d55e4  vmovaps xmm0, [rsp]
00007aa3a45d55e9  vmovaps xmm1, [rsp+0x10]
00007aa3a45d55ef  vmovaps xmm2, [rsp+0x20]
00007aa3a45d55f5  vmovaps xmm3, [rsp+0x30]
00007aa3a45d55fb  vmovaps xmm4, [rsp+0x40]
00007aa3a45d5601  vmovaps xmm5, [rsp+0x50]
00007aa3a45d5607  vmovaps xmm6, [rsp+0x60]
00007aa3a45d560d  vmovaps xmm7, [rsp+0x70]
00007aa3a45d5613  vmovaps xmm8, [rsp+0x80]
00007aa3a45d561c  vmovaps xmm9, [rsp+0x90]
00007aa3a45d5625  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d562e  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d5637  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d5640  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d5649  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d5652  add rsp, 0xF0
00007aa3a45d5659  pop r11
00007aa3a45d565b  pop r10
00007aa3a45d565d  pop r9
00007aa3a45d565f  pop r8
00007aa3a45d5661  pop rsi
00007aa3a45d5662  pop rdi
00007aa3a45d5663  pop rdx
00007aa3a45d5664  pop rcx
00007aa3a45d5665  pop rax
00007aa3a45d5666  add rsp, 0x08
00007aa3a45d566a  jmp 0x00007AA3A45D031A
00007aa3a45d566f  sub rsp, 0x08
00007aa3a45d5673  push rax
00007aa3a45d5674  push rcx
00007aa3a45d5675  push rdx
00007aa3a45d5676  push rdi
00007aa3a45d5677  push rsi
00007aa3a45d5678  push r8
00007aa3a45d567a  push r9
00007aa3a45d567c  push r10
00007aa3a45d567e  push r11
00007aa3a45d5680  sub rsp, 0xF0
00007aa3a45d5687  vmovaps [rsp], xmm0
00007aa3a45d568c  vmovaps [rsp+0x10], xmm2
00007aa3a45d5692  vmovaps [rsp+0x20], xmm3
00007aa3a45d5698  vmovaps [rsp+0x30], xmm4
00007aa3a45d569e  vmovaps [rsp+0x40], xmm5
00007aa3a45d56a4  vmovaps [rsp+0x50], xmm6
00007aa3a45d56aa  vmovaps [rsp+0x60], xmm7
00007aa3a45d56b0  vmovaps [rsp+0x70], xmm8
00007aa3a45d56b6  vmovaps [rsp+0x80], xmm9
00007aa3a45d56bf  vmovaps [rsp+0x90], xmm10
00007aa3a45d56c8  vmovaps [rsp+0xA0], xmm11
00007aa3a45d56d1  vmovaps [rsp+0xB0], xmm12
00007aa3a45d56da  vmovaps [rsp+0xC0], xmm13
00007aa3a45d56e3  vmovaps [rsp+0xD0], xmm14
00007aa3a45d56ec  vmovaps [rsp+0xE0], xmm15
00007aa3a45d56f5  sub rsp, 0x30
00007aa3a45d56f9  movaps [rsp], xmm1
00007aa3a45d56fd  movaps [rsp+0x10], xmm7
00007aa3a45d5702  movaps [rsp+0x20], xmm11
00007aa3a45d5708  lea rdi, [rsp]
00007aa3a45d570c  mov esi, 0x00
00007aa3a45d5711  mov rax, 0x5F551B683530
00007aa3a45d571b  call rax
00007aa3a45d571d  movaps xmm1, [rsp]
00007aa3a45d5721  add rsp, 0x30
00007aa3a45d5725  vmovaps xmm0, [rsp]
00007aa3a45d572a  vmovaps xmm2, [rsp+0x10]
00007aa3a45d5730  vmovaps xmm3, [rsp+0x20]
00007aa3a45d5736  vmovaps xmm4, [rsp+0x30]
00007aa3a45d573c  vmovaps xmm5, [rsp+0x40]
00007aa3a45d5742  vmovaps xmm6, [rsp+0x50]
00007aa3a45d5748  vmovaps xmm7, [rsp+0x60]
00007aa3a45d574e  vmovaps xmm8, [rsp+0x70]
00007aa3a45d5754  vmovaps xmm9, [rsp+0x80]
00007aa3a45d575d  vmovaps xmm10, [rsp+0x90]
00007aa3a45d5766  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d576f  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d5778  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d5781  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d578a  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d5793  add rsp, 0xF0
00007aa3a45d579a  pop r11
00007aa3a45d579c  pop r10
00007aa3a45d579e  pop r9
00007aa3a45d57a0  pop r8
00007aa3a45d57a2  pop rsi
00007aa3a45d57a3  pop rdi
00007aa3a45d57a4  pop rdx
00007aa3a45d57a5  pop rcx
00007aa3a45d57a6  pop rax
00007aa3a45d57a7  add rsp, 0x08
00007aa3a45d57ab  jmp 0x00007AA3A45D033B
00007aa3a45d57b0  call 0x00007AA3A440E880
00007aa3a45d57b5  jmp 0x00007AA3A45D034E
00007aa3a45d57ba  call 0x00007AA3A440C380
00007aa3a45d57bf  jmp 0x00007AA3A45D0359
00007aa3a45d57c4  call 0x00007AA3A440D600
00007aa3a45d57c9  jmp 0x00007AA3A45D0364
00007aa3a45d57ce  call 0x00007AA3A43FF540
00007aa3a45d57d3  jmp 0x00007AA3A45D036F
00007aa3a45d57d8  int3
00007aa3a45d57d9  nop [rax], eax
00007aa3a45d57e0  mov rax, [r15+0x40]
00007aa3a45d57e4  mov r14, [r15+0x58]
00007aa3a45d57e8  lea r12, [rax+r14*1]
00007aa3a45d57ec  movaps xmm1, [r15+0x1D0]
00007aa3a45d57f4  vmovaps [rsp+0x10], xmm1
00007aa3a45d57fa  vmovaps xmm15, [rsp+0x10]
00007aa3a45d5800  por xmm1, xmm15
00007aa3a45d5805  movaps xmm14, [r15+0x1A0]
00007aa3a45d580d  vmovaps [rsp+0x10], xmm14
00007aa3a45d5813  vmovaps xmm13, [rsp+0x10]
00007aa3a45d5819  por xmm14, xmm13
00007aa3a45d581e  lea rax, [r12+0x30]
00007aa3a45d5823  mov r11, [r13+rax*1]
00007aa3a45d5828  lea rax, [r12+0x38]
00007aa3a45d582d  mov r10, [r13+rax*1]
00007aa3a45d5832  movq xmm13, r11
00007aa3a45d5837  movq xmm12, r10
00007aa3a45d583c  movq xmm13, xmm13
00007aa3a45d5841  vmovaps [rsp+0x10], xmm13
00007aa3a45d5847  movq xmm13, xmm13
00007aa3a45d584c  movaps [r15+0x130], xmm13
00007aa3a45d5854  movq xmm12, xmm12
00007aa3a45d5859  vmovaps [rsp+0x20], xmm12
00007aa3a45d585f  movq xmm12, xmm12
00007aa3a45d5864  movaps [r15+0x280], xmm12
00007aa3a45d586c  movaps xmm13, [r15+0x270]
00007aa3a45d5874  vmovaps [rsp+0x30], xmm13
00007aa3a45d587a  vmovaps xmm12, [rsp+0x30]
00007aa3a45d5880  por xmm13, xmm12
00007aa3a45d5885  lea rax, [r12+0x20]
00007aa3a45d588a  mov r11, [r13+rax*1]
00007aa3a45d588f  lea rax, [r12+0x28]
00007aa3a45d5894  mov r10, [r13+rax*1]
00007aa3a45d5899  movq xmm12, r11
00007aa3a45d589e  movq xmm11, r10
00007aa3a45d58a3  movq xmm12, xmm12
00007aa3a45d58a8  vmovaps [rsp+0x30], xmm12
00007aa3a45d58ae  movq xmm12, xmm12
00007aa3a45d58b3  movaps [r15+0x150], xmm12
00007aa3a45d58bb  movq xmm11, xmm11
00007aa3a45d58c0  vmovaps [rsp+0x40], xmm11
00007aa3a45d58c6  movq xmm11, xmm11
00007aa3a45d58cb  movaps [r15+0x140], xmm11
00007aa3a45d58d3  lea rax, [r12+0x10]
00007aa3a45d58d8  mov r11, [r13+rax*1]
00007aa3a45d58dd  lea rax, [r12+0x18]
00007aa3a45d58e2  mov r10, [r13+rax*1]
00007aa3a45d58e7  movq xmm12, r11
00007aa3a45d58ec  movq xmm11, r10
00007aa3a45d58f1  movq xmm12, xmm12
00007aa3a45d58f6  vmovaps [rsp+0x50], xmm12
00007aa3a45d58fc  movq xmm12, xmm12
00007aa3a45d5901  movaps [r15+0x170], xmm12
00007aa3a45d5909  movq xmm11, xmm11
00007aa3a45d590e  vmovaps [rsp+0x60], xmm11
00007aa3a45d5914  movq xmm11, xmm11
00007aa3a45d5919  movaps [r15+0x160], xmm11
00007aa3a45d5921  mov rax, [r13+r12*1]
00007aa3a45d5926  vmovq xmm12, rax
00007aa3a45d592b  vpbroadcastq xmm12, xmm12
00007aa3a45d5930  lea rax, [r12+0x08]
00007aa3a45d5935  mov r12, [r13+rax*1]
00007aa3a45d593a  movq xmm11, r12
00007aa3a45d593f  movaps [r15+0x230], xmm11
00007aa3a45d5947  mov rax, [r15+0xF8]
00007aa3a45d594e  lea r12, [rax+0x50]
00007aa3a45d5952  movups xmm11, [r13+r12*1]
00007aa3a45d5958  lea r12, [rax+0x60]
00007aa3a45d595c  movups xmm10, [r13+r12*1]
00007aa3a45d5962  lea r12, [rax+0x30]
00007aa3a45d5966  movups xmm9, [r13+r12*1]
00007aa3a45d596c  mov r12, [r15+0x50]
00007aa3a45d5970  lea r11, [r12+r14*1]
00007aa3a45d5974  mov [r15+0x60], r11
00007aa3a45d5978  lea r12, [r14+0x40]
00007aa3a45d597c  mov [r15+0x58], r12
00007aa3a45d5980  movaps xmm8, xmm12
00007aa3a45d5984  mulpd xmm8, xmm15
00007aa3a45d5989  vcmppd xmm7, xmm8, xmm8, 0x03
00007aa3a45d598f  ptest xmm7, xmm7
00007aa3a45d5994  jnz 0x00007AA3A45D67B7
00007aa3a45d599a  movq xmm15, qword ptr [r15+0x230]
00007aa3a45d59a3  vmovaps [rsp+0x70], xmm15
00007aa3a45d59a9  vpermilpd xmm15, xmm15, 0x00
00007aa3a45d59af  movaps xmm7, xmm9
00007aa3a45d59b3  mulpd xmm7, xmm15
00007aa3a45d59b8  vcmppd xmm6, xmm7, xmm7, 0x03
00007aa3a45d59bd  ptest xmm6, xmm6
00007aa3a45d59c2  jnz 0x00007AA3A45D68FB
00007aa3a45d59c8  vxorps xmm15, xmm15, xmm15
00007aa3a45d59cd  vpbroadcastq xmm15, xmm15
00007aa3a45d59d2  movaps xmm9, xmm12
00007aa3a45d59d6  mulpd xmm9, xmm10
00007aa3a45d59db  vcmppd xmm6, xmm9, xmm9, 0x03
00007aa3a45d59e1  ptest xmm6, xmm6
00007aa3a45d59e6  jnz 0x00007AA3A45D6A3D
00007aa3a45d59ec  movaps xmm10, xmm12
00007aa3a45d59f0  mulpd xmm10, xmm11
00007aa3a45d59f5  vcmppd xmm6, xmm10, xmm10, 0x03
00007aa3a45d59fb  ptest xmm6, xmm6
00007aa3a45d5a00  jnz 0x00007AA3A45D6B81
00007aa3a45d5a06  movaps xmm11, [r15+0x1F0]
00007aa3a45d5a0e  movaps xmm6, xmm12
00007aa3a45d5a12  mulpd xmm6, xmm11
00007aa3a45d5a17  vcmppd xmm5, xmm6, xmm6, 0x03
00007aa3a45d5a1c  ptest xmm5, xmm5
00007aa3a45d5a21  jnz 0x00007AA3A45D6CC5
00007aa3a45d5a27  movaps xmm12, [r15+0x2A0]
00007aa3a45d5a2f  vmovaps [rsp+0x80], xmm12
00007aa3a45d5a38  vmovaps xmm11, [rsp+0x80]
00007aa3a45d5a41  por xmm12, xmm11
00007aa3a45d5a46  movaps xmm11, [r15+0x250]
00007aa3a45d5a4e  vmovaps [rsp+0x80], xmm11
00007aa3a45d5a57  vmovaps xmm5, [rsp+0x80]
00007aa3a45d5a60  por xmm11, xmm5
00007aa3a45d5a65  vmovaps xmm4, [rsp+0x70]
00007aa3a45d5a6b  vpermilpd xmm4, xmm4, 0x00
00007aa3a45d5a71  movaps xmm3, xmm5
00007aa3a45d5a74  mulpd xmm3, xmm4
00007aa3a45d5a78  vcmppd xmm2, xmm3, xmm3, 0x03
00007aa3a45d5a7d  ptest xmm2, xmm2
00007aa3a45d5a82  jnz 0x00007AA3A45D6E07
00007aa3a45d5a88  mov [rsp+0x80], rax
00007aa3a45d5a90  xor eax, eax
00007aa3a45d5a92  mov r14d, 0x200
00007aa3a45d5a98  cmp r12, r14
00007aa3a45d5a9b  cmc
00007aa3a45d5a9c  lahf
00007aa3a45d5a9d  seto al
00007aa3a45d5aa0  mov [r15+0x108], eax
00007aa3a45d5aa7  movaps xmm5, xmm8
00007aa3a45d5aab  addpd xmm5, xmm15
00007aa3a45d5ab0  vcmppd xmm4, xmm5, xmm5, 0x03
00007aa3a45d5ab5  ptest xmm4, xmm4
00007aa3a45d5aba  jnz 0x00007AA3A45D6F47
00007aa3a45d5ac0  movaps xmm8, [r15+0x1B0]
00007aa3a45d5ac8  movaps xmm4, xmm9
00007aa3a45d5acc  addpd xmm4, xmm8
00007aa3a45d5ad1  vcmppd xmm2, xmm4, xmm4, 0x03
00007aa3a45d5ad6  ptest xmm2, xmm2
00007aa3a45d5adb  jnz 0x00007AA3A45D7089
00007aa3a45d5ae1  movaps xmm9, xmm10
00007aa3a45d5ae5  addpd xmm9, xmm8
00007aa3a45d5aea  vcmppd xmm2, xmm9, xmm9, 0x03
00007aa3a45d5af0  ptest xmm2, xmm2
00007aa3a45d5af5  jnz 0x00007AA3A45D71CB
00007aa3a45d5afb  movaps xmm10, [r15+0x2F0]
00007aa3a45d5b03  vmovaps [rsp+0x90], xmm10
00007aa3a45d5b0c  vmovaps xmm8, [rsp+0x90]
00007aa3a45d5b15  por xmm10, xmm8
00007aa3a45d5b1a  movaps xmm8, [r15+0x2E0]
00007aa3a45d5b22  vmovaps [rsp+0x90], xmm8
00007aa3a45d5b2b  vmovaps xmm2, [rsp+0x90]
00007aa3a45d5b34  por xmm8, xmm2
00007aa3a45d5b39  movaps xmm2, [r15+0x2D0]
00007aa3a45d5b41  vmovaps [rsp+0x90], xmm2
00007aa3a45d5b4a  vmovaps [rsp+0xA0], xmm1
00007aa3a45d5b53  vmovaps xmm1, [rsp+0x90]
00007aa3a45d5b5c  por xmm2, xmm1
00007aa3a45d5b60  movaps xmm1, [r15+0x200]
00007aa3a45d5b68  vmovaps [rsp+0x90], xmm1
00007aa3a45d5b71  vmovaps [rsp+0xB0], xmm15
00007aa3a45d5b7a  vmovaps xmm15, [rsp+0x90]
00007aa3a45d5b83  por xmm1, xmm15
00007aa3a45d5b88  movaps xmm15, [r15+0x1C0]
00007aa3a45d5b90  vmovaps [rsp+0x90], xmm15
00007aa3a45d5b99  vmovaps [rsp+0xC0], xmm1
00007aa3a45d5ba2  vmovaps xmm1, [rsp+0x90]
00007aa3a45d5bab  por xmm15, xmm1
00007aa3a45d5bb0  movaps xmm1, [r15+0x190]
00007aa3a45d5bb8  vmovaps [rsp+0x90], xmm1
00007aa3a45d5bc1  vmovaps [rsp+0xD0], xmm15
00007aa3a45d5bca  vmovaps xmm15, [rsp+0x90]
00007aa3a45d5bd3  por xmm1, xmm15
00007aa3a45d5bd8  movaps xmm15, [r15+0x300]
00007aa3a45d5be0  vmovaps [rsp+0x90], xmm15
00007aa3a45d5be9  vmovaps [rsp+0xE0], xmm1
00007aa3a45d5bf2  vmovaps xmm1, [rsp+0x90]
00007aa3a45d5bfb  por xmm15, xmm1
00007aa3a45d5c00  mov rax, [rsp+0x80]
00007aa3a45d5c08  lea r14, [rax+0xA0]
00007aa3a45d5c0f  movups xmm1, [r13+r14*1]
00007aa3a45d5c15  lea r14, [rax+0xB0]
00007aa3a45d5c1c  vmovaps [rsp+0x80], xmm1
00007aa3a45d5c25  movups xmm1, [r13+r14*1]
00007aa3a45d5c2b  vmovaps [rsp+0x90], xmm1
00007aa3a45d5c34  vmovaps [rsp+0xF0], xmm15
00007aa3a45d5c3d  vmovaps xmm15, [rsp+0xB0]
00007aa3a45d5c46  vmovaps [rsp+0xB0], xmm14
00007aa3a45d5c4f  movaps xmm1, xmm6
00007aa3a45d5c52  addpd xmm1, xmm15
00007aa3a45d5c57  vcmppd xmm14, xmm1, xmm1, 0x03
00007aa3a45d5c5c  ptest xmm14, xmm14
00007aa3a45d5c62  jnz 0x00007AA3A45D7323
00007aa3a45d5c68  lea r14, [rax+0xF0]
00007aa3a45d5c6f  movups xmm15, [r13+r14*1]
00007aa3a45d5c75  movaps xmm14, xmm4
00007aa3a45d5c79  addpd xmm14, xmm3
00007aa3a45d5c7e  vcmppd xmm6, xmm14, xmm14, 0x03
00007aa3a45d5c84  ptest xmm6, xmm6
00007aa3a45d5c89  jnz 0x00007AA3A45D746E
00007aa3a45d5c8f  movaps xmm6, xmm9
00007aa3a45d5c93  addpd xmm6, xmm7
00007aa3a45d5c97  vcmppd xmm4, xmm6, xmm6, 0x03
00007aa3a45d5c9c  ptest xmm4, xmm4
00007aa3a45d5ca1  jnz 0x00007AA3A45D75B0
00007aa3a45d5ca7  vmovaps xmm9, [rsp+0x70]
00007aa3a45d5cad  vpermilpd xmm9, xmm9, 0x00
00007aa3a45d5cb3  vmovaps xmm4, [rsp+0x90]
00007aa3a45d5cbc  movaps xmm7, xmm4
00007aa3a45d5cbf  mulpd xmm7, xmm9
00007aa3a45d5cc4  vcmppd xmm3, xmm7, xmm7, 0x03
00007aa3a45d5cc9  ptest xmm3, xmm3
00007aa3a45d5cce  jnz 0x00007AA3A45D76F1
00007aa3a45d5cd4  vmovaps xmm9, [rsp+0x50]
00007aa3a45d5cda  vpermilpd xmm9, xmm9, 0x00
00007aa3a45d5ce0  movaps xmm4, xmm15
00007aa3a45d5ce4  mulpd xmm4, xmm9
00007aa3a45d5ce9  vcmppd xmm3, xmm4, xmm4, 0x03
00007aa3a45d5cee  ptest xmm3, xmm3
00007aa3a45d5cf3  jnz 0x00007AA3A45D7832
00007aa3a45d5cf9  lea r14, [rax+0xE0]
00007aa3a45d5d00  movups xmm15, [r13+r14*1]
00007aa3a45d5d06  vmovaps xmm9, [rsp+0x70]
00007aa3a45d5d0c  vpermilpd xmm9, xmm9, 0x00
00007aa3a45d5d12  vmovaps [rsp+0x70], xmm1
00007aa3a45d5d18  vmovaps xmm1, [rsp+0x80]
00007aa3a45d5d21  vmovaps [rsp+0x80], xmm15
00007aa3a45d5d2a  movaps xmm3, xmm1
00007aa3a45d5d2d  mulpd xmm3, xmm9
00007aa3a45d5d32  vcmppd xmm15, xmm3, xmm3, 0x03
00007aa3a45d5d37  ptest xmm15, xmm15
00007aa3a45d5d3d  jnz 0x00007AA3A45D797E
00007aa3a45d5d43  vmovaps xmm1, [rsp+0xF0]
00007aa3a45d5d4c  vmovaps xmm15, [rsp+0xF0]
00007aa3a45d5d55  por xmm1, xmm15
00007aa3a45d5d5a  movaps [r15+0x300], xmm1
00007aa3a45d5d62  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d5d6b  vmovaps xmm9, [rsp+0xE0]
00007aa3a45d5d74  por xmm15, xmm9
00007aa3a45d5d79  movaps [r15+0x190], xmm15
00007aa3a45d5d81  vmovaps xmm9, [rsp+0x50]
00007aa3a45d5d87  vpermilpd xmm9, xmm9, 0x00
00007aa3a45d5d8d  vmovaps [rsp+0x90], xmm1
00007aa3a45d5d96  vmovaps [rsp+0xE0], xmm15
00007aa3a45d5d9f  vmovaps xmm15, [rsp+0x80]
00007aa3a45d5da8  vmovaps [rsp+0x80], xmm14
00007aa3a45d5db1  movaps xmm1, xmm15
00007aa3a45d5db5  mulpd xmm1, xmm9
00007aa3a45d5dba  vcmppd xmm14, xmm1, xmm1, 0x03
00007aa3a45d5dbf  ptest xmm14, xmm14
00007aa3a45d5dc5  jnz 0x00007AA3A45D7ABF
00007aa3a45d5dcb  lea r14, [rax+0x90]
00007aa3a45d5dd2  movups xmm15, [r13+r14*1]
00007aa3a45d5dd8  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d5de1  vmovaps xmm9, [rsp+0xD0]
00007aa3a45d5dea  por xmm14, xmm9
00007aa3a45d5def  movaps [r15+0x1C0], xmm14
00007aa3a45d5df7  vmovaps xmm9, [rsp+0xC0]
00007aa3a45d5e00  vmovaps [rsp+0xD0], xmm1
00007aa3a45d5e09  vmovaps xmm1, [rsp+0xC0]
00007aa3a45d5e12  por xmm9, xmm1
00007aa3a45d5e17  movaps [r15+0x200], xmm9
00007aa3a45d5e1f  vmovaps [rsp+0xC0], xmm2
00007aa3a45d5e28  vmovaps xmm1, [rsp+0xC0]
00007aa3a45d5e31  por xmm2, xmm1
00007aa3a45d5e35  movaps [r15+0x2D0], xmm2
00007aa3a45d5e3d  vmovaps [rsp+0xC0], xmm8
00007aa3a45d5e46  vmovaps xmm1, [rsp+0xC0]
00007aa3a45d5e4f  por xmm8, xmm1
00007aa3a45d5e54  movaps [r15+0x2E0], xmm8
00007aa3a45d5e5c  vmovaps [rsp+0xC0], xmm15
00007aa3a45d5e65  movaps xmm1, xmm5
00007aa3a45d5e68  addpd xmm1, xmm7
00007aa3a45d5e6c  vcmppd xmm15, xmm1, xmm1, 0x03
00007aa3a45d5e71  ptest xmm15, xmm15
00007aa3a45d5e77  jnz 0x00007AA3A45D7C0B
00007aa3a45d5e7d  vmovaps xmm15, [rsp+0x50]
00007aa3a45d5e83  vpermilpd xmm15, xmm15, 0x00
00007aa3a45d5e89  vmovaps xmm5, [rsp+0xC0]
00007aa3a45d5e92  vmovaps [rsp+0xC0], xmm1
00007aa3a45d5e9b  movaps xmm7, xmm5
00007aa3a45d5e9e  mulpd xmm7, xmm15
00007aa3a45d5ea3  vcmppd xmm1, xmm7, xmm7, 0x03
00007aa3a45d5ea8  ptest xmm1, xmm1
00007aa3a45d5ead  jnz 0x00007AA3A45D7D4B
00007aa3a45d5eb3  lea r14, [rax+0x80]
00007aa3a45d5eba  movups xmm1, [r13+r14*1]
00007aa3a45d5ec0  vmovaps xmm5, [rsp+0x70]
00007aa3a45d5ec6  vmovaps [rsp+0x70], xmm1
00007aa3a45d5ecc  movaps xmm15, xmm5
00007aa3a45d5ed0  addpd xmm15, xmm3
00007aa3a45d5ed5  vcmppd xmm1, xmm15, xmm15, 0x03
00007aa3a45d5edb  ptest xmm1, xmm1
00007aa3a45d5ee0  jnz 0x00007AA3A45D7E96
00007aa3a45d5ee6  vmovaps xmm5, [rsp+0x80]
00007aa3a45d5eef  movaps xmm1, xmm5
00007aa3a45d5ef2  addpd xmm1, xmm4
00007aa3a45d5ef6  vcmppd xmm3, xmm1, xmm1, 0x03
00007aa3a45d5efb  ptest xmm3, xmm3
00007aa3a45d5f00  jnz 0x00007AA3A45D7FD8
00007aa3a45d5f06  vmovaps [rsp+0x80], xmm10
00007aa3a45d5f0f  vmovaps xmm5, [rsp+0x80]
00007aa3a45d5f18  por xmm10, xmm5
00007aa3a45d5f1d  movaps [r15+0x2F0], xmm10
00007aa3a45d5f25  vmovaps xmm5, [rsp+0x50]
00007aa3a45d5f2b  vpermilpd xmm5, xmm5, 0x00
00007aa3a45d5f31  vmovaps xmm3, [rsp+0x70]
00007aa3a45d5f37  vmovaps [rsp+0x50], xmm1
00007aa3a45d5f3d  movaps xmm4, xmm3
00007aa3a45d5f40  mulpd xmm4, xmm5
00007aa3a45d5f44  vcmppd xmm1, xmm4, xmm4, 0x03
00007aa3a45d5f49  ptest xmm1, xmm1
00007aa3a45d5f4e  jnz 0x00007AA3A45D8118
00007aa3a45d5f54  lea r14, [rax+0xD0]
00007aa3a45d5f5b  movups xmm1, [r13+r14*1]
00007aa3a45d5f61  vmovaps xmm3, [rsp+0xD0]
00007aa3a45d5f6a  vmovaps [rsp+0x70], xmm1
00007aa3a45d5f70  movaps xmm5, xmm6
00007aa3a45d5f73  addpd xmm5, xmm3
00007aa3a45d5f77  vcmppd xmm1, xmm5, xmm5, 0x03
00007aa3a45d5f7c  ptest xmm1, xmm1
00007aa3a45d5f81  jnz 0x00007AA3A45D8262
00007aa3a45d5f87  vmovaps xmm1, [rsp+0x60]
00007aa3a45d5f8d  vpermilpd xmm1, xmm1, 0x00
00007aa3a45d5f93  movaps xmm6, xmm9
00007aa3a45d5f97  mulpd xmm6, xmm1
00007aa3a45d5f9b  vcmppd xmm3, xmm6, xmm6, 0x03
00007aa3a45d5fa0  ptest xmm3, xmm3
00007aa3a45d5fa5  jnz 0x00007AA3A45D83A2
00007aa3a45d5fab  movaps [r15+0x260], xmm6
00007aa3a45d5fb3  vxorps xmm1, xmm1, xmm1
00007aa3a45d5fb7  vpbroadcastq xmm1, xmm1
00007aa3a45d5fbc  movaps [r15+0x1B0], xmm1
00007aa3a45d5fc4  vmovaps xmm1, [rsp+0x60]
00007aa3a45d5fca  vpermilpd xmm1, xmm1, 0x00
00007aa3a45d5fd0  vmovaps xmm3, [rsp+0x70]
00007aa3a45d5fd6  vmovaps [rsp+0x70], xmm15
00007aa3a45d5fdc  movaps xmm9, xmm3
00007aa3a45d5fe0  mulpd xmm9, xmm1
00007aa3a45d5fe5  vcmppd xmm15, xmm9, xmm9, 0x03
00007aa3a45d5feb  ptest xmm15, xmm15
00007aa3a45d5ff1  jnz 0x00007AA3A45D84E3
00007aa3a45d5ff7  lea r14, [rax+0xC0]
00007aa3a45d5ffe  movups xmm1, [r13+r14*1]
00007aa3a45d6004  vmovaps xmm3, [rsp+0xC0]
00007aa3a45d600d  vmovaps [rsp+0x80], xmm1
00007aa3a45d6016  movaps xmm15, xmm3
00007aa3a45d601a  addpd xmm15, xmm7
00007aa3a45d601f  vcmppd xmm1, xmm15, xmm15, 0x03
00007aa3a45d6025  ptest xmm1, xmm1
00007aa3a45d602a  jnz 0x00007AA3A45D862F
00007aa3a45d6030  vmovaps [rsp+0xC0], xmm13
00007aa3a45d6039  vmovaps xmm1, [rsp+0xC0]
00007aa3a45d6042  por xmm13, xmm1
00007aa3a45d6047  movaps [r15+0x270], xmm13
00007aa3a45d604f  vmovaps xmm1, [rsp+0xB0]
00007aa3a45d6058  vmovaps xmm7, [rsp+0xB0]
00007aa3a45d6061  por xmm1, xmm7
00007aa3a45d6065  movaps [r15+0x1A0], xmm1
00007aa3a45d606d  vmovaps xmm1, [rsp+0x60]
00007aa3a45d6073  vpermilpd xmm1, xmm1, 0x00
00007aa3a45d6079  vmovaps [rsp+0xB0], xmm1
00007aa3a45d6082  vmovaps xmm1, [rsp+0x80]
00007aa3a45d608b  vmovaps [rsp+0x80], xmm15
00007aa3a45d6094  vmovaps xmm15, [rsp+0xB0]
00007aa3a45d609d  vmovaps [rsp+0xB0], xmm14
00007aa3a45d60a6  movaps xmm3, xmm1
00007aa3a45d60a9  mulpd xmm3, xmm15
00007aa3a45d60ae  vcmppd xmm14, xmm3, xmm3, 0x03
00007aa3a45d60b3  ptest xmm14, xmm14
00007aa3a45d60b9  jnz 0x00007AA3A45D8771
00007aa3a45d60bf  lea r14, [rax+0x20]
00007aa3a45d60c3  movups xmm1, [r13+r14*1]
00007aa3a45d60c9  movaps [r15+0x110], xmm1
00007aa3a45d60d1  vmovaps xmm14, [rsp+0x70]
00007aa3a45d60d7  vmovaps [rsp+0x70], xmm1
00007aa3a45d60dd  movaps xmm15, xmm14
00007aa3a45d60e1  addpd xmm15, xmm4
00007aa3a45d60e6  vcmppd xmm1, xmm15, xmm15, 0x03
00007aa3a45d60ec  ptest xmm1, xmm1
00007aa3a45d60f1  jnz 0x00007AA3A45D88BC
00007aa3a45d60f7  vmovaps xmm1, [rsp+0x60]
00007aa3a45d60fd  vpermilpd xmm1, xmm1, 0x00
00007aa3a45d6103  movaps xmm14, xmm2
00007aa3a45d6107  mulpd xmm14, xmm1
00007aa3a45d610c  vcmppd xmm4, xmm14, xmm14, 0x03
00007aa3a45d6112  ptest xmm4, xmm4
00007aa3a45d6117  jnz 0x00007AA3A45D89FF
00007aa3a45d611d  vmovaps xmm4, [rsp+0x50]
00007aa3a45d6123  movaps xmm1, xmm4
00007aa3a45d6126  addpd xmm1, xmm9
00007aa3a45d612b  vcmppd xmm2, xmm1, xmm1, 0x03
00007aa3a45d6130  ptest xmm2, xmm2
00007aa3a45d6135  jnz 0x00007AA3A45D8B41
00007aa3a45d613b  vmovaps xmm9, [rsp+0x30]
00007aa3a45d6141  vpermilpd xmm9, xmm9, 0x00
00007aa3a45d6147  vmovaps xmm2, [rsp+0x70]
00007aa3a45d614d  vmovaps [rsp+0x50], xmm1
00007aa3a45d6153  movaps xmm4, xmm2
00007aa3a45d6156  mulpd xmm4, xmm9
00007aa3a45d615b  vcmppd xmm1, xmm4, xmm4, 0x03
00007aa3a45d6160  ptest xmm1, xmm1
00007aa3a45d6165  jnz 0x00007AA3A45D8C82
00007aa3a45d616b  vmovaps xmm1, [rsp+0x30]
00007aa3a45d6171  vpermilpd xmm1, xmm1, 0x00
00007aa3a45d6177  vmovaps xmm2, [rsp+0x90]
00007aa3a45d6180  vmovaps [rsp+0x60], xmm15
00007aa3a45d6186  movaps xmm9, xmm2
00007aa3a45d618a  mulpd xmm9, xmm1
00007aa3a45d618f  vcmppd xmm15, xmm9, xmm9, 0x03
00007aa3a45d6195  ptest xmm15, xmm15
00007aa3a45d619b  jnz 0x00007AA3A45D8DC3
00007aa3a45d61a1  vmovaps xmm15, [rsp+0x80]
00007aa3a45d61aa  movaps xmm1, xmm15
00007aa3a45d61ae  addpd xmm1, xmm6
00007aa3a45d61b2  vcmppd xmm2, xmm1, xmm1, 0x03
00007aa3a45d61b7  ptest xmm2, xmm2
00007aa3a45d61bc  jnz 0x00007AA3A45D8F05
00007aa3a45d61c2  movaps xmm15, xmm5
00007aa3a45d61c6  addpd xmm15, xmm3
00007aa3a45d61cb  vcmppd xmm6, xmm15, xmm15, 0x03
00007aa3a45d61d1  ptest xmm6, xmm6
00007aa3a45d61d6  jnz 0x00007AA3A45D9046
00007aa3a45d61dc  vmovaps xmm6, [rsp+0x30]
00007aa3a45d61e2  vpermilpd xmm6, xmm6, 0x00
00007aa3a45d61e8  movaps xmm5, xmm8
00007aa3a45d61ec  mulpd xmm5, xmm6
00007aa3a45d61f0  vcmppd xmm3, xmm5, xmm5, 0x03
00007aa3a45d61f5  ptest xmm3, xmm3
00007aa3a45d61fa  jnz 0x00007AA3A45D9188
00007aa3a45d6200  vmovaps xmm8, [rsp+0x30]
00007aa3a45d6206  vpermilpd xmm8, xmm8, 0x00
00007aa3a45d620c  movaps xmm6, xmm10
00007aa3a45d6210  mulpd xmm6, xmm8
00007aa3a45d6215  vcmppd xmm3, xmm6, xmm6, 0x03
00007aa3a45d621a  ptest xmm3, xmm3
00007aa3a45d621f  jnz 0x00007AA3A45D92C9
00007aa3a45d6225  vmovaps xmm8, [rsp+0x60]
00007aa3a45d622b  movaps xmm10, xmm8
00007aa3a45d622f  addpd xmm10, xmm14
00007aa3a45d6234  vcmppd xmm3, xmm10, xmm10, 0x03
00007aa3a45d623a  ptest xmm3, xmm3
00007aa3a45d623f  jnz 0x00007AA3A45D940B
00007aa3a45d6245  vmovaps xmm8, [rsp+0x50]
00007aa3a45d624b  movaps xmm14, xmm8
00007aa3a45d624f  addpd xmm14, xmm4
00007aa3a45d6254  vcmppd xmm3, xmm14, xmm14, 0x03
00007aa3a45d625a  ptest xmm3, xmm3
00007aa3a45d625f  jnz 0x00007AA3A45D954F
00007aa3a45d6265  vmovaps xmm8, [rsp+0x40]
00007aa3a45d626b  vpermilpd xmm8, xmm8, 0x00
00007aa3a45d6271  movaps xmm4, xmm13
00007aa3a45d6275  mulpd xmm4, xmm8
00007aa3a45d627a  vcmppd xmm3, xmm4, xmm4, 0x03
00007aa3a45d627f  ptest xmm3, xmm3
00007aa3a45d6284  jnz 0x00007AA3A45D9692
00007aa3a45d628a  movaps xmm13, xmm15
00007aa3a45d628e  addpd xmm13, xmm9
00007aa3a45d6293  vcmppd xmm8, xmm13, xmm13, 0x03
00007aa3a45d6299  ptest xmm8, xmm8
00007aa3a45d629f  jnz 0x00007AA3A45D97D4
00007aa3a45d62a5  movaps xmm15, xmm1
00007aa3a45d62a9  addpd xmm15, xmm5
00007aa3a45d62ae  vcmppd xmm9, xmm15, xmm15, 0x03
00007aa3a45d62b4  ptest xmm9, xmm9
00007aa3a45d62ba  jnz 0x00007AA3A45D9918
00007aa3a45d62c0  vmovaps [rsp+0x30], xmm11
00007aa3a45d62c6  vmovaps xmm1, [rsp+0x30]
00007aa3a45d62cc  por xmm11, xmm1
00007aa3a45d62d1  movaps [r15+0x250], xmm11
00007aa3a45d62d9  vmovaps [rsp+0x30], xmm12
00007aa3a45d62df  vmovaps xmm1, [rsp+0x30]
00007aa3a45d62e5  por xmm12, xmm1
00007aa3a45d62ea  movaps [r15+0x2A0], xmm12
00007aa3a45d62f2  vmovaps xmm1, [rsp+0xA0]
00007aa3a45d62fb  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d6304  por xmm1, xmm11
00007aa3a45d6309  movaps [r15+0x1D0], xmm1
00007aa3a45d6311  lea r14, [rax+0x40]
00007aa3a45d6315  movups xmm1, [r13+r14*1]
00007aa3a45d631b  movaps [r15+0x2C0], xmm1
00007aa3a45d6323  vmovaps xmm11, [rsp+0x40]
00007aa3a45d6329  vpermilpd xmm11, xmm11, 0x00
00007aa3a45d632f  vmovaps xmm8, [rsp+0xE0]
00007aa3a45d6338  movaps xmm9, xmm8
00007aa3a45d633c  mulpd xmm9, xmm11
00007aa3a45d6341  vcmppd xmm5, xmm9, xmm9, 0x03
00007aa3a45d6347  ptest xmm5, xmm5
00007aa3a45d634c  jnz 0x00007AA3A45D9A64
00007aa3a45d6352  movaps xmm11, xmm10
00007aa3a45d6356  addpd xmm11, xmm6
00007aa3a45d635b  vcmppd xmm8, xmm11, xmm11, 0x03
00007aa3a45d6361  ptest xmm8, xmm8
00007aa3a45d6367  jnz 0x00007AA3A45D9BA8
00007aa3a45d636d  movaps xmm10, xmm14
00007aa3a45d6371  addpd xmm10, xmm4
00007aa3a45d6376  vcmppd xmm8, xmm10, xmm10, 0x03
00007aa3a45d637c  ptest xmm8, xmm8
00007aa3a45d6382  jnz 0x00007AA3A45D9CEB
00007aa3a45d6388  vmovaps xmm14, [rsp+0x40]
00007aa3a45d638e  vpermilpd xmm14, xmm14, 0x00
00007aa3a45d6394  movaps xmm8, xmm1
00007aa3a45d6398  mulpd xmm8, xmm14
00007aa3a45d639d  vcmppd xmm6, xmm8, xmm8, 0x03
00007aa3a45d63a3  ptest xmm6, xmm6
00007aa3a45d63a8  jnz 0x00007AA3A45D9E2E
00007aa3a45d63ae  movaps xmm1, [r15+0x2B0]
00007aa3a45d63b6  vmovaps xmm14, [rsp+0x40]
00007aa3a45d63bc  vpermilpd xmm14, xmm14, 0x00
00007aa3a45d63c2  movaps xmm6, xmm1
00007aa3a45d63c5  mulpd xmm6, xmm14
00007aa3a45d63ca  vcmppd xmm5, xmm6, xmm6, 0x03
00007aa3a45d63cf  ptest xmm5, xmm5
00007aa3a45d63d4  jnz 0x00007AA3A45D9F71
00007aa3a45d63da  vmovaps xmm1, [rsp+0x10]
00007aa3a45d63e0  vpermilpd xmm1, xmm1, 0x00
00007aa3a45d63e6  movaps xmm14, xmm12
00007aa3a45d63ea  mulpd xmm14, xmm1
00007aa3a45d63ef  vcmppd xmm5, xmm14, xmm14, 0x03
00007aa3a45d63f5  ptest xmm5, xmm5
00007aa3a45d63fa  jnz 0x00007AA3A45DA0B2
00007aa3a45d6400  movaps xmm1, xmm13
00007aa3a45d6404  addpd xmm1, xmm9
00007aa3a45d6409  vcmppd xmm12, xmm1, xmm1, 0x03
00007aa3a45d640e  ptest xmm12, xmm12
00007aa3a45d6414  jnz 0x00007AA3A45DA1F5
00007aa3a45d641a  vmovaps xmm13, [rsp+0x10]
00007aa3a45d6420  vpermilpd xmm13, xmm13, 0x00
00007aa3a45d6426  movaps xmm12, xmm7
00007aa3a45d642a  mulpd xmm12, xmm13
00007aa3a45d642f  vcmppd xmm9, xmm12, xmm12, 0x03
00007aa3a45d6435  ptest xmm9, xmm9
00007aa3a45d643b  jnz 0x00007AA3A45DA337
00007aa3a45d6441  movaps xmm13, xmm15
00007aa3a45d6445  addpd xmm13, xmm8
00007aa3a45d644a  vcmppd xmm9, xmm13, xmm13, 0x03
00007aa3a45d6450  ptest xmm9, xmm9
00007aa3a45d6456  jnz 0x00007AA3A45DA47A
00007aa3a45d645c  movaps xmm15, [r15+0x290]
00007aa3a45d6464  vmovaps xmm9, [rsp+0x10]
00007aa3a45d646a  vpermilpd xmm9, xmm9, 0x00
00007aa3a45d6470  movaps xmm8, xmm15
00007aa3a45d6474  mulpd xmm8, xmm9
00007aa3a45d6479  vcmppd xmm7, xmm8, xmm8, 0x03
00007aa3a45d647f  ptest xmm7, xmm7
00007aa3a45d6484  jnz 0x00007AA3A45DA5BE
00007aa3a45d648a  movaps xmm15, xmm11
00007aa3a45d648e  addpd xmm15, xmm6
00007aa3a45d6493  vcmppd xmm9, xmm15, xmm15, 0x03
00007aa3a45d6499  ptest xmm9, xmm9
00007aa3a45d649f  jnz 0x00007AA3A45DA702
00007aa3a45d64a5  movaps xmm11, [r15+0x1E0]
00007aa3a45d64ad  vmovaps xmm9, [rsp+0x10]
00007aa3a45d64b3  vpermilpd xmm9, xmm9, 0x00
00007aa3a45d64b9  movaps xmm7, xmm11
00007aa3a45d64bd  mulpd xmm7, xmm9
00007aa3a45d64c2  vcmppd xmm6, xmm7, xmm7, 0x03
00007aa3a45d64c7  ptest xmm6, xmm6
00007aa3a45d64cc  jnz 0x00007AA3A45DA845
00007aa3a45d64d2  movaps xmm11, xmm10
00007aa3a45d64d6  addpd xmm11, xmm14
00007aa3a45d64db  vcmppd xmm9, xmm11, xmm11, 0x03
00007aa3a45d64e1  ptest xmm9, xmm9
00007aa3a45d64e7  jnz 0x00007AA3A45DA987
00007aa3a45d64ed  lea r14, [rax+0x70]
00007aa3a45d64f1  movups xmm14, [r13+r14*1]
00007aa3a45d64f7  movaps [r15+0x240], xmm14
00007aa3a45d64ff  movaps xmm10, xmm1
00007aa3a45d6503  addpd xmm10, xmm12
00007aa3a45d6508  vcmppd xmm9, xmm10, xmm10, 0x03
00007aa3a45d650e  ptest xmm9, xmm9
00007aa3a45d6514  jnz 0x00007AA3A45DAAD5
00007aa3a45d651a  movaps [r15+0x170], xmm10
00007aa3a45d6522  vmovaps xmm1, [rsp+0x20]
00007aa3a45d6528  vpermilpd xmm1, xmm1, 0x00
00007aa3a45d652e  movaps xmm12, xmm14
00007aa3a45d6532  mulpd xmm12, xmm1
00007aa3a45d6537  vcmppd xmm9, xmm12, xmm12, 0x03
00007aa3a45d653d  ptest xmm9, xmm9
00007aa3a45d6543  jnz 0x00007AA3A45DAC18
00007aa3a45d6549  vmovaps xmm1, [rsp+0x20]
00007aa3a45d654f  vpermilpd xmm1, xmm1, 0x00
00007aa3a45d6555  vmovaps xmm9, [rsp+0xB0]
00007aa3a45d655e  movaps xmm14, xmm9
00007aa3a45d6562  mulpd xmm14, xmm1
00007aa3a45d6567  vcmppd xmm6, xmm14, xmm14, 0x03
00007aa3a45d656d  ptest xmm6, xmm6
00007aa3a45d6572  jnz 0x00007AA3A45DAD5B
00007aa3a45d6578  movaps [r15+0x180], xmm14
00007aa3a45d6580  movaps xmm1, xmm13
00007aa3a45d6584  addpd xmm1, xmm8
00007aa3a45d6589  vcmppd xmm9, xmm1, xmm1, 0x03
00007aa3a45d658e  ptest xmm9, xmm9
00007aa3a45d6594  jnz 0x00007AA3A45DAE9E
00007aa3a45d659a  movaps [r15+0x210], xmm1
00007aa3a45d65a2  movups xmm13, [r13+rax*1]
00007aa3a45d65a8  lea r14, [rax+0x10]
00007aa3a45d65ac  movups xmm9, [r13+r14*1]
00007aa3a45d65b2  movaps [r15+0x230], xmm9
00007aa3a45d65ba  movaps xmm8, xmm15
00007aa3a45d65be  addpd xmm8, xmm7
00007aa3a45d65c3  vcmppd xmm6, xmm8, xmm8, 0x03
00007aa3a45d65c9  ptest xmm6, xmm6
00007aa3a45d65ce  jnz 0x00007AA3A45DAFF4
00007aa3a45d65d4  movaps [r15+0x130], xmm8
00007aa3a45d65dc  vmovaps xmm15, [rsp+0x20]
00007aa3a45d65e2  vpermilpd xmm15, xmm15, 0x00
00007aa3a45d65e8  movaps xmm7, xmm9
00007aa3a45d65ec  mulpd xmm7, xmm15
00007aa3a45d65f1  vcmppd xmm6, xmm7, xmm7, 0x03
00007aa3a45d65f6  ptest xmm6, xmm6
00007aa3a45d65fb  jnz 0x00007AA3A45DB137
00007aa3a45d6601  movaps [r15+0x220], xmm7
00007aa3a45d6609  vmovaps xmm15, [rsp+0x20]
00007aa3a45d660f  vpermilpd xmm15, xmm15, 0x00
00007aa3a45d6615  movaps xmm9, xmm13
00007aa3a45d6619  mulpd xmm9, xmm15
00007aa3a45d661e  vcmppd xmm6, xmm9, xmm9, 0x03
00007aa3a45d6624  ptest xmm6, xmm6
00007aa3a45d6629  jnz 0x00007AA3A45DB279
00007aa3a45d662f  movaps xmm15, xmm11
00007aa3a45d6633  addpd xmm15, xmm12
00007aa3a45d6638  vcmppd xmm13, xmm15, xmm15, 0x03
00007aa3a45d663e  ptest xmm13, xmm13
00007aa3a45d6644  jnz 0x00007AA3A45DB3BD
00007aa3a45d664a  movaps [r15+0x140], xmm15
00007aa3a45d6652  movaps xmm13, xmm10
00007aa3a45d6656  addpd xmm13, xmm14
00007aa3a45d665b  vcmppd xmm12, xmm13, xmm13, 0x03
00007aa3a45d6661  ptest xmm12, xmm12
00007aa3a45d6667  jnz 0x00007AA3A45DB501
00007aa3a45d666d  movaps [r15+0x150], xmm13
00007aa3a45d6675  movaps xmm14, xmm1
00007aa3a45d6679  addpd xmm14, xmm7
00007aa3a45d667e  vcmppd xmm12, xmm14, xmm14, 0x03
00007aa3a45d6684  ptest xmm12, xmm12
00007aa3a45d668a  jnz 0x00007AA3A45DB645
00007aa3a45d6690  movaps [r15+0x160], xmm14
00007aa3a45d6698  movaps xmm1, xmm8
00007aa3a45d669c  addpd xmm1, xmm9
00007aa3a45d66a1  vcmppd xmm12, xmm1, xmm1, 0x03
00007aa3a45d66a6  ptest xmm12, xmm12
00007aa3a45d66ac  jnz 0x00007AA3A45DB787
00007aa3a45d66b2  movaps [r15+0x120], xmm1
00007aa3a45d66ba  movups [r13+r11*1], xmm15
00007aa3a45d66c0  lea rax, [r11+0x10]
00007aa3a45d66c4  movups [r13+rax*1], xmm13
00007aa3a45d66ca  lea rax, [r11+0x20]
00007aa3a45d66ce  movups [r13+rax*1], xmm14
00007aa3a45d66d4  lea rax, [r11+0x30]
00007aa3a45d66d8  movups [r13+rax*1], xmm1
00007aa3a45d66de  mov eax, [r15+0x108]
00007aa3a45d66e5  sahf
00007aa3a45d66e6  jnz 0x00007AA3A45D6718
00007aa3a45d66e8  cmp dword ptr [r15+0x318], 0x00
00007aa3a45d66f0  jz 0x00007AA3A45DB900
00007aa3a45d66f6  nop [rax+rax*1], ax
00007aa3a45d66ff  nop [rax+rax*1], eax
00007aa3a45d6707  mov eax, 0x410444
00007aa3a45d670c  mov [r15+0x100], rax
00007aa3a45d6713  jmp 0x00007AA3A43FE110
00007aa3a45d6718  cmp dword ptr [r15+0x318], 0x00
00007aa3a45d6720  jz 0x00007AA3A45D57E0
00007aa3a45d6726  nop [rax+rax*1], ax
00007aa3a45d672f  nop [rax+rax*1], eax
00007aa3a45d6737  mov eax, 0x410278
00007aa3a45d673c  mov [r15+0x100], rax
00007aa3a45d6743  jmp 0x00007AA3A43FE110
00007aa3a45d6748  int3
00007aa3a45d6749  call 0x00007AA3A440A4B0
00007aa3a45d674e  jmp 0x00007AA3A45D5828
00007aa3a45d6753  call 0x00007AA3A4409240
00007aa3a45d6758  jmp 0x00007AA3A45D5832
00007aa3a45d675d  call 0x00007AA3A440A4B0
00007aa3a45d6762  jmp 0x00007AA3A45D588F
00007aa3a45d6767  call 0x00007AA3A4409240
00007aa3a45d676c  jmp 0x00007AA3A45D5899
00007aa3a45d6771  call 0x00007AA3A440A4B0
00007aa3a45d6776  jmp 0x00007AA3A45D58DD
00007aa3a45d677b  call 0x00007AA3A4409240
00007aa3a45d6780  jmp 0x00007AA3A45D58E7
00007aa3a45d6785  call 0x00007AA3A44B47C0
00007aa3a45d678a  jmp 0x00007AA3A45D5926
00007aa3a45d678f  call 0x00007AA3A440B720
00007aa3a45d6794  jmp 0x00007AA3A45D593A
00007aa3a45d6799  call 0x00007AA3A44BFC30
00007aa3a45d679e  jmp 0x00007AA3A45D5958
00007aa3a45d67a3  call 0x00007AA3A44BE9C0
00007aa3a45d67a8  jmp 0x00007AA3A45D5962
00007aa3a45d67ad  call 0x00007AA3A44BD750
00007aa3a45d67b2  jmp 0x00007AA3A45D596C
00007aa3a45d67b7  sub rsp, 0x08
00007aa3a45d67bb  push rax
00007aa3a45d67bc  push rcx
00007aa3a45d67bd  push rdx
00007aa3a45d67be  push rdi
00007aa3a45d67bf  push rsi
00007aa3a45d67c0  push r8
00007aa3a45d67c2  push r9
00007aa3a45d67c4  push r10
00007aa3a45d67c6  push r11
00007aa3a45d67c8  sub rsp, 0xF0
00007aa3a45d67cf  vmovaps [rsp], xmm0
00007aa3a45d67d4  vmovaps [rsp+0x10], xmm1
00007aa3a45d67da  vmovaps [rsp+0x20], xmm2
00007aa3a45d67e0  vmovaps [rsp+0x30], xmm3
00007aa3a45d67e6  vmovaps [rsp+0x40], xmm4
00007aa3a45d67ec  vmovaps [rsp+0x50], xmm5
00007aa3a45d67f2  vmovaps [rsp+0x60], xmm6
00007aa3a45d67f8  vmovaps [rsp+0x70], xmm7
00007aa3a45d67fe  vmovaps [rsp+0x80], xmm9
00007aa3a45d6807  vmovaps [rsp+0x90], xmm10
00007aa3a45d6810  vmovaps [rsp+0xA0], xmm11
00007aa3a45d6819  vmovaps [rsp+0xB0], xmm12
00007aa3a45d6822  vmovaps [rsp+0xC0], xmm13
00007aa3a45d682b  vmovaps [rsp+0xD0], xmm14
00007aa3a45d6834  vmovaps [rsp+0xE0], xmm15
00007aa3a45d683d  sub rsp, 0x30
00007aa3a45d6841  movaps [rsp], xmm8
00007aa3a45d6846  movaps [rsp+0x10], xmm12
00007aa3a45d684c  movaps [rsp+0x20], xmm15
00007aa3a45d6852  lea rdi, [rsp]
00007aa3a45d6856  mov esi, 0x00
00007aa3a45d685b  mov rax, 0x5F551B683530
00007aa3a45d6865  call rax
00007aa3a45d6867  movaps xmm8, [rsp]
00007aa3a45d686c  add rsp, 0x30
00007aa3a45d6870  vmovaps xmm0, [rsp]
00007aa3a45d6875  vmovaps xmm1, [rsp+0x10]
00007aa3a45d687b  vmovaps xmm2, [rsp+0x20]
00007aa3a45d6881  vmovaps xmm3, [rsp+0x30]
00007aa3a45d6887  vmovaps xmm4, [rsp+0x40]
00007aa3a45d688d  vmovaps xmm5, [rsp+0x50]
00007aa3a45d6893  vmovaps xmm6, [rsp+0x60]
00007aa3a45d6899  vmovaps xmm7, [rsp+0x70]
00007aa3a45d689f  vmovaps xmm9, [rsp+0x80]
00007aa3a45d68a8  vmovaps xmm10, [rsp+0x90]
00007aa3a45d68b1  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d68ba  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d68c3  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d68cc  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d68d5  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d68de  add rsp, 0xF0
00007aa3a45d68e5  pop r11
00007aa3a45d68e7  pop r10
00007aa3a45d68e9  pop r9
00007aa3a45d68eb  pop r8
00007aa3a45d68ed  pop rsi
00007aa3a45d68ee  pop rdi
00007aa3a45d68ef  pop rdx
00007aa3a45d68f0  pop rcx
00007aa3a45d68f1  pop rax
00007aa3a45d68f2  add rsp, 0x08
00007aa3a45d68f6  jmp 0x00007AA3A45D599A
00007aa3a45d68fb  sub rsp, 0x08
00007aa3a45d68ff  push rax
00007aa3a45d6900  push rcx
00007aa3a45d6901  push rdx
00007aa3a45d6902  push rdi
00007aa3a45d6903  push rsi
00007aa3a45d6904  push r8
00007aa3a45d6906  push r9
00007aa3a45d6908  push r10
00007aa3a45d690a  push r11
00007aa3a45d690c  sub rsp, 0xF0
00007aa3a45d6913  vmovaps [rsp], xmm0
00007aa3a45d6918  vmovaps [rsp+0x10], xmm1
00007aa3a45d691e  vmovaps [rsp+0x20], xmm2
00007aa3a45d6924  vmovaps [rsp+0x30], xmm3
00007aa3a45d692a  vmovaps [rsp+0x40], xmm4
00007aa3a45d6930  vmovaps [rsp+0x50], xmm5
00007aa3a45d6936  vmovaps [rsp+0x60], xmm6
00007aa3a45d693c  vmovaps [rsp+0x70], xmm8
00007aa3a45d6942  vmovaps [rsp+0x80], xmm9
00007aa3a45d694b  vmovaps [rsp+0x90], xmm10
00007aa3a45d6954  vmovaps [rsp+0xA0], xmm11
00007aa3a45d695d  vmovaps [rsp+0xB0], xmm12
00007aa3a45d6966  vmovaps [rsp+0xC0], xmm13
00007aa3a45d696f  vmovaps [rsp+0xD0], xmm14
00007aa3a45d6978  vmovaps [rsp+0xE0], xmm15
00007aa3a45d6981  sub rsp, 0x30
00007aa3a45d6985  movaps [rsp], xmm7
00007aa3a45d6989  movaps [rsp+0x10], xmm9
00007aa3a45d698f  movaps [rsp+0x20], xmm15
00007aa3a45d6995  lea rdi, [rsp]
00007aa3a45d6999  mov esi, 0x00
00007aa3a45d699e  mov rax, 0x5F551B683530
00007aa3a45d69a8  call rax
00007aa3a45d69aa  movaps xmm7, [rsp]
00007aa3a45d69ae  add rsp, 0x30
00007aa3a45d69b2  vmovaps xmm0, [rsp]
00007aa3a45d69b7  vmovaps xmm1, [rsp+0x10]
00007aa3a45d69bd  vmovaps xmm2, [rsp+0x20]
00007aa3a45d69c3  vmovaps xmm3, [rsp+0x30]
00007aa3a45d69c9  vmovaps xmm4, [rsp+0x40]
00007aa3a45d69cf  vmovaps xmm5, [rsp+0x50]
00007aa3a45d69d5  vmovaps xmm6, [rsp+0x60]
00007aa3a45d69db  vmovaps xmm8, [rsp+0x70]
00007aa3a45d69e1  vmovaps xmm9, [rsp+0x80]
00007aa3a45d69ea  vmovaps xmm10, [rsp+0x90]
00007aa3a45d69f3  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d69fc  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d6a05  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d6a0e  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d6a17  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d6a20  add rsp, 0xF0
00007aa3a45d6a27  pop r11
00007aa3a45d6a29  pop r10
00007aa3a45d6a2b  pop r9
00007aa3a45d6a2d  pop r8
00007aa3a45d6a2f  pop rsi
00007aa3a45d6a30  pop rdi
00007aa3a45d6a31  pop rdx
00007aa3a45d6a32  pop rcx
00007aa3a45d6a33  pop rax
00007aa3a45d6a34  add rsp, 0x08
00007aa3a45d6a38  jmp 0x00007AA3A45D59C8
00007aa3a45d6a3d  sub rsp, 0x08
00007aa3a45d6a41  push rax
00007aa3a45d6a42  push rcx
00007aa3a45d6a43  push rdx
00007aa3a45d6a44  push rdi
00007aa3a45d6a45  push rsi
00007aa3a45d6a46  push r8
00007aa3a45d6a48  push r9
00007aa3a45d6a4a  push r10
00007aa3a45d6a4c  push r11
00007aa3a45d6a4e  sub rsp, 0xF0
00007aa3a45d6a55  vmovaps [rsp], xmm0
00007aa3a45d6a5a  vmovaps [rsp+0x10], xmm1
00007aa3a45d6a60  vmovaps [rsp+0x20], xmm2
00007aa3a45d6a66  vmovaps [rsp+0x30], xmm3
00007aa3a45d6a6c  vmovaps [rsp+0x40], xmm4
00007aa3a45d6a72  vmovaps [rsp+0x50], xmm5
00007aa3a45d6a78  vmovaps [rsp+0x60], xmm6
00007aa3a45d6a7e  vmovaps [rsp+0x70], xmm7
00007aa3a45d6a84  vmovaps [rsp+0x80], xmm8
00007aa3a45d6a8d  vmovaps [rsp+0x90], xmm10
00007aa3a45d6a96  vmovaps [rsp+0xA0], xmm11
00007aa3a45d6a9f  vmovaps [rsp+0xB0], xmm12
00007aa3a45d6aa8  vmovaps [rsp+0xC0], xmm13
00007aa3a45d6ab1  vmovaps [rsp+0xD0], xmm14
00007aa3a45d6aba  vmovaps [rsp+0xE0], xmm15
00007aa3a45d6ac3  sub rsp, 0x30
00007aa3a45d6ac7  movaps [rsp], xmm9
00007aa3a45d6acc  movaps [rsp+0x10], xmm12
00007aa3a45d6ad2  movaps [rsp+0x20], xmm10
00007aa3a45d6ad8  lea rdi, [rsp]
00007aa3a45d6adc  mov esi, 0x00
00007aa3a45d6ae1  mov rax, 0x5F551B683530
00007aa3a45d6aeb  call rax
00007aa3a45d6aed  movaps xmm9, [rsp]
00007aa3a45d6af2  add rsp, 0x30
00007aa3a45d6af6  vmovaps xmm0, [rsp]
00007aa3a45d6afb  vmovaps xmm1, [rsp+0x10]
00007aa3a45d6b01  vmovaps xmm2, [rsp+0x20]
00007aa3a45d6b07  vmovaps xmm3, [rsp+0x30]
00007aa3a45d6b0d  vmovaps xmm4, [rsp+0x40]
00007aa3a45d6b13  vmovaps xmm5, [rsp+0x50]
00007aa3a45d6b19  vmovaps xmm6, [rsp+0x60]
00007aa3a45d6b1f  vmovaps xmm7, [rsp+0x70]
00007aa3a45d6b25  vmovaps xmm8, [rsp+0x80]
00007aa3a45d6b2e  vmovaps xmm10, [rsp+0x90]
00007aa3a45d6b37  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d6b40  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d6b49  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d6b52  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d6b5b  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d6b64  add rsp, 0xF0
00007aa3a45d6b6b  pop r11
00007aa3a45d6b6d  pop r10
00007aa3a45d6b6f  pop r9
00007aa3a45d6b71  pop r8
00007aa3a45d6b73  pop rsi
00007aa3a45d6b74  pop rdi
00007aa3a45d6b75  pop rdx
00007aa3a45d6b76  pop rcx
00007aa3a45d6b77  pop rax
00007aa3a45d6b78  add rsp, 0x08
00007aa3a45d6b7c  jmp 0x00007AA3A45D59EC
00007aa3a45d6b81  sub rsp, 0x08
00007aa3a45d6b85  push rax
00007aa3a45d6b86  push rcx
00007aa3a45d6b87  push rdx
00007aa3a45d6b88  push rdi
00007aa3a45d6b89  push rsi
00007aa3a45d6b8a  push r8
00007aa3a45d6b8c  push r9
00007aa3a45d6b8e  push r10
00007aa3a45d6b90  push r11
00007aa3a45d6b92  sub rsp, 0xF0
00007aa3a45d6b99  vmovaps [rsp], xmm0
00007aa3a45d6b9e  vmovaps [rsp+0x10], xmm1
00007aa3a45d6ba4  vmovaps [rsp+0x20], xmm2
00007aa3a45d6baa  vmovaps [rsp+0x30], xmm3
00007aa3a45d6bb0  vmovaps [rsp+0x40], xmm4
00007aa3a45d6bb6  vmovaps [rsp+0x50], xmm5
00007aa3a45d6bbc  vmovaps [rsp+0x60], xmm6
00007aa3a45d6bc2  vmovaps [rsp+0x70], xmm7
00007aa3a45d6bc8  vmovaps [rsp+0x80], xmm8
00007aa3a45d6bd1  vmovaps [rsp+0x90], xmm9
00007aa3a45d6bda  vmovaps [rsp+0xA0], xmm11
00007aa3a45d6be3  vmovaps [rsp+0xB0], xmm12
00007aa3a45d6bec  vmovaps [rsp+0xC0], xmm13
00007aa3a45d6bf5  vmovaps [rsp+0xD0], xmm14
00007aa3a45d6bfe  vmovaps [rsp+0xE0], xmm15
00007aa3a45d6c07  sub rsp, 0x30
00007aa3a45d6c0b  movaps [rsp], xmm10
00007aa3a45d6c10  movaps [rsp+0x10], xmm12
00007aa3a45d6c16  movaps [rsp+0x20], xmm11
00007aa3a45d6c1c  lea rdi, [rsp]
00007aa3a45d6c20  mov esi, 0x00
00007aa3a45d6c25  mov rax, 0x5F551B683530
00007aa3a45d6c2f  call rax
00007aa3a45d6c31  movaps xmm10, [rsp]
00007aa3a45d6c36  add rsp, 0x30
00007aa3a45d6c3a  vmovaps xmm0, [rsp]
00007aa3a45d6c3f  vmovaps xmm1, [rsp+0x10]
00007aa3a45d6c45  vmovaps xmm2, [rsp+0x20]
00007aa3a45d6c4b  vmovaps xmm3, [rsp+0x30]
00007aa3a45d6c51  vmovaps xmm4, [rsp+0x40]
00007aa3a45d6c57  vmovaps xmm5, [rsp+0x50]
00007aa3a45d6c5d  vmovaps xmm6, [rsp+0x60]
00007aa3a45d6c63  vmovaps xmm7, [rsp+0x70]
00007aa3a45d6c69  vmovaps xmm8, [rsp+0x80]
00007aa3a45d6c72  vmovaps xmm9, [rsp+0x90]
00007aa3a45d6c7b  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d6c84  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d6c8d  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d6c96  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d6c9f  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d6ca8  add rsp, 0xF0
00007aa3a45d6caf  pop r11
00007aa3a45d6cb1  pop r10
00007aa3a45d6cb3  pop r9
00007aa3a45d6cb5  pop r8
00007aa3a45d6cb7  pop rsi
00007aa3a45d6cb8  pop rdi
00007aa3a45d6cb9  pop rdx
00007aa3a45d6cba  pop rcx
00007aa3a45d6cbb  pop rax
00007aa3a45d6cbc  add rsp, 0x08
00007aa3a45d6cc0  jmp 0x00007AA3A45D5A06
00007aa3a45d6cc5  sub rsp, 0x08
00007aa3a45d6cc9  push rax
00007aa3a45d6cca  push rcx
00007aa3a45d6ccb  push rdx
00007aa3a45d6ccc  push rdi
00007aa3a45d6ccd  push rsi
00007aa3a45d6cce  push r8
00007aa3a45d6cd0  push r9
00007aa3a45d6cd2  push r10
00007aa3a45d6cd4  push r11
00007aa3a45d6cd6  sub rsp, 0xF0
00007aa3a45d6cdd  vmovaps [rsp], xmm0
00007aa3a45d6ce2  vmovaps [rsp+0x10], xmm1
00007aa3a45d6ce8  vmovaps [rsp+0x20], xmm2
00007aa3a45d6cee  vmovaps [rsp+0x30], xmm3
00007aa3a45d6cf4  vmovaps [rsp+0x40], xmm4
00007aa3a45d6cfa  vmovaps [rsp+0x50], xmm5
00007aa3a45d6d00  vmovaps [rsp+0x60], xmm7
00007aa3a45d6d06  vmovaps [rsp+0x70], xmm8
00007aa3a45d6d0c  vmovaps [rsp+0x80], xmm9
00007aa3a45d6d15  vmovaps [rsp+0x90], xmm10
00007aa3a45d6d1e  vmovaps [rsp+0xA0], xmm11
00007aa3a45d6d27  vmovaps [rsp+0xB0], xmm12
00007aa3a45d6d30  vmovaps [rsp+0xC0], xmm13
00007aa3a45d6d39  vmovaps [rsp+0xD0], xmm14
00007aa3a45d6d42  vmovaps [rsp+0xE0], xmm15
00007aa3a45d6d4b  sub rsp, 0x30
00007aa3a45d6d4f  movaps [rsp], xmm6
00007aa3a45d6d53  movaps [rsp+0x10], xmm12
00007aa3a45d6d59  movaps [rsp+0x20], xmm11
00007aa3a45d6d5f  lea rdi, [rsp]
00007aa3a45d6d63  mov esi, 0x00
00007aa3a45d6d68  mov rax, 0x5F551B683530
00007aa3a45d6d72  call rax
00007aa3a45d6d74  movaps xmm6, [rsp]
00007aa3a45d6d78  add rsp, 0x30
00007aa3a45d6d7c  vmovaps xmm0, [rsp]
00007aa3a45d6d81  vmovaps xmm1, [rsp+0x10]
00007aa3a45d6d87  vmovaps xmm2, [rsp+0x20]
00007aa3a45d6d8d  vmovaps xmm3, [rsp+0x30]
00007aa3a45d6d93  vmovaps xmm4, [rsp+0x40]
00007aa3a45d6d99  vmovaps xmm5, [rsp+0x50]
00007aa3a45d6d9f  vmovaps xmm7, [rsp+0x60]
00007aa3a45d6da5  vmovaps xmm8, [rsp+0x70]
00007aa3a45d6dab  vmovaps xmm9, [rsp+0x80]
00007aa3a45d6db4  vmovaps xmm10, [rsp+0x90]
00007aa3a45d6dbd  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d6dc6  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d6dcf  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d6dd8  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d6de1  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d6dea  add rsp, 0xF0
00007aa3a45d6df1  pop r11
00007aa3a45d6df3  pop r10
00007aa3a45d6df5  pop r9
00007aa3a45d6df7  pop r8
00007aa3a45d6df9  pop rsi
00007aa3a45d6dfa  pop rdi
00007aa3a45d6dfb  pop rdx
00007aa3a45d6dfc  pop rcx
00007aa3a45d6dfd  pop rax
00007aa3a45d6dfe  add rsp, 0x08
00007aa3a45d6e02  jmp 0x00007AA3A45D5A27
00007aa3a45d6e07  sub rsp, 0x08
00007aa3a45d6e0b  push rax
00007aa3a45d6e0c  push rcx
00007aa3a45d6e0d  push rdx
00007aa3a45d6e0e  push rdi
00007aa3a45d6e0f  push rsi
00007aa3a45d6e10  push r8
00007aa3a45d6e12  push r9
00007aa3a45d6e14  push r10
00007aa3a45d6e16  push r11
00007aa3a45d6e18  sub rsp, 0xF0
00007aa3a45d6e1f  vmovaps [rsp], xmm0
00007aa3a45d6e24  vmovaps [rsp+0x10], xmm1
00007aa3a45d6e2a  vmovaps [rsp+0x20], xmm2
00007aa3a45d6e30  vmovaps [rsp+0x30], xmm4
00007aa3a45d6e36  vmovaps [rsp+0x40], xmm5
00007aa3a45d6e3c  vmovaps [rsp+0x50], xmm6
00007aa3a45d6e42  vmovaps [rsp+0x60], xmm7
00007aa3a45d6e48  vmovaps [rsp+0x70], xmm8
00007aa3a45d6e4e  vmovaps [rsp+0x80], xmm9
00007aa3a45d6e57  vmovaps [rsp+0x90], xmm10
00007aa3a45d6e60  vmovaps [rsp+0xA0], xmm11
00007aa3a45d6e69  vmovaps [rsp+0xB0], xmm12
00007aa3a45d6e72  vmovaps [rsp+0xC0], xmm13
00007aa3a45d6e7b  vmovaps [rsp+0xD0], xmm14
00007aa3a45d6e84  vmovaps [rsp+0xE0], xmm15
00007aa3a45d6e8d  sub rsp, 0x30
00007aa3a45d6e91  movaps [rsp], xmm3
00007aa3a45d6e95  movaps [rsp+0x10], xmm5
00007aa3a45d6e9a  movaps [rsp+0x20], xmm4
00007aa3a45d6e9f  lea rdi, [rsp]
00007aa3a45d6ea3  mov esi, 0x00
00007aa3a45d6ea8  mov rax, 0x5F551B683530
00007aa3a45d6eb2  call rax
00007aa3a45d6eb4  movaps xmm3, [rsp]
00007aa3a45d6eb8  add rsp, 0x30
00007aa3a45d6ebc  vmovaps xmm0, [rsp]
00007aa3a45d6ec1  vmovaps xmm1, [rsp+0x10]
00007aa3a45d6ec7  vmovaps xmm2, [rsp+0x20]
00007aa3a45d6ecd  vmovaps xmm4, [rsp+0x30]
00007aa3a45d6ed3  vmovaps xmm5, [rsp+0x40]
00007aa3a45d6ed9  vmovaps xmm6, [rsp+0x50]
00007aa3a45d6edf  vmovaps xmm7, [rsp+0x60]
00007aa3a45d6ee5  vmovaps xmm8, [rsp+0x70]
00007aa3a45d6eeb  vmovaps xmm9, [rsp+0x80]
00007aa3a45d6ef4  vmovaps xmm10, [rsp+0x90]
00007aa3a45d6efd  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d6f06  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d6f0f  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d6f18  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d6f21  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d6f2a  add rsp, 0xF0
00007aa3a45d6f31  pop r11
00007aa3a45d6f33  pop r10
00007aa3a45d6f35  pop r9
00007aa3a45d6f37  pop r8
00007aa3a45d6f39  pop rsi
00007aa3a45d6f3a  pop rdi
00007aa3a45d6f3b  pop rdx
00007aa3a45d6f3c  pop rcx
00007aa3a45d6f3d  pop rax
00007aa3a45d6f3e  add rsp, 0x08
00007aa3a45d6f42  jmp 0x00007AA3A45D5A88
00007aa3a45d6f47  sub rsp, 0x08
00007aa3a45d6f4b  push rax
00007aa3a45d6f4c  push rcx
00007aa3a45d6f4d  push rdx
00007aa3a45d6f4e  push rdi
00007aa3a45d6f4f  push rsi
00007aa3a45d6f50  push r8
00007aa3a45d6f52  push r9
00007aa3a45d6f54  push r10
00007aa3a45d6f56  push r11
00007aa3a45d6f58  sub rsp, 0xF0
00007aa3a45d6f5f  vmovaps [rsp], xmm0
00007aa3a45d6f64  vmovaps [rsp+0x10], xmm1
00007aa3a45d6f6a  vmovaps [rsp+0x20], xmm2
00007aa3a45d6f70  vmovaps [rsp+0x30], xmm3
00007aa3a45d6f76  vmovaps [rsp+0x40], xmm4
00007aa3a45d6f7c  vmovaps [rsp+0x50], xmm6
00007aa3a45d6f82  vmovaps [rsp+0x60], xmm7
00007aa3a45d6f88  vmovaps [rsp+0x70], xmm8
00007aa3a45d6f8e  vmovaps [rsp+0x80], xmm9
00007aa3a45d6f97  vmovaps [rsp+0x90], xmm10
00007aa3a45d6fa0  vmovaps [rsp+0xA0], xmm11
00007aa3a45d6fa9  vmovaps [rsp+0xB0], xmm12
00007aa3a45d6fb2  vmovaps [rsp+0xC0], xmm13
00007aa3a45d6fbb  vmovaps [rsp+0xD0], xmm14
00007aa3a45d6fc4  vmovaps [rsp+0xE0], xmm15
00007aa3a45d6fcd  sub rsp, 0x30
00007aa3a45d6fd1  movaps [rsp], xmm5
00007aa3a45d6fd5  movaps [rsp+0x10], xmm8
00007aa3a45d6fdb  movaps [rsp+0x20], xmm15
00007aa3a45d6fe1  lea rdi, [rsp]
00007aa3a45d6fe5  mov esi, 0x00
00007aa3a45d6fea  mov rax, 0x5F551B683530
00007aa3a45d6ff4  call rax
00007aa3a45d6ff6  movaps xmm5, [rsp]
00007aa3a45d6ffa  add rsp, 0x30
00007aa3a45d6ffe  vmovaps xmm0, [rsp]
00007aa3a45d7003  vmovaps xmm1, [rsp+0x10]
00007aa3a45d7009  vmovaps xmm2, [rsp+0x20]
00007aa3a45d700f  vmovaps xmm3, [rsp+0x30]
00007aa3a45d7015  vmovaps xmm4, [rsp+0x40]
00007aa3a45d701b  vmovaps xmm6, [rsp+0x50]
00007aa3a45d7021  vmovaps xmm7, [rsp+0x60]
00007aa3a45d7027  vmovaps xmm8, [rsp+0x70]
00007aa3a45d702d  vmovaps xmm9, [rsp+0x80]
00007aa3a45d7036  vmovaps xmm10, [rsp+0x90]
00007aa3a45d703f  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d7048  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d7051  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d705a  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d7063  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d706c  add rsp, 0xF0
00007aa3a45d7073  pop r11
00007aa3a45d7075  pop r10
00007aa3a45d7077  pop r9
00007aa3a45d7079  pop r8
00007aa3a45d707b  pop rsi
00007aa3a45d707c  pop rdi
00007aa3a45d707d  pop rdx
00007aa3a45d707e  pop rcx
00007aa3a45d707f  pop rax
00007aa3a45d7080  add rsp, 0x08
00007aa3a45d7084  jmp 0x00007AA3A45D5AC0
00007aa3a45d7089  sub rsp, 0x08
00007aa3a45d708d  push rax
00007aa3a45d708e  push rcx
00007aa3a45d708f  push rdx
00007aa3a45d7090  push rdi
00007aa3a45d7091  push rsi
00007aa3a45d7092  push r8
00007aa3a45d7094  push r9
00007aa3a45d7096  push r10
00007aa3a45d7098  push r11
00007aa3a45d709a  sub rsp, 0xF0
00007aa3a45d70a1  vmovaps [rsp], xmm0
00007aa3a45d70a6  vmovaps [rsp+0x10], xmm1
00007aa3a45d70ac  vmovaps [rsp+0x20], xmm2
00007aa3a45d70b2  vmovaps [rsp+0x30], xmm3
00007aa3a45d70b8  vmovaps [rsp+0x40], xmm5
00007aa3a45d70be  vmovaps [rsp+0x50], xmm6
00007aa3a45d70c4  vmovaps [rsp+0x60], xmm7
00007aa3a45d70ca  vmovaps [rsp+0x70], xmm8
00007aa3a45d70d0  vmovaps [rsp+0x80], xmm9
00007aa3a45d70d9  vmovaps [rsp+0x90], xmm10
00007aa3a45d70e2  vmovaps [rsp+0xA0], xmm11
00007aa3a45d70eb  vmovaps [rsp+0xB0], xmm12
00007aa3a45d70f4  vmovaps [rsp+0xC0], xmm13
00007aa3a45d70fd  vmovaps [rsp+0xD0], xmm14
00007aa3a45d7106  vmovaps [rsp+0xE0], xmm15
00007aa3a45d710f  sub rsp, 0x30
00007aa3a45d7113  movaps [rsp], xmm4
00007aa3a45d7117  movaps [rsp+0x10], xmm9
00007aa3a45d711d  movaps [rsp+0x20], xmm8
00007aa3a45d7123  lea rdi, [rsp]
00007aa3a45d7127  mov esi, 0x00
00007aa3a45d712c  mov rax, 0x5F551B683530
00007aa3a45d7136  call rax
00007aa3a45d7138  movaps xmm4, [rsp]
00007aa3a45d713c  add rsp, 0x30
00007aa3a45d7140  vmovaps xmm0, [rsp]
00007aa3a45d7145  vmovaps xmm1, [rsp+0x10]
00007aa3a45d714b  vmovaps xmm2, [rsp+0x20]
00007aa3a45d7151  vmovaps xmm3, [rsp+0x30]
00007aa3a45d7157  vmovaps xmm5, [rsp+0x40]
00007aa3a45d715d  vmovaps xmm6, [rsp+0x50]
00007aa3a45d7163  vmovaps xmm7, [rsp+0x60]
00007aa3a45d7169  vmovaps xmm8, [rsp+0x70]
00007aa3a45d716f  vmovaps xmm9, [rsp+0x80]
00007aa3a45d7178  vmovaps xmm10, [rsp+0x90]
00007aa3a45d7181  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d718a  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d7193  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d719c  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d71a5  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d71ae  add rsp, 0xF0
00007aa3a45d71b5  pop r11
00007aa3a45d71b7  pop r10
00007aa3a45d71b9  pop r9
00007aa3a45d71bb  pop r8
00007aa3a45d71bd  pop rsi
00007aa3a45d71be  pop rdi
00007aa3a45d71bf  pop rdx
00007aa3a45d71c0  pop rcx
00007aa3a45d71c1  pop rax
00007aa3a45d71c2  add rsp, 0x08
00007aa3a45d71c6  jmp 0x00007AA3A45D5AE1
00007aa3a45d71cb  sub rsp, 0x08
00007aa3a45d71cf  push rax
00007aa3a45d71d0  push rcx
00007aa3a45d71d1  push rdx
00007aa3a45d71d2  push rdi
00007aa3a45d71d3  push rsi
00007aa3a45d71d4  push r8
00007aa3a45d71d6  push r9
00007aa3a45d71d8  push r10
00007aa3a45d71da  push r11
00007aa3a45d71dc  sub rsp, 0xF0
00007aa3a45d71e3  vmovaps [rsp], xmm0
00007aa3a45d71e8  vmovaps [rsp+0x10], xmm1
00007aa3a45d71ee  vmovaps [rsp+0x20], xmm2
00007aa3a45d71f4  vmovaps [rsp+0x30], xmm3
00007aa3a45d71fa  vmovaps [rsp+0x40], xmm4
00007aa3a45d7200  vmovaps [rsp+0x50], xmm5
00007aa3a45d7206  vmovaps [rsp+0x60], xmm6
00007aa3a45d720c  vmovaps [rsp+0x70], xmm7
00007aa3a45d7212  vmovaps [rsp+0x80], xmm8
00007aa3a45d721b  vmovaps [rsp+0x90], xmm10
00007aa3a45d7224  vmovaps [rsp+0xA0], xmm11
00007aa3a45d722d  vmovaps [rsp+0xB0], xmm12
00007aa3a45d7236  vmovaps [rsp+0xC0], xmm13
00007aa3a45d723f  vmovaps [rsp+0xD0], xmm14
00007aa3a45d7248  vmovaps [rsp+0xE0], xmm15
00007aa3a45d7251  sub rsp, 0x30
00007aa3a45d7255  movaps [rsp], xmm9
00007aa3a45d725a  movaps [rsp+0x10], xmm10
00007aa3a45d7260  movaps [rsp+0x20], xmm8
00007aa3a45d7266  lea rdi, [rsp]
00007aa3a45d726a  mov esi, 0x00
00007aa3a45d726f  mov rax, 0x5F551B683530
00007aa3a45d7279  call rax
00007aa3a45d727b  movaps xmm9, [rsp]
00007aa3a45d7280  add rsp, 0x30
00007aa3a45d7284  vmovaps xmm0, [rsp]
00007aa3a45d7289  vmovaps xmm1, [rsp+0x10]
00007aa3a45d728f  vmovaps xmm2, [rsp+0x20]
00007aa3a45d7295  vmovaps xmm3, [rsp+0x30]
00007aa3a45d729b  vmovaps xmm4, [rsp+0x40]
00007aa3a45d72a1  vmovaps xmm5, [rsp+0x50]
00007aa3a45d72a7  vmovaps xmm6, [rsp+0x60]
00007aa3a45d72ad  vmovaps xmm7, [rsp+0x70]
00007aa3a45d72b3  vmovaps xmm8, [rsp+0x80]
00007aa3a45d72bc  vmovaps xmm10, [rsp+0x90]
00007aa3a45d72c5  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d72ce  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d72d7  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d72e0  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d72e9  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d72f2  add rsp, 0xF0
00007aa3a45d72f9  pop r11
00007aa3a45d72fb  pop r10
00007aa3a45d72fd  pop r9
00007aa3a45d72ff  pop r8
00007aa3a45d7301  pop rsi
00007aa3a45d7302  pop rdi
00007aa3a45d7303  pop rdx
00007aa3a45d7304  pop rcx
00007aa3a45d7305  pop rax
00007aa3a45d7306  add rsp, 0x08
00007aa3a45d730a  jmp 0x00007AA3A45D5AFB
00007aa3a45d730f  call 0x00007AA3A44D64F0
00007aa3a45d7314  jmp 0x00007AA3A45D5C15
00007aa3a45d7319  call 0x00007AA3A44D64F0
00007aa3a45d731e  jmp 0x00007AA3A45D5C2B
00007aa3a45d7323  sub rsp, 0x08
00007aa3a45d7327  push rax
00007aa3a45d7328  push rcx
00007aa3a45d7329  push rdx
00007aa3a45d732a  push rdi
00007aa3a45d732b  push rsi
00007aa3a45d732c  push r8
00007aa3a45d732e  push r9
00007aa3a45d7330  push r10
00007aa3a45d7332  push r11
00007aa3a45d7334  sub rsp, 0xF0
00007aa3a45d733b  vmovaps [rsp], xmm0
00007aa3a45d7340  vmovaps [rsp+0x10], xmm2
00007aa3a45d7346  vmovaps [rsp+0x20], xmm3
00007aa3a45d734c  vmovaps [rsp+0x30], xmm4
00007aa3a45d7352  vmovaps [rsp+0x40], xmm5
00007aa3a45d7358  vmovaps [rsp+0x50], xmm6
00007aa3a45d735e  vmovaps [rsp+0x60], xmm7
00007aa3a45d7364  vmovaps [rsp+0x70], xmm8
00007aa3a45d736a  vmovaps [rsp+0x80], xmm9
00007aa3a45d7373  vmovaps [rsp+0x90], xmm10
00007aa3a45d737c  vmovaps [rsp+0xA0], xmm11
00007aa3a45d7385  vmovaps [rsp+0xB0], xmm12
00007aa3a45d738e  vmovaps [rsp+0xC0], xmm13
00007aa3a45d7397  vmovaps [rsp+0xD0], xmm14
00007aa3a45d73a0  vmovaps [rsp+0xE0], xmm15
00007aa3a45d73a9  sub rsp, 0x30
00007aa3a45d73ad  movaps [rsp], xmm1
00007aa3a45d73b1  movaps [rsp+0x10], xmm6
00007aa3a45d73b6  movaps [rsp+0x20], xmm15
00007aa3a45d73bc  lea rdi, [rsp]
00007aa3a45d73c0  mov esi, 0x00
00007aa3a45d73c5  mov rax, 0x5F551B683530
00007aa3a45d73cf  call rax
00007aa3a45d73d1  movaps xmm1, [rsp]
00007aa3a45d73d5  add rsp, 0x30
00007aa3a45d73d9  vmovaps xmm0, [rsp]
00007aa3a45d73de  vmovaps xmm2, [rsp+0x10]
00007aa3a45d73e4  vmovaps xmm3, [rsp+0x20]
00007aa3a45d73ea  vmovaps xmm4, [rsp+0x30]
00007aa3a45d73f0  vmovaps xmm5, [rsp+0x40]
00007aa3a45d73f6  vmovaps xmm6, [rsp+0x50]
00007aa3a45d73fc  vmovaps xmm7, [rsp+0x60]
00007aa3a45d7402  vmovaps xmm8, [rsp+0x70]
00007aa3a45d7408  vmovaps xmm9, [rsp+0x80]
00007aa3a45d7411  vmovaps xmm10, [rsp+0x90]
00007aa3a45d741a  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d7423  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d742c  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d7435  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d743e  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d7447  add rsp, 0xF0
00007aa3a45d744e  pop r11
00007aa3a45d7450  pop r10
00007aa3a45d7452  pop r9
00007aa3a45d7454  pop r8
00007aa3a45d7456  pop rsi
00007aa3a45d7457  pop rdi
00007aa3a45d7458  pop rdx
00007aa3a45d7459  pop rcx
00007aa3a45d745a  pop rax
00007aa3a45d745b  add rsp, 0x08
00007aa3a45d745f  jmp 0x00007AA3A45D5C68
00007aa3a45d7464  call 0x00007AA3A44E5820
00007aa3a45d7469  jmp 0x00007AA3A45D5C75
00007aa3a45d746e  sub rsp, 0x08
00007aa3a45d7472  push rax
00007aa3a45d7473  push rcx
00007aa3a45d7474  push rdx
00007aa3a45d7475  push rdi
00007aa3a45d7476  push rsi
00007aa3a45d7477  push r8
00007aa3a45d7479  push r9
00007aa3a45d747b  push r10
00007aa3a45d747d  push r11
00007aa3a45d747f  sub rsp, 0xF0
00007aa3a45d7486  vmovaps [rsp], xmm0
00007aa3a45d748b  vmovaps [rsp+0x10], xmm1
00007aa3a45d7491  vmovaps [rsp+0x20], xmm2
00007aa3a45d7497  vmovaps [rsp+0x30], xmm3
00007aa3a45d749d  vmovaps [rsp+0x40], xmm4
00007aa3a45d74a3  vmovaps [rsp+0x50], xmm5
00007aa3a45d74a9  vmovaps [rsp+0x60], xmm6
00007aa3a45d74af  vmovaps [rsp+0x70], xmm7
00007aa3a45d74b5  vmovaps [rsp+0x80], xmm8
00007aa3a45d74be  vmovaps [rsp+0x90], xmm9
00007aa3a45d74c7  vmovaps [rsp+0xA0], xmm10
00007aa3a45d74d0  vmovaps [rsp+0xB0], xmm11
00007aa3a45d74d9  vmovaps [rsp+0xC0], xmm12
00007aa3a45d74e2  vmovaps [rsp+0xD0], xmm13
00007aa3a45d74eb  vmovaps [rsp+0xE0], xmm15
00007aa3a45d74f4  sub rsp, 0x30
00007aa3a45d74f8  movaps [rsp], xmm14
00007aa3a45d74fd  movaps [rsp+0x10], xmm4
00007aa3a45d7502  movaps [rsp+0x20], xmm3
00007aa3a45d7507  lea rdi, [rsp]
00007aa3a45d750b  mov esi, 0x00
00007aa3a45d7510  mov rax, 0x5F551B683530
00007aa3a45d751a  call rax
00007aa3a45d751c  movaps xmm14, [rsp]
00007aa3a45d7521  add rsp, 0x30
00007aa3a45d7525  vmovaps xmm0, [rsp]
00007aa3a45d752a  vmovaps xmm1, [rsp+0x10]
00007aa3a45d7530  vmovaps xmm2, [rsp+0x20]
00007aa3a45d7536  vmovaps xmm3, [rsp+0x30]
00007aa3a45d753c  vmovaps xmm4, [rsp+0x40]
00007aa3a45d7542  vmovaps xmm5, [rsp+0x50]
00007aa3a45d7548  vmovaps xmm6, [rsp+0x60]
00007aa3a45d754e  vmovaps xmm7, [rsp+0x70]
00007aa3a45d7554  vmovaps xmm8, [rsp+0x80]
00007aa3a45d755d  vmovaps xmm9, [rsp+0x90]
00007aa3a45d7566  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d756f  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d7578  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d7581  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d758a  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d7593  add rsp, 0xF0
00007aa3a45d759a  pop r11
00007aa3a45d759c  pop r10
00007aa3a45d759e  pop r9
00007aa3a45d75a0  pop r8
00007aa3a45d75a2  pop rsi
00007aa3a45d75a3  pop rdi
00007aa3a45d75a4  pop rdx
00007aa3a45d75a5  pop rcx
00007aa3a45d75a6  pop rax
00007aa3a45d75a7  add rsp, 0x08
00007aa3a45d75ab  jmp 0x00007AA3A45D5C8F
00007aa3a45d75b0  sub rsp, 0x08
00007aa3a45d75b4  push rax
00007aa3a45d75b5  push rcx
00007aa3a45d75b6  push rdx
00007aa3a45d75b7  push rdi
00007aa3a45d75b8  push rsi
00007aa3a45d75b9  push r8
00007aa3a45d75bb  push r9
00007aa3a45d75bd  push r10
00007aa3a45d75bf  push r11
00007aa3a45d75c1  sub rsp, 0xF0
00007aa3a45d75c8  vmovaps [rsp], xmm0
00007aa3a45d75cd  vmovaps [rsp+0x10], xmm1
00007aa3a45d75d3  vmovaps [rsp+0x20], xmm2
00007aa3a45d75d9  vmovaps [rsp+0x30], xmm3
00007aa3a45d75df  vmovaps [rsp+0x40], xmm4
00007aa3a45d75e5  vmovaps [rsp+0x50], xmm5
00007aa3a45d75eb  vmovaps [rsp+0x60], xmm7
00007aa3a45d75f1  vmovaps [rsp+0x70], xmm8
00007aa3a45d75f7  vmovaps [rsp+0x80], xmm9
00007aa3a45d7600  vmovaps [rsp+0x90], xmm10
00007aa3a45d7609  vmovaps [rsp+0xA0], xmm11
00007aa3a45d7612  vmovaps [rsp+0xB0], xmm12
00007aa3a45d761b  vmovaps [rsp+0xC0], xmm13
00007aa3a45d7624  vmovaps [rsp+0xD0], xmm14
00007aa3a45d762d  vmovaps [rsp+0xE0], xmm15
00007aa3a45d7636  sub rsp, 0x30
00007aa3a45d763a  movaps [rsp], xmm6
00007aa3a45d763e  movaps [rsp+0x10], xmm9
00007aa3a45d7644  movaps [rsp+0x20], xmm7
00007aa3a45d7649  lea rdi, [rsp]
00007aa3a45d764d  mov esi, 0x00
00007aa3a45d7652  mov rax, 0x5F551B683530
00007aa3a45d765c  call rax
00007aa3a45d765e  movaps xmm6, [rsp]
00007aa3a45d7662  add rsp, 0x30
00007aa3a45d7666  vmovaps xmm0, [rsp]
00007aa3a45d766b  vmovaps xmm1, [rsp+0x10]
00007aa3a45d7671  vmovaps xmm2, [rsp+0x20]
00007aa3a45d7677  vmovaps xmm3, [rsp+0x30]
00007aa3a45d767d  vmovaps xmm4, [rsp+0x40]
00007aa3a45d7683  vmovaps xmm5, [rsp+0x50]
00007aa3a45d7689  vmovaps xmm7, [rsp+0x60]
00007aa3a45d768f  vmovaps xmm8, [rsp+0x70]
00007aa3a45d7695  vmovaps xmm9, [rsp+0x80]
00007aa3a45d769e  vmovaps xmm10, [rsp+0x90]
00007aa3a45d76a7  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d76b0  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d76b9  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d76c2  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d76cb  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d76d4  add rsp, 0xF0
00007aa3a45d76db  pop r11
00007aa3a45d76dd  pop r10
00007aa3a45d76df  pop r9
00007aa3a45d76e1  pop r8
00007aa3a45d76e3  pop rsi
00007aa3a45d76e4  pop rdi
00007aa3a45d76e5  pop rdx
00007aa3a45d76e6  pop rcx
00007aa3a45d76e7  pop rax
00007aa3a45d76e8  add rsp, 0x08
00007aa3a45d76ec  jmp 0x00007AA3A45D5CA7
00007aa3a45d76f1  sub rsp, 0x08
00007aa3a45d76f5  push rax
00007aa3a45d76f6  push rcx
00007aa3a45d76f7  push rdx
00007aa3a45d76f8  push rdi
00007aa3a45d76f9  push rsi
00007aa3a45d76fa  push r8
00007aa3a45d76fc  push r9
00007aa3a45d76fe  push r10
00007aa3a45d7700  push r11
00007aa3a45d7702  sub rsp, 0xF0
00007aa3a45d7709  vmovaps [rsp], xmm0
00007aa3a45d770e  vmovaps [rsp+0x10], xmm1
00007aa3a45d7714  vmovaps [rsp+0x20], xmm2
00007aa3a45d771a  vmovaps [rsp+0x30], xmm3
00007aa3a45d7720  vmovaps [rsp+0x40], xmm4
00007aa3a45d7726  vmovaps [rsp+0x50], xmm5
00007aa3a45d772c  vmovaps [rsp+0x60], xmm6
00007aa3a45d7732  vmovaps [rsp+0x70], xmm8
00007aa3a45d7738  vmovaps [rsp+0x80], xmm9
00007aa3a45d7741  vmovaps [rsp+0x90], xmm10
00007aa3a45d774a  vmovaps [rsp+0xA0], xmm11
00007aa3a45d7753  vmovaps [rsp+0xB0], xmm12
00007aa3a45d775c  vmovaps [rsp+0xC0], xmm13
00007aa3a45d7765  vmovaps [rsp+0xD0], xmm14
00007aa3a45d776e  vmovaps [rsp+0xE0], xmm15
00007aa3a45d7777  sub rsp, 0x30
00007aa3a45d777b  movaps [rsp], xmm7
00007aa3a45d777f  movaps [rsp+0x10], xmm4
00007aa3a45d7784  movaps [rsp+0x20], xmm9
00007aa3a45d778a  lea rdi, [rsp]
00007aa3a45d778e  mov esi, 0x00
00007aa3a45d7793  mov rax, 0x5F551B683530
00007aa3a45d779d  call rax
00007aa3a45d779f  movaps xmm7, [rsp]
00007aa3a45d77a3  add rsp, 0x30
00007aa3a45d77a7  vmovaps xmm0, [rsp]
00007aa3a45d77ac  vmovaps xmm1, [rsp+0x10]
00007aa3a45d77b2  vmovaps xmm2, [rsp+0x20]
00007aa3a45d77b8  vmovaps xmm3, [rsp+0x30]
00007aa3a45d77be  vmovaps xmm4, [rsp+0x40]
00007aa3a45d77c4  vmovaps xmm5, [rsp+0x50]
00007aa3a45d77ca  vmovaps xmm6, [rsp+0x60]
00007aa3a45d77d0  vmovaps xmm8, [rsp+0x70]
00007aa3a45d77d6  vmovaps xmm9, [rsp+0x80]
00007aa3a45d77df  vmovaps xmm10, [rsp+0x90]
00007aa3a45d77e8  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d77f1  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d77fa  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d7803  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d780c  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d7815  add rsp, 0xF0
00007aa3a45d781c  pop r11
00007aa3a45d781e  pop r10
00007aa3a45d7820  pop r9
00007aa3a45d7822  pop r8
00007aa3a45d7824  pop rsi
00007aa3a45d7825  pop rdi
00007aa3a45d7826  pop rdx
00007aa3a45d7827  pop rcx
00007aa3a45d7828  pop rax
00007aa3a45d7829  add rsp, 0x08
00007aa3a45d782d  jmp 0x00007AA3A45D5CD4
00007aa3a45d7832  sub rsp, 0x08
00007aa3a45d7836  push rax
00007aa3a45d7837  push rcx
00007aa3a45d7838  push rdx
00007aa3a45d7839  push rdi
00007aa3a45d783a  push rsi
00007aa3a45d783b  push r8
00007aa3a45d783d  push r9
00007aa3a45d783f  push r10
00007aa3a45d7841  push r11
00007aa3a45d7843  sub rsp, 0xF0
00007aa3a45d784a  vmovaps [rsp], xmm0
00007aa3a45d784f  vmovaps [rsp+0x10], xmm1
00007aa3a45d7855  vmovaps [rsp+0x20], xmm2
00007aa3a45d785b  vmovaps [rsp+0x30], xmm3
00007aa3a45d7861  vmovaps [rsp+0x40], xmm5
00007aa3a45d7867  vmovaps [rsp+0x50], xmm6
00007aa3a45d786d  vmovaps [rsp+0x60], xmm7
00007aa3a45d7873  vmovaps [rsp+0x70], xmm8
00007aa3a45d7879  vmovaps [rsp+0x80], xmm9
00007aa3a45d7882  vmovaps [rsp+0x90], xmm10
00007aa3a45d788b  vmovaps [rsp+0xA0], xmm11
00007aa3a45d7894  vmovaps [rsp+0xB0], xmm12
00007aa3a45d789d  vmovaps [rsp+0xC0], xmm13
00007aa3a45d78a6  vmovaps [rsp+0xD0], xmm14
00007aa3a45d78af  vmovaps [rsp+0xE0], xmm15
00007aa3a45d78b8  sub rsp, 0x30
00007aa3a45d78bc  movaps [rsp], xmm4
00007aa3a45d78c0  movaps [rsp+0x10], xmm15
00007aa3a45d78c6  movaps [rsp+0x20], xmm9
00007aa3a45d78cc  lea rdi, [rsp]
00007aa3a45d78d0  mov esi, 0x00
00007aa3a45d78d5  mov rax, 0x5F551B683530
00007aa3a45d78df  call rax
00007aa3a45d78e1  movaps xmm4, [rsp]
00007aa3a45d78e5  add rsp, 0x30
00007aa3a45d78e9  vmovaps xmm0, [rsp]
00007aa3a45d78ee  vmovaps xmm1, [rsp+0x10]
00007aa3a45d78f4  vmovaps xmm2, [rsp+0x20]
00007aa3a45d78fa  vmovaps xmm3, [rsp+0x30]
00007aa3a45d7900  vmovaps xmm5, [rsp+0x40]
00007aa3a45d7906  vmovaps xmm6, [rsp+0x50]
00007aa3a45d790c  vmovaps xmm7, [rsp+0x60]
00007aa3a45d7912  vmovaps xmm8, [rsp+0x70]
00007aa3a45d7918  vmovaps xmm9, [rsp+0x80]
00007aa3a45d7921  vmovaps xmm10, [rsp+0x90]
00007aa3a45d792a  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d7933  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d793c  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d7945  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d794e  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d7957  add rsp, 0xF0
00007aa3a45d795e  pop r11
00007aa3a45d7960  pop r10
00007aa3a45d7962  pop r9
00007aa3a45d7964  pop r8
00007aa3a45d7966  pop rsi
00007aa3a45d7967  pop rdi
00007aa3a45d7968  pop rdx
00007aa3a45d7969  pop rcx
00007aa3a45d796a  pop rax
00007aa3a45d796b  add rsp, 0x08
00007aa3a45d796f  jmp 0x00007AA3A45D5CF9
00007aa3a45d7974  call 0x00007AA3A44E5820
00007aa3a45d7979  jmp 0x00007AA3A45D5D06
00007aa3a45d797e  sub rsp, 0x08
00007aa3a45d7982  push rax
00007aa3a45d7983  push rcx
00007aa3a45d7984  push rdx
00007aa3a45d7985  push rdi
00007aa3a45d7986  push rsi
00007aa3a45d7987  push r8
00007aa3a45d7989  push r9
00007aa3a45d798b  push r10
00007aa3a45d798d  push r11
00007aa3a45d798f  sub rsp, 0xF0
00007aa3a45d7996  vmovaps [rsp], xmm0
00007aa3a45d799b  vmovaps [rsp+0x10], xmm1
00007aa3a45d79a1  vmovaps [rsp+0x20], xmm2
00007aa3a45d79a7  vmovaps [rsp+0x30], xmm4
00007aa3a45d79ad  vmovaps [rsp+0x40], xmm5
00007aa3a45d79b3  vmovaps [rsp+0x50], xmm6
00007aa3a45d79b9  vmovaps [rsp+0x60], xmm7
00007aa3a45d79bf  vmovaps [rsp+0x70], xmm8
00007aa3a45d79c5  vmovaps [rsp+0x80], xmm9
00007aa3a45d79ce  vmovaps [rsp+0x90], xmm10
00007aa3a45d79d7  vmovaps [rsp+0xA0], xmm11
00007aa3a45d79e0  vmovaps [rsp+0xB0], xmm12
00007aa3a45d79e9  vmovaps [rsp+0xC0], xmm13
00007aa3a45d79f2  vmovaps [rsp+0xD0], xmm14
00007aa3a45d79fb  vmovaps [rsp+0xE0], xmm15
00007aa3a45d7a04  sub rsp, 0x30
00007aa3a45d7a08  movaps [rsp], xmm3
00007aa3a45d7a0c  movaps [rsp+0x10], xmm1
00007aa3a45d7a11  movaps [rsp+0x20], xmm9
00007aa3a45d7a17  lea rdi, [rsp]
00007aa3a45d7a1b  mov esi, 0x00
00007aa3a45d7a20  mov rax, 0x5F551B683530
00007aa3a45d7a2a  call rax
00007aa3a45d7a2c  movaps xmm3, [rsp]
00007aa3a45d7a30  add rsp, 0x30
00007aa3a45d7a34  vmovaps xmm0, [rsp]
00007aa3a45d7a39  vmovaps xmm1, [rsp+0x10]
00007aa3a45d7a3f  vmovaps xmm2, [rsp+0x20]
00007aa3a45d7a45  vmovaps xmm4, [rsp+0x30]
00007aa3a45d7a4b  vmovaps xmm5, [rsp+0x40]
00007aa3a45d7a51  vmovaps xmm6, [rsp+0x50]
00007aa3a45d7a57  vmovaps xmm7, [rsp+0x60]
00007aa3a45d7a5d  vmovaps xmm8, [rsp+0x70]
00007aa3a45d7a63  vmovaps xmm9, [rsp+0x80]
00007aa3a45d7a6c  vmovaps xmm10, [rsp+0x90]
00007aa3a45d7a75  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d7a7e  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d7a87  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d7a90  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d7a99  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d7aa2  add rsp, 0xF0
00007aa3a45d7aa9  pop r11
00007aa3a45d7aab  pop r10
00007aa3a45d7aad  pop r9
00007aa3a45d7aaf  pop r8
00007aa3a45d7ab1  pop rsi
00007aa3a45d7ab2  pop rdi
00007aa3a45d7ab3  pop rdx
00007aa3a45d7ab4  pop rcx
00007aa3a45d7ab5  pop rax
00007aa3a45d7ab6  add rsp, 0x08
00007aa3a45d7aba  jmp 0x00007AA3A45D5D43
00007aa3a45d7abf  sub rsp, 0x08
00007aa3a45d7ac3  push rax
00007aa3a45d7ac4  push rcx
00007aa3a45d7ac5  push rdx
00007aa3a45d7ac6  push rdi
00007aa3a45d7ac7  push rsi
00007aa3a45d7ac8  push r8
00007aa3a45d7aca  push r9
00007aa3a45d7acc  push r10
00007aa3a45d7ace  push r11
00007aa3a45d7ad0  sub rsp, 0xF0
00007aa3a45d7ad7  vmovaps [rsp], xmm0
00007aa3a45d7adc  vmovaps [rsp+0x10], xmm2
00007aa3a45d7ae2  vmovaps [rsp+0x20], xmm3
00007aa3a45d7ae8  vmovaps [rsp+0x30], xmm4
00007aa3a45d7aee  vmovaps [rsp+0x40], xmm5
00007aa3a45d7af4  vmovaps [rsp+0x50], xmm6
00007aa3a45d7afa  vmovaps [rsp+0x60], xmm7
00007aa3a45d7b00  vmovaps [rsp+0x70], xmm8
00007aa3a45d7b06  vmovaps [rsp+0x80], xmm9
00007aa3a45d7b0f  vmovaps [rsp+0x90], xmm10
00007aa3a45d7b18  vmovaps [rsp+0xA0], xmm11
00007aa3a45d7b21  vmovaps [rsp+0xB0], xmm12
00007aa3a45d7b2a  vmovaps [rsp+0xC0], xmm13
00007aa3a45d7b33  vmovaps [rsp+0xD0], xmm14
00007aa3a45d7b3c  vmovaps [rsp+0xE0], xmm15
00007aa3a45d7b45  sub rsp, 0x30
00007aa3a45d7b49  movaps [rsp], xmm1
00007aa3a45d7b4d  movaps [rsp+0x10], xmm15
00007aa3a45d7b53  movaps [rsp+0x20], xmm9
00007aa3a45d7b59  lea rdi, [rsp]
00007aa3a45d7b5d  mov esi, 0x00
00007aa3a45d7b62  mov rax, 0x5F551B683530
00007aa3a45d7b6c  call rax
00007aa3a45d7b6e  movaps xmm1, [rsp]
00007aa3a45d7b72  add rsp, 0x30
00007aa3a45d7b76  vmovaps xmm0, [rsp]
00007aa3a45d7b7b  vmovaps xmm2, [rsp+0x10]
00007aa3a45d7b81  vmovaps xmm3, [rsp+0x20]
00007aa3a45d7b87  vmovaps xmm4, [rsp+0x30]
00007aa3a45d7b8d  vmovaps xmm5, [rsp+0x40]
00007aa3a45d7b93  vmovaps xmm6, [rsp+0x50]
00007aa3a45d7b99  vmovaps xmm7, [rsp+0x60]
00007aa3a45d7b9f  vmovaps xmm8, [rsp+0x70]
00007aa3a45d7ba5  vmovaps xmm9, [rsp+0x80]
00007aa3a45d7bae  vmovaps xmm10, [rsp+0x90]
00007aa3a45d7bb7  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d7bc0  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d7bc9  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d7bd2  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d7bdb  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d7be4  add rsp, 0xF0
00007aa3a45d7beb  pop r11
00007aa3a45d7bed  pop r10
00007aa3a45d7bef  pop r9
00007aa3a45d7bf1  pop r8
00007aa3a45d7bf3  pop rsi
00007aa3a45d7bf4  pop rdi
00007aa3a45d7bf5  pop rdx
00007aa3a45d7bf6  pop rcx
00007aa3a45d7bf7  pop rax
00007aa3a45d7bf8  add rsp, 0x08
00007aa3a45d7bfc  jmp 0x00007AA3A45D5DCB
00007aa3a45d7c01  call 0x00007AA3A44E5820
00007aa3a45d7c06  jmp 0x00007AA3A45D5DD8
00007aa3a45d7c0b  sub rsp, 0x08
00007aa3a45d7c0f  push rax
00007aa3a45d7c10  push rcx
00007aa3a45d7c11  push rdx
00007aa3a45d7c12  push rdi
00007aa3a45d7c13  push rsi
00007aa3a45d7c14  push r8
00007aa3a45d7c16  push r9
00007aa3a45d7c18  push r10
00007aa3a45d7c1a  push r11
00007aa3a45d7c1c  sub rsp, 0xF0
00007aa3a45d7c23  vmovaps [rsp], xmm0
00007aa3a45d7c28  vmovaps [rsp+0x10], xmm2
00007aa3a45d7c2e  vmovaps [rsp+0x20], xmm3
00007aa3a45d7c34  vmovaps [rsp+0x30], xmm4
00007aa3a45d7c3a  vmovaps [rsp+0x40], xmm5
00007aa3a45d7c40  vmovaps [rsp+0x50], xmm6
00007aa3a45d7c46  vmovaps [rsp+0x60], xmm7
00007aa3a45d7c4c  vmovaps [rsp+0x70], xmm8
00007aa3a45d7c52  vmovaps [rsp+0x80], xmm9
00007aa3a45d7c5b  vmovaps [rsp+0x90], xmm10
00007aa3a45d7c64  vmovaps [rsp+0xA0], xmm11
00007aa3a45d7c6d  vmovaps [rsp+0xB0], xmm12
00007aa3a45d7c76  vmovaps [rsp+0xC0], xmm13
00007aa3a45d7c7f  vmovaps [rsp+0xD0], xmm14
00007aa3a45d7c88  vmovaps [rsp+0xE0], xmm15
00007aa3a45d7c91  sub rsp, 0x30
00007aa3a45d7c95  movaps [rsp], xmm1
00007aa3a45d7c99  movaps [rsp+0x10], xmm5
00007aa3a45d7c9e  movaps [rsp+0x20], xmm7
00007aa3a45d7ca3  lea rdi, [rsp]
00007aa3a45d7ca7  mov esi, 0x00
00007aa3a45d7cac  mov rax, 0x5F551B683530
00007aa3a45d7cb6  call rax
00007aa3a45d7cb8  movaps xmm1, [rsp]
00007aa3a45d7cbc  add rsp, 0x30
00007aa3a45d7cc0  vmovaps xmm0, [rsp]
00007aa3a45d7cc5  vmovaps xmm2, [rsp+0x10]
00007aa3a45d7ccb  vmovaps xmm3, [rsp+0x20]
00007aa3a45d7cd1  vmovaps xmm4, [rsp+0x30]
00007aa3a45d7cd7  vmovaps xmm5, [rsp+0x40]
00007aa3a45d7cdd  vmovaps xmm6, [rsp+0x50]
00007aa3a45d7ce3  vmovaps xmm7, [rsp+0x60]
00007aa3a45d7ce9  vmovaps xmm8, [rsp+0x70]
00007aa3a45d7cef  vmovaps xmm9, [rsp+0x80]
00007aa3a45d7cf8  vmovaps xmm10, [rsp+0x90]
00007aa3a45d7d01  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d7d0a  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d7d13  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d7d1c  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d7d25  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d7d2e  add rsp, 0xF0
00007aa3a45d7d35  pop r11
00007aa3a45d7d37  pop r10
00007aa3a45d7d39  pop r9
00007aa3a45d7d3b  pop r8
00007aa3a45d7d3d  pop rsi
00007aa3a45d7d3e  pop rdi
00007aa3a45d7d3f  pop rdx
00007aa3a45d7d40  pop rcx
00007aa3a45d7d41  pop rax
00007aa3a45d7d42  add rsp, 0x08
00007aa3a45d7d46  jmp 0x00007AA3A45D5E7D
00007aa3a45d7d4b  sub rsp, 0x08
00007aa3a45d7d4f  push rax
00007aa3a45d7d50  push rcx
00007aa3a45d7d51  push rdx
00007aa3a45d7d52  push rdi
00007aa3a45d7d53  push rsi
00007aa3a45d7d54  push r8
00007aa3a45d7d56  push r9
00007aa3a45d7d58  push r10
00007aa3a45d7d5a  push r11
00007aa3a45d7d5c  sub rsp, 0xF0
00007aa3a45d7d63  vmovaps [rsp], xmm0
00007aa3a45d7d68  vmovaps [rsp+0x10], xmm1
00007aa3a45d7d6e  vmovaps [rsp+0x20], xmm2
00007aa3a45d7d74  vmovaps [rsp+0x30], xmm3
00007aa3a45d7d7a  vmovaps [rsp+0x40], xmm4
00007aa3a45d7d80  vmovaps [rsp+0x50], xmm5
00007aa3a45d7d86  vmovaps [rsp+0x60], xmm6
00007aa3a45d7d8c  vmovaps [rsp+0x70], xmm8
00007aa3a45d7d92  vmovaps [rsp+0x80], xmm9
00007aa3a45d7d9b  vmovaps [rsp+0x90], xmm10
00007aa3a45d7da4  vmovaps [rsp+0xA0], xmm11
00007aa3a45d7dad  vmovaps [rsp+0xB0], xmm12
00007aa3a45d7db6  vmovaps [rsp+0xC0], xmm13
00007aa3a45d7dbf  vmovaps [rsp+0xD0], xmm14
00007aa3a45d7dc8  vmovaps [rsp+0xE0], xmm15
00007aa3a45d7dd1  sub rsp, 0x30
00007aa3a45d7dd5  movaps [rsp], xmm7
00007aa3a45d7dd9  movaps [rsp+0x10], xmm5
00007aa3a45d7dde  movaps [rsp+0x20], xmm15
00007aa3a45d7de4  lea rdi, [rsp]
00007aa3a45d7de8  mov esi, 0x00
00007aa3a45d7ded  mov rax, 0x5F551B683530
00007aa3a45d7df7  call rax
00007aa3a45d7df9  movaps xmm7, [rsp]
00007aa3a45d7dfd  add rsp, 0x30
00007aa3a45d7e01  vmovaps xmm0, [rsp]
00007aa3a45d7e06  vmovaps xmm1, [rsp+0x10]
00007aa3a45d7e0c  vmovaps xmm2, [rsp+0x20]
00007aa3a45d7e12  vmovaps xmm3, [rsp+0x30]
00007aa3a45d7e18  vmovaps xmm4, [rsp+0x40]
00007aa3a45d7e1e  vmovaps xmm5, [rsp+0x50]
00007aa3a45d7e24  vmovaps xmm6, [rsp+0x60]
00007aa3a45d7e2a  vmovaps xmm8, [rsp+0x70]
00007aa3a45d7e30  vmovaps xmm9, [rsp+0x80]
00007aa3a45d7e39  vmovaps xmm10, [rsp+0x90]
00007aa3a45d7e42  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d7e4b  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d7e54  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d7e5d  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d7e66  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d7e6f  add rsp, 0xF0
00007aa3a45d7e76  pop r11
00007aa3a45d7e78  pop r10
00007aa3a45d7e7a  pop r9
00007aa3a45d7e7c  pop r8
00007aa3a45d7e7e  pop rsi
00007aa3a45d7e7f  pop rdi
00007aa3a45d7e80  pop rdx
00007aa3a45d7e81  pop rcx
00007aa3a45d7e82  pop rax
00007aa3a45d7e83  add rsp, 0x08
00007aa3a45d7e87  jmp 0x00007AA3A45D5EB3
00007aa3a45d7e8c  call 0x00007AA3A44D64F0
00007aa3a45d7e91  jmp 0x00007AA3A45D5EC0
00007aa3a45d7e96  sub rsp, 0x08
00007aa3a45d7e9a  push rax
00007aa3a45d7e9b  push rcx
00007aa3a45d7e9c  push rdx
00007aa3a45d7e9d  push rdi
00007aa3a45d7e9e  push rsi
00007aa3a45d7e9f  push r8
00007aa3a45d7ea1  push r9
00007aa3a45d7ea3  push r10
00007aa3a45d7ea5  push r11
00007aa3a45d7ea7  sub rsp, 0xF0
00007aa3a45d7eae  vmovaps [rsp], xmm0
00007aa3a45d7eb3  vmovaps [rsp+0x10], xmm1
00007aa3a45d7eb9  vmovaps [rsp+0x20], xmm2
00007aa3a45d7ebf  vmovaps [rsp+0x30], xmm3
00007aa3a45d7ec5  vmovaps [rsp+0x40], xmm4
00007aa3a45d7ecb  vmovaps [rsp+0x50], xmm5
00007aa3a45d7ed1  vmovaps [rsp+0x60], xmm6
00007aa3a45d7ed7  vmovaps [rsp+0x70], xmm7
00007aa3a45d7edd  vmovaps [rsp+0x80], xmm8
00007aa3a45d7ee6  vmovaps [rsp+0x90], xmm9
00007aa3a45d7eef  vmovaps [rsp+0xA0], xmm10
00007aa3a45d7ef8  vmovaps [rsp+0xB0], xmm11
00007aa3a45d7f01  vmovaps [rsp+0xC0], xmm12
00007aa3a45d7f0a  vmovaps [rsp+0xD0], xmm13
00007aa3a45d7f13  vmovaps [rsp+0xE0], xmm14
00007aa3a45d7f1c  sub rsp, 0x30
00007aa3a45d7f20  movaps [rsp], xmm15
00007aa3a45d7f25  movaps [rsp+0x10], xmm5
00007aa3a45d7f2a  movaps [rsp+0x20], xmm3
00007aa3a45d7f2f  lea rdi, [rsp]
00007aa3a45d7f33  mov esi, 0x00
00007aa3a45d7f38  mov rax, 0x5F551B683530
00007aa3a45d7f42  call rax
00007aa3a45d7f44  movaps xmm15, [rsp]
00007aa3a45d7f49  add rsp, 0x30
00007aa3a45d7f4d  vmovaps xmm0, [rsp]
00007aa3a45d7f52  vmovaps xmm1, [rsp+0x10]
00007aa3a45d7f58  vmovaps xmm2, [rsp+0x20]
00007aa3a45d7f5e  vmovaps xmm3, [rsp+0x30]
00007aa3a45d7f64  vmovaps xmm4, [rsp+0x40]
00007aa3a45d7f6a  vmovaps xmm5, [rsp+0x50]
00007aa3a45d7f70  vmovaps xmm6, [rsp+0x60]
00007aa3a45d7f76  vmovaps xmm7, [rsp+0x70]
00007aa3a45d7f7c  vmovaps xmm8, [rsp+0x80]
00007aa3a45d7f85  vmovaps xmm9, [rsp+0x90]
00007aa3a45d7f8e  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d7f97  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d7fa0  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d7fa9  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d7fb2  vmovaps xmm14, [rsp+0xE0]
00007aa3a45d7fbb  add rsp, 0xF0
00007aa3a45d7fc2  pop r11
00007aa3a45d7fc4  pop r10
00007aa3a45d7fc6  pop r9
00007aa3a45d7fc8  pop r8
00007aa3a45d7fca  pop rsi
00007aa3a45d7fcb  pop rdi
00007aa3a45d7fcc  pop rdx
00007aa3a45d7fcd  pop rcx
00007aa3a45d7fce  pop rax
00007aa3a45d7fcf  add rsp, 0x08
00007aa3a45d7fd3  jmp 0x00007AA3A45D5EE6
00007aa3a45d7fd8  sub rsp, 0x08
00007aa3a45d7fdc  push rax
00007aa3a45d7fdd  push rcx
00007aa3a45d7fde  push rdx
00007aa3a45d7fdf  push rdi
00007aa3a45d7fe0  push rsi
00007aa3a45d7fe1  push r8
00007aa3a45d7fe3  push r9
00007aa3a45d7fe5  push r10
00007aa3a45d7fe7  push r11
00007aa3a45d7fe9  sub rsp, 0xF0
00007aa3a45d7ff0  vmovaps [rsp], xmm0
00007aa3a45d7ff5  vmovaps [rsp+0x10], xmm2
00007aa3a45d7ffb  vmovaps [rsp+0x20], xmm3
00007aa3a45d8001  vmovaps [rsp+0x30], xmm4
00007aa3a45d8007  vmovaps [rsp+0x40], xmm5
00007aa3a45d800d  vmovaps [rsp+0x50], xmm6
00007aa3a45d8013  vmovaps [rsp+0x60], xmm7
00007aa3a45d8019  vmovaps [rsp+0x70], xmm8
00007aa3a45d801f  vmovaps [rsp+0x80], xmm9
00007aa3a45d8028  vmovaps [rsp+0x90], xmm10
00007aa3a45d8031  vmovaps [rsp+0xA0], xmm11
00007aa3a45d803a  vmovaps [rsp+0xB0], xmm12
00007aa3a45d8043  vmovaps [rsp+0xC0], xmm13
00007aa3a45d804c  vmovaps [rsp+0xD0], xmm14
00007aa3a45d8055  vmovaps [rsp+0xE0], xmm15
00007aa3a45d805e  sub rsp, 0x30
00007aa3a45d8062  movaps [rsp], xmm1
00007aa3a45d8066  movaps [rsp+0x10], xmm5
00007aa3a45d806b  movaps [rsp+0x20], xmm4
00007aa3a45d8070  lea rdi, [rsp]
00007aa3a45d8074  mov esi, 0x00
00007aa3a45d8079  mov rax, 0x5F551B683530
00007aa3a45d8083  call rax
00007aa3a45d8085  movaps xmm1, [rsp]
00007aa3a45d8089  add rsp, 0x30
00007aa3a45d808d  vmovaps xmm0, [rsp]
00007aa3a45d8092  vmovaps xmm2, [rsp+0x10]
00007aa3a45d8098  vmovaps xmm3, [rsp+0x20]
00007aa3a45d809e  vmovaps xmm4, [rsp+0x30]
00007aa3a45d80a4  vmovaps xmm5, [rsp+0x40]
00007aa3a45d80aa  vmovaps xmm6, [rsp+0x50]
00007aa3a45d80b0  vmovaps xmm7, [rsp+0x60]
00007aa3a45d80b6  vmovaps xmm8, [rsp+0x70]
00007aa3a45d80bc  vmovaps xmm9, [rsp+0x80]
00007aa3a45d80c5  vmovaps xmm10, [rsp+0x90]
00007aa3a45d80ce  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d80d7  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d80e0  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d80e9  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d80f2  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d80fb  add rsp, 0xF0
00007aa3a45d8102  pop r11
00007aa3a45d8104  pop r10
00007aa3a45d8106  pop r9
00007aa3a45d8108  pop r8
00007aa3a45d810a  pop rsi
00007aa3a45d810b  pop rdi
00007aa3a45d810c  pop rdx
00007aa3a45d810d  pop rcx
00007aa3a45d810e  pop rax
00007aa3a45d810f  add rsp, 0x08
00007aa3a45d8113  jmp 0x00007AA3A45D5F06
00007aa3a45d8118  sub rsp, 0x08
00007aa3a45d811c  push rax
00007aa3a45d811d  push rcx
00007aa3a45d811e  push rdx
00007aa3a45d811f  push rdi
00007aa3a45d8120  push rsi
00007aa3a45d8121  push r8
00007aa3a45d8123  push r9
00007aa3a45d8125  push r10
00007aa3a45d8127  push r11
00007aa3a45d8129  sub rsp, 0xF0
00007aa3a45d8130  vmovaps [rsp], xmm0
00007aa3a45d8135  vmovaps [rsp+0x10], xmm1
00007aa3a45d813b  vmovaps [rsp+0x20], xmm2
00007aa3a45d8141  vmovaps [rsp+0x30], xmm3
00007aa3a45d8147  vmovaps [rsp+0x40], xmm5
00007aa3a45d814d  vmovaps [rsp+0x50], xmm6
00007aa3a45d8153  vmovaps [rsp+0x60], xmm7
00007aa3a45d8159  vmovaps [rsp+0x70], xmm8
00007aa3a45d815f  vmovaps [rsp+0x80], xmm9
00007aa3a45d8168  vmovaps [rsp+0x90], xmm10
00007aa3a45d8171  vmovaps [rsp+0xA0], xmm11
00007aa3a45d817a  vmovaps [rsp+0xB0], xmm12
00007aa3a45d8183  vmovaps [rsp+0xC0], xmm13
00007aa3a45d818c  vmovaps [rsp+0xD0], xmm14
00007aa3a45d8195  vmovaps [rsp+0xE0], xmm15
00007aa3a45d819e  sub rsp, 0x30
00007aa3a45d81a2  movaps [rsp], xmm4
00007aa3a45d81a6  movaps [rsp+0x10], xmm3
00007aa3a45d81ab  movaps [rsp+0x20], xmm5
00007aa3a45d81b0  lea rdi, [rsp]
00007aa3a45d81b4  mov esi, 0x00
00007aa3a45d81b9  mov rax, 0x5F551B683530
00007aa3a45d81c3  call rax
00007aa3a45d81c5  movaps xmm4, [rsp]
00007aa3a45d81c9  add rsp, 0x30
00007aa3a45d81cd  vmovaps xmm0, [rsp]
00007aa3a45d81d2  vmovaps xmm1, [rsp+0x10]
00007aa3a45d81d8  vmovaps xmm2, [rsp+0x20]
00007aa3a45d81de  vmovaps xmm3, [rsp+0x30]
00007aa3a45d81e4  vmovaps xmm5, [rsp+0x40]
00007aa3a45d81ea  vmovaps xmm6, [rsp+0x50]
00007aa3a45d81f0  vmovaps xmm7, [rsp+0x60]
00007aa3a45d81f6  vmovaps xmm8, [rsp+0x70]
00007aa3a45d81fc  vmovaps xmm9, [rsp+0x80]
00007aa3a45d8205  vmovaps xmm10, [rsp+0x90]
00007aa3a45d820e  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d8217  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d8220  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d8229  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d8232  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d823b  add rsp, 0xF0
00007aa3a45d8242  pop r11
00007aa3a45d8244  pop r10
00007aa3a45d8246  pop r9
00007aa3a45d8248  pop r8
00007aa3a45d824a  pop rsi
00007aa3a45d824b  pop rdi
00007aa3a45d824c  pop rdx
00007aa3a45d824d  pop rcx
00007aa3a45d824e  pop rax
00007aa3a45d824f  add rsp, 0x08
00007aa3a45d8253  jmp 0x00007AA3A45D5F54
00007aa3a45d8258  call 0x00007AA3A44D64F0
00007aa3a45d825d  jmp 0x00007AA3A45D5F61
00007aa3a45d8262  sub rsp, 0x08
00007aa3a45d8266  push rax
00007aa3a45d8267  push rcx
00007aa3a45d8268  push rdx
00007aa3a45d8269  push rdi
00007aa3a45d826a  push rsi
00007aa3a45d826b  push r8
00007aa3a45d826d  push r9
00007aa3a45d826f  push r10
00007aa3a45d8271  push r11
00007aa3a45d8273  sub rsp, 0xF0
00007aa3a45d827a  vmovaps [rsp], xmm0
00007aa3a45d827f  vmovaps [rsp+0x10], xmm1
00007aa3a45d8285  vmovaps [rsp+0x20], xmm2
00007aa3a45d828b  vmovaps [rsp+0x30], xmm3
00007aa3a45d8291  vmovaps [rsp+0x40], xmm4
00007aa3a45d8297  vmovaps [rsp+0x50], xmm6
00007aa3a45d829d  vmovaps [rsp+0x60], xmm7
00007aa3a45d82a3  vmovaps [rsp+0x70], xmm8
00007aa3a45d82a9  vmovaps [rsp+0x80], xmm9
00007aa3a45d82b2  vmovaps [rsp+0x90], xmm10
00007aa3a45d82bb  vmovaps [rsp+0xA0], xmm11
00007aa3a45d82c4  vmovaps [rsp+0xB0], xmm12
00007aa3a45d82cd  vmovaps [rsp+0xC0], xmm13
00007aa3a45d82d6  vmovaps [rsp+0xD0], xmm14
00007aa3a45d82df  vmovaps [rsp+0xE0], xmm15
00007aa3a45d82e8  sub rsp, 0x30
00007aa3a45d82ec  movaps [rsp], xmm5
00007aa3a45d82f0  movaps [rsp+0x10], xmm6
00007aa3a45d82f5  movaps [rsp+0x20], xmm3
00007aa3a45d82fa  lea rdi, [rsp]
00007aa3a45d82fe  mov esi, 0x00
00007aa3a45d8303  mov rax, 0x5F551B683530
00007aa3a45d830d  call rax
00007aa3a45d830f  movaps xmm5, [rsp]
00007aa3a45d8313  add rsp, 0x30
00007aa3a45d8317  vmovaps xmm0, [rsp]
00007aa3a45d831c  vmovaps xmm1, [rsp+0x10]
00007aa3a45d8322  vmovaps xmm2, [rsp+0x20]
00007aa3a45d8328  vmovaps xmm3, [rsp+0x30]
00007aa3a45d832e  vmovaps xmm4, [rsp+0x40]
00007aa3a45d8334  vmovaps xmm6, [rsp+0x50]
00007aa3a45d833a  vmovaps xmm7, [rsp+0x60]
00007aa3a45d8340  vmovaps xmm8, [rsp+0x70]
00007aa3a45d8346  vmovaps xmm9, [rsp+0x80]
00007aa3a45d834f  vmovaps xmm10, [rsp+0x90]
00007aa3a45d8358  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d8361  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d836a  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d8373  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d837c  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d8385  add rsp, 0xF0
00007aa3a45d838c  pop r11
00007aa3a45d838e  pop r10
00007aa3a45d8390  pop r9
00007aa3a45d8392  pop r8
00007aa3a45d8394  pop rsi
00007aa3a45d8395  pop rdi
00007aa3a45d8396  pop rdx
00007aa3a45d8397  pop rcx
00007aa3a45d8398  pop rax
00007aa3a45d8399  add rsp, 0x08
00007aa3a45d839d  jmp 0x00007AA3A45D5F87
00007aa3a45d83a2  sub rsp, 0x08
00007aa3a45d83a6  push rax
00007aa3a45d83a7  push rcx
00007aa3a45d83a8  push rdx
00007aa3a45d83a9  push rdi
00007aa3a45d83aa  push rsi
00007aa3a45d83ab  push r8
00007aa3a45d83ad  push r9
00007aa3a45d83af  push r10
00007aa3a45d83b1  push r11
00007aa3a45d83b3  sub rsp, 0xF0
00007aa3a45d83ba  vmovaps [rsp], xmm0
00007aa3a45d83bf  vmovaps [rsp+0x10], xmm1
00007aa3a45d83c5  vmovaps [rsp+0x20], xmm2
00007aa3a45d83cb  vmovaps [rsp+0x30], xmm3
00007aa3a45d83d1  vmovaps [rsp+0x40], xmm4
00007aa3a45d83d7  vmovaps [rsp+0x50], xmm5
00007aa3a45d83dd  vmovaps [rsp+0x60], xmm7
00007aa3a45d83e3  vmovaps [rsp+0x70], xmm8
00007aa3a45d83e9  vmovaps [rsp+0x80], xmm9
00007aa3a45d83f2  vmovaps [rsp+0x90], xmm10
00007aa3a45d83fb  vmovaps [rsp+0xA0], xmm11
00007aa3a45d8404  vmovaps [rsp+0xB0], xmm12
00007aa3a45d840d  vmovaps [rsp+0xC0], xmm13
00007aa3a45d8416  vmovaps [rsp+0xD0], xmm14
00007aa3a45d841f  vmovaps [rsp+0xE0], xmm15
00007aa3a45d8428  sub rsp, 0x30
00007aa3a45d842c  movaps [rsp], xmm6
00007aa3a45d8430  movaps [rsp+0x10], xmm9
00007aa3a45d8436  movaps [rsp+0x20], xmm1
00007aa3a45d843b  lea rdi, [rsp]
00007aa3a45d843f  mov esi, 0x00
00007aa3a45d8444  mov rax, 0x5F551B683530
00007aa3a45d844e  call rax
00007aa3a45d8450  movaps xmm6, [rsp]
00007aa3a45d8454  add rsp, 0x30
00007aa3a45d8458  vmovaps xmm0, [rsp]
00007aa3a45d845d  vmovaps xmm1, [rsp+0x10]
00007aa3a45d8463  vmovaps xmm2, [rsp+0x20]
00007aa3a45d8469  vmovaps xmm3, [rsp+0x30]
00007aa3a45d846f  vmovaps xmm4, [rsp+0x40]
00007aa3a45d8475  vmovaps xmm5, [rsp+0x50]
00007aa3a45d847b  vmovaps xmm7, [rsp+0x60]
00007aa3a45d8481  vmovaps xmm8, [rsp+0x70]
00007aa3a45d8487  vmovaps xmm9, [rsp+0x80]
00007aa3a45d8490  vmovaps xmm10, [rsp+0x90]
00007aa3a45d8499  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d84a2  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d84ab  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d84b4  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d84bd  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d84c6  add rsp, 0xF0
00007aa3a45d84cd  pop r11
00007aa3a45d84cf  pop r10
00007aa3a45d84d1  pop r9
00007aa3a45d84d3  pop r8
00007aa3a45d84d5  pop rsi
00007aa3a45d84d6  pop rdi
00007aa3a45d84d7  pop rdx
00007aa3a45d84d8  pop rcx
00007aa3a45d84d9  pop rax
00007aa3a45d84da  add rsp, 0x08
00007aa3a45d84de  jmp 0x00007AA3A45D5FAB
00007aa3a45d84e3  sub rsp, 0x08
00007aa3a45d84e7  push rax
00007aa3a45d84e8  push rcx
00007aa3a45d84e9  push rdx
00007aa3a45d84ea  push rdi
00007aa3a45d84eb  push rsi
00007aa3a45d84ec  push r8
00007aa3a45d84ee  push r9
00007aa3a45d84f0  push r10
00007aa3a45d84f2  push r11
00007aa3a45d84f4  sub rsp, 0xF0
00007aa3a45d84fb  vmovaps [rsp], xmm0
00007aa3a45d8500  vmovaps [rsp+0x10], xmm1
00007aa3a45d8506  vmovaps [rsp+0x20], xmm2
00007aa3a45d850c  vmovaps [rsp+0x30], xmm3
00007aa3a45d8512  vmovaps [rsp+0x40], xmm4
00007aa3a45d8518  vmovaps [rsp+0x50], xmm5
00007aa3a45d851e  vmovaps [rsp+0x60], xmm6
00007aa3a45d8524  vmovaps [rsp+0x70], xmm7
00007aa3a45d852a  vmovaps [rsp+0x80], xmm8
00007aa3a45d8533  vmovaps [rsp+0x90], xmm10
00007aa3a45d853c  vmovaps [rsp+0xA0], xmm11
00007aa3a45d8545  vmovaps [rsp+0xB0], xmm12
00007aa3a45d854e  vmovaps [rsp+0xC0], xmm13
00007aa3a45d8557  vmovaps [rsp+0xD0], xmm14
00007aa3a45d8560  vmovaps [rsp+0xE0], xmm15
00007aa3a45d8569  sub rsp, 0x30
00007aa3a45d856d  movaps [rsp], xmm9
00007aa3a45d8572  movaps [rsp+0x10], xmm3
00007aa3a45d8577  movaps [rsp+0x20], xmm1
00007aa3a45d857c  lea rdi, [rsp]
00007aa3a45d8580  mov esi, 0x00
00007aa3a45d8585  mov rax, 0x5F551B683530
00007aa3a45d858f  call rax
00007aa3a45d8591  movaps xmm9, [rsp]
00007aa3a45d8596  add rsp, 0x30
00007aa3a45d859a  vmovaps xmm0, [rsp]
00007aa3a45d859f  vmovaps xmm1, [rsp+0x10]
00007aa3a45d85a5  vmovaps xmm2, [rsp+0x20]
00007aa3a45d85ab  vmovaps xmm3, [rsp+0x30]
00007aa3a45d85b1  vmovaps xmm4, [rsp+0x40]
00007aa3a45d85b7  vmovaps xmm5, [rsp+0x50]
00007aa3a45d85bd  vmovaps xmm6, [rsp+0x60]
00007aa3a45d85c3  vmovaps xmm7, [rsp+0x70]
00007aa3a45d85c9  vmovaps xmm8, [rsp+0x80]
00007aa3a45d85d2  vmovaps xmm10, [rsp+0x90]
00007aa3a45d85db  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d85e4  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d85ed  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d85f6  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d85ff  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d8608  add rsp, 0xF0
00007aa3a45d860f  pop r11
00007aa3a45d8611  pop r10
00007aa3a45d8613  pop r9
00007aa3a45d8615  pop r8
00007aa3a45d8617  pop rsi
00007aa3a45d8618  pop rdi
00007aa3a45d8619  pop rdx
00007aa3a45d861a  pop rcx
00007aa3a45d861b  pop rax
00007aa3a45d861c  add rsp, 0x08
00007aa3a45d8620  jmp 0x00007AA3A45D5FF7
00007aa3a45d8625  call 0x00007AA3A44D64F0
00007aa3a45d862a  jmp 0x00007AA3A45D6004
00007aa3a45d862f  sub rsp, 0x08
00007aa3a45d8633  push rax
00007aa3a45d8634  push rcx
00007aa3a45d8635  push rdx
00007aa3a45d8636  push rdi
00007aa3a45d8637  push rsi
00007aa3a45d8638  push r8
00007aa3a45d863a  push r9
00007aa3a45d863c  push r10
00007aa3a45d863e  push r11
00007aa3a45d8640  sub rsp, 0xF0
00007aa3a45d8647  vmovaps [rsp], xmm0
00007aa3a45d864c  vmovaps [rsp+0x10], xmm1
00007aa3a45d8652  vmovaps [rsp+0x20], xmm2
00007aa3a45d8658  vmovaps [rsp+0x30], xmm3
00007aa3a45d865e  vmovaps [rsp+0x40], xmm4
00007aa3a45d8664  vmovaps [rsp+0x50], xmm5
00007aa3a45d866a  vmovaps [rsp+0x60], xmm6
00007aa3a45d8670  vmovaps [rsp+0x70], xmm7
00007aa3a45d8676  vmovaps [rsp+0x80], xmm8
00007aa3a45d867f  vmovaps [rsp+0x90], xmm9
00007aa3a45d8688  vmovaps [rsp+0xA0], xmm10
00007aa3a45d8691  vmovaps [rsp+0xB0], xmm11
00007aa3a45d869a  vmovaps [rsp+0xC0], xmm12
00007aa3a45d86a3  vmovaps [rsp+0xD0], xmm13
00007aa3a45d86ac  vmovaps [rsp+0xE0], xmm14
00007aa3a45d86b5  sub rsp, 0x30
00007aa3a45d86b9  movaps [rsp], xmm15
00007aa3a45d86be  movaps [rsp+0x10], xmm3
00007aa3a45d86c3  movaps [rsp+0x20], xmm7
00007aa3a45d86c8  lea rdi, [rsp]
00007aa3a45d86cc  mov esi, 0x00
00007aa3a45d86d1  mov rax, 0x5F551B683530
00007aa3a45d86db  call rax
00007aa3a45d86dd  movaps xmm15, [rsp]
00007aa3a45d86e2  add rsp, 0x30
00007aa3a45d86e6  vmovaps xmm0, [rsp]
00007aa3a45d86eb  vmovaps xmm1, [rsp+0x10]
00007aa3a45d86f1  vmovaps xmm2, [rsp+0x20]
00007aa3a45d86f7  vmovaps xmm3, [rsp+0x30]
00007aa3a45d86fd  vmovaps xmm4, [rsp+0x40]
00007aa3a45d8703  vmovaps xmm5, [rsp+0x50]
00007aa3a45d8709  vmovaps xmm6, [rsp+0x60]
00007aa3a45d870f  vmovaps xmm7, [rsp+0x70]
00007aa3a45d8715  vmovaps xmm8, [rsp+0x80]
00007aa3a45d871e  vmovaps xmm9, [rsp+0x90]
00007aa3a45d8727  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d8730  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d8739  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d8742  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d874b  vmovaps xmm14, [rsp+0xE0]
00007aa3a45d8754  add rsp, 0xF0
00007aa3a45d875b  pop r11
00007aa3a45d875d  pop r10
00007aa3a45d875f  pop r9
00007aa3a45d8761  pop r8
00007aa3a45d8763  pop rsi
00007aa3a45d8764  pop rdi
00007aa3a45d8765  pop rdx
00007aa3a45d8766  pop rcx
00007aa3a45d8767  pop rax
00007aa3a45d8768  add rsp, 0x08
00007aa3a45d876c  jmp 0x00007AA3A45D6030
00007aa3a45d8771  sub rsp, 0x08
00007aa3a45d8775  push rax
00007aa3a45d8776  push rcx
00007aa3a45d8777  push rdx
00007aa3a45d8778  push rdi
00007aa3a45d8779  push rsi
00007aa3a45d877a  push r8
00007aa3a45d877c  push r9
00007aa3a45d877e  push r10
00007aa3a45d8780  push r11
00007aa3a45d8782  sub rsp, 0xF0
00007aa3a45d8789  vmovaps [rsp], xmm0
00007aa3a45d878e  vmovaps [rsp+0x10], xmm1
00007aa3a45d8794  vmovaps [rsp+0x20], xmm2
00007aa3a45d879a  vmovaps [rsp+0x30], xmm4
00007aa3a45d87a0  vmovaps [rsp+0x40], xmm5
00007aa3a45d87a6  vmovaps [rsp+0x50], xmm6
00007aa3a45d87ac  vmovaps [rsp+0x60], xmm7
00007aa3a45d87b2  vmovaps [rsp+0x70], xmm8
00007aa3a45d87b8  vmovaps [rsp+0x80], xmm9
00007aa3a45d87c1  vmovaps [rsp+0x90], xmm10
00007aa3a45d87ca  vmovaps [rsp+0xA0], xmm11
00007aa3a45d87d3  vmovaps [rsp+0xB0], xmm12
00007aa3a45d87dc  vmovaps [rsp+0xC0], xmm13
00007aa3a45d87e5  vmovaps [rsp+0xD0], xmm14
00007aa3a45d87ee  vmovaps [rsp+0xE0], xmm15
00007aa3a45d87f7  sub rsp, 0x30
00007aa3a45d87fb  movaps [rsp], xmm3
00007aa3a45d87ff  movaps [rsp+0x10], xmm1
00007aa3a45d8804  movaps [rsp+0x20], xmm15
00007aa3a45d880a  lea rdi, [rsp]
00007aa3a45d880e  mov esi, 0x00
00007aa3a45d8813  mov rax, 0x5F551B683530
00007aa3a45d881d  call rax
00007aa3a45d881f  movaps xmm3, [rsp]
00007aa3a45d8823  add rsp, 0x30
00007aa3a45d8827  vmovaps xmm0, [rsp]
00007aa3a45d882c  vmovaps xmm1, [rsp+0x10]
00007aa3a45d8832  vmovaps xmm2, [rsp+0x20]
00007aa3a45d8838  vmovaps xmm4, [rsp+0x30]
00007aa3a45d883e  vmovaps xmm5, [rsp+0x40]
00007aa3a45d8844  vmovaps xmm6, [rsp+0x50]
00007aa3a45d884a  vmovaps xmm7, [rsp+0x60]
00007aa3a45d8850  vmovaps xmm8, [rsp+0x70]
00007aa3a45d8856  vmovaps xmm9, [rsp+0x80]
00007aa3a45d885f  vmovaps xmm10, [rsp+0x90]
00007aa3a45d8868  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d8871  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d887a  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d8883  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d888c  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d8895  add rsp, 0xF0
00007aa3a45d889c  pop r11
00007aa3a45d889e  pop r10
00007aa3a45d88a0  pop r9
00007aa3a45d88a2  pop r8
00007aa3a45d88a4  pop rsi
00007aa3a45d88a5  pop rdi
00007aa3a45d88a6  pop rdx
00007aa3a45d88a7  pop rcx
00007aa3a45d88a8  pop rax
00007aa3a45d88a9  add rsp, 0x08
00007aa3a45d88ad  jmp 0x00007AA3A45D60BF
00007aa3a45d88b2  call 0x00007AA3A44D64F0
00007aa3a45d88b7  jmp 0x00007AA3A45D60C9
00007aa3a45d88bc  sub rsp, 0x08
00007aa3a45d88c0  push rax
00007aa3a45d88c1  push rcx
00007aa3a45d88c2  push rdx
00007aa3a45d88c3  push rdi
00007aa3a45d88c4  push rsi
00007aa3a45d88c5  push r8
00007aa3a45d88c7  push r9
00007aa3a45d88c9  push r10
00007aa3a45d88cb  push r11
00007aa3a45d88cd  sub rsp, 0xF0
00007aa3a45d88d4  vmovaps [rsp], xmm0
00007aa3a45d88d9  vmovaps [rsp+0x10], xmm1
00007aa3a45d88df  vmovaps [rsp+0x20], xmm2
00007aa3a45d88e5  vmovaps [rsp+0x30], xmm3
00007aa3a45d88eb  vmovaps [rsp+0x40], xmm4
00007aa3a45d88f1  vmovaps [rsp+0x50], xmm5
00007aa3a45d88f7  vmovaps [rsp+0x60], xmm6
00007aa3a45d88fd  vmovaps [rsp+0x70], xmm7
00007aa3a45d8903  vmovaps [rsp+0x80], xmm8
00007aa3a45d890c  vmovaps [rsp+0x90], xmm9
00007aa3a45d8915  vmovaps [rsp+0xA0], xmm10
00007aa3a45d891e  vmovaps [rsp+0xB0], xmm11
00007aa3a45d8927  vmovaps [rsp+0xC0], xmm12
00007aa3a45d8930  vmovaps [rsp+0xD0], xmm13
00007aa3a45d8939  vmovaps [rsp+0xE0], xmm14
00007aa3a45d8942  sub rsp, 0x30
00007aa3a45d8946  movaps [rsp], xmm15
00007aa3a45d894b  movaps [rsp+0x10], xmm14
00007aa3a45d8951  movaps [rsp+0x20], xmm4
00007aa3a45d8956  lea rdi, [rsp]
00007aa3a45d895a  mov esi, 0x00
00007aa3a45d895f  mov rax, 0x5F551B683530
00007aa3a45d8969  call rax
00007aa3a45d896b  movaps xmm15, [rsp]
00007aa3a45d8970  add rsp, 0x30
00007aa3a45d8974  vmovaps xmm0, [rsp]
00007aa3a45d8979  vmovaps xmm1, [rsp+0x10]
00007aa3a45d897f  vmovaps xmm2, [rsp+0x20]
00007aa3a45d8985  vmovaps xmm3, [rsp+0x30]
00007aa3a45d898b  vmovaps xmm4, [rsp+0x40]
00007aa3a45d8991  vmovaps xmm5, [rsp+0x50]
00007aa3a45d8997  vmovaps xmm6, [rsp+0x60]
00007aa3a45d899d  vmovaps xmm7, [rsp+0x70]
00007aa3a45d89a3  vmovaps xmm8, [rsp+0x80]
00007aa3a45d89ac  vmovaps xmm9, [rsp+0x90]
00007aa3a45d89b5  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d89be  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d89c7  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d89d0  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d89d9  vmovaps xmm14, [rsp+0xE0]
00007aa3a45d89e2  add rsp, 0xF0
00007aa3a45d89e9  pop r11
00007aa3a45d89eb  pop r10
00007aa3a45d89ed  pop r9
00007aa3a45d89ef  pop r8
00007aa3a45d89f1  pop rsi
00007aa3a45d89f2  pop rdi
00007aa3a45d89f3  pop rdx
00007aa3a45d89f4  pop rcx
00007aa3a45d89f5  pop rax
00007aa3a45d89f6  add rsp, 0x08
00007aa3a45d89fa  jmp 0x00007AA3A45D60F7
00007aa3a45d89ff  sub rsp, 0x08
00007aa3a45d8a03  push rax
00007aa3a45d8a04  push rcx
00007aa3a45d8a05  push rdx
00007aa3a45d8a06  push rdi
00007aa3a45d8a07  push rsi
00007aa3a45d8a08  push r8
00007aa3a45d8a0a  push r9
00007aa3a45d8a0c  push r10
00007aa3a45d8a0e  push r11
00007aa3a45d8a10  sub rsp, 0xF0
00007aa3a45d8a17  vmovaps [rsp], xmm0
00007aa3a45d8a1c  vmovaps [rsp+0x10], xmm1
00007aa3a45d8a22  vmovaps [rsp+0x20], xmm2
00007aa3a45d8a28  vmovaps [rsp+0x30], xmm3
00007aa3a45d8a2e  vmovaps [rsp+0x40], xmm4
00007aa3a45d8a34  vmovaps [rsp+0x50], xmm5
00007aa3a45d8a3a  vmovaps [rsp+0x60], xmm6
00007aa3a45d8a40  vmovaps [rsp+0x70], xmm7
00007aa3a45d8a46  vmovaps [rsp+0x80], xmm8
00007aa3a45d8a4f  vmovaps [rsp+0x90], xmm9
00007aa3a45d8a58  vmovaps [rsp+0xA0], xmm10
00007aa3a45d8a61  vmovaps [rsp+0xB0], xmm11
00007aa3a45d8a6a  vmovaps [rsp+0xC0], xmm12
00007aa3a45d8a73  vmovaps [rsp+0xD0], xmm13
00007aa3a45d8a7c  vmovaps [rsp+0xE0], xmm15
00007aa3a45d8a85  sub rsp, 0x30
00007aa3a45d8a89  movaps [rsp], xmm14
00007aa3a45d8a8e  movaps [rsp+0x10], xmm2
00007aa3a45d8a93  movaps [rsp+0x20], xmm1
00007aa3a45d8a98  lea rdi, [rsp]
00007aa3a45d8a9c  mov esi, 0x00
00007aa3a45d8aa1  mov rax, 0x5F551B683530
00007aa3a45d8aab  call rax
00007aa3a45d8aad  movaps xmm14, [rsp]
00007aa3a45d8ab2  add rsp, 0x30
00007aa3a45d8ab6  vmovaps xmm0, [rsp]
00007aa3a45d8abb  vmovaps xmm1, [rsp+0x10]
00007aa3a45d8ac1  vmovaps xmm2, [rsp+0x20]
00007aa3a45d8ac7  vmovaps xmm3, [rsp+0x30]
00007aa3a45d8acd  vmovaps xmm4, [rsp+0x40]
00007aa3a45d8ad3  vmovaps xmm5, [rsp+0x50]
00007aa3a45d8ad9  vmovaps xmm6, [rsp+0x60]
00007aa3a45d8adf  vmovaps xmm7, [rsp+0x70]
00007aa3a45d8ae5  vmovaps xmm8, [rsp+0x80]
00007aa3a45d8aee  vmovaps xmm9, [rsp+0x90]
00007aa3a45d8af7  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d8b00  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d8b09  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d8b12  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d8b1b  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d8b24  add rsp, 0xF0
00007aa3a45d8b2b  pop r11
00007aa3a45d8b2d  pop r10
00007aa3a45d8b2f  pop r9
00007aa3a45d8b31  pop r8
00007aa3a45d8b33  pop rsi
00007aa3a45d8b34  pop rdi
00007aa3a45d8b35  pop rdx
00007aa3a45d8b36  pop rcx
00007aa3a45d8b37  pop rax
00007aa3a45d8b38  add rsp, 0x08
00007aa3a45d8b3c  jmp 0x00007AA3A45D611D
00007aa3a45d8b41  sub rsp, 0x08
00007aa3a45d8b45  push rax
00007aa3a45d8b46  push rcx
00007aa3a45d8b47  push rdx
00007aa3a45d8b48  push rdi
00007aa3a45d8b49  push rsi
00007aa3a45d8b4a  push r8
00007aa3a45d8b4c  push r9
00007aa3a45d8b4e  push r10
00007aa3a45d8b50  push r11
00007aa3a45d8b52  sub rsp, 0xF0
00007aa3a45d8b59  vmovaps [rsp], xmm0
00007aa3a45d8b5e  vmovaps [rsp+0x10], xmm2
00007aa3a45d8b64  vmovaps [rsp+0x20], xmm3
00007aa3a45d8b6a  vmovaps [rsp+0x30], xmm4
00007aa3a45d8b70  vmovaps [rsp+0x40], xmm5
00007aa3a45d8b76  vmovaps [rsp+0x50], xmm6
00007aa3a45d8b7c  vmovaps [rsp+0x60], xmm7
00007aa3a45d8b82  vmovaps [rsp+0x70], xmm8
00007aa3a45d8b88  vmovaps [rsp+0x80], xmm9
00007aa3a45d8b91  vmovaps [rsp+0x90], xmm10
00007aa3a45d8b9a  vmovaps [rsp+0xA0], xmm11
00007aa3a45d8ba3  vmovaps [rsp+0xB0], xmm12
00007aa3a45d8bac  vmovaps [rsp+0xC0], xmm13
00007aa3a45d8bb5  vmovaps [rsp+0xD0], xmm14
00007aa3a45d8bbe  vmovaps [rsp+0xE0], xmm15
00007aa3a45d8bc7  sub rsp, 0x30
00007aa3a45d8bcb  movaps [rsp], xmm1
00007aa3a45d8bcf  movaps [rsp+0x10], xmm4
00007aa3a45d8bd4  movaps [rsp+0x20], xmm9
00007aa3a45d8bda  lea rdi, [rsp]
00007aa3a45d8bde  mov esi, 0x00
00007aa3a45d8be3  mov rax, 0x5F551B683530
00007aa3a45d8bed  call rax
00007aa3a45d8bef  movaps xmm1, [rsp]
00007aa3a45d8bf3  add rsp, 0x30
00007aa3a45d8bf7  vmovaps xmm0, [rsp]
00007aa3a45d8bfc  vmovaps xmm2, [rsp+0x10]
00007aa3a45d8c02  vmovaps xmm3, [rsp+0x20]
00007aa3a45d8c08  vmovaps xmm4, [rsp+0x30]
00007aa3a45d8c0e  vmovaps xmm5, [rsp+0x40]
00007aa3a45d8c14  vmovaps xmm6, [rsp+0x50]
00007aa3a45d8c1a  vmovaps xmm7, [rsp+0x60]
00007aa3a45d8c20  vmovaps xmm8, [rsp+0x70]
00007aa3a45d8c26  vmovaps xmm9, [rsp+0x80]
00007aa3a45d8c2f  vmovaps xmm10, [rsp+0x90]
00007aa3a45d8c38  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d8c41  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d8c4a  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d8c53  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d8c5c  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d8c65  add rsp, 0xF0
00007aa3a45d8c6c  pop r11
00007aa3a45d8c6e  pop r10
00007aa3a45d8c70  pop r9
00007aa3a45d8c72  pop r8
00007aa3a45d8c74  pop rsi
00007aa3a45d8c75  pop rdi
00007aa3a45d8c76  pop rdx
00007aa3a45d8c77  pop rcx
00007aa3a45d8c78  pop rax
00007aa3a45d8c79  add rsp, 0x08
00007aa3a45d8c7d  jmp 0x00007AA3A45D613B
00007aa3a45d8c82  sub rsp, 0x08
00007aa3a45d8c86  push rax
00007aa3a45d8c87  push rcx
00007aa3a45d8c88  push rdx
00007aa3a45d8c89  push rdi
00007aa3a45d8c8a  push rsi
00007aa3a45d8c8b  push r8
00007aa3a45d8c8d  push r9
00007aa3a45d8c8f  push r10
00007aa3a45d8c91  push r11
00007aa3a45d8c93  sub rsp, 0xF0
00007aa3a45d8c9a  vmovaps [rsp], xmm0
00007aa3a45d8c9f  vmovaps [rsp+0x10], xmm1
00007aa3a45d8ca5  vmovaps [rsp+0x20], xmm2
00007aa3a45d8cab  vmovaps [rsp+0x30], xmm3
00007aa3a45d8cb1  vmovaps [rsp+0x40], xmm5
00007aa3a45d8cb7  vmovaps [rsp+0x50], xmm6
00007aa3a45d8cbd  vmovaps [rsp+0x60], xmm7
00007aa3a45d8cc3  vmovaps [rsp+0x70], xmm8
00007aa3a45d8cc9  vmovaps [rsp+0x80], xmm9
00007aa3a45d8cd2  vmovaps [rsp+0x90], xmm10
00007aa3a45d8cdb  vmovaps [rsp+0xA0], xmm11
00007aa3a45d8ce4  vmovaps [rsp+0xB0], xmm12
00007aa3a45d8ced  vmovaps [rsp+0xC0], xmm13
00007aa3a45d8cf6  vmovaps [rsp+0xD0], xmm14
00007aa3a45d8cff  vmovaps [rsp+0xE0], xmm15
00007aa3a45d8d08  sub rsp, 0x30
00007aa3a45d8d0c  movaps [rsp], xmm4
00007aa3a45d8d10  movaps [rsp+0x10], xmm2
00007aa3a45d8d15  movaps [rsp+0x20], xmm9
00007aa3a45d8d1b  lea rdi, [rsp]
00007aa3a45d8d1f  mov esi, 0x00
00007aa3a45d8d24  mov rax, 0x5F551B683530
00007aa3a45d8d2e  call rax
00007aa3a45d8d30  movaps xmm4, [rsp]
00007aa3a45d8d34  add rsp, 0x30
00007aa3a45d8d38  vmovaps xmm0, [rsp]
00007aa3a45d8d3d  vmovaps xmm1, [rsp+0x10]
00007aa3a45d8d43  vmovaps xmm2, [rsp+0x20]
00007aa3a45d8d49  vmovaps xmm3, [rsp+0x30]
00007aa3a45d8d4f  vmovaps xmm5, [rsp+0x40]
00007aa3a45d8d55  vmovaps xmm6, [rsp+0x50]
00007aa3a45d8d5b  vmovaps xmm7, [rsp+0x60]
00007aa3a45d8d61  vmovaps xmm8, [rsp+0x70]
00007aa3a45d8d67  vmovaps xmm9, [rsp+0x80]
00007aa3a45d8d70  vmovaps xmm10, [rsp+0x90]
00007aa3a45d8d79  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d8d82  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d8d8b  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d8d94  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d8d9d  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d8da6  add rsp, 0xF0
00007aa3a45d8dad  pop r11
00007aa3a45d8daf  pop r10
00007aa3a45d8db1  pop r9
00007aa3a45d8db3  pop r8
00007aa3a45d8db5  pop rsi
00007aa3a45d8db6  pop rdi
00007aa3a45d8db7  pop rdx
00007aa3a45d8db8  pop rcx
00007aa3a45d8db9  pop rax
00007aa3a45d8dba  add rsp, 0x08
00007aa3a45d8dbe  jmp 0x00007AA3A45D616B
00007aa3a45d8dc3  sub rsp, 0x08
00007aa3a45d8dc7  push rax
00007aa3a45d8dc8  push rcx
00007aa3a45d8dc9  push rdx
00007aa3a45d8dca  push rdi
00007aa3a45d8dcb  push rsi
00007aa3a45d8dcc  push r8
00007aa3a45d8dce  push r9
00007aa3a45d8dd0  push r10
00007aa3a45d8dd2  push r11
00007aa3a45d8dd4  sub rsp, 0xF0
00007aa3a45d8ddb  vmovaps [rsp], xmm0
00007aa3a45d8de0  vmovaps [rsp+0x10], xmm1
00007aa3a45d8de6  vmovaps [rsp+0x20], xmm2
00007aa3a45d8dec  vmovaps [rsp+0x30], xmm3
00007aa3a45d8df2  vmovaps [rsp+0x40], xmm4
00007aa3a45d8df8  vmovaps [rsp+0x50], xmm5
00007aa3a45d8dfe  vmovaps [rsp+0x60], xmm6
00007aa3a45d8e04  vmovaps [rsp+0x70], xmm7
00007aa3a45d8e0a  vmovaps [rsp+0x80], xmm8
00007aa3a45d8e13  vmovaps [rsp+0x90], xmm10
00007aa3a45d8e1c  vmovaps [rsp+0xA0], xmm11
00007aa3a45d8e25  vmovaps [rsp+0xB0], xmm12
00007aa3a45d8e2e  vmovaps [rsp+0xC0], xmm13
00007aa3a45d8e37  vmovaps [rsp+0xD0], xmm14
00007aa3a45d8e40  vmovaps [rsp+0xE0], xmm15
00007aa3a45d8e49  sub rsp, 0x30
00007aa3a45d8e4d  movaps [rsp], xmm9
00007aa3a45d8e52  movaps [rsp+0x10], xmm2
00007aa3a45d8e57  movaps [rsp+0x20], xmm1
00007aa3a45d8e5c  lea rdi, [rsp]
00007aa3a45d8e60  mov esi, 0x00
00007aa3a45d8e65  mov rax, 0x5F551B683530
00007aa3a45d8e6f  call rax
00007aa3a45d8e71  movaps xmm9, [rsp]
00007aa3a45d8e76  add rsp, 0x30
00007aa3a45d8e7a  vmovaps xmm0, [rsp]
00007aa3a45d8e7f  vmovaps xmm1, [rsp+0x10]
00007aa3a45d8e85  vmovaps xmm2, [rsp+0x20]
00007aa3a45d8e8b  vmovaps xmm3, [rsp+0x30]
00007aa3a45d8e91  vmovaps xmm4, [rsp+0x40]
00007aa3a45d8e97  vmovaps xmm5, [rsp+0x50]
00007aa3a45d8e9d  vmovaps xmm6, [rsp+0x60]
00007aa3a45d8ea3  vmovaps xmm7, [rsp+0x70]
00007aa3a45d8ea9  vmovaps xmm8, [rsp+0x80]
00007aa3a45d8eb2  vmovaps xmm10, [rsp+0x90]
00007aa3a45d8ebb  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d8ec4  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d8ecd  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d8ed6  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d8edf  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d8ee8  add rsp, 0xF0
00007aa3a45d8eef  pop r11
00007aa3a45d8ef1  pop r10
00007aa3a45d8ef3  pop r9
00007aa3a45d8ef5  pop r8
00007aa3a45d8ef7  pop rsi
00007aa3a45d8ef8  pop rdi
00007aa3a45d8ef9  pop rdx
00007aa3a45d8efa  pop rcx
00007aa3a45d8efb  pop rax
00007aa3a45d8efc  add rsp, 0x08
00007aa3a45d8f00  jmp 0x00007AA3A45D61A1
00007aa3a45d8f05  sub rsp, 0x08
00007aa3a45d8f09  push rax
00007aa3a45d8f0a  push rcx
00007aa3a45d8f0b  push rdx
00007aa3a45d8f0c  push rdi
00007aa3a45d8f0d  push rsi
00007aa3a45d8f0e  push r8
00007aa3a45d8f10  push r9
00007aa3a45d8f12  push r10
00007aa3a45d8f14  push r11
00007aa3a45d8f16  sub rsp, 0xF0
00007aa3a45d8f1d  vmovaps [rsp], xmm0
00007aa3a45d8f22  vmovaps [rsp+0x10], xmm2
00007aa3a45d8f28  vmovaps [rsp+0x20], xmm3
00007aa3a45d8f2e  vmovaps [rsp+0x30], xmm4
00007aa3a45d8f34  vmovaps [rsp+0x40], xmm5
00007aa3a45d8f3a  vmovaps [rsp+0x50], xmm6
00007aa3a45d8f40  vmovaps [rsp+0x60], xmm7
00007aa3a45d8f46  vmovaps [rsp+0x70], xmm8
00007aa3a45d8f4c  vmovaps [rsp+0x80], xmm9
00007aa3a45d8f55  vmovaps [rsp+0x90], xmm10
00007aa3a45d8f5e  vmovaps [rsp+0xA0], xmm11
00007aa3a45d8f67  vmovaps [rsp+0xB0], xmm12
00007aa3a45d8f70  vmovaps [rsp+0xC0], xmm13
00007aa3a45d8f79  vmovaps [rsp+0xD0], xmm14
00007aa3a45d8f82  vmovaps [rsp+0xE0], xmm15
00007aa3a45d8f8b  sub rsp, 0x30
00007aa3a45d8f8f  movaps [rsp], xmm1
00007aa3a45d8f93  movaps [rsp+0x10], xmm15
00007aa3a45d8f99  movaps [rsp+0x20], xmm6
00007aa3a45d8f9e  lea rdi, [rsp]
00007aa3a45d8fa2  mov esi, 0x00
00007aa3a45d8fa7  mov rax, 0x5F551B683530
00007aa3a45d8fb1  call rax
00007aa3a45d8fb3  movaps xmm1, [rsp]
00007aa3a45d8fb7  add rsp, 0x30
00007aa3a45d8fbb  vmovaps xmm0, [rsp]
00007aa3a45d8fc0  vmovaps xmm2, [rsp+0x10]
00007aa3a45d8fc6  vmovaps xmm3, [rsp+0x20]
00007aa3a45d8fcc  vmovaps xmm4, [rsp+0x30]
00007aa3a45d8fd2  vmovaps xmm5, [rsp+0x40]
00007aa3a45d8fd8  vmovaps xmm6, [rsp+0x50]
00007aa3a45d8fde  vmovaps xmm7, [rsp+0x60]
00007aa3a45d8fe4  vmovaps xmm8, [rsp+0x70]
00007aa3a45d8fea  vmovaps xmm9, [rsp+0x80]
00007aa3a45d8ff3  vmovaps xmm10, [rsp+0x90]
00007aa3a45d8ffc  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d9005  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d900e  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d9017  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d9020  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d9029  add rsp, 0xF0
00007aa3a45d9030  pop r11
00007aa3a45d9032  pop r10
00007aa3a45d9034  pop r9
00007aa3a45d9036  pop r8
00007aa3a45d9038  pop rsi
00007aa3a45d9039  pop rdi
00007aa3a45d903a  pop rdx
00007aa3a45d903b  pop rcx
00007aa3a45d903c  pop rax
00007aa3a45d903d  add rsp, 0x08
00007aa3a45d9041  jmp 0x00007AA3A45D61C2
00007aa3a45d9046  sub rsp, 0x08
00007aa3a45d904a  push rax
00007aa3a45d904b  push rcx
00007aa3a45d904c  push rdx
00007aa3a45d904d  push rdi
00007aa3a45d904e  push rsi
00007aa3a45d904f  push r8
00007aa3a45d9051  push r9
00007aa3a45d9053  push r10
00007aa3a45d9055  push r11
00007aa3a45d9057  sub rsp, 0xF0
00007aa3a45d905e  vmovaps [rsp], xmm0
00007aa3a45d9063  vmovaps [rsp+0x10], xmm1
00007aa3a45d9069  vmovaps [rsp+0x20], xmm2
00007aa3a45d906f  vmovaps [rsp+0x30], xmm3
00007aa3a45d9075  vmovaps [rsp+0x40], xmm4
00007aa3a45d907b  vmovaps [rsp+0x50], xmm5
00007aa3a45d9081  vmovaps [rsp+0x60], xmm6
00007aa3a45d9087  vmovaps [rsp+0x70], xmm7
00007aa3a45d908d  vmovaps [rsp+0x80], xmm8
00007aa3a45d9096  vmovaps [rsp+0x90], xmm9
00007aa3a45d909f  vmovaps [rsp+0xA0], xmm10
00007aa3a45d90a8  vmovaps [rsp+0xB0], xmm11
00007aa3a45d90b1  vmovaps [rsp+0xC0], xmm12
00007aa3a45d90ba  vmovaps [rsp+0xD0], xmm13
00007aa3a45d90c3  vmovaps [rsp+0xE0], xmm14
00007aa3a45d90cc  sub rsp, 0x30
00007aa3a45d90d0  movaps [rsp], xmm15
00007aa3a45d90d5  movaps [rsp+0x10], xmm5
00007aa3a45d90da  movaps [rsp+0x20], xmm3
00007aa3a45d90df  lea rdi, [rsp]
00007aa3a45d90e3  mov esi, 0x00
00007aa3a45d90e8  mov rax, 0x5F551B683530
00007aa3a45d90f2  call rax
00007aa3a45d90f4  movaps xmm15, [rsp]
00007aa3a45d90f9  add rsp, 0x30
00007aa3a45d90fd  vmovaps xmm0, [rsp]
00007aa3a45d9102  vmovaps xmm1, [rsp+0x10]
00007aa3a45d9108  vmovaps xmm2, [rsp+0x20]
00007aa3a45d910e  vmovaps xmm3, [rsp+0x30]
00007aa3a45d9114  vmovaps xmm4, [rsp+0x40]
00007aa3a45d911a  vmovaps xmm5, [rsp+0x50]
00007aa3a45d9120  vmovaps xmm6, [rsp+0x60]
00007aa3a45d9126  vmovaps xmm7, [rsp+0x70]
00007aa3a45d912c  vmovaps xmm8, [rsp+0x80]
00007aa3a45d9135  vmovaps xmm9, [rsp+0x90]
00007aa3a45d913e  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d9147  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d9150  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d9159  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d9162  vmovaps xmm14, [rsp+0xE0]
00007aa3a45d916b  add rsp, 0xF0
00007aa3a45d9172  pop r11
00007aa3a45d9174  pop r10
00007aa3a45d9176  pop r9
00007aa3a45d9178  pop r8
00007aa3a45d917a  pop rsi
00007aa3a45d917b  pop rdi
00007aa3a45d917c  pop rdx
00007aa3a45d917d  pop rcx
00007aa3a45d917e  pop rax
00007aa3a45d917f  add rsp, 0x08
00007aa3a45d9183  jmp 0x00007AA3A45D61DC
00007aa3a45d9188  sub rsp, 0x08
00007aa3a45d918c  push rax
00007aa3a45d918d  push rcx
00007aa3a45d918e  push rdx
00007aa3a45d918f  push rdi
00007aa3a45d9190  push rsi
00007aa3a45d9191  push r8
00007aa3a45d9193  push r9
00007aa3a45d9195  push r10
00007aa3a45d9197  push r11
00007aa3a45d9199  sub rsp, 0xF0
00007aa3a45d91a0  vmovaps [rsp], xmm0
00007aa3a45d91a5  vmovaps [rsp+0x10], xmm1
00007aa3a45d91ab  vmovaps [rsp+0x20], xmm2
00007aa3a45d91b1  vmovaps [rsp+0x30], xmm3
00007aa3a45d91b7  vmovaps [rsp+0x40], xmm4
00007aa3a45d91bd  vmovaps [rsp+0x50], xmm6
00007aa3a45d91c3  vmovaps [rsp+0x60], xmm7
00007aa3a45d91c9  vmovaps [rsp+0x70], xmm8
00007aa3a45d91cf  vmovaps [rsp+0x80], xmm9
00007aa3a45d91d8  vmovaps [rsp+0x90], xmm10
00007aa3a45d91e1  vmovaps [rsp+0xA0], xmm11
00007aa3a45d91ea  vmovaps [rsp+0xB0], xmm12
00007aa3a45d91f3  vmovaps [rsp+0xC0], xmm13
00007aa3a45d91fc  vmovaps [rsp+0xD0], xmm14
00007aa3a45d9205  vmovaps [rsp+0xE0], xmm15
00007aa3a45d920e  sub rsp, 0x30
00007aa3a45d9212  movaps [rsp], xmm5
00007aa3a45d9216  movaps [rsp+0x10], xmm8
00007aa3a45d921c  movaps [rsp+0x20], xmm6
00007aa3a45d9221  lea rdi, [rsp]
00007aa3a45d9225  mov esi, 0x00
00007aa3a45d922a  mov rax, 0x5F551B683530
00007aa3a45d9234  call rax
00007aa3a45d9236  movaps xmm5, [rsp]
00007aa3a45d923a  add rsp, 0x30
00007aa3a45d923e  vmovaps xmm0, [rsp]
00007aa3a45d9243  vmovaps xmm1, [rsp+0x10]
00007aa3a45d9249  vmovaps xmm2, [rsp+0x20]
00007aa3a45d924f  vmovaps xmm3, [rsp+0x30]
00007aa3a45d9255  vmovaps xmm4, [rsp+0x40]
00007aa3a45d925b  vmovaps xmm6, [rsp+0x50]
00007aa3a45d9261  vmovaps xmm7, [rsp+0x60]
00007aa3a45d9267  vmovaps xmm8, [rsp+0x70]
00007aa3a45d926d  vmovaps xmm9, [rsp+0x80]
00007aa3a45d9276  vmovaps xmm10, [rsp+0x90]
00007aa3a45d927f  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d9288  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d9291  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d929a  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d92a3  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d92ac  add rsp, 0xF0
00007aa3a45d92b3  pop r11
00007aa3a45d92b5  pop r10
00007aa3a45d92b7  pop r9
00007aa3a45d92b9  pop r8
00007aa3a45d92bb  pop rsi
00007aa3a45d92bc  pop rdi
00007aa3a45d92bd  pop rdx
00007aa3a45d92be  pop rcx
00007aa3a45d92bf  pop rax
00007aa3a45d92c0  add rsp, 0x08
00007aa3a45d92c4  jmp 0x00007AA3A45D6200
00007aa3a45d92c9  sub rsp, 0x08
00007aa3a45d92cd  push rax
00007aa3a45d92ce  push rcx
00007aa3a45d92cf  push rdx
00007aa3a45d92d0  push rdi
00007aa3a45d92d1  push rsi
00007aa3a45d92d2  push r8
00007aa3a45d92d4  push r9
00007aa3a45d92d6  push r10
00007aa3a45d92d8  push r11
00007aa3a45d92da  sub rsp, 0xF0
00007aa3a45d92e1  vmovaps [rsp], xmm0
00007aa3a45d92e6  vmovaps [rsp+0x10], xmm1
00007aa3a45d92ec  vmovaps [rsp+0x20], xmm2
00007aa3a45d92f2  vmovaps [rsp+0x30], xmm3
00007aa3a45d92f8  vmovaps [rsp+0x40], xmm4
00007aa3a45d92fe  vmovaps [rsp+0x50], xmm5
00007aa3a45d9304  vmovaps [rsp+0x60], xmm7
00007aa3a45d930a  vmovaps [rsp+0x70], xmm8
00007aa3a45d9310  vmovaps [rsp+0x80], xmm9
00007aa3a45d9319  vmovaps [rsp+0x90], xmm10
00007aa3a45d9322  vmovaps [rsp+0xA0], xmm11
00007aa3a45d932b  vmovaps [rsp+0xB0], xmm12
00007aa3a45d9334  vmovaps [rsp+0xC0], xmm13
00007aa3a45d933d  vmovaps [rsp+0xD0], xmm14
00007aa3a45d9346  vmovaps [rsp+0xE0], xmm15
00007aa3a45d934f  sub rsp, 0x30
00007aa3a45d9353  movaps [rsp], xmm6
00007aa3a45d9357  movaps [rsp+0x10], xmm10
00007aa3a45d935d  movaps [rsp+0x20], xmm8
00007aa3a45d9363  lea rdi, [rsp]
00007aa3a45d9367  mov esi, 0x00
00007aa3a45d936c  mov rax, 0x5F551B683530
00007aa3a45d9376  call rax
00007aa3a45d9378  movaps xmm6, [rsp]
00007aa3a45d937c  add rsp, 0x30
00007aa3a45d9380  vmovaps xmm0, [rsp]
00007aa3a45d9385  vmovaps xmm1, [rsp+0x10]
00007aa3a45d938b  vmovaps xmm2, [rsp+0x20]
00007aa3a45d9391  vmovaps xmm3, [rsp+0x30]
00007aa3a45d9397  vmovaps xmm4, [rsp+0x40]
00007aa3a45d939d  vmovaps xmm5, [rsp+0x50]
00007aa3a45d93a3  vmovaps xmm7, [rsp+0x60]
00007aa3a45d93a9  vmovaps xmm8, [rsp+0x70]
00007aa3a45d93af  vmovaps xmm9, [rsp+0x80]
00007aa3a45d93b8  vmovaps xmm10, [rsp+0x90]
00007aa3a45d93c1  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d93ca  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d93d3  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d93dc  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d93e5  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d93ee  add rsp, 0xF0
00007aa3a45d93f5  pop r11
00007aa3a45d93f7  pop r10
00007aa3a45d93f9  pop r9
00007aa3a45d93fb  pop r8
00007aa3a45d93fd  pop rsi
00007aa3a45d93fe  pop rdi
00007aa3a45d93ff  pop rdx
00007aa3a45d9400  pop rcx
00007aa3a45d9401  pop rax
00007aa3a45d9402  add rsp, 0x08
00007aa3a45d9406  jmp 0x00007AA3A45D6225
00007aa3a45d940b  sub rsp, 0x08
00007aa3a45d940f  push rax
00007aa3a45d9410  push rcx
00007aa3a45d9411  push rdx
00007aa3a45d9412  push rdi
00007aa3a45d9413  push rsi
00007aa3a45d9414  push r8
00007aa3a45d9416  push r9
00007aa3a45d9418  push r10
00007aa3a45d941a  push r11
00007aa3a45d941c  sub rsp, 0xF0
00007aa3a45d9423  vmovaps [rsp], xmm0
00007aa3a45d9428  vmovaps [rsp+0x10], xmm1
00007aa3a45d942e  vmovaps [rsp+0x20], xmm2
00007aa3a45d9434  vmovaps [rsp+0x30], xmm3
00007aa3a45d943a  vmovaps [rsp+0x40], xmm4
00007aa3a45d9440  vmovaps [rsp+0x50], xmm5
00007aa3a45d9446  vmovaps [rsp+0x60], xmm6
00007aa3a45d944c  vmovaps [rsp+0x70], xmm7
00007aa3a45d9452  vmovaps [rsp+0x80], xmm8
00007aa3a45d945b  vmovaps [rsp+0x90], xmm9
00007aa3a45d9464  vmovaps [rsp+0xA0], xmm11
00007aa3a45d946d  vmovaps [rsp+0xB0], xmm12
00007aa3a45d9476  vmovaps [rsp+0xC0], xmm13
00007aa3a45d947f  vmovaps [rsp+0xD0], xmm14
00007aa3a45d9488  vmovaps [rsp+0xE0], xmm15
00007aa3a45d9491  sub rsp, 0x30
00007aa3a45d9495  movaps [rsp], xmm10
00007aa3a45d949a  movaps [rsp+0x10], xmm8
00007aa3a45d94a0  movaps [rsp+0x20], xmm14
00007aa3a45d94a6  lea rdi, [rsp]
00007aa3a45d94aa  mov esi, 0x00
00007aa3a45d94af  mov rax, 0x5F551B683530
00007aa3a45d94b9  call rax
00007aa3a45d94bb  movaps xmm10, [rsp]
00007aa3a45d94c0  add rsp, 0x30
00007aa3a45d94c4  vmovaps xmm0, [rsp]
00007aa3a45d94c9  vmovaps xmm1, [rsp+0x10]
00007aa3a45d94cf  vmovaps xmm2, [rsp+0x20]
00007aa3a45d94d5  vmovaps xmm3, [rsp+0x30]
00007aa3a45d94db  vmovaps xmm4, [rsp+0x40]
00007aa3a45d94e1  vmovaps xmm5, [rsp+0x50]
00007aa3a45d94e7  vmovaps xmm6, [rsp+0x60]
00007aa3a45d94ed  vmovaps xmm7, [rsp+0x70]
00007aa3a45d94f3  vmovaps xmm8, [rsp+0x80]
00007aa3a45d94fc  vmovaps xmm9, [rsp+0x90]
00007aa3a45d9505  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d950e  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d9517  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d9520  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d9529  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d9532  add rsp, 0xF0
00007aa3a45d9539  pop r11
00007aa3a45d953b  pop r10
00007aa3a45d953d  pop r9
00007aa3a45d953f  pop r8
00007aa3a45d9541  pop rsi
00007aa3a45d9542  pop rdi
00007aa3a45d9543  pop rdx
00007aa3a45d9544  pop rcx
00007aa3a45d9545  pop rax
00007aa3a45d9546  add rsp, 0x08
00007aa3a45d954a  jmp 0x00007AA3A45D6245
00007aa3a45d954f  sub rsp, 0x08
00007aa3a45d9553  push rax
00007aa3a45d9554  push rcx
00007aa3a45d9555  push rdx
00007aa3a45d9556  push rdi
00007aa3a45d9557  push rsi
00007aa3a45d9558  push r8
00007aa3a45d955a  push r9
00007aa3a45d955c  push r10
00007aa3a45d955e  push r11
00007aa3a45d9560  sub rsp, 0xF0
00007aa3a45d9567  vmovaps [rsp], xmm0
00007aa3a45d956c  vmovaps [rsp+0x10], xmm1
00007aa3a45d9572  vmovaps [rsp+0x20], xmm2
00007aa3a45d9578  vmovaps [rsp+0x30], xmm3
00007aa3a45d957e  vmovaps [rsp+0x40], xmm4
00007aa3a45d9584  vmovaps [rsp+0x50], xmm5
00007aa3a45d958a  vmovaps [rsp+0x60], xmm6
00007aa3a45d9590  vmovaps [rsp+0x70], xmm7
00007aa3a45d9596  vmovaps [rsp+0x80], xmm8
00007aa3a45d959f  vmovaps [rsp+0x90], xmm9
00007aa3a45d95a8  vmovaps [rsp+0xA0], xmm10
00007aa3a45d95b1  vmovaps [rsp+0xB0], xmm11
00007aa3a45d95ba  vmovaps [rsp+0xC0], xmm12
00007aa3a45d95c3  vmovaps [rsp+0xD0], xmm13
00007aa3a45d95cc  vmovaps [rsp+0xE0], xmm15
00007aa3a45d95d5  sub rsp, 0x30
00007aa3a45d95d9  movaps [rsp], xmm14
00007aa3a45d95de  movaps [rsp+0x10], xmm8
00007aa3a45d95e4  movaps [rsp+0x20], xmm4
00007aa3a45d95e9  lea rdi, [rsp]
00007aa3a45d95ed  mov esi, 0x00
00007aa3a45d95f2  mov rax, 0x5F551B683530
00007aa3a45d95fc  call rax
00007aa3a45d95fe  movaps xmm14, [rsp]
00007aa3a45d9603  add rsp, 0x30
00007aa3a45d9607  vmovaps xmm0, [rsp]
00007aa3a45d960c  vmovaps xmm1, [rsp+0x10]
00007aa3a45d9612  vmovaps xmm2, [rsp+0x20]
00007aa3a45d9618  vmovaps xmm3, [rsp+0x30]
00007aa3a45d961e  vmovaps xmm4, [rsp+0x40]
00007aa3a45d9624  vmovaps xmm5, [rsp+0x50]
00007aa3a45d962a  vmovaps xmm6, [rsp+0x60]
00007aa3a45d9630  vmovaps xmm7, [rsp+0x70]
00007aa3a45d9636  vmovaps xmm8, [rsp+0x80]
00007aa3a45d963f  vmovaps xmm9, [rsp+0x90]
00007aa3a45d9648  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d9651  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d965a  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d9663  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d966c  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d9675  add rsp, 0xF0
00007aa3a45d967c  pop r11
00007aa3a45d967e  pop r10
00007aa3a45d9680  pop r9
00007aa3a45d9682  pop r8
00007aa3a45d9684  pop rsi
00007aa3a45d9685  pop rdi
00007aa3a45d9686  pop rdx
00007aa3a45d9687  pop rcx
00007aa3a45d9688  pop rax
00007aa3a45d9689  add rsp, 0x08
00007aa3a45d968d  jmp 0x00007AA3A45D6265
00007aa3a45d9692  sub rsp, 0x08
00007aa3a45d9696  push rax
00007aa3a45d9697  push rcx
00007aa3a45d9698  push rdx
00007aa3a45d9699  push rdi
00007aa3a45d969a  push rsi
00007aa3a45d969b  push r8
00007aa3a45d969d  push r9
00007aa3a45d969f  push r10
00007aa3a45d96a1  push r11
00007aa3a45d96a3  sub rsp, 0xF0
00007aa3a45d96aa  vmovaps [rsp], xmm0
00007aa3a45d96af  vmovaps [rsp+0x10], xmm1
00007aa3a45d96b5  vmovaps [rsp+0x20], xmm2
00007aa3a45d96bb  vmovaps [rsp+0x30], xmm3
00007aa3a45d96c1  vmovaps [rsp+0x40], xmm5
00007aa3a45d96c7  vmovaps [rsp+0x50], xmm6
00007aa3a45d96cd  vmovaps [rsp+0x60], xmm7
00007aa3a45d96d3  vmovaps [rsp+0x70], xmm8
00007aa3a45d96d9  vmovaps [rsp+0x80], xmm9
00007aa3a45d96e2  vmovaps [rsp+0x90], xmm10
00007aa3a45d96eb  vmovaps [rsp+0xA0], xmm11
00007aa3a45d96f4  vmovaps [rsp+0xB0], xmm12
00007aa3a45d96fd  vmovaps [rsp+0xC0], xmm13
00007aa3a45d9706  vmovaps [rsp+0xD0], xmm14
00007aa3a45d970f  vmovaps [rsp+0xE0], xmm15
00007aa3a45d9718  sub rsp, 0x30
00007aa3a45d971c  movaps [rsp], xmm4
00007aa3a45d9720  movaps [rsp+0x10], xmm13
00007aa3a45d9726  movaps [rsp+0x20], xmm8
00007aa3a45d972c  lea rdi, [rsp]
00007aa3a45d9730  mov esi, 0x00
00007aa3a45d9735  mov rax, 0x5F551B683530
00007aa3a45d973f  call rax
00007aa3a45d9741  movaps xmm4, [rsp]
00007aa3a45d9745  add rsp, 0x30
00007aa3a45d9749  vmovaps xmm0, [rsp]
00007aa3a45d974e  vmovaps xmm1, [rsp+0x10]
00007aa3a45d9754  vmovaps xmm2, [rsp+0x20]
00007aa3a45d975a  vmovaps xmm3, [rsp+0x30]
00007aa3a45d9760  vmovaps xmm5, [rsp+0x40]
00007aa3a45d9766  vmovaps xmm6, [rsp+0x50]
00007aa3a45d976c  vmovaps xmm7, [rsp+0x60]
00007aa3a45d9772  vmovaps xmm8, [rsp+0x70]
00007aa3a45d9778  vmovaps xmm9, [rsp+0x80]
00007aa3a45d9781  vmovaps xmm10, [rsp+0x90]
00007aa3a45d978a  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d9793  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d979c  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d97a5  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d97ae  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d97b7  add rsp, 0xF0
00007aa3a45d97be  pop r11
00007aa3a45d97c0  pop r10
00007aa3a45d97c2  pop r9
00007aa3a45d97c4  pop r8
00007aa3a45d97c6  pop rsi
00007aa3a45d97c7  pop rdi
00007aa3a45d97c8  pop rdx
00007aa3a45d97c9  pop rcx
00007aa3a45d97ca  pop rax
00007aa3a45d97cb  add rsp, 0x08
00007aa3a45d97cf  jmp 0x00007AA3A45D628A
00007aa3a45d97d4  sub rsp, 0x08
00007aa3a45d97d8  push rax
00007aa3a45d97d9  push rcx
00007aa3a45d97da  push rdx
00007aa3a45d97db  push rdi
00007aa3a45d97dc  push rsi
00007aa3a45d97dd  push r8
00007aa3a45d97df  push r9
00007aa3a45d97e1  push r10
00007aa3a45d97e3  push r11
00007aa3a45d97e5  sub rsp, 0xF0
00007aa3a45d97ec  vmovaps [rsp], xmm0
00007aa3a45d97f1  vmovaps [rsp+0x10], xmm1
00007aa3a45d97f7  vmovaps [rsp+0x20], xmm2
00007aa3a45d97fd  vmovaps [rsp+0x30], xmm3
00007aa3a45d9803  vmovaps [rsp+0x40], xmm4
00007aa3a45d9809  vmovaps [rsp+0x50], xmm5
00007aa3a45d980f  vmovaps [rsp+0x60], xmm6
00007aa3a45d9815  vmovaps [rsp+0x70], xmm7
00007aa3a45d981b  vmovaps [rsp+0x80], xmm8
00007aa3a45d9824  vmovaps [rsp+0x90], xmm9
00007aa3a45d982d  vmovaps [rsp+0xA0], xmm10
00007aa3a45d9836  vmovaps [rsp+0xB0], xmm11
00007aa3a45d983f  vmovaps [rsp+0xC0], xmm12
00007aa3a45d9848  vmovaps [rsp+0xD0], xmm14
00007aa3a45d9851  vmovaps [rsp+0xE0], xmm15
00007aa3a45d985a  sub rsp, 0x30
00007aa3a45d985e  movaps [rsp], xmm13
00007aa3a45d9863  movaps [rsp+0x10], xmm15
00007aa3a45d9869  movaps [rsp+0x20], xmm9
00007aa3a45d986f  lea rdi, [rsp]
00007aa3a45d9873  mov esi, 0x00
00007aa3a45d9878  mov rax, 0x5F551B683530
00007aa3a45d9882  call rax
00007aa3a45d9884  movaps xmm13, [rsp]
00007aa3a45d9889  add rsp, 0x30
00007aa3a45d988d  vmovaps xmm0, [rsp]
00007aa3a45d9892  vmovaps xmm1, [rsp+0x10]
00007aa3a45d9898  vmovaps xmm2, [rsp+0x20]
00007aa3a45d989e  vmovaps xmm3, [rsp+0x30]
00007aa3a45d98a4  vmovaps xmm4, [rsp+0x40]
00007aa3a45d98aa  vmovaps xmm5, [rsp+0x50]
00007aa3a45d98b0  vmovaps xmm6, [rsp+0x60]
00007aa3a45d98b6  vmovaps xmm7, [rsp+0x70]
00007aa3a45d98bc  vmovaps xmm8, [rsp+0x80]
00007aa3a45d98c5  vmovaps xmm9, [rsp+0x90]
00007aa3a45d98ce  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d98d7  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d98e0  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d98e9  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d98f2  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d98fb  add rsp, 0xF0
00007aa3a45d9902  pop r11
00007aa3a45d9904  pop r10
00007aa3a45d9906  pop r9
00007aa3a45d9908  pop r8
00007aa3a45d990a  pop rsi
00007aa3a45d990b  pop rdi
00007aa3a45d990c  pop rdx
00007aa3a45d990d  pop rcx
00007aa3a45d990e  pop rax
00007aa3a45d990f  add rsp, 0x08
00007aa3a45d9913  jmp 0x00007AA3A45D62A5
00007aa3a45d9918  sub rsp, 0x08
00007aa3a45d991c  push rax
00007aa3a45d991d  push rcx
00007aa3a45d991e  push rdx
00007aa3a45d991f  push rdi
00007aa3a45d9920  push rsi
00007aa3a45d9921  push r8
00007aa3a45d9923  push r9
00007aa3a45d9925  push r10
00007aa3a45d9927  push r11
00007aa3a45d9929  sub rsp, 0xF0
00007aa3a45d9930  vmovaps [rsp], xmm0
00007aa3a45d9935  vmovaps [rsp+0x10], xmm1
00007aa3a45d993b  vmovaps [rsp+0x20], xmm2
00007aa3a45d9941  vmovaps [rsp+0x30], xmm3
00007aa3a45d9947  vmovaps [rsp+0x40], xmm4
00007aa3a45d994d  vmovaps [rsp+0x50], xmm5
00007aa3a45d9953  vmovaps [rsp+0x60], xmm6
00007aa3a45d9959  vmovaps [rsp+0x70], xmm7
00007aa3a45d995f  vmovaps [rsp+0x80], xmm8
00007aa3a45d9968  vmovaps [rsp+0x90], xmm9
00007aa3a45d9971  vmovaps [rsp+0xA0], xmm10
00007aa3a45d997a  vmovaps [rsp+0xB0], xmm11
00007aa3a45d9983  vmovaps [rsp+0xC0], xmm12
00007aa3a45d998c  vmovaps [rsp+0xD0], xmm13
00007aa3a45d9995  vmovaps [rsp+0xE0], xmm14
00007aa3a45d999e  sub rsp, 0x30
00007aa3a45d99a2  movaps [rsp], xmm15
00007aa3a45d99a7  movaps [rsp+0x10], xmm1
00007aa3a45d99ac  movaps [rsp+0x20], xmm5
00007aa3a45d99b1  lea rdi, [rsp]
00007aa3a45d99b5  mov esi, 0x00
00007aa3a45d99ba  mov rax, 0x5F551B683530
00007aa3a45d99c4  call rax
00007aa3a45d99c6  movaps xmm15, [rsp]
00007aa3a45d99cb  add rsp, 0x30
00007aa3a45d99cf  vmovaps xmm0, [rsp]
00007aa3a45d99d4  vmovaps xmm1, [rsp+0x10]
00007aa3a45d99da  vmovaps xmm2, [rsp+0x20]
00007aa3a45d99e0  vmovaps xmm3, [rsp+0x30]
00007aa3a45d99e6  vmovaps xmm4, [rsp+0x40]
00007aa3a45d99ec  vmovaps xmm5, [rsp+0x50]
00007aa3a45d99f2  vmovaps xmm6, [rsp+0x60]
00007aa3a45d99f8  vmovaps xmm7, [rsp+0x70]
00007aa3a45d99fe  vmovaps xmm8, [rsp+0x80]
00007aa3a45d9a07  vmovaps xmm9, [rsp+0x90]
00007aa3a45d9a10  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d9a19  vmovaps xmm11, [rsp+0xB0]
00007aa3a45d9a22  vmovaps xmm12, [rsp+0xC0]
00007aa3a45d9a2b  vmovaps xmm13, [rsp+0xD0]
00007aa3a45d9a34  vmovaps xmm14, [rsp+0xE0]
00007aa3a45d9a3d  add rsp, 0xF0
00007aa3a45d9a44  pop r11
00007aa3a45d9a46  pop r10
00007aa3a45d9a48  pop r9
00007aa3a45d9a4a  pop r8
00007aa3a45d9a4c  pop rsi
00007aa3a45d9a4d  pop rdi
00007aa3a45d9a4e  pop rdx
00007aa3a45d9a4f  pop rcx
00007aa3a45d9a50  pop rax
00007aa3a45d9a51  add rsp, 0x08
00007aa3a45d9a55  jmp 0x00007AA3A45D62C0
00007aa3a45d9a5a  call 0x00007AA3A44D64F0
00007aa3a45d9a5f  jmp 0x00007AA3A45D631B
00007aa3a45d9a64  sub rsp, 0x08
00007aa3a45d9a68  push rax
00007aa3a45d9a69  push rcx
00007aa3a45d9a6a  push rdx
00007aa3a45d9a6b  push rdi
00007aa3a45d9a6c  push rsi
00007aa3a45d9a6d  push r8
00007aa3a45d9a6f  push r9
00007aa3a45d9a71  push r10
00007aa3a45d9a73  push r11
00007aa3a45d9a75  sub rsp, 0xF0
00007aa3a45d9a7c  vmovaps [rsp], xmm0
00007aa3a45d9a81  vmovaps [rsp+0x10], xmm1
00007aa3a45d9a87  vmovaps [rsp+0x20], xmm2
00007aa3a45d9a8d  vmovaps [rsp+0x30], xmm3
00007aa3a45d9a93  vmovaps [rsp+0x40], xmm4
00007aa3a45d9a99  vmovaps [rsp+0x50], xmm5
00007aa3a45d9a9f  vmovaps [rsp+0x60], xmm6
00007aa3a45d9aa5  vmovaps [rsp+0x70], xmm7
00007aa3a45d9aab  vmovaps [rsp+0x80], xmm8
00007aa3a45d9ab4  vmovaps [rsp+0x90], xmm10
00007aa3a45d9abd  vmovaps [rsp+0xA0], xmm11
00007aa3a45d9ac6  vmovaps [rsp+0xB0], xmm12
00007aa3a45d9acf  vmovaps [rsp+0xC0], xmm13
00007aa3a45d9ad8  vmovaps [rsp+0xD0], xmm14
00007aa3a45d9ae1  vmovaps [rsp+0xE0], xmm15
00007aa3a45d9aea  sub rsp, 0x30
00007aa3a45d9aee  movaps [rsp], xmm9
00007aa3a45d9af3  movaps [rsp+0x10], xmm8
00007aa3a45d9af9  movaps [rsp+0x20], xmm11
00007aa3a45d9aff  lea rdi, [rsp]
00007aa3a45d9b03  mov esi, 0x00
00007aa3a45d9b08  mov rax, 0x5F551B683530
00007aa3a45d9b12  call rax
00007aa3a45d9b14  movaps xmm9, [rsp]
00007aa3a45d9b19  add rsp, 0x30
00007aa3a45d9b1d  vmovaps xmm0, [rsp]
00007aa3a45d9b22  vmovaps xmm1, [rsp+0x10]
00007aa3a45d9b28  vmovaps xmm2, [rsp+0x20]
00007aa3a45d9b2e  vmovaps xmm3, [rsp+0x30]
00007aa3a45d9b34  vmovaps xmm4, [rsp+0x40]
00007aa3a45d9b3a  vmovaps xmm5, [rsp+0x50]
00007aa3a45d9b40  vmovaps xmm6, [rsp+0x60]
00007aa3a45d9b46  vmovaps xmm7, [rsp+0x70]
00007aa3a45d9b4c  vmovaps xmm8, [rsp+0x80]
00007aa3a45d9b55  vmovaps xmm10, [rsp+0x90]
00007aa3a45d9b5e  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d9b67  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d9b70  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d9b79  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d9b82  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d9b8b  add rsp, 0xF0
00007aa3a45d9b92  pop r11
00007aa3a45d9b94  pop r10
00007aa3a45d9b96  pop r9
00007aa3a45d9b98  pop r8
00007aa3a45d9b9a  pop rsi
00007aa3a45d9b9b  pop rdi
00007aa3a45d9b9c  pop rdx
00007aa3a45d9b9d  pop rcx
00007aa3a45d9b9e  pop rax
00007aa3a45d9b9f  add rsp, 0x08
00007aa3a45d9ba3  jmp 0x00007AA3A45D6352
00007aa3a45d9ba8  sub rsp, 0x08
00007aa3a45d9bac  push rax
00007aa3a45d9bad  push rcx
00007aa3a45d9bae  push rdx
00007aa3a45d9baf  push rdi
00007aa3a45d9bb0  push rsi
00007aa3a45d9bb1  push r8
00007aa3a45d9bb3  push r9
00007aa3a45d9bb5  push r10
00007aa3a45d9bb7  push r11
00007aa3a45d9bb9  sub rsp, 0xF0
00007aa3a45d9bc0  vmovaps [rsp], xmm0
00007aa3a45d9bc5  vmovaps [rsp+0x10], xmm1
00007aa3a45d9bcb  vmovaps [rsp+0x20], xmm2
00007aa3a45d9bd1  vmovaps [rsp+0x30], xmm3
00007aa3a45d9bd7  vmovaps [rsp+0x40], xmm4
00007aa3a45d9bdd  vmovaps [rsp+0x50], xmm5
00007aa3a45d9be3  vmovaps [rsp+0x60], xmm6
00007aa3a45d9be9  vmovaps [rsp+0x70], xmm7
00007aa3a45d9bef  vmovaps [rsp+0x80], xmm8
00007aa3a45d9bf8  vmovaps [rsp+0x90], xmm9
00007aa3a45d9c01  vmovaps [rsp+0xA0], xmm10
00007aa3a45d9c0a  vmovaps [rsp+0xB0], xmm12
00007aa3a45d9c13  vmovaps [rsp+0xC0], xmm13
00007aa3a45d9c1c  vmovaps [rsp+0xD0], xmm14
00007aa3a45d9c25  vmovaps [rsp+0xE0], xmm15
00007aa3a45d9c2e  sub rsp, 0x30
00007aa3a45d9c32  movaps [rsp], xmm11
00007aa3a45d9c37  movaps [rsp+0x10], xmm10
00007aa3a45d9c3d  movaps [rsp+0x20], xmm6
00007aa3a45d9c42  lea rdi, [rsp]
00007aa3a45d9c46  mov esi, 0x00
00007aa3a45d9c4b  mov rax, 0x5F551B683530
00007aa3a45d9c55  call rax
00007aa3a45d9c57  movaps xmm11, [rsp]
00007aa3a45d9c5c  add rsp, 0x30
00007aa3a45d9c60  vmovaps xmm0, [rsp]
00007aa3a45d9c65  vmovaps xmm1, [rsp+0x10]
00007aa3a45d9c6b  vmovaps xmm2, [rsp+0x20]
00007aa3a45d9c71  vmovaps xmm3, [rsp+0x30]
00007aa3a45d9c77  vmovaps xmm4, [rsp+0x40]
00007aa3a45d9c7d  vmovaps xmm5, [rsp+0x50]
00007aa3a45d9c83  vmovaps xmm6, [rsp+0x60]
00007aa3a45d9c89  vmovaps xmm7, [rsp+0x70]
00007aa3a45d9c8f  vmovaps xmm8, [rsp+0x80]
00007aa3a45d9c98  vmovaps xmm9, [rsp+0x90]
00007aa3a45d9ca1  vmovaps xmm10, [rsp+0xA0]
00007aa3a45d9caa  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d9cb3  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d9cbc  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d9cc5  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d9cce  add rsp, 0xF0
00007aa3a45d9cd5  pop r11
00007aa3a45d9cd7  pop r10
00007aa3a45d9cd9  pop r9
00007aa3a45d9cdb  pop r8
00007aa3a45d9cdd  pop rsi
00007aa3a45d9cde  pop rdi
00007aa3a45d9cdf  pop rdx
00007aa3a45d9ce0  pop rcx
00007aa3a45d9ce1  pop rax
00007aa3a45d9ce2  add rsp, 0x08
00007aa3a45d9ce6  jmp 0x00007AA3A45D636D
00007aa3a45d9ceb  sub rsp, 0x08
00007aa3a45d9cef  push rax
00007aa3a45d9cf0  push rcx
00007aa3a45d9cf1  push rdx
00007aa3a45d9cf2  push rdi
00007aa3a45d9cf3  push rsi
00007aa3a45d9cf4  push r8
00007aa3a45d9cf6  push r9
00007aa3a45d9cf8  push r10
00007aa3a45d9cfa  push r11
00007aa3a45d9cfc  sub rsp, 0xF0
00007aa3a45d9d03  vmovaps [rsp], xmm0
00007aa3a45d9d08  vmovaps [rsp+0x10], xmm1
00007aa3a45d9d0e  vmovaps [rsp+0x20], xmm2
00007aa3a45d9d14  vmovaps [rsp+0x30], xmm3
00007aa3a45d9d1a  vmovaps [rsp+0x40], xmm4
00007aa3a45d9d20  vmovaps [rsp+0x50], xmm5
00007aa3a45d9d26  vmovaps [rsp+0x60], xmm6
00007aa3a45d9d2c  vmovaps [rsp+0x70], xmm7
00007aa3a45d9d32  vmovaps [rsp+0x80], xmm8
00007aa3a45d9d3b  vmovaps [rsp+0x90], xmm9
00007aa3a45d9d44  vmovaps [rsp+0xA0], xmm11
00007aa3a45d9d4d  vmovaps [rsp+0xB0], xmm12
00007aa3a45d9d56  vmovaps [rsp+0xC0], xmm13
00007aa3a45d9d5f  vmovaps [rsp+0xD0], xmm14
00007aa3a45d9d68  vmovaps [rsp+0xE0], xmm15
00007aa3a45d9d71  sub rsp, 0x30
00007aa3a45d9d75  movaps [rsp], xmm10
00007aa3a45d9d7a  movaps [rsp+0x10], xmm14
00007aa3a45d9d80  movaps [rsp+0x20], xmm4
00007aa3a45d9d85  lea rdi, [rsp]
00007aa3a45d9d89  mov esi, 0x00
00007aa3a45d9d8e  mov rax, 0x5F551B683530
00007aa3a45d9d98  call rax
00007aa3a45d9d9a  movaps xmm10, [rsp]
00007aa3a45d9d9f  add rsp, 0x30
00007aa3a45d9da3  vmovaps xmm0, [rsp]
00007aa3a45d9da8  vmovaps xmm1, [rsp+0x10]
00007aa3a45d9dae  vmovaps xmm2, [rsp+0x20]
00007aa3a45d9db4  vmovaps xmm3, [rsp+0x30]
00007aa3a45d9dba  vmovaps xmm4, [rsp+0x40]
00007aa3a45d9dc0  vmovaps xmm5, [rsp+0x50]
00007aa3a45d9dc6  vmovaps xmm6, [rsp+0x60]
00007aa3a45d9dcc  vmovaps xmm7, [rsp+0x70]
00007aa3a45d9dd2  vmovaps xmm8, [rsp+0x80]
00007aa3a45d9ddb  vmovaps xmm9, [rsp+0x90]
00007aa3a45d9de4  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d9ded  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d9df6  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d9dff  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d9e08  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d9e11  add rsp, 0xF0
00007aa3a45d9e18  pop r11
00007aa3a45d9e1a  pop r10
00007aa3a45d9e1c  pop r9
00007aa3a45d9e1e  pop r8
00007aa3a45d9e20  pop rsi
00007aa3a45d9e21  pop rdi
00007aa3a45d9e22  pop rdx
00007aa3a45d9e23  pop rcx
00007aa3a45d9e24  pop rax
00007aa3a45d9e25  add rsp, 0x08
00007aa3a45d9e29  jmp 0x00007AA3A45D6388
00007aa3a45d9e2e  sub rsp, 0x08
00007aa3a45d9e32  push rax
00007aa3a45d9e33  push rcx
00007aa3a45d9e34  push rdx
00007aa3a45d9e35  push rdi
00007aa3a45d9e36  push rsi
00007aa3a45d9e37  push r8
00007aa3a45d9e39  push r9
00007aa3a45d9e3b  push r10
00007aa3a45d9e3d  push r11
00007aa3a45d9e3f  sub rsp, 0xF0
00007aa3a45d9e46  vmovaps [rsp], xmm0
00007aa3a45d9e4b  vmovaps [rsp+0x10], xmm1
00007aa3a45d9e51  vmovaps [rsp+0x20], xmm2
00007aa3a45d9e57  vmovaps [rsp+0x30], xmm3
00007aa3a45d9e5d  vmovaps [rsp+0x40], xmm4
00007aa3a45d9e63  vmovaps [rsp+0x50], xmm5
00007aa3a45d9e69  vmovaps [rsp+0x60], xmm6
00007aa3a45d9e6f  vmovaps [rsp+0x70], xmm7
00007aa3a45d9e75  vmovaps [rsp+0x80], xmm9
00007aa3a45d9e7e  vmovaps [rsp+0x90], xmm10
00007aa3a45d9e87  vmovaps [rsp+0xA0], xmm11
00007aa3a45d9e90  vmovaps [rsp+0xB0], xmm12
00007aa3a45d9e99  vmovaps [rsp+0xC0], xmm13
00007aa3a45d9ea2  vmovaps [rsp+0xD0], xmm14
00007aa3a45d9eab  vmovaps [rsp+0xE0], xmm15
00007aa3a45d9eb4  sub rsp, 0x30
00007aa3a45d9eb8  movaps [rsp], xmm8
00007aa3a45d9ebd  movaps [rsp+0x10], xmm1
00007aa3a45d9ec2  movaps [rsp+0x20], xmm14
00007aa3a45d9ec8  lea rdi, [rsp]
00007aa3a45d9ecc  mov esi, 0x00
00007aa3a45d9ed1  mov rax, 0x5F551B683530
00007aa3a45d9edb  call rax
00007aa3a45d9edd  movaps xmm8, [rsp]
00007aa3a45d9ee2  add rsp, 0x30
00007aa3a45d9ee6  vmovaps xmm0, [rsp]
00007aa3a45d9eeb  vmovaps xmm1, [rsp+0x10]
00007aa3a45d9ef1  vmovaps xmm2, [rsp+0x20]
00007aa3a45d9ef7  vmovaps xmm3, [rsp+0x30]
00007aa3a45d9efd  vmovaps xmm4, [rsp+0x40]
00007aa3a45d9f03  vmovaps xmm5, [rsp+0x50]
00007aa3a45d9f09  vmovaps xmm6, [rsp+0x60]
00007aa3a45d9f0f  vmovaps xmm7, [rsp+0x70]
00007aa3a45d9f15  vmovaps xmm9, [rsp+0x80]
00007aa3a45d9f1e  vmovaps xmm10, [rsp+0x90]
00007aa3a45d9f27  vmovaps xmm11, [rsp+0xA0]
00007aa3a45d9f30  vmovaps xmm12, [rsp+0xB0]
00007aa3a45d9f39  vmovaps xmm13, [rsp+0xC0]
00007aa3a45d9f42  vmovaps xmm14, [rsp+0xD0]
00007aa3a45d9f4b  vmovaps xmm15, [rsp+0xE0]
00007aa3a45d9f54  add rsp, 0xF0
00007aa3a45d9f5b  pop r11
00007aa3a45d9f5d  pop r10
00007aa3a45d9f5f  pop r9
00007aa3a45d9f61  pop r8
00007aa3a45d9f63  pop rsi
00007aa3a45d9f64  pop rdi
00007aa3a45d9f65  pop rdx
00007aa3a45d9f66  pop rcx
00007aa3a45d9f67  pop rax
00007aa3a45d9f68  add rsp, 0x08
00007aa3a45d9f6c  jmp 0x00007AA3A45D63AE
00007aa3a45d9f71  sub rsp, 0x08
00007aa3a45d9f75  push rax
00007aa3a45d9f76  push rcx
00007aa3a45d9f77  push rdx
00007aa3a45d9f78  push rdi
00007aa3a45d9f79  push rsi
00007aa3a45d9f7a  push r8
00007aa3a45d9f7c  push r9
00007aa3a45d9f7e  push r10
00007aa3a45d9f80  push r11
00007aa3a45d9f82  sub rsp, 0xF0
00007aa3a45d9f89  vmovaps [rsp], xmm0
00007aa3a45d9f8e  vmovaps [rsp+0x10], xmm1
00007aa3a45d9f94  vmovaps [rsp+0x20], xmm2
00007aa3a45d9f9a  vmovaps [rsp+0x30], xmm3
00007aa3a45d9fa0  vmovaps [rsp+0x40], xmm4
00007aa3a45d9fa6  vmovaps [rsp+0x50], xmm5
00007aa3a45d9fac  vmovaps [rsp+0x60], xmm7
00007aa3a45d9fb2  vmovaps [rsp+0x70], xmm8
00007aa3a45d9fb8  vmovaps [rsp+0x80], xmm9
00007aa3a45d9fc1  vmovaps [rsp+0x90], xmm10
00007aa3a45d9fca  vmovaps [rsp+0xA0], xmm11
00007aa3a45d9fd3  vmovaps [rsp+0xB0], xmm12
00007aa3a45d9fdc  vmovaps [rsp+0xC0], xmm13
00007aa3a45d9fe5  vmovaps [rsp+0xD0], xmm14
00007aa3a45d9fee  vmovaps [rsp+0xE0], xmm15
00007aa3a45d9ff7  sub rsp, 0x30
00007aa3a45d9ffb  movaps [rsp], xmm6
00007aa3a45d9fff  movaps [rsp+0x10], xmm1
00007aa3a45da004  movaps [rsp+0x20], xmm14
00007aa3a45da00a  lea rdi, [rsp]
00007aa3a45da00e  mov esi, 0x00
00007aa3a45da013  mov rax, 0x5F551B683530
00007aa3a45da01d  call rax
00007aa3a45da01f  movaps xmm6, [rsp]
00007aa3a45da023  add rsp, 0x30
00007aa3a45da027  vmovaps xmm0, [rsp]
00007aa3a45da02c  vmovaps xmm1, [rsp+0x10]
00007aa3a45da032  vmovaps xmm2, [rsp+0x20]
00007aa3a45da038  vmovaps xmm3, [rsp+0x30]
00007aa3a45da03e  vmovaps xmm4, [rsp+0x40]
00007aa3a45da044  vmovaps xmm5, [rsp+0x50]
00007aa3a45da04a  vmovaps xmm7, [rsp+0x60]
00007aa3a45da050  vmovaps xmm8, [rsp+0x70]
00007aa3a45da056  vmovaps xmm9, [rsp+0x80]
00007aa3a45da05f  vmovaps xmm10, [rsp+0x90]
00007aa3a45da068  vmovaps xmm11, [rsp+0xA0]
00007aa3a45da071  vmovaps xmm12, [rsp+0xB0]
00007aa3a45da07a  vmovaps xmm13, [rsp+0xC0]
00007aa3a45da083  vmovaps xmm14, [rsp+0xD0]
00007aa3a45da08c  vmovaps xmm15, [rsp+0xE0]
00007aa3a45da095  add rsp, 0xF0
00007aa3a45da09c  pop r11
00007aa3a45da09e  pop r10
00007aa3a45da0a0  pop r9
00007aa3a45da0a2  pop r8
00007aa3a45da0a4  pop rsi
00007aa3a45da0a5  pop rdi
00007aa3a45da0a6  pop rdx
00007aa3a45da0a7  pop rcx
00007aa3a45da0a8  pop rax
00007aa3a45da0a9  add rsp, 0x08
00007aa3a45da0ad  jmp 0x00007AA3A45D63DA
00007aa3a45da0b2  sub rsp, 0x08
00007aa3a45da0b6  push rax
00007aa3a45da0b7  push rcx
00007aa3a45da0b8  push rdx
00007aa3a45da0b9  push rdi
00007aa3a45da0ba  push rsi
00007aa3a45da0bb  push r8
00007aa3a45da0bd  push r9
00007aa3a45da0bf  push r10
00007aa3a45da0c1  push r11
00007aa3a45da0c3  sub rsp, 0xF0
00007aa3a45da0ca  vmovaps [rsp], xmm0
00007aa3a45da0cf  vmovaps [rsp+0x10], xmm1
00007aa3a45da0d5  vmovaps [rsp+0x20], xmm2
00007aa3a45da0db  vmovaps [rsp+0x30], xmm3
00007aa3a45da0e1  vmovaps [rsp+0x40], xmm4
00007aa3a45da0e7  vmovaps [rsp+0x50], xmm5
00007aa3a45da0ed  vmovaps [rsp+0x60], xmm6
00007aa3a45da0f3  vmovaps [rsp+0x70], xmm7
00007aa3a45da0f9  vmovaps [rsp+0x80], xmm8
00007aa3a45da102  vmovaps [rsp+0x90], xmm9
00007aa3a45da10b  vmovaps [rsp+0xA0], xmm10
00007aa3a45da114  vmovaps [rsp+0xB0], xmm11
00007aa3a45da11d  vmovaps [rsp+0xC0], xmm12
00007aa3a45da126  vmovaps [rsp+0xD0], xmm13
00007aa3a45da12f  vmovaps [rsp+0xE0], xmm15
00007aa3a45da138  sub rsp, 0x30
00007aa3a45da13c  movaps [rsp], xmm14
00007aa3a45da141  movaps [rsp+0x10], xmm12
00007aa3a45da147  movaps [rsp+0x20], xmm1
00007aa3a45da14c  lea rdi, [rsp]
00007aa3a45da150  mov esi, 0x00
00007aa3a45da155  mov rax, 0x5F551B683530
00007aa3a45da15f  call rax
00007aa3a45da161  movaps xmm14, [rsp]
00007aa3a45da166  add rsp, 0x30
00007aa3a45da16a  vmovaps xmm0, [rsp]
00007aa3a45da16f  vmovaps xmm1, [rsp+0x10]
00007aa3a45da175  vmovaps xmm2, [rsp+0x20]
00007aa3a45da17b  vmovaps xmm3, [rsp+0x30]
00007aa3a45da181  vmovaps xmm4, [rsp+0x40]
00007aa3a45da187  vmovaps xmm5, [rsp+0x50]
00007aa3a45da18d  vmovaps xmm6, [rsp+0x60]
00007aa3a45da193  vmovaps xmm7, [rsp+0x70]
00007aa3a45da199  vmovaps xmm8, [rsp+0x80]
00007aa3a45da1a2  vmovaps xmm9, [rsp+0x90]
00007aa3a45da1ab  vmovaps xmm10, [rsp+0xA0]
00007aa3a45da1b4  vmovaps xmm11, [rsp+0xB0]
00007aa3a45da1bd  vmovaps xmm12, [rsp+0xC0]
00007aa3a45da1c6  vmovaps xmm13, [rsp+0xD0]
00007aa3a45da1cf  vmovaps xmm15, [rsp+0xE0]
00007aa3a45da1d8  add rsp, 0xF0
00007aa3a45da1df  pop r11
00007aa3a45da1e1  pop r10
00007aa3a45da1e3  pop r9
00007aa3a45da1e5  pop r8
00007aa3a45da1e7  pop rsi
00007aa3a45da1e8  pop rdi
00007aa3a45da1e9  pop rdx
00007aa3a45da1ea  pop rcx
00007aa3a45da1eb  pop rax
00007aa3a45da1ec  add rsp, 0x08
00007aa3a45da1f0  jmp 0x00007AA3A45D6400
00007aa3a45da1f5  sub rsp, 0x08
00007aa3a45da1f9  push rax
00007aa3a45da1fa  push rcx
00007aa3a45da1fb  push rdx
00007aa3a45da1fc  push rdi
00007aa3a45da1fd  push rsi
00007aa3a45da1fe  push r8
00007aa3a45da200  push r9
00007aa3a45da202  push r10
00007aa3a45da204  push r11
00007aa3a45da206  sub rsp, 0xF0
00007aa3a45da20d  vmovaps [rsp], xmm0
00007aa3a45da212  vmovaps [rsp+0x10], xmm2
00007aa3a45da218  vmovaps [rsp+0x20], xmm3
00007aa3a45da21e  vmovaps [rsp+0x30], xmm4
00007aa3a45da224  vmovaps [rsp+0x40], xmm5
00007aa3a45da22a  vmovaps [rsp+0x50], xmm6
00007aa3a45da230  vmovaps [rsp+0x60], xmm7
00007aa3a45da236  vmovaps [rsp+0x70], xmm8
00007aa3a45da23c  vmovaps [rsp+0x80], xmm9
00007aa3a45da245  vmovaps [rsp+0x90], xmm10
00007aa3a45da24e  vmovaps [rsp+0xA0], xmm11
00007aa3a45da257  vmovaps [rsp+0xB0], xmm12
00007aa3a45da260  vmovaps [rsp+0xC0], xmm13
00007aa3a45da269  vmovaps [rsp+0xD0], xmm14
00007aa3a45da272  vmovaps [rsp+0xE0], xmm15
00007aa3a45da27b  sub rsp, 0x30
00007aa3a45da27f  movaps [rsp], xmm1
00007aa3a45da283  movaps [rsp+0x10], xmm13
00007aa3a45da289  movaps [rsp+0x20], xmm9
00007aa3a45da28f  lea rdi, [rsp]
00007aa3a45da293  mov esi, 0x00
00007aa3a45da298  mov rax, 0x5F551B683530
00007aa3a45da2a2  call rax
00007aa3a45da2a4  movaps xmm1, [rsp]
00007aa3a45da2a8  add rsp, 0x30
00007aa3a45da2ac  vmovaps xmm0, [rsp]
00007aa3a45da2b1  vmovaps xmm2, [rsp+0x10]
00007aa3a45da2b7  vmovaps xmm3, [rsp+0x20]
00007aa3a45da2bd  vmovaps xmm4, [rsp+0x30]
00007aa3a45da2c3  vmovaps xmm5, [rsp+0x40]
00007aa3a45da2c9  vmovaps xmm6, [rsp+0x50]
00007aa3a45da2cf  vmovaps xmm7, [rsp+0x60]
00007aa3a45da2d5  vmovaps xmm8, [rsp+0x70]
00007aa3a45da2db  vmovaps xmm9, [rsp+0x80]
00007aa3a45da2e4  vmovaps xmm10, [rsp+0x90]
00007aa3a45da2ed  vmovaps xmm11, [rsp+0xA0]
00007aa3a45da2f6  vmovaps xmm12, [rsp+0xB0]
00007aa3a45da2ff  vmovaps xmm13, [rsp+0xC0]
00007aa3a45da308  vmovaps xmm14, [rsp+0xD0]
00007aa3a45da311  vmovaps xmm15, [rsp+0xE0]
00007aa3a45da31a  add rsp, 0xF0
00007aa3a45da321  pop r11
00007aa3a45da323  pop r10
00007aa3a45da325  pop r9
00007aa3a45da327  pop r8
00007aa3a45da329  pop rsi
00007aa3a45da32a  pop rdi
00007aa3a45da32b  pop rdx
00007aa3a45da32c  pop rcx
00007aa3a45da32d  pop rax
00007aa3a45da32e  add rsp, 0x08
00007aa3a45da332  jmp 0x00007AA3A45D641A
00007aa3a45da337  sub rsp, 0x08
00007aa3a45da33b  push rax
00007aa3a45da33c  push rcx
00007aa3a45da33d  push rdx
00007aa3a45da33e  push rdi
00007aa3a45da33f  push rsi
00007aa3a45da340  push r8
00007aa3a45da342  push r9
00007aa3a45da344  push r10
00007aa3a45da346  push r11
00007aa3a45da348  sub rsp, 0xF0
00007aa3a45da34f  vmovaps [rsp], xmm0
00007aa3a45da354  vmovaps [rsp+0x10], xmm1
00007aa3a45da35a  vmovaps [rsp+0x20], xmm2
00007aa3a45da360  vmovaps [rsp+0x30], xmm3
00007aa3a45da366  vmovaps [rsp+0x40], xmm4
00007aa3a45da36c  vmovaps [rsp+0x50], xmm5
00007aa3a45da372  vmovaps [rsp+0x60], xmm6
00007aa3a45da378  vmovaps [rsp+0x70], xmm7
00007aa3a45da37e  vmovaps [rsp+0x80], xmm8
00007aa3a45da387  vmovaps [rsp+0x90], xmm9
00007aa3a45da390  vmovaps [rsp+0xA0], xmm10
00007aa3a45da399  vmovaps [rsp+0xB0], xmm11
00007aa3a45da3a2  vmovaps [rsp+0xC0], xmm13
00007aa3a45da3ab  vmovaps [rsp+0xD0], xmm14
00007aa3a45da3b4  vmovaps [rsp+0xE0], xmm15
00007aa3a45da3bd  sub rsp, 0x30
00007aa3a45da3c1  movaps [rsp], xmm12
00007aa3a45da3c6  movaps [rsp+0x10], xmm7
00007aa3a45da3cb  movaps [rsp+0x20], xmm13
00007aa3a45da3d1  lea rdi, [rsp]
00007aa3a45da3d5  mov esi, 0x00
00007aa3a45da3da  mov rax, 0x5F551B683530
00007aa3a45da3e4  call rax
00007aa3a45da3e6  movaps xmm12, [rsp]
00007aa3a45da3eb  add rsp, 0x30
00007aa3a45da3ef  vmovaps xmm0, [rsp]
00007aa3a45da3f4  vmovaps xmm1, [rsp+0x10]
00007aa3a45da3fa  vmovaps xmm2, [rsp+0x20]
00007aa3a45da400  vmovaps xmm3, [rsp+0x30]
00007aa3a45da406  vmovaps xmm4, [rsp+0x40]
00007aa3a45da40c  vmovaps xmm5, [rsp+0x50]
00007aa3a45da412  vmovaps xmm6, [rsp+0x60]
00007aa3a45da418  vmovaps xmm7, [rsp+0x70]
00007aa3a45da41e  vmovaps xmm8, [rsp+0x80]
00007aa3a45da427  vmovaps xmm9, [rsp+0x90]
00007aa3a45da430  vmovaps xmm10, [rsp+0xA0]
00007aa3a45da439  vmovaps xmm11, [rsp+0xB0]
00007aa3a45da442  vmovaps xmm13, [rsp+0xC0]
00007aa3a45da44b  vmovaps xmm14, [rsp+0xD0]
00007aa3a45da454  vmovaps xmm15, [rsp+0xE0]
00007aa3a45da45d  add rsp, 0xF0
00007aa3a45da464  pop r11
00007aa3a45da466  pop r10
00007aa3a45da468  pop r9
00007aa3a45da46a  pop r8
00007aa3a45da46c  pop rsi
00007aa3a45da46d  pop rdi
00007aa3a45da46e  pop rdx
00007aa3a45da46f  pop rcx
00007aa3a45da470  pop rax
00007aa3a45da471  add rsp, 0x08
00007aa3a45da475  jmp 0x00007AA3A45D6441
00007aa3a45da47a  sub rsp, 0x08
00007aa3a45da47e  push rax
00007aa3a45da47f  push rcx
00007aa3a45da480  push rdx
00007aa3a45da481  push rdi
00007aa3a45da482  push rsi
00007aa3a45da483  push r8
00007aa3a45da485  push r9
00007aa3a45da487  push r10
00007aa3a45da489  push r11
00007aa3a45da48b  sub rsp, 0xF0
00007aa3a45da492  vmovaps [rsp], xmm0
00007aa3a45da497  vmovaps [rsp+0x10], xmm1
00007aa3a45da49d  vmovaps [rsp+0x20], xmm2
00007aa3a45da4a3  vmovaps [rsp+0x30], xmm3
00007aa3a45da4a9  vmovaps [rsp+0x40], xmm4
00007aa3a45da4af  vmovaps [rsp+0x50], xmm5
00007aa3a45da4b5  vmovaps [rsp+0x60], xmm6
00007aa3a45da4bb  vmovaps [rsp+0x70], xmm7
00007aa3a45da4c1  vmovaps [rsp+0x80], xmm8
00007aa3a45da4ca  vmovaps [rsp+0x90], xmm9
00007aa3a45da4d3  vmovaps [rsp+0xA0], xmm10
00007aa3a45da4dc  vmovaps [rsp+0xB0], xmm11
00007aa3a45da4e5  vmovaps [rsp+0xC0], xmm12
00007aa3a45da4ee  vmovaps [rsp+0xD0], xmm14
00007aa3a45da4f7  vmovaps [rsp+0xE0], xmm15
00007aa3a45da500  sub rsp, 0x30
00007aa3a45da504  movaps [rsp], xmm13
00007aa3a45da509  movaps [rsp+0x10], xmm15
00007aa3a45da50f  movaps [rsp+0x20], xmm8
00007aa3a45da515  lea rdi, [rsp]
00007aa3a45da519  mov esi, 0x00
00007aa3a45da51e  mov rax, 0x5F551B683530
00007aa3a45da528  call rax
00007aa3a45da52a  movaps xmm13, [rsp]
00007aa3a45da52f  add rsp, 0x30
00007aa3a45da533  vmovaps xmm0, [rsp]
00007aa3a45da538  vmovaps xmm1, [rsp+0x10]
00007aa3a45da53e  vmovaps xmm2, [rsp+0x20]
00007aa3a45da544  vmovaps xmm3, [rsp+0x30]
00007aa3a45da54a  vmovaps xmm4, [rsp+0x40]
00007aa3a45da550  vmovaps xmm5, [rsp+0x50]
00007aa3a45da556  vmovaps xmm6, [rsp+0x60]
00007aa3a45da55c  vmovaps xmm7, [rsp+0x70]
00007aa3a45da562  vmovaps xmm8, [rsp+0x80]
00007aa3a45da56b  vmovaps xmm9, [rsp+0x90]
00007aa3a45da574  vmovaps xmm10, [rsp+0xA0]
00007aa3a45da57d  vmovaps xmm11, [rsp+0xB0]
00007aa3a45da586  vmovaps xmm12, [rsp+0xC0]
00007aa3a45da58f  vmovaps xmm14, [rsp+0xD0]
00007aa3a45da598  vmovaps xmm15, [rsp+0xE0]
00007aa3a45da5a1  add rsp, 0xF0
00007aa3a45da5a8  pop r11
00007aa3a45da5aa  pop r10
00007aa3a45da5ac  pop r9
00007aa3a45da5ae  pop r8
00007aa3a45da5b0  pop rsi
00007aa3a45da5b1  pop rdi
00007aa3a45da5b2  pop rdx
00007aa3a45da5b3  pop rcx
00007aa3a45da5b4  pop rax
00007aa3a45da5b5  add rsp, 0x08
00007aa3a45da5b9  jmp 0x00007AA3A45D645C
00007aa3a45da5be  sub rsp, 0x08
00007aa3a45da5c2  push rax
00007aa3a45da5c3  push rcx
00007aa3a45da5c4  push rdx
00007aa3a45da5c5  push rdi
00007aa3a45da5c6  push rsi
00007aa3a45da5c7  push r8
00007aa3a45da5c9  push r9
00007aa3a45da5cb  push r10
00007aa3a45da5cd  push r11
00007aa3a45da5cf  sub rsp, 0xF0
00007aa3a45da5d6  vmovaps [rsp], xmm0
00007aa3a45da5db  vmovaps [rsp+0x10], xmm1
00007aa3a45da5e1  vmovaps [rsp+0x20], xmm2
00007aa3a45da5e7  vmovaps [rsp+0x30], xmm3
00007aa3a45da5ed  vmovaps [rsp+0x40], xmm4
00007aa3a45da5f3  vmovaps [rsp+0x50], xmm5
00007aa3a45da5f9  vmovaps [rsp+0x60], xmm6
00007aa3a45da5ff  vmovaps [rsp+0x70], xmm7
00007aa3a45da605  vmovaps [rsp+0x80], xmm9
00007aa3a45da60e  vmovaps [rsp+0x90], xmm10
00007aa3a45da617  vmovaps [rsp+0xA0], xmm11
00007aa3a45da620  vmovaps [rsp+0xB0], xmm12
00007aa3a45da629  vmovaps [rsp+0xC0], xmm13
00007aa3a45da632  vmovaps [rsp+0xD0], xmm14
00007aa3a45da63b  vmovaps [rsp+0xE0], xmm15
00007aa3a45da644  sub rsp, 0x30
00007aa3a45da648  movaps [rsp], xmm8
00007aa3a45da64d  movaps [rsp+0x10], xmm15
00007aa3a45da653  movaps [rsp+0x20], xmm9
00007aa3a45da659  lea rdi, [rsp]
00007aa3a45da65d  mov esi, 0x00
00007aa3a45da662  mov rax, 0x5F551B683530
00007aa3a45da66c  call rax
00007aa3a45da66e  movaps xmm8, [rsp]
00007aa3a45da673  add rsp, 0x30
00007aa3a45da677  vmovaps xmm0, [rsp]
00007aa3a45da67c  vmovaps xmm1, [rsp+0x10]
00007aa3a45da682  vmovaps xmm2, [rsp+0x20]
00007aa3a45da688  vmovaps xmm3, [rsp+0x30]
00007aa3a45da68e  vmovaps xmm4, [rsp+0x40]
00007aa3a45da694  vmovaps xmm5, [rsp+0x50]
00007aa3a45da69a  vmovaps xmm6, [rsp+0x60]
00007aa3a45da6a0  vmovaps xmm7, [rsp+0x70]
00007aa3a45da6a6  vmovaps xmm9, [rsp+0x80]
00007aa3a45da6af  vmovaps xmm10, [rsp+0x90]
00007aa3a45da6b8  vmovaps xmm11, [rsp+0xA0]
00007aa3a45da6c1  vmovaps xmm12, [rsp+0xB0]
00007aa3a45da6ca  vmovaps xmm13, [rsp+0xC0]
00007aa3a45da6d3  vmovaps xmm14, [rsp+0xD0]
00007aa3a45da6dc  vmovaps xmm15, [rsp+0xE0]
00007aa3a45da6e5  add rsp, 0xF0
00007aa3a45da6ec  pop r11
00007aa3a45da6ee  pop r10
00007aa3a45da6f0  pop r9
00007aa3a45da6f2  pop r8
00007aa3a45da6f4  pop rsi
00007aa3a45da6f5  pop rdi
00007aa3a45da6f6  pop rdx
00007aa3a45da6f7  pop rcx
00007aa3a45da6f8  pop rax
00007aa3a45da6f9  add rsp, 0x08
00007aa3a45da6fd  jmp 0x00007AA3A45D648A
00007aa3a45da702  sub rsp, 0x08
00007aa3a45da706  push rax
00007aa3a45da707  push rcx
00007aa3a45da708  push rdx
00007aa3a45da709  push rdi
00007aa3a45da70a  push rsi
00007aa3a45da70b  push r8
00007aa3a45da70d  push r9
00007aa3a45da70f  push r10
00007aa3a45da711  push r11
00007aa3a45da713  sub rsp, 0xF0
00007aa3a45da71a  vmovaps [rsp], xmm0
00007aa3a45da71f  vmovaps [rsp+0x10], xmm1
00007aa3a45da725  vmovaps [rsp+0x20], xmm2
00007aa3a45da72b  vmovaps [rsp+0x30], xmm3
00007aa3a45da731  vmovaps [rsp+0x40], xmm4
00007aa3a45da737  vmovaps [rsp+0x50], xmm5
00007aa3a45da73d  vmovaps [rsp+0x60], xmm6
00007aa3a45da743  vmovaps [rsp+0x70], xmm7
00007aa3a45da749  vmovaps [rsp+0x80], xmm8
00007aa3a45da752  vmovaps [rsp+0x90], xmm9
00007aa3a45da75b  vmovaps [rsp+0xA0], xmm10
00007aa3a45da764  vmovaps [rsp+0xB0], xmm11
00007aa3a45da76d  vmovaps [rsp+0xC0], xmm12
00007aa3a45da776  vmovaps [rsp+0xD0], xmm13
00007aa3a45da77f  vmovaps [rsp+0xE0], xmm14
00007aa3a45da788  sub rsp, 0x30
00007aa3a45da78c  movaps [rsp], xmm15
00007aa3a45da791  movaps [rsp+0x10], xmm11
00007aa3a45da797  movaps [rsp+0x20], xmm6
00007aa3a45da79c  lea rdi, [rsp]
00007aa3a45da7a0  mov esi, 0x00
00007aa3a45da7a5  mov rax, 0x5F551B683530
00007aa3a45da7af  call rax
00007aa3a45da7b1  movaps xmm15, [rsp]
00007aa3a45da7b6  add rsp, 0x30
00007aa3a45da7ba  vmovaps xmm0, [rsp]
00007aa3a45da7bf  vmovaps xmm1, [rsp+0x10]
00007aa3a45da7c5  vmovaps xmm2, [rsp+0x20]
00007aa3a45da7cb  vmovaps xmm3, [rsp+0x30]
00007aa3a45da7d1  vmovaps xmm4, [rsp+0x40]
00007aa3a45da7d7  vmovaps xmm5, [rsp+0x50]
00007aa3a45da7dd  vmovaps xmm6, [rsp+0x60]
00007aa3a45da7e3  vmovaps xmm7, [rsp+0x70]
00007aa3a45da7e9  vmovaps xmm8, [rsp+0x80]
00007aa3a45da7f2  vmovaps xmm9, [rsp+0x90]
00007aa3a45da7fb  vmovaps xmm10, [rsp+0xA0]
00007aa3a45da804  vmovaps xmm11, [rsp+0xB0]
00007aa3a45da80d  vmovaps xmm12, [rsp+0xC0]
00007aa3a45da816  vmovaps xmm13, [rsp+0xD0]
00007aa3a45da81f  vmovaps xmm14, [rsp+0xE0]
00007aa3a45da828  add rsp, 0xF0
00007aa3a45da82f  pop r11
00007aa3a45da831  pop r10
00007aa3a45da833  pop r9
00007aa3a45da835  pop r8
00007aa3a45da837  pop rsi
00007aa3a45da838  pop rdi
00007aa3a45da839  pop rdx
00007aa3a45da83a  pop rcx
00007aa3a45da83b  pop rax
00007aa3a45da83c  add rsp, 0x08
00007aa3a45da840  jmp 0x00007AA3A45D64A5
00007aa3a45da845  sub rsp, 0x08
00007aa3a45da849  push rax
00007aa3a45da84a  push rcx
00007aa3a45da84b  push rdx
00007aa3a45da84c  push rdi
00007aa3a45da84d  push rsi
00007aa3a45da84e  push r8
00007aa3a45da850  push r9
00007aa3a45da852  push r10
00007aa3a45da854  push r11
00007aa3a45da856  sub rsp, 0xF0
00007aa3a45da85d  vmovaps [rsp], xmm0
00007aa3a45da862  vmovaps [rsp+0x10], xmm1
00007aa3a45da868  vmovaps [rsp+0x20], xmm2
00007aa3a45da86e  vmovaps [rsp+0x30], xmm3
00007aa3a45da874  vmovaps [rsp+0x40], xmm4
00007aa3a45da87a  vmovaps [rsp+0x50], xmm5
00007aa3a45da880  vmovaps [rsp+0x60], xmm6
00007aa3a45da886  vmovaps [rsp+0x70], xmm8
00007aa3a45da88c  vmovaps [rsp+0x80], xmm9
00007aa3a45da895  vmovaps [rsp+0x90], xmm10
00007aa3a45da89e  vmovaps [rsp+0xA0], xmm11
00007aa3a45da8a7  vmovaps [rsp+0xB0], xmm12
00007aa3a45da8b0  vmovaps [rsp+0xC0], xmm13
00007aa3a45da8b9  vmovaps [rsp+0xD0], xmm14
00007aa3a45da8c2  vmovaps [rsp+0xE0], xmm15
00007aa3a45da8cb  sub rsp, 0x30
00007aa3a45da8cf  movaps [rsp], xmm7
00007aa3a45da8d3  movaps [rsp+0x10], xmm11
00007aa3a45da8d9  movaps [rsp+0x20], xmm9
00007aa3a45da8df  lea rdi, [rsp]
00007aa3a45da8e3  mov esi, 0x00
00007aa3a45da8e8  mov rax, 0x5F551B683530
00007aa3a45da8f2  call rax
00007aa3a45da8f4  movaps xmm7, [rsp]
00007aa3a45da8f8  add rsp, 0x30
00007aa3a45da8fc  vmovaps xmm0, [rsp]
00007aa3a45da901  vmovaps xmm1, [rsp+0x10]
00007aa3a45da907  vmovaps xmm2, [rsp+0x20]
00007aa3a45da90d  vmovaps xmm3, [rsp+0x30]
00007aa3a45da913  vmovaps xmm4, [rsp+0x40]
00007aa3a45da919  vmovaps xmm5, [rsp+0x50]
00007aa3a45da91f  vmovaps xmm6, [rsp+0x60]
00007aa3a45da925  vmovaps xmm8, [rsp+0x70]
00007aa3a45da92b  vmovaps xmm9, [rsp+0x80]
00007aa3a45da934  vmovaps xmm10, [rsp+0x90]
00007aa3a45da93d  vmovaps xmm11, [rsp+0xA0]
00007aa3a45da946  vmovaps xmm12, [rsp+0xB0]
00007aa3a45da94f  vmovaps xmm13, [rsp+0xC0]
00007aa3a45da958  vmovaps xmm14, [rsp+0xD0]
00007aa3a45da961  vmovaps xmm15, [rsp+0xE0]
00007aa3a45da96a  add rsp, 0xF0
00007aa3a45da971  pop r11
00007aa3a45da973  pop r10
00007aa3a45da975  pop r9
00007aa3a45da977  pop r8
00007aa3a45da979  pop rsi
00007aa3a45da97a  pop rdi
00007aa3a45da97b  pop rdx
00007aa3a45da97c  pop rcx
00007aa3a45da97d  pop rax
00007aa3a45da97e  add rsp, 0x08
00007aa3a45da982  jmp 0x00007AA3A45D64D2
00007aa3a45da987  sub rsp, 0x08
00007aa3a45da98b  push rax
00007aa3a45da98c  push rcx
00007aa3a45da98d  push rdx
00007aa3a45da98e  push rdi
00007aa3a45da98f  push rsi
00007aa3a45da990  push r8
00007aa3a45da992  push r9
00007aa3a45da994  push r10
00007aa3a45da996  push r11
00007aa3a45da998  sub rsp, 0xF0
00007aa3a45da99f  vmovaps [rsp], xmm0
00007aa3a45da9a4  vmovaps [rsp+0x10], xmm1
00007aa3a45da9aa  vmovaps [rsp+0x20], xmm2
00007aa3a45da9b0  vmovaps [rsp+0x30], xmm3
00007aa3a45da9b6  vmovaps [rsp+0x40], xmm4
00007aa3a45da9bc  vmovaps [rsp+0x50], xmm5
00007aa3a45da9c2  vmovaps [rsp+0x60], xmm6
00007aa3a45da9c8  vmovaps [rsp+0x70], xmm7
00007aa3a45da9ce  vmovaps [rsp+0x80], xmm8
00007aa3a45da9d7  vmovaps [rsp+0x90], xmm9
00007aa3a45da9e0  vmovaps [rsp+0xA0], xmm10
00007aa3a45da9e9  vmovaps [rsp+0xB0], xmm12
00007aa3a45da9f2  vmovaps [rsp+0xC0], xmm13
00007aa3a45da9fb  vmovaps [rsp+0xD0], xmm14
00007aa3a45daa04  vmovaps [rsp+0xE0], xmm15
00007aa3a45daa0d  sub rsp, 0x30
00007aa3a45daa11  movaps [rsp], xmm11
00007aa3a45daa16  movaps [rsp+0x10], xmm10
00007aa3a45daa1c  movaps [rsp+0x20], xmm14
00007aa3a45daa22  lea rdi, [rsp]
00007aa3a45daa26  mov esi, 0x00
00007aa3a45daa2b  mov rax, 0x5F551B683530
00007aa3a45daa35  call rax
00007aa3a45daa37  movaps xmm11, [rsp]
00007aa3a45daa3c  add rsp, 0x30
00007aa3a45daa40  vmovaps xmm0, [rsp]
00007aa3a45daa45  vmovaps xmm1, [rsp+0x10]
00007aa3a45daa4b  vmovaps xmm2, [rsp+0x20]
00007aa3a45daa51  vmovaps xmm3, [rsp+0x30]
00007aa3a45daa57  vmovaps xmm4, [rsp+0x40]
00007aa3a45daa5d  vmovaps xmm5, [rsp+0x50]
00007aa3a45daa63  vmovaps xmm6, [rsp+0x60]
00007aa3a45daa69  vmovaps xmm7, [rsp+0x70]
00007aa3a45daa6f  vmovaps xmm8, [rsp+0x80]
00007aa3a45daa78  vmovaps xmm9, [rsp+0x90]
00007aa3a45daa81  vmovaps xmm10, [rsp+0xA0]
00007aa3a45daa8a  vmovaps xmm12, [rsp+0xB0]
00007aa3a45daa93  vmovaps xmm13, [rsp+0xC0]
00007aa3a45daa9c  vmovaps xmm14, [rsp+0xD0]
00007aa3a45daaa5  vmovaps xmm15, [rsp+0xE0]
00007aa3a45daaae  add rsp, 0xF0
00007aa3a45daab5  pop r11
00007aa3a45daab7  pop r10
00007aa3a45daab9  pop r9
00007aa3a45daabb  pop r8
00007aa3a45daabd  pop rsi
00007aa3a45daabe  pop rdi
00007aa3a45daabf  pop rdx
00007aa3a45daac0  pop rcx
00007aa3a45daac1  pop rax
00007aa3a45daac2  add rsp, 0x08
00007aa3a45daac6  jmp 0x00007AA3A45D64ED
00007aa3a45daacb  call 0x00007AA3A44E45A0
00007aa3a45daad0  jmp 0x00007AA3A45D64F7
00007aa3a45daad5  sub rsp, 0x08
00007aa3a45daad9  push rax
00007aa3a45daada  push rcx
00007aa3a45daadb  push rdx
00007aa3a45daadc  push rdi
00007aa3a45daadd  push rsi
00007aa3a45daade  push r8
00007aa3a45daae0  push r9
00007aa3a45daae2  push r10
00007aa3a45daae4  push r11
00007aa3a45daae6  sub rsp, 0xF0
00007aa3a45daaed  vmovaps [rsp], xmm0
00007aa3a45daaf2  vmovaps [rsp+0x10], xmm1
00007aa3a45daaf8  vmovaps [rsp+0x20], xmm2
00007aa3a45daafe  vmovaps [rsp+0x30], xmm3
00007aa3a45dab04  vmovaps [rsp+0x40], xmm4
00007aa3a45dab0a  vmovaps [rsp+0x50], xmm5
00007aa3a45dab10  vmovaps [rsp+0x60], xmm6
00007aa3a45dab16  vmovaps [rsp+0x70], xmm7
00007aa3a45dab1c  vmovaps [rsp+0x80], xmm8
00007aa3a45dab25  vmovaps [rsp+0x90], xmm9
00007aa3a45dab2e  vmovaps [rsp+0xA0], xmm11
00007aa3a45dab37  vmovaps [rsp+0xB0], xmm12
00007aa3a45dab40  vmovaps [rsp+0xC0], xmm13
00007aa3a45dab49  vmovaps [rsp+0xD0], xmm14
00007aa3a45dab52  vmovaps [rsp+0xE0], xmm15
00007aa3a45dab5b  sub rsp, 0x30
00007aa3a45dab5f  movaps [rsp], xmm10
00007aa3a45dab64  movaps [rsp+0x10], xmm1
00007aa3a45dab69  movaps [rsp+0x20], xmm12
00007aa3a45dab6f  lea rdi, [rsp]
00007aa3a45dab73  mov esi, 0x00
00007aa3a45dab78  mov rax, 0x5F551B683530
00007aa3a45dab82  call rax
00007aa3a45dab84  movaps xmm10, [rsp]
00007aa3a45dab89  add rsp, 0x30
00007aa3a45dab8d  vmovaps xmm0, [rsp]
00007aa3a45dab92  vmovaps xmm1, [rsp+0x10]
00007aa3a45dab98  vmovaps xmm2, [rsp+0x20]
00007aa3a45dab9e  vmovaps xmm3, [rsp+0x30]
00007aa3a45daba4  vmovaps xmm4, [rsp+0x40]
00007aa3a45dabaa  vmovaps xmm5, [rsp+0x50]
00007aa3a45dabb0  vmovaps xmm6, [rsp+0x60]
00007aa3a45dabb6  vmovaps xmm7, [rsp+0x70]
00007aa3a45dabbc  vmovaps xmm8, [rsp+0x80]
00007aa3a45dabc5  vmovaps xmm9, [rsp+0x90]
00007aa3a45dabce  vmovaps xmm11, [rsp+0xA0]
00007aa3a45dabd7  vmovaps xmm12, [rsp+0xB0]
00007aa3a45dabe0  vmovaps xmm13, [rsp+0xC0]
00007aa3a45dabe9  vmovaps xmm14, [rsp+0xD0]
00007aa3a45dabf2  vmovaps xmm15, [rsp+0xE0]
00007aa3a45dabfb  add rsp, 0xF0
00007aa3a45dac02  pop r11
00007aa3a45dac04  pop r10
00007aa3a45dac06  pop r9
00007aa3a45dac08  pop r8
00007aa3a45dac0a  pop rsi
00007aa3a45dac0b  pop rdi
00007aa3a45dac0c  pop rdx
00007aa3a45dac0d  pop rcx
00007aa3a45dac0e  pop rax
00007aa3a45dac0f  add rsp, 0x08
00007aa3a45dac13  jmp 0x00007AA3A45D651A
00007aa3a45dac18  sub rsp, 0x08
00007aa3a45dac1c  push rax
00007aa3a45dac1d  push rcx
00007aa3a45dac1e  push rdx
00007aa3a45dac1f  push rdi
00007aa3a45dac20  push rsi
00007aa3a45dac21  push r8
00007aa3a45dac23  push r9
00007aa3a45dac25  push r10
00007aa3a45dac27  push r11
00007aa3a45dac29  sub rsp, 0xF0
00007aa3a45dac30  vmovaps [rsp], xmm0
00007aa3a45dac35  vmovaps [rsp+0x10], xmm1
00007aa3a45dac3b  vmovaps [rsp+0x20], xmm2
00007aa3a45dac41  vmovaps [rsp+0x30], xmm3
00007aa3a45dac47  vmovaps [rsp+0x40], xmm4
00007aa3a45dac4d  vmovaps [rsp+0x50], xmm5
00007aa3a45dac53  vmovaps [rsp+0x60], xmm6
00007aa3a45dac59  vmovaps [rsp+0x70], xmm7
00007aa3a45dac5f  vmovaps [rsp+0x80], xmm8
00007aa3a45dac68  vmovaps [rsp+0x90], xmm9
00007aa3a45dac71  vmovaps [rsp+0xA0], xmm10
00007aa3a45dac7a  vmovaps [rsp+0xB0], xmm11
00007aa3a45dac83  vmovaps [rsp+0xC0], xmm13
00007aa3a45dac8c  vmovaps [rsp+0xD0], xmm14
00007aa3a45dac95  vmovaps [rsp+0xE0], xmm15
00007aa3a45dac9e  sub rsp, 0x30
00007aa3a45daca2  movaps [rsp], xmm12
00007aa3a45daca7  movaps [rsp+0x10], xmm14
00007aa3a45dacad  movaps [rsp+0x20], xmm1
00007aa3a45dacb2  lea rdi, [rsp]
00007aa3a45dacb6  mov esi, 0x00
00007aa3a45dacbb  mov rax, 0x5F551B683530
00007aa3a45dacc5  call rax
00007aa3a45dacc7  movaps xmm12, [rsp]
00007aa3a45daccc  add rsp, 0x30
00007aa3a45dacd0  vmovaps xmm0, [rsp]
00007aa3a45dacd5  vmovaps xmm1, [rsp+0x10]
00007aa3a45dacdb  vmovaps xmm2, [rsp+0x20]
00007aa3a45dace1  vmovaps xmm3, [rsp+0x30]
00007aa3a45dace7  vmovaps xmm4, [rsp+0x40]
00007aa3a45daced  vmovaps xmm5, [rsp+0x50]
00007aa3a45dacf3  vmovaps xmm6, [rsp+0x60]
00007aa3a45dacf9  vmovaps xmm7, [rsp+0x70]
00007aa3a45dacff  vmovaps xmm8, [rsp+0x80]
00007aa3a45dad08  vmovaps xmm9, [rsp+0x90]
00007aa3a45dad11  vmovaps xmm10, [rsp+0xA0]
00007aa3a45dad1a  vmovaps xmm11, [rsp+0xB0]
00007aa3a45dad23  vmovaps xmm13, [rsp+0xC0]
00007aa3a45dad2c  vmovaps xmm14, [rsp+0xD0]
00007aa3a45dad35  vmovaps xmm15, [rsp+0xE0]
00007aa3a45dad3e  add rsp, 0xF0
00007aa3a45dad45  pop r11
00007aa3a45dad47  pop r10
00007aa3a45dad49  pop r9
00007aa3a45dad4b  pop r8
00007aa3a45dad4d  pop rsi
00007aa3a45dad4e  pop rdi
00007aa3a45dad4f  pop rdx
00007aa3a45dad50  pop rcx
00007aa3a45dad51  pop rax
00007aa3a45dad52  add rsp, 0x08
00007aa3a45dad56  jmp 0x00007AA3A45D6549
00007aa3a45dad5b  sub rsp, 0x08
00007aa3a45dad5f  push rax
00007aa3a45dad60  push rcx
00007aa3a45dad61  push rdx
00007aa3a45dad62  push rdi
00007aa3a45dad63  push rsi
00007aa3a45dad64  push r8
00007aa3a45dad66  push r9
00007aa3a45dad68  push r10
00007aa3a45dad6a  push r11
00007aa3a45dad6c  sub rsp, 0xF0
00007aa3a45dad73  vmovaps [rsp], xmm0
00007aa3a45dad78  vmovaps [rsp+0x10], xmm1
00007aa3a45dad7e  vmovaps [rsp+0x20], xmm2
00007aa3a45dad84  vmovaps [rsp+0x30], xmm3
00007aa3a45dad8a  vmovaps [rsp+0x40], xmm4
00007aa3a45dad90  vmovaps [rsp+0x50], xmm5
00007aa3a45dad96  vmovaps [rsp+0x60], xmm6
00007aa3a45dad9c  vmovaps [rsp+0x70], xmm7
00007aa3a45dada2  vmovaps [rsp+0x80], xmm8
00007aa3a45dadab  vmovaps [rsp+0x90], xmm9
00007aa3a45dadb4  vmovaps [rsp+0xA0], xmm10
00007aa3a45dadbd  vmovaps [rsp+0xB0], xmm11
00007aa3a45dadc6  vmovaps [rsp+0xC0], xmm12
00007aa3a45dadcf  vmovaps [rsp+0xD0], xmm13
00007aa3a45dadd8  vmovaps [rsp+0xE0], xmm15
00007aa3a45dade1  sub rsp, 0x30
00007aa3a45dade5  movaps [rsp], xmm14
00007aa3a45dadea  movaps [rsp+0x10], xmm9
00007aa3a45dadf0  movaps [rsp+0x20], xmm1
00007aa3a45dadf5  lea rdi, [rsp]
00007aa3a45dadf9  mov esi, 0x00
00007aa3a45dadfe  mov rax, 0x5F551B683530
00007aa3a45dae08  call rax
00007aa3a45dae0a  movaps xmm14, [rsp]
00007aa3a45dae0f  add rsp, 0x30
00007aa3a45dae13  vmovaps xmm0, [rsp]
00007aa3a45dae18  vmovaps xmm1, [rsp+0x10]
00007aa3a45dae1e  vmovaps xmm2, [rsp+0x20]
00007aa3a45dae24  vmovaps xmm3, [rsp+0x30]
00007aa3a45dae2a  vmovaps xmm4, [rsp+0x40]
00007aa3a45dae30  vmovaps xmm5, [rsp+0x50]
00007aa3a45dae36  vmovaps xmm6, [rsp+0x60]
00007aa3a45dae3c  vmovaps xmm7, [rsp+0x70]
00007aa3a45dae42  vmovaps xmm8, [rsp+0x80]
00007aa3a45dae4b  vmovaps xmm9, [rsp+0x90]
00007aa3a45dae54  vmovaps xmm10, [rsp+0xA0]
00007aa3a45dae5d  vmovaps xmm11, [rsp+0xB0]
00007aa3a45dae66  vmovaps xmm12, [rsp+0xC0]
00007aa3a45dae6f  vmovaps xmm13, [rsp+0xD0]
00007aa3a45dae78  vmovaps xmm15, [rsp+0xE0]
00007aa3a45dae81  add rsp, 0xF0
00007aa3a45dae88  pop r11
00007aa3a45dae8a  pop r10
00007aa3a45dae8c  pop r9
00007aa3a45dae8e  pop r8
00007aa3a45dae90  pop rsi
00007aa3a45dae91  pop rdi
00007aa3a45dae92  pop rdx
00007aa3a45dae93  pop rcx
00007aa3a45dae94  pop rax
00007aa3a45dae95  add rsp, 0x08
00007aa3a45dae99  jmp 0x00007AA3A45D6578
00007aa3a45dae9e  sub rsp, 0x08
00007aa3a45daea2  push rax
00007aa3a45daea3  push rcx
00007aa3a45daea4  push rdx
00007aa3a45daea5  push rdi
00007aa3a45daea6  push rsi
00007aa3a45daea7  push r8
00007aa3a45daea9  push r9
00007aa3a45daeab  push r10
00007aa3a45daead  push r11
00007aa3a45daeaf  sub rsp, 0xF0
00007aa3a45daeb6  vmovaps [rsp], xmm0
00007aa3a45daebb  vmovaps [rsp+0x10], xmm2
00007aa3a45daec1  vmovaps [rsp+0x20], xmm3
00007aa3a45daec7  vmovaps [rsp+0x30], xmm4
00007aa3a45daecd  vmovaps [rsp+0x40], xmm5
00007aa3a45daed3  vmovaps [rsp+0x50], xmm6
00007aa3a45daed9  vmovaps [rsp+0x60], xmm7
00007aa3a45daedf  vmovaps [rsp+0x70], xmm8
00007aa3a45daee5  vmovaps [rsp+0x80], xmm9
00007aa3a45daeee  vmovaps [rsp+0x90], xmm10
00007aa3a45daef7  vmovaps [rsp+0xA0], xmm11
00007aa3a45daf00  vmovaps [rsp+0xB0], xmm12
00007aa3a45daf09  vmovaps [rsp+0xC0], xmm13
00007aa3a45daf12  vmovaps [rsp+0xD0], xmm14
00007aa3a45daf1b  vmovaps [rsp+0xE0], xmm15
00007aa3a45daf24  sub rsp, 0x30
00007aa3a45daf28  movaps [rsp], xmm1
00007aa3a45daf2c  movaps [rsp+0x10], xmm13
00007aa3a45daf32  movaps [rsp+0x20], xmm8
00007aa3a45daf38  lea rdi, [rsp]
00007aa3a45daf3c  mov esi, 0x00
00007aa3a45daf41  mov rax, 0x5F551B683530
00007aa3a45daf4b  call rax
00007aa3a45daf4d  movaps xmm1, [rsp]
00007aa3a45daf51  add rsp, 0x30
00007aa3a45daf55  vmovaps xmm0, [rsp]
00007aa3a45daf5a  vmovaps xmm2, [rsp+0x10]
00007aa3a45daf60  vmovaps xmm3, [rsp+0x20]
00007aa3a45daf66  vmovaps xmm4, [rsp+0x30]
00007aa3a45daf6c  vmovaps xmm5, [rsp+0x40]
00007aa3a45daf72  vmovaps xmm6, [rsp+0x50]
00007aa3a45daf78  vmovaps xmm7, [rsp+0x60]
00007aa3a45daf7e  vmovaps xmm8, [rsp+0x70]
00007aa3a45daf84  vmovaps xmm9, [rsp+0x80]
00007aa3a45daf8d  vmovaps xmm10, [rsp+0x90]
00007aa3a45daf96  vmovaps xmm11, [rsp+0xA0]
00007aa3a45daf9f  vmovaps xmm12, [rsp+0xB0]
00007aa3a45dafa8  vmovaps xmm13, [rsp+0xC0]
00007aa3a45dafb1  vmovaps xmm14, [rsp+0xD0]
00007aa3a45dafba  vmovaps xmm15, [rsp+0xE0]
00007aa3a45dafc3  add rsp, 0xF0
00007aa3a45dafca  pop r11
00007aa3a45dafcc  pop r10
00007aa3a45dafce  pop r9
00007aa3a45dafd0  pop r8
00007aa3a45dafd2  pop rsi
00007aa3a45dafd3  pop rdi
00007aa3a45dafd4  pop rdx
00007aa3a45dafd5  pop rcx
00007aa3a45dafd6  pop rax
00007aa3a45dafd7  add rsp, 0x08
00007aa3a45dafdb  jmp 0x00007AA3A45D659A
00007aa3a45dafe0  call 0x00007AA3A440C260
00007aa3a45dafe5  jmp 0x00007AA3A45D65A8
00007aa3a45dafea  call 0x00007AA3A44DE950
00007aa3a45dafef  jmp 0x00007AA3A45D65B2
00007aa3a45daff4  sub rsp, 0x08
00007aa3a45daff8  push rax
00007aa3a45daff9  push rcx
00007aa3a45daffa  push rdx
00007aa3a45daffb  push rdi
00007aa3a45daffc  push rsi
00007aa3a45daffd  push r8
00007aa3a45dafff  push r9
00007aa3a45db001  push r10
00007aa3a45db003  push r11
00007aa3a45db005  sub rsp, 0xF0
00007aa3a45db00c  vmovaps [rsp], xmm0
00007aa3a45db011  vmovaps [rsp+0x10], xmm1
00007aa3a45db017  vmovaps [rsp+0x20], xmm2
00007aa3a45db01d  vmovaps [rsp+0x30], xmm3
00007aa3a45db023  vmovaps [rsp+0x40], xmm4
00007aa3a45db029  vmovaps [rsp+0x50], xmm5
00007aa3a45db02f  vmovaps [rsp+0x60], xmm6
00007aa3a45db035  vmovaps [rsp+0x70], xmm7
00007aa3a45db03b  vmovaps [rsp+0x80], xmm9
00007aa3a45db044  vmovaps [rsp+0x90], xmm10
00007aa3a45db04d  vmovaps [rsp+0xA0], xmm11
00007aa3a45db056  vmovaps [rsp+0xB0], xmm12
00007aa3a45db05f  vmovaps [rsp+0xC0], xmm13
00007aa3a45db068  vmovaps [rsp+0xD0], xmm14
00007aa3a45db071  vmovaps [rsp+0xE0], xmm15
00007aa3a45db07a  sub rsp, 0x30
00007aa3a45db07e  movaps [rsp], xmm8
00007aa3a45db083  movaps [rsp+0x10], xmm15
00007aa3a45db089  movaps [rsp+0x20], xmm7
00007aa3a45db08e  lea rdi, [rsp]
00007aa3a45db092  mov esi, 0x00
00007aa3a45db097  mov rax, 0x5F551B683530
00007aa3a45db0a1  call rax
00007aa3a45db0a3  movaps xmm8, [rsp]
00007aa3a45db0a8  add rsp, 0x30
00007aa3a45db0ac  vmovaps xmm0, [rsp]
00007aa3a45db0b1  vmovaps xmm1, [rsp+0x10]
00007aa3a45db0b7  vmovaps xmm2, [rsp+0x20]
00007aa3a45db0bd  vmovaps xmm3, [rsp+0x30]
00007aa3a45db0c3  vmovaps xmm4, [rsp+0x40]
00007aa3a45db0c9  vmovaps xmm5, [rsp+0x50]
00007aa3a45db0cf  vmovaps xmm6, [rsp+0x60]
00007aa3a45db0d5  vmovaps xmm7, [rsp+0x70]
00007aa3a45db0db  vmovaps xmm9, [rsp+0x80]
00007aa3a45db0e4  vmovaps xmm10, [rsp+0x90]
00007aa3a45db0ed  vmovaps xmm11, [rsp+0xA0]
00007aa3a45db0f6  vmovaps xmm12, [rsp+0xB0]
00007aa3a45db0ff  vmovaps xmm13, [rsp+0xC0]
00007aa3a45db108  vmovaps xmm14, [rsp+0xD0]
00007aa3a45db111  vmovaps xmm15, [rsp+0xE0]
00007aa3a45db11a  add rsp, 0xF0
00007aa3a45db121  pop r11
00007aa3a45db123  pop r10
00007aa3a45db125  pop r9
00007aa3a45db127  pop r8
00007aa3a45db129  pop rsi
00007aa3a45db12a  pop rdi
00007aa3a45db12b  pop rdx
00007aa3a45db12c  pop rcx
00007aa3a45db12d  pop rax
00007aa3a45db12e  add rsp, 0x08
00007aa3a45db132  jmp 0x00007AA3A45D65D4
00007aa3a45db137  sub rsp, 0x08
00007aa3a45db13b  push rax
00007aa3a45db13c  push rcx
00007aa3a45db13d  push rdx
00007aa3a45db13e  push rdi
00007aa3a45db13f  push rsi
00007aa3a45db140  push r8
00007aa3a45db142  push r9
00007aa3a45db144  push r10
00007aa3a45db146  push r11
00007aa3a45db148  sub rsp, 0xF0
00007aa3a45db14f  vmovaps [rsp], xmm0
00007aa3a45db154  vmovaps [rsp+0x10], xmm1
00007aa3a45db15a  vmovaps [rsp+0x20], xmm2
00007aa3a45db160  vmovaps [rsp+0x30], xmm3
00007aa3a45db166  vmovaps [rsp+0x40], xmm4
00007aa3a45db16c  vmovaps [rsp+0x50], xmm5
00007aa3a45db172  vmovaps [rsp+0x60], xmm6
00007aa3a45db178  vmovaps [rsp+0x70], xmm8
00007aa3a45db17e  vmovaps [rsp+0x80], xmm9
00007aa3a45db187  vmovaps [rsp+0x90], xmm10
00007aa3a45db190  vmovaps [rsp+0xA0], xmm11
00007aa3a45db199  vmovaps [rsp+0xB0], xmm12
00007aa3a45db1a2  vmovaps [rsp+0xC0], xmm13
00007aa3a45db1ab  vmovaps [rsp+0xD0], xmm14
00007aa3a45db1b4  vmovaps [rsp+0xE0], xmm15
00007aa3a45db1bd  sub rsp, 0x30
00007aa3a45db1c1  movaps [rsp], xmm7
00007aa3a45db1c5  movaps [rsp+0x10], xmm9
00007aa3a45db1cb  movaps [rsp+0x20], xmm15
00007aa3a45db1d1  lea rdi, [rsp]
00007aa3a45db1d5  mov esi, 0x00
00007aa3a45db1da  mov rax, 0x5F551B683530
00007aa3a45db1e4  call rax
00007aa3a45db1e6  movaps xmm7, [rsp]
00007aa3a45db1ea  add rsp, 0x30
00007aa3a45db1ee  vmovaps xmm0, [rsp]
00007aa3a45db1f3  vmovaps xmm1, [rsp+0x10]
00007aa3a45db1f9  vmovaps xmm2, [rsp+0x20]
00007aa3a45db1ff  vmovaps xmm3, [rsp+0x30]
00007aa3a45db205  vmovaps xmm4, [rsp+0x40]
00007aa3a45db20b  vmovaps xmm5, [rsp+0x50]
00007aa3a45db211  vmovaps xmm6, [rsp+0x60]
00007aa3a45db217  vmovaps xmm8, [rsp+0x70]
00007aa3a45db21d  vmovaps xmm9, [rsp+0x80]
00007aa3a45db226  vmovaps xmm10, [rsp+0x90]
00007aa3a45db22f  vmovaps xmm11, [rsp+0xA0]
00007aa3a45db238  vmovaps xmm12, [rsp+0xB0]
00007aa3a45db241  vmovaps xmm13, [rsp+0xC0]
00007aa3a45db24a  vmovaps xmm14, [rsp+0xD0]
00007aa3a45db253  vmovaps xmm15, [rsp+0xE0]
00007aa3a45db25c  add rsp, 0xF0
00007aa3a45db263  pop r11
00007aa3a45db265  pop r10
00007aa3a45db267  pop r9
00007aa3a45db269  pop r8
00007aa3a45db26b  pop rsi
00007aa3a45db26c  pop rdi
00007aa3a45db26d  pop rdx
00007aa3a45db26e  pop rcx
00007aa3a45db26f  pop rax
00007aa3a45db270  add rsp, 0x08
00007aa3a45db274  jmp 0x00007AA3A45D6601
00007aa3a45db279  sub rsp, 0x08
00007aa3a45db27d  push rax
00007aa3a45db27e  push rcx
00007aa3a45db27f  push rdx
00007aa3a45db280  push rdi
00007aa3a45db281  push rsi
00007aa3a45db282  push r8
00007aa3a45db284  push r9
00007aa3a45db286  push r10
00007aa3a45db288  push r11
00007aa3a45db28a  sub rsp, 0xF0
00007aa3a45db291  vmovaps [rsp], xmm0
00007aa3a45db296  vmovaps [rsp+0x10], xmm1
00007aa3a45db29c  vmovaps [rsp+0x20], xmm2
00007aa3a45db2a2  vmovaps [rsp+0x30], xmm3
00007aa3a45db2a8  vmovaps [rsp+0x40], xmm4
00007aa3a45db2ae  vmovaps [rsp+0x50], xmm5
00007aa3a45db2b4  vmovaps [rsp+0x60], xmm6
00007aa3a45db2ba  vmovaps [rsp+0x70], xmm7
00007aa3a45db2c0  vmovaps [rsp+0x80], xmm8
00007aa3a45db2c9  vmovaps [rsp+0x90], xmm10
00007aa3a45db2d2  vmovaps [rsp+0xA0], xmm11
00007aa3a45db2db  vmovaps [rsp+0xB0], xmm12
00007aa3a45db2e4  vmovaps [rsp+0xC0], xmm13
00007aa3a45db2ed  vmovaps [rsp+0xD0], xmm14
00007aa3a45db2f6  vmovaps [rsp+0xE0], xmm15
00007aa3a45db2ff  sub rsp, 0x30
00007aa3a45db303  movaps [rsp], xmm9
00007aa3a45db308  movaps [rsp+0x10], xmm13
00007aa3a45db30e  movaps [rsp+0x20], xmm15
00007aa3a45db314  lea rdi, [rsp]
00007aa3a45db318  mov esi, 0x00
00007aa3a45db31d  mov rax, 0x5F551B683530
00007aa3a45db327  call rax
00007aa3a45db329  movaps xmm9, [rsp]
00007aa3a45db32e  add rsp, 0x30
00007aa3a45db332  vmovaps xmm0, [rsp]
00007aa3a45db337  vmovaps xmm1, [rsp+0x10]
00007aa3a45db33d  vmovaps xmm2, [rsp+0x20]
00007aa3a45db343  vmovaps xmm3, [rsp+0x30]
00007aa3a45db349  vmovaps xmm4, [rsp+0x40]
00007aa3a45db34f  vmovaps xmm5, [rsp+0x50]
00007aa3a45db355  vmovaps xmm6, [rsp+0x60]
00007aa3a45db35b  vmovaps xmm7, [rsp+0x70]
00007aa3a45db361  vmovaps xmm8, [rsp+0x80]
00007aa3a45db36a  vmovaps xmm10, [rsp+0x90]
00007aa3a45db373  vmovaps xmm11, [rsp+0xA0]
00007aa3a45db37c  vmovaps xmm12, [rsp+0xB0]
00007aa3a45db385  vmovaps xmm13, [rsp+0xC0]
00007aa3a45db38e  vmovaps xmm14, [rsp+0xD0]
00007aa3a45db397  vmovaps xmm15, [rsp+0xE0]
00007aa3a45db3a0  add rsp, 0xF0
00007aa3a45db3a7  pop r11
00007aa3a45db3a9  pop r10
00007aa3a45db3ab  pop r9
00007aa3a45db3ad  pop r8
00007aa3a45db3af  pop rsi
00007aa3a45db3b0  pop rdi
00007aa3a45db3b1  pop rdx
00007aa3a45db3b2  pop rcx
00007aa3a45db3b3  pop rax
00007aa3a45db3b4  add rsp, 0x08
00007aa3a45db3b8  jmp 0x00007AA3A45D662F
00007aa3a45db3bd  sub rsp, 0x08
00007aa3a45db3c1  push rax
00007aa3a45db3c2  push rcx
00007aa3a45db3c3  push rdx
00007aa3a45db3c4  push rdi
00007aa3a45db3c5  push rsi
00007aa3a45db3c6  push r8
00007aa3a45db3c8  push r9
00007aa3a45db3ca  push r10
00007aa3a45db3cc  push r11
00007aa3a45db3ce  sub rsp, 0xF0
00007aa3a45db3d5  vmovaps [rsp], xmm0
00007aa3a45db3da  vmovaps [rsp+0x10], xmm1
00007aa3a45db3e0  vmovaps [rsp+0x20], xmm2
00007aa3a45db3e6  vmovaps [rsp+0x30], xmm3
00007aa3a45db3ec  vmovaps [rsp+0x40], xmm4
00007aa3a45db3f2  vmovaps [rsp+0x50], xmm5
00007aa3a45db3f8  vmovaps [rsp+0x60], xmm6
00007aa3a45db3fe  vmovaps [rsp+0x70], xmm7
00007aa3a45db404  vmovaps [rsp+0x80], xmm8
00007aa3a45db40d  vmovaps [rsp+0x90], xmm9
00007aa3a45db416  vmovaps [rsp+0xA0], xmm10
00007aa3a45db41f  vmovaps [rsp+0xB0], xmm11
00007aa3a45db428  vmovaps [rsp+0xC0], xmm12
00007aa3a45db431  vmovaps [rsp+0xD0], xmm13
00007aa3a45db43a  vmovaps [rsp+0xE0], xmm14
00007aa3a45db443  sub rsp, 0x30
00007aa3a45db447  movaps [rsp], xmm15
00007aa3a45db44c  movaps [rsp+0x10], xmm11
00007aa3a45db452  movaps [rsp+0x20], xmm12
00007aa3a45db458  lea rdi, [rsp]
00007aa3a45db45c  mov esi, 0x00
00007aa3a45db461  mov rax, 0x5F551B683530
00007aa3a45db46b  call rax
00007aa3a45db46d  movaps xmm15, [rsp]
00007aa3a45db472  add rsp, 0x30
00007aa3a45db476  vmovaps xmm0, [rsp]
00007aa3a45db47b  vmovaps xmm1, [rsp+0x10]
00007aa3a45db481  vmovaps xmm2, [rsp+0x20]
00007aa3a45db487  vmovaps xmm3, [rsp+0x30]
00007aa3a45db48d  vmovaps xmm4, [rsp+0x40]
00007aa3a45db493  vmovaps xmm5, [rsp+0x50]
00007aa3a45db499  vmovaps xmm6, [rsp+0x60]
00007aa3a45db49f  vmovaps xmm7, [rsp+0x70]
00007aa3a45db4a5  vmovaps xmm8, [rsp+0x80]
00007aa3a45db4ae  vmovaps xmm9, [rsp+0x90]
00007aa3a45db4b7  vmovaps xmm10, [rsp+0xA0]
00007aa3a45db4c0  vmovaps xmm11, [rsp+0xB0]
00007aa3a45db4c9  vmovaps xmm12, [rsp+0xC0]
00007aa3a45db4d2  vmovaps xmm13, [rsp+0xD0]
00007aa3a45db4db  vmovaps xmm14, [rsp+0xE0]
00007aa3a45db4e4  add rsp, 0xF0
00007aa3a45db4eb  pop r11
00007aa3a45db4ed  pop r10
00007aa3a45db4ef  pop r9
00007aa3a45db4f1  pop r8
00007aa3a45db4f3  pop rsi
00007aa3a45db4f4  pop rdi
00007aa3a45db4f5  pop rdx
00007aa3a45db4f6  pop rcx
00007aa3a45db4f7  pop rax
00007aa3a45db4f8  add rsp, 0x08
00007aa3a45db4fc  jmp 0x00007AA3A45D664A
00007aa3a45db501  sub rsp, 0x08
00007aa3a45db505  push rax
00007aa3a45db506  push rcx
00007aa3a45db507  push rdx
00007aa3a45db508  push rdi
00007aa3a45db509  push rsi
00007aa3a45db50a  push r8
00007aa3a45db50c  push r9
00007aa3a45db50e  push r10
00007aa3a45db510  push r11
00007aa3a45db512  sub rsp, 0xF0
00007aa3a45db519  vmovaps [rsp], xmm0
00007aa3a45db51e  vmovaps [rsp+0x10], xmm1
00007aa3a45db524  vmovaps [rsp+0x20], xmm2
00007aa3a45db52a  vmovaps [rsp+0x30], xmm3
00007aa3a45db530  vmovaps [rsp+0x40], xmm4
00007aa3a45db536  vmovaps [rsp+0x50], xmm5
00007aa3a45db53c  vmovaps [rsp+0x60], xmm6
00007aa3a45db542  vmovaps [rsp+0x70], xmm7
00007aa3a45db548  vmovaps [rsp+0x80], xmm8
00007aa3a45db551  vmovaps [rsp+0x90], xmm9
00007aa3a45db55a  vmovaps [rsp+0xA0], xmm10
00007aa3a45db563  vmovaps [rsp+0xB0], xmm11
00007aa3a45db56c  vmovaps [rsp+0xC0], xmm12
00007aa3a45db575  vmovaps [rsp+0xD0], xmm14
00007aa3a45db57e  vmovaps [rsp+0xE0], xmm15
00007aa3a45db587  sub rsp, 0x30
00007aa3a45db58b  movaps [rsp], xmm13
00007aa3a45db590  movaps [rsp+0x10], xmm10
00007aa3a45db596  movaps [rsp+0x20], xmm14
00007aa3a45db59c  lea rdi, [rsp]
00007aa3a45db5a0  mov esi, 0x00
00007aa3a45db5a5  mov rax, 0x5F551B683530
00007aa3a45db5af  call rax
00007aa3a45db5b1  movaps xmm13, [rsp]
00007aa3a45db5b6  add rsp, 0x30
00007aa3a45db5ba  vmovaps xmm0, [rsp]
00007aa3a45db5bf  vmovaps xmm1, [rsp+0x10]
00007aa3a45db5c5  vmovaps xmm2, [rsp+0x20]
00007aa3a45db5cb  vmovaps xmm3, [rsp+0x30]
00007aa3a45db5d1  vmovaps xmm4, [rsp+0x40]
00007aa3a45db5d7  vmovaps xmm5, [rsp+0x50]
00007aa3a45db5dd  vmovaps xmm6, [rsp+0x60]
00007aa3a45db5e3  vmovaps xmm7, [rsp+0x70]
00007aa3a45db5e9  vmovaps xmm8, [rsp+0x80]
00007aa3a45db5f2  vmovaps xmm9, [rsp+0x90]
00007aa3a45db5fb  vmovaps xmm10, [rsp+0xA0]
00007aa3a45db604  vmovaps xmm11, [rsp+0xB0]
00007aa3a45db60d  vmovaps xmm12, [rsp+0xC0]
00007aa3a45db616  vmovaps xmm14, [rsp+0xD0]
00007aa3a45db61f  vmovaps xmm15, [rsp+0xE0]
00007aa3a45db628  add rsp, 0xF0
00007aa3a45db62f  pop r11
00007aa3a45db631  pop r10
00007aa3a45db633  pop r9
00007aa3a45db635  pop r8
00007aa3a45db637  pop rsi
00007aa3a45db638  pop rdi
00007aa3a45db639  pop rdx
00007aa3a45db63a  pop rcx
00007aa3a45db63b  pop rax
00007aa3a45db63c  add rsp, 0x08
00007aa3a45db640  jmp 0x00007AA3A45D666D
00007aa3a45db645  sub rsp, 0x08
00007aa3a45db649  push rax
00007aa3a45db64a  push rcx
00007aa3a45db64b  push rdx
00007aa3a45db64c  push rdi
00007aa3a45db64d  push rsi
00007aa3a45db64e  push r8
00007aa3a45db650  push r9
00007aa3a45db652  push r10
00007aa3a45db654  push r11
00007aa3a45db656  sub rsp, 0xF0
00007aa3a45db65d  vmovaps [rsp], xmm0
00007aa3a45db662  vmovaps [rsp+0x10], xmm1
00007aa3a45db668  vmovaps [rsp+0x20], xmm2
00007aa3a45db66e  vmovaps [rsp+0x30], xmm3
00007aa3a45db674  vmovaps [rsp+0x40], xmm4
00007aa3a45db67a  vmovaps [rsp+0x50], xmm5
00007aa3a45db680  vmovaps [rsp+0x60], xmm6
00007aa3a45db686  vmovaps [rsp+0x70], xmm7
00007aa3a45db68c  vmovaps [rsp+0x80], xmm8
00007aa3a45db695  vmovaps [rsp+0x90], xmm9
00007aa3a45db69e  vmovaps [rsp+0xA0], xmm10
00007aa3a45db6a7  vmovaps [rsp+0xB0], xmm11
00007aa3a45db6b0  vmovaps [rsp+0xC0], xmm12
00007aa3a45db6b9  vmovaps [rsp+0xD0], xmm13
00007aa3a45db6c2  vmovaps [rsp+0xE0], xmm15
00007aa3a45db6cb  sub rsp, 0x30
00007aa3a45db6cf  movaps [rsp], xmm14
00007aa3a45db6d4  movaps [rsp+0x10], xmm1
00007aa3a45db6d9  movaps [rsp+0x20], xmm7
00007aa3a45db6de  lea rdi, [rsp]
00007aa3a45db6e2  mov esi, 0x00
00007aa3a45db6e7  mov rax, 0x5F551B683530
00007aa3a45db6f1  call rax
00007aa3a45db6f3  movaps xmm14, [rsp]
00007aa3a45db6f8  add rsp, 0x30
00007aa3a45db6fc  vmovaps xmm0, [rsp]
00007aa3a45db701  vmovaps xmm1, [rsp+0x10]
00007aa3a45db707  vmovaps xmm2, [rsp+0x20]
00007aa3a45db70d  vmovaps xmm3, [rsp+0x30]
00007aa3a45db713  vmovaps xmm4, [rsp+0x40]
00007aa3a45db719  vmovaps xmm5, [rsp+0x50]
00007aa3a45db71f  vmovaps xmm6, [rsp+0x60]
00007aa3a45db725  vmovaps xmm7, [rsp+0x70]
00007aa3a45db72b  vmovaps xmm8, [rsp+0x80]
00007aa3a45db734  vmovaps xmm9, [rsp+0x90]
00007aa3a45db73d  vmovaps xmm10, [rsp+0xA0]
00007aa3a45db746  vmovaps xmm11, [rsp+0xB0]
00007aa3a45db74f  vmovaps xmm12, [rsp+0xC0]
00007aa3a45db758  vmovaps xmm13, [rsp+0xD0]
00007aa3a45db761  vmovaps xmm15, [rsp+0xE0]
00007aa3a45db76a  add rsp, 0xF0
00007aa3a45db771  pop r11
00007aa3a45db773  pop r10
00007aa3a45db775  pop r9
00007aa3a45db777  pop r8
00007aa3a45db779  pop rsi
00007aa3a45db77a  pop rdi
00007aa3a45db77b  pop rdx
00007aa3a45db77c  pop rcx
00007aa3a45db77d  pop rax
00007aa3a45db77e  add rsp, 0x08
00007aa3a45db782  jmp 0x00007AA3A45D6690
00007aa3a45db787  sub rsp, 0x08
00007aa3a45db78b  push rax
00007aa3a45db78c  push rcx
00007aa3a45db78d  push rdx
00007aa3a45db78e  push rdi
00007aa3a45db78f  push rsi
00007aa3a45db790  push r8
00007aa3a45db792  push r9
00007aa3a45db794  push r10
00007aa3a45db796  push r11
00007aa3a45db798  sub rsp, 0xF0
00007aa3a45db79f  vmovaps [rsp], xmm0
00007aa3a45db7a4  vmovaps [rsp+0x10], xmm2
00007aa3a45db7aa  vmovaps [rsp+0x20], xmm3
00007aa3a45db7b0  vmovaps [rsp+0x30], xmm4
00007aa3a45db7b6  vmovaps [rsp+0x40], xmm5
00007aa3a45db7bc  vmovaps [rsp+0x50], xmm6
00007aa3a45db7c2  vmovaps [rsp+0x60], xmm7
00007aa3a45db7c8  vmovaps [rsp+0x70], xmm8
00007aa3a45db7ce  vmovaps [rsp+0x80], xmm9
00007aa3a45db7d7  vmovaps [rsp+0x90], xmm10
00007aa3a45db7e0  vmovaps [rsp+0xA0], xmm11
00007aa3a45db7e9  vmovaps [rsp+0xB0], xmm12
00007aa3a45db7f2  vmovaps [rsp+0xC0], xmm13
00007aa3a45db7fb  vmovaps [rsp+0xD0], xmm14
00007aa3a45db804  vmovaps [rsp+0xE0], xmm15
00007aa3a45db80d  sub rsp, 0x30
00007aa3a45db811  movaps [rsp], xmm1
00007aa3a45db815  movaps [rsp+0x10], xmm8
00007aa3a45db81b  movaps [rsp+0x20], xmm9
00007aa3a45db821  lea rdi, [rsp]
00007aa3a45db825  mov esi, 0x00
00007aa3a45db82a  mov rax, 0x5F551B683530
00007aa3a45db834  call rax
00007aa3a45db836  movaps xmm1, [rsp]
00007aa3a45db83a  add rsp, 0x30
00007aa3a45db83e  vmovaps xmm0, [rsp]
00007aa3a45db843  vmovaps xmm2, [rsp+0x10]
00007aa3a45db849  vmovaps xmm3, [rsp+0x20]
00007aa3a45db84f  vmovaps xmm4, [rsp+0x30]
00007aa3a45db855  vmovaps xmm5, [rsp+0x40]
00007aa3a45db85b  vmovaps xmm6, [rsp+0x50]
00007aa3a45db861  vmovaps xmm7, [rsp+0x60]
00007aa3a45db867  vmovaps xmm8, [rsp+0x70]
00007aa3a45db86d  vmovaps xmm9, [rsp+0x80]
00007aa3a45db876  vmovaps xmm10, [rsp+0x90]
00007aa3a45db87f  vmovaps xmm11, [rsp+0xA0]
00007aa3a45db888  vmovaps xmm12, [rsp+0xB0]
00007aa3a45db891  vmovaps xmm13, [rsp+0xC0]
00007aa3a45db89a  vmovaps xmm14, [rsp+0xD0]
00007aa3a45db8a3  vmovaps xmm15, [rsp+0xE0]
00007aa3a45db8ac  add rsp, 0xF0
00007aa3a45db8b3  pop r11
00007aa3a45db8b5  pop r10
00007aa3a45db8b7  pop r9
00007aa3a45db8b9  pop r8
00007aa3a45db8bb  pop rsi
00007aa3a45db8bc  pop rdi
00007aa3a45db8bd  pop rdx
00007aa3a45db8be  pop rcx
00007aa3a45db8bf  pop rax
00007aa3a45db8c0  add rsp, 0x08
00007aa3a45db8c4  jmp 0x00007AA3A45D66B2
00007aa3a45db8c9  call 0x00007AA3A44B3E40
00007aa3a45db8ce  jmp 0x00007AA3A45D66C0
00007aa3a45db8d3  call 0x00007AA3A440C380
00007aa3a45db8d8  jmp 0x00007AA3A45D66CA
00007aa3a45db8dd  call 0x00007AA3A440D600
00007aa3a45db8e2  jmp 0x00007AA3A45D66D4
00007aa3a45db8e7  call 0x00007AA3A43FF540
00007aa3a45db8ec  jmp 0x00007AA3A45D66DE
00007aa3a45db8f1  int3
00007aa3a45db8f2  nop [rax+rax*1], ax
00007aa3a45db8fb  nop [rax+rax*1], eax
00007aa3a45db900  mov eax, [r15+0x48]
00007aa3a45db904  lea r14d, [eax+0x01]
00007aa3a45db909  mov [rsp+0x10], r14d
00007aa3a45db90e  mov r14d, r14d
00007aa3a45db911  mov [r15+0x48], r14
00007aa3a45db915  xor eax, eax
00007aa3a45db917  mov r14d, [rsp+0x10]
00007aa3a45db91c  cmp r14d, 0x1F4
00007aa3a45db923  cmc
00007aa3a45db924  lahf
00007aa3a45db925  seto al
00007aa3a45db928  mov [r15+0x108], eax
00007aa3a45db92f  mov eax, [r15+0x108]
00007aa3a45db936  sahf
00007aa3a45db937  jnz 0x00007AA3A45DB969
00007aa3a45db939  cmp dword ptr [r15+0x318], 0x00
00007aa3a45db941  jz 0x00007AA3A45E1AB0
00007aa3a45db947  nop [rax+rax*1], ax
00007aa3a45db950  nop [rax+rax*1], eax
00007aa3a45db958  mov eax, 0x410450
00007aa3a45db95d  mov [r15+0x100], rax
00007aa3a45db964  jmp 0x00007AA3A43FE110
00007aa3a45db969  cmp dword ptr [r15+0x318], 0x00
00007aa3a45db971  jz 0x00007AA3A45DB9A0
00007aa3a45db977  nop [rax+rax*1], ax
00007aa3a45db980  nop [rax+rax*1], eax
00007aa3a45db988  mov eax, 0x410274
00007aa3a45db98d  mov [r15+0x100], rax
00007aa3a45db994  jmp 0x00007AA3A43FE110
00007aa3a45db999  int3
00007aa3a45db99a  int3
00007aa3a45db99b  nop [rax+rax*1], eax
00007aa3a45db9a0  mov rax, [r15+0x40]
00007aa3a45db9a4  movaps xmm1, [r15+0x1D0]
00007aa3a45db9ac  vmovaps [rsp+0x10], xmm1
00007aa3a45db9b2  vmovaps xmm15, [rsp+0x10]
00007aa3a45db9b8  por xmm1, xmm15
00007aa3a45db9bd  movaps xmm14, [r15+0x1A0]
00007aa3a45db9c5  vmovaps [rsp+0x10], xmm14
00007aa3a45db9cb  vmovaps xmm13, [rsp+0x10]
00007aa3a45db9d1  por xmm14, xmm13
00007aa3a45db9d6  lea r14, [rax+0x30]
00007aa3a45db9da  mov r12, [r13+r14*1]
00007aa3a45db9df  lea r14, [rax+0x38]
00007aa3a45db9e3  mov r11, [r13+r14*1]
00007aa3a45db9e8  movq xmm13, r12
00007aa3a45db9ed  movq xmm12, r11
00007aa3a45db9f2  movq xmm13, xmm13
00007aa3a45db9f7  vmovaps [rsp+0x10], xmm13
00007aa3a45db9fd  movq xmm13, xmm13
00007aa3a45dba02  movaps [r15+0x130], xmm13
00007aa3a45dba0a  movq xmm12, xmm12
00007aa3a45dba0f  vmovaps [rsp+0x20], xmm12
00007aa3a45dba15  movq xmm12, xmm12
00007aa3a45dba1a  movaps [r15+0x280], xmm12
00007aa3a45dba22  movaps xmm13, [r15+0x270]
00007aa3a45dba2a  vmovaps [rsp+0x30], xmm13
00007aa3a45dba30  vmovaps xmm12, [rsp+0x30]
00007aa3a45dba36  por xmm13, xmm12
00007aa3a45dba3b  lea r14, [rax+0x20]
00007aa3a45dba3f  mov r12, [r13+r14*1]
00007aa3a45dba44  lea r14, [rax+0x28]
00007aa3a45dba48  mov r11, [r13+r14*1]
00007aa3a45dba4d  movq xmm12, r12
00007aa3a45dba52  movq xmm11, r11
00007aa3a45dba57  movq xmm12, xmm12
00007aa3a45dba5c  vmovaps [rsp+0x30], xmm12
00007aa3a45dba62  movq xmm12, xmm12
00007aa3a45dba67  movaps [r15+0x150], xmm12
00007aa3a45dba6f  movq xmm11, xmm11
00007aa3a45dba74  vmovaps [rsp+0x40], xmm11
00007aa3a45dba7a  movq xmm11, xmm11
00007aa3a45dba7f  movaps [r15+0x140], xmm11
00007aa3a45dba87  lea r14, [rax+0x10]
00007aa3a45dba8b  mov r12, [r13+r14*1]
00007aa3a45dba90  lea r14, [rax+0x18]
00007aa3a45dba94  mov r11, [r13+r14*1]
00007aa3a45dba99  movq xmm12, r12
00007aa3a45dba9e  movq xmm11, r11
00007aa3a45dbaa3  movq xmm12, xmm12
00007aa3a45dbaa8  vmovaps [rsp+0x50], xmm12
00007aa3a45dbaae  movq xmm12, xmm12
00007aa3a45dbab3  movaps [r15+0x170], xmm12
00007aa3a45dbabb  movq xmm11, xmm11
00007aa3a45dbac0  vmovaps [rsp+0x60], xmm11
00007aa3a45dbac6  movq xmm11, xmm11
00007aa3a45dbacb  movaps [r15+0x160], xmm11
00007aa3a45dbad3  mov r14, [r13+rax*1]
00007aa3a45dbad8  vmovq xmm12, r14
00007aa3a45dbadd  vpbroadcastq xmm12, xmm12
00007aa3a45dbae2  lea r14, [rax+0x08]
00007aa3a45dbae6  mov rax, [r13+r14*1]
00007aa3a45dbaeb  movq xmm11, rax
00007aa3a45dbaf0  movaps [r15+0x230], xmm11
00007aa3a45dbaf8  mov rax, [r15+0xF8]
00007aa3a45dbaff  lea r14, [rax+0x50]
00007aa3a45dbb03  movups xmm11, [r13+r14*1]
00007aa3a45dbb09  lea r14, [rax+0x60]
00007aa3a45dbb0d  movups xmm10, [r13+r14*1]
00007aa3a45dbb13  lea r14, [rax+0x30]
00007aa3a45dbb17  movups xmm9, [r13+r14*1]
00007aa3a45dbb1d  mov r14, [r15+0x50]
00007aa3a45dbb21  mov [r15+0x60], r14
00007aa3a45dbb25  mov qword ptr [r15+0x58], 0x40
00007aa3a45dbb2d  movaps xmm8, xmm12
00007aa3a45dbb31  mulpd xmm8, xmm15
00007aa3a45dbb36  vcmppd xmm7, xmm8, xmm8, 0x03
00007aa3a45dbb3c  ptest xmm7, xmm7
00007aa3a45dbb41  jnz 0x00007AA3A45DC96A
00007aa3a45dbb47  movq xmm15, qword ptr [r15+0x230]
00007aa3a45dbb50  vmovaps [rsp+0x70], xmm15
00007aa3a45dbb56  vpermilpd xmm15, xmm15, 0x00
00007aa3a45dbb5c  movaps xmm7, xmm9
00007aa3a45dbb60  mulpd xmm7, xmm15
00007aa3a45dbb65  vcmppd xmm6, xmm7, xmm7, 0x03
00007aa3a45dbb6a  ptest xmm6, xmm6
00007aa3a45dbb6f  jnz 0x00007AA3A45DCAAE
00007aa3a45dbb75  vxorps xmm15, xmm15, xmm15
00007aa3a45dbb7a  vpbroadcastq xmm15, xmm15
00007aa3a45dbb7f  movaps xmm9, xmm12
00007aa3a45dbb83  mulpd xmm9, xmm10
00007aa3a45dbb88  vcmppd xmm6, xmm9, xmm9, 0x03
00007aa3a45dbb8e  ptest xmm6, xmm6
00007aa3a45dbb93  jnz 0x00007AA3A45DCBF0
00007aa3a45dbb99  movaps xmm10, xmm12
00007aa3a45dbb9d  mulpd xmm10, xmm11
00007aa3a45dbba2  vcmppd xmm6, xmm10, xmm10, 0x03
00007aa3a45dbba8  ptest xmm6, xmm6
00007aa3a45dbbad  jnz 0x00007AA3A45DCD34
00007aa3a45dbbb3  movaps xmm11, [r15+0x1F0]
00007aa3a45dbbbb  movaps xmm6, xmm12
00007aa3a45dbbbf  mulpd xmm6, xmm11
00007aa3a45dbbc4  vcmppd xmm5, xmm6, xmm6, 0x03
00007aa3a45dbbc9  ptest xmm5, xmm5
00007aa3a45dbbce  jnz 0x00007AA3A45DCE78
00007aa3a45dbbd4  movaps xmm12, [r15+0x2A0]
00007aa3a45dbbdc  vmovaps [rsp+0x80], xmm12
00007aa3a45dbbe5  vmovaps xmm11, [rsp+0x80]
00007aa3a45dbbee  por xmm12, xmm11
00007aa3a45dbbf3  movaps xmm11, [r15+0x250]
00007aa3a45dbbfb  vmovaps [rsp+0x80], xmm11
00007aa3a45dbc04  vmovaps xmm5, [rsp+0x80]
00007aa3a45dbc0d  por xmm11, xmm5
00007aa3a45dbc12  vmovaps xmm4, [rsp+0x70]
00007aa3a45dbc18  vpermilpd xmm4, xmm4, 0x00
00007aa3a45dbc1e  movaps xmm3, xmm5
00007aa3a45dbc21  mulpd xmm3, xmm4
00007aa3a45dbc25  vcmppd xmm2, xmm3, xmm3, 0x03
00007aa3a45dbc2a  ptest xmm2, xmm2
00007aa3a45dbc2f  jnz 0x00007AA3A45DCFBA
00007aa3a45dbc35  mov [rsp+0x80], rax
00007aa3a45dbc3d  xor eax, eax
00007aa3a45dbc3f  mov r12d, 0x40
00007aa3a45dbc45  mov r11d, 0x200
00007aa3a45dbc4b  cmp r12, r11
00007aa3a45dbc4e  cmc
00007aa3a45dbc4f  lahf
00007aa3a45dbc50  seto al
00007aa3a45dbc53  mov [r15+0x108], eax
00007aa3a45dbc5a  movaps xmm5, xmm8
00007aa3a45dbc5e  addpd xmm5, xmm15
00007aa3a45dbc63  vcmppd xmm4, xmm5, xmm5, 0x03
00007aa3a45dbc68  ptest xmm4, xmm4
00007aa3a45dbc6d  jnz 0x00007AA3A45DD0FA
00007aa3a45dbc73  movaps xmm8, [r15+0x1B0]
00007aa3a45dbc7b  movaps xmm4, xmm9
00007aa3a45dbc7f  addpd xmm4, xmm8
00007aa3a45dbc84  vcmppd xmm2, xmm4, xmm4, 0x03
00007aa3a45dbc89  ptest xmm2, xmm2
00007aa3a45dbc8e  jnz 0x00007AA3A45DD23C
00007aa3a45dbc94  movaps xmm9, xmm10
00007aa3a45dbc98  addpd xmm9, xmm8
00007aa3a45dbc9d  vcmppd xmm2, xmm9, xmm9, 0x03
00007aa3a45dbca3  ptest xmm2, xmm2
00007aa3a45dbca8  jnz 0x00007AA3A45DD37E
00007aa3a45dbcae  movaps xmm10, [r15+0x2F0]
00007aa3a45dbcb6  vmovaps [rsp+0x90], xmm10
00007aa3a45dbcbf  vmovaps xmm8, [rsp+0x90]
00007aa3a45dbcc8  por xmm10, xmm8
00007aa3a45dbccd  movaps xmm8, [r15+0x2E0]
00007aa3a45dbcd5  vmovaps [rsp+0x90], xmm8
00007aa3a45dbcde  vmovaps xmm2, [rsp+0x90]
00007aa3a45dbce7  por xmm8, xmm2
00007aa3a45dbcec  movaps xmm2, [r15+0x2D0]
00007aa3a45dbcf4  vmovaps [rsp+0x90], xmm2
00007aa3a45dbcfd  vmovaps [rsp+0xA0], xmm1
00007aa3a45dbd06  vmovaps xmm1, [rsp+0x90]
00007aa3a45dbd0f  por xmm2, xmm1
00007aa3a45dbd13  movaps xmm1, [r15+0x200]
00007aa3a45dbd1b  vmovaps [rsp+0x90], xmm1
00007aa3a45dbd24  vmovaps [rsp+0xB0], xmm15
00007aa3a45dbd2d  vmovaps xmm15, [rsp+0x90]
00007aa3a45dbd36  por xmm1, xmm15
00007aa3a45dbd3b  movaps xmm15, [r15+0x1C0]
00007aa3a45dbd43  vmovaps [rsp+0x90], xmm15
00007aa3a45dbd4c  vmovaps [rsp+0xC0], xmm1
00007aa3a45dbd55  vmovaps xmm1, [rsp+0x90]
00007aa3a45dbd5e  por xmm15, xmm1
00007aa3a45dbd63  movaps xmm1, [r15+0x190]
00007aa3a45dbd6b  vmovaps [rsp+0x90], xmm1
00007aa3a45dbd74  vmovaps [rsp+0xD0], xmm15
00007aa3a45dbd7d  vmovaps xmm15, [rsp+0x90]
00007aa3a45dbd86  por xmm1, xmm15
00007aa3a45dbd8b  movaps xmm15, [r15+0x300]
00007aa3a45dbd93  vmovaps [rsp+0x90], xmm15
00007aa3a45dbd9c  vmovaps [rsp+0xE0], xmm1
00007aa3a45dbda5  vmovaps xmm1, [rsp+0x90]
00007aa3a45dbdae  por xmm15, xmm1
00007aa3a45dbdb3  mov rax, [rsp+0x80]
00007aa3a45dbdbb  lea r12, [rax+0xA0]
00007aa3a45dbdc2  movups xmm1, [r13+r12*1]
00007aa3a45dbdc8  lea r12, [rax+0xB0]
00007aa3a45dbdcf  vmovaps [rsp+0x80], xmm1
00007aa3a45dbdd8  movups xmm1, [r13+r12*1]
00007aa3a45dbdde  vmovaps [rsp+0x90], xmm1
00007aa3a45dbde7  vmovaps [rsp+0xF0], xmm15
00007aa3a45dbdf0  vmovaps xmm15, [rsp+0xB0]
00007aa3a45dbdf9  vmovaps [rsp+0xB0], xmm14
00007aa3a45dbe02  movaps xmm1, xmm6
00007aa3a45dbe05  addpd xmm1, xmm15
00007aa3a45dbe0a  vcmppd xmm14, xmm1, xmm1, 0x03
00007aa3a45dbe0f  ptest xmm14, xmm14
00007aa3a45dbe15  jnz 0x00007AA3A45DD4D6
00007aa3a45dbe1b  lea r12, [rax+0xF0]
00007aa3a45dbe22  movups xmm15, [r13+r12*1]
00007aa3a45dbe28  movaps xmm14, xmm4
00007aa3a45dbe2c  addpd xmm14, xmm3
00007aa3a45dbe31  vcmppd xmm6, xmm14, xmm14, 0x03
00007aa3a45dbe37  ptest xmm6, xmm6
00007aa3a45dbe3c  jnz 0x00007AA3A45DD621
00007aa3a45dbe42  movaps xmm6, xmm9
00007aa3a45dbe46  addpd xmm6, xmm7
00007aa3a45dbe4a  vcmppd xmm4, xmm6, xmm6, 0x03
00007aa3a45dbe4f  ptest xmm4, xmm4
00007aa3a45dbe54  jnz 0x00007AA3A45DD763
00007aa3a45dbe5a  vmovaps xmm9, [rsp+0x70]
00007aa3a45dbe60  vpermilpd xmm9, xmm9, 0x00
00007aa3a45dbe66  vmovaps xmm4, [rsp+0x90]
00007aa3a45dbe6f  movaps xmm7, xmm4
00007aa3a45dbe72  mulpd xmm7, xmm9
00007aa3a45dbe77  vcmppd xmm3, xmm7, xmm7, 0x03
00007aa3a45dbe7c  ptest xmm3, xmm3
00007aa3a45dbe81  jnz 0x00007AA3A45DD8A4
00007aa3a45dbe87  vmovaps xmm9, [rsp+0x50]
00007aa3a45dbe8d  vpermilpd xmm9, xmm9, 0x00
00007aa3a45dbe93  movaps xmm4, xmm15
00007aa3a45dbe97  mulpd xmm4, xmm9
00007aa3a45dbe9c  vcmppd xmm3, xmm4, xmm4, 0x03
00007aa3a45dbea1  ptest xmm3, xmm3
00007aa3a45dbea6  jnz 0x00007AA3A45DD9E5
00007aa3a45dbeac  lea r12, [rax+0xE0]
00007aa3a45dbeb3  movups xmm15, [r13+r12*1]
00007aa3a45dbeb9  vmovaps xmm9, [rsp+0x70]
00007aa3a45dbebf  vpermilpd xmm9, xmm9, 0x00
00007aa3a45dbec5  vmovaps [rsp+0x70], xmm1
00007aa3a45dbecb  vmovaps xmm1, [rsp+0x80]
00007aa3a45dbed4  vmovaps [rsp+0x80], xmm15
00007aa3a45dbedd  movaps xmm3, xmm1
00007aa3a45dbee0  mulpd xmm3, xmm9
00007aa3a45dbee5  vcmppd xmm15, xmm3, xmm3, 0x03
00007aa3a45dbeea  ptest xmm15, xmm15
00007aa3a45dbef0  jnz 0x00007AA3A45DDB31
00007aa3a45dbef6  vmovaps xmm1, [rsp+0xF0]
00007aa3a45dbeff  vmovaps xmm15, [rsp+0xF0]
00007aa3a45dbf08  por xmm1, xmm15
00007aa3a45dbf0d  movaps [r15+0x300], xmm1
00007aa3a45dbf15  vmovaps xmm15, [rsp+0xE0]
00007aa3a45dbf1e  vmovaps xmm9, [rsp+0xE0]
00007aa3a45dbf27  por xmm15, xmm9
00007aa3a45dbf2c  movaps [r15+0x190], xmm15
00007aa3a45dbf34  vmovaps xmm9, [rsp+0x50]
00007aa3a45dbf3a  vpermilpd xmm9, xmm9, 0x00
00007aa3a45dbf40  vmovaps [rsp+0x90], xmm1
00007aa3a45dbf49  vmovaps [rsp+0xE0], xmm15
00007aa3a45dbf52  vmovaps xmm15, [rsp+0x80]
00007aa3a45dbf5b  vmovaps [rsp+0x80], xmm14
00007aa3a45dbf64  movaps xmm1, xmm15
00007aa3a45dbf68  mulpd xmm1, xmm9
00007aa3a45dbf6d  vcmppd xmm14, xmm1, xmm1, 0x03
00007aa3a45dbf72  ptest xmm14, xmm14
00007aa3a45dbf78  jnz 0x00007AA3A45DDC72
00007aa3a45dbf7e  lea r12, [rax+0x90]
00007aa3a45dbf85  movups xmm15, [r13+r12*1]
00007aa3a45dbf8b  vmovaps xmm14, [rsp+0xD0]
00007aa3a45dbf94  vmovaps xmm9, [rsp+0xD0]
00007aa3a45dbf9d  por xmm14, xmm9
00007aa3a45dbfa2  movaps [r15+0x1C0], xmm14
00007aa3a45dbfaa  vmovaps xmm9, [rsp+0xC0]
00007aa3a45dbfb3  vmovaps [rsp+0xD0], xmm1
00007aa3a45dbfbc  vmovaps xmm1, [rsp+0xC0]
00007aa3a45dbfc5  por xmm9, xmm1
00007aa3a45dbfca  movaps [r15+0x200], xmm9
00007aa3a45dbfd2  vmovaps [rsp+0xC0], xmm2
00007aa3a45dbfdb  vmovaps xmm1, [rsp+0xC0]
00007aa3a45dbfe4  por xmm2, xmm1
00007aa3a45dbfe8  movaps [r15+0x2D0], xmm2
00007aa3a45dbff0  vmovaps [rsp+0xC0], xmm8
00007aa3a45dbff9  vmovaps xmm1, [rsp+0xC0]
00007aa3a45dc002  por xmm8, xmm1
00007aa3a45dc007  movaps [r15+0x2E0], xmm8
00007aa3a45dc00f  vmovaps [rsp+0xC0], xmm15
00007aa3a45dc018  movaps xmm1, xmm5
00007aa3a45dc01b  addpd xmm1, xmm7
00007aa3a45dc01f  vcmppd xmm15, xmm1, xmm1, 0x03
00007aa3a45dc024  ptest xmm15, xmm15
00007aa3a45dc02a  jnz 0x00007AA3A45DDDBE
00007aa3a45dc030  vmovaps xmm15, [rsp+0x50]
00007aa3a45dc036  vpermilpd xmm15, xmm15, 0x00
00007aa3a45dc03c  vmovaps xmm5, [rsp+0xC0]
00007aa3a45dc045  vmovaps [rsp+0xC0], xmm1
00007aa3a45dc04e  movaps xmm7, xmm5
00007aa3a45dc051  mulpd xmm7, xmm15
00007aa3a45dc056  vcmppd xmm1, xmm7, xmm7, 0x03
00007aa3a45dc05b  ptest xmm1, xmm1
00007aa3a45dc060  jnz 0x00007AA3A45DDEFE
00007aa3a45dc066  lea r12, [rax+0x80]
00007aa3a45dc06d  movups xmm1, [r13+r12*1]
00007aa3a45dc073  vmovaps xmm5, [rsp+0x70]
00007aa3a45dc079  vmovaps [rsp+0x70], xmm1
00007aa3a45dc07f  movaps xmm15, xmm5
00007aa3a45dc083  addpd xmm15, xmm3
00007aa3a45dc088  vcmppd xmm1, xmm15, xmm15, 0x03
00007aa3a45dc08e  ptest xmm1, xmm1
00007aa3a45dc093  jnz 0x00007AA3A45DE049
00007aa3a45dc099  vmovaps xmm5, [rsp+0x80]
00007aa3a45dc0a2  movaps xmm1, xmm5
00007aa3a45dc0a5  addpd xmm1, xmm4
00007aa3a45dc0a9  vcmppd xmm3, xmm1, xmm1, 0x03
00007aa3a45dc0ae  ptest xmm3, xmm3
00007aa3a45dc0b3  jnz 0x00007AA3A45DE18B
00007aa3a45dc0b9  vmovaps [rsp+0x80], xmm10
00007aa3a45dc0c2  vmovaps xmm5, [rsp+0x80]
00007aa3a45dc0cb  por xmm10, xmm5
00007aa3a45dc0d0  movaps [r15+0x2F0], xmm10
00007aa3a45dc0d8  vmovaps xmm5, [rsp+0x50]
00007aa3a45dc0de  vpermilpd xmm5, xmm5, 0x00
00007aa3a45dc0e4  vmovaps xmm3, [rsp+0x70]
00007aa3a45dc0ea  vmovaps [rsp+0x50], xmm1
00007aa3a45dc0f0  movaps xmm4, xmm3
00007aa3a45dc0f3  mulpd xmm4, xmm5
00007aa3a45dc0f7  vcmppd xmm1, xmm4, xmm4, 0x03
00007aa3a45dc0fc  ptest xmm1, xmm1
00007aa3a45dc101  jnz 0x00007AA3A45DE2CB
00007aa3a45dc107  lea r12, [rax+0xD0]
00007aa3a45dc10e  movups xmm1, [r13+r12*1]
00007aa3a45dc114  vmovaps xmm3, [rsp+0xD0]
00007aa3a45dc11d  vmovaps [rsp+0x70], xmm1
00007aa3a45dc123  movaps xmm5, xmm6
00007aa3a45dc126  addpd xmm5, xmm3
00007aa3a45dc12a  vcmppd xmm1, xmm5, xmm5, 0x03
00007aa3a45dc12f  ptest xmm1, xmm1
00007aa3a45dc134  jnz 0x00007AA3A45DE415
00007aa3a45dc13a  vmovaps xmm1, [rsp+0x60]
00007aa3a45dc140  vpermilpd xmm1, xmm1, 0x00
00007aa3a45dc146  movaps xmm6, xmm9
00007aa3a45dc14a  mulpd xmm6, xmm1
00007aa3a45dc14e  vcmppd xmm3, xmm6, xmm6, 0x03
00007aa3a45dc153  ptest xmm3, xmm3
00007aa3a45dc158  jnz 0x00007AA3A45DE555
00007aa3a45dc15e  movaps [r15+0x260], xmm6
00007aa3a45dc166  vxorps xmm1, xmm1, xmm1
00007aa3a45dc16a  vpbroadcastq xmm1, xmm1
00007aa3a45dc16f  movaps [r15+0x1B0], xmm1
00007aa3a45dc177  vmovaps xmm1, [rsp+0x60]
00007aa3a45dc17d  vpermilpd xmm1, xmm1, 0x00
00007aa3a45dc183  vmovaps xmm3, [rsp+0x70]
00007aa3a45dc189  vmovaps [rsp+0x70], xmm15
00007aa3a45dc18f  movaps xmm9, xmm3
00007aa3a45dc193  mulpd xmm9, xmm1
00007aa3a45dc198  vcmppd xmm15, xmm9, xmm9, 0x03
00007aa3a45dc19e  ptest xmm15, xmm15
00007aa3a45dc1a4  jnz 0x00007AA3A45DE696
00007aa3a45dc1aa  lea r12, [rax+0xC0]
00007aa3a45dc1b1  movups xmm1, [r13+r12*1]
00007aa3a45dc1b7  vmovaps xmm3, [rsp+0xC0]
00007aa3a45dc1c0  vmovaps [rsp+0x80], xmm1
00007aa3a45dc1c9  movaps xmm15, xmm3
00007aa3a45dc1cd  addpd xmm15, xmm7
00007aa3a45dc1d2  vcmppd xmm1, xmm15, xmm15, 0x03
00007aa3a45dc1d8  ptest xmm1, xmm1
00007aa3a45dc1dd  jnz 0x00007AA3A45DE7E2
00007aa3a45dc1e3  vmovaps [rsp+0xC0], xmm13
00007aa3a45dc1ec  vmovaps xmm1, [rsp+0xC0]
00007aa3a45dc1f5  por xmm13, xmm1
00007aa3a45dc1fa  movaps [r15+0x270], xmm13
00007aa3a45dc202  vmovaps xmm1, [rsp+0xB0]
00007aa3a45dc20b  vmovaps xmm7, [rsp+0xB0]
00007aa3a45dc214  por xmm1, xmm7
00007aa3a45dc218  movaps [r15+0x1A0], xmm1
00007aa3a45dc220  vmovaps xmm1, [rsp+0x60]
00007aa3a45dc226  vpermilpd xmm1, xmm1, 0x00
00007aa3a45dc22c  vmovaps [rsp+0xB0], xmm1
00007aa3a45dc235  vmovaps xmm1, [rsp+0x80]
00007aa3a45dc23e  vmovaps [rsp+0x80], xmm15
00007aa3a45dc247  vmovaps xmm15, [rsp+0xB0]
00007aa3a45dc250  vmovaps [rsp+0xB0], xmm14
00007aa3a45dc259  movaps xmm3, xmm1
00007aa3a45dc25c  mulpd xmm3, xmm15
00007aa3a45dc261  vcmppd xmm14, xmm3, xmm3, 0x03
00007aa3a45dc266  ptest xmm14, xmm14
00007aa3a45dc26c  jnz 0x00007AA3A45DE924
00007aa3a45dc272  lea r12, [rax+0x20]
00007aa3a45dc276  movups xmm1, [r13+r12*1]
00007aa3a45dc27c  movaps [r15+0x110], xmm1
00007aa3a45dc284  vmovaps xmm14, [rsp+0x70]
00007aa3a45dc28a  vmovaps [rsp+0x70], xmm1
00007aa3a45dc290  movaps xmm15, xmm14
00007aa3a45dc294  addpd xmm15, xmm4
00007aa3a45dc299  vcmppd xmm1, xmm15, xmm15, 0x03
00007aa3a45dc29f  ptest xmm1, xmm1
00007aa3a45dc2a4  jnz 0x00007AA3A45DEA6F
00007aa3a45dc2aa  vmovaps xmm1, [rsp+0x60]
00007aa3a45dc2b0  vpermilpd xmm1, xmm1, 0x00
00007aa3a45dc2b6  movaps xmm14, xmm2
00007aa3a45dc2ba  mulpd xmm14, xmm1
00007aa3a45dc2bf  vcmppd xmm4, xmm14, xmm14, 0x03
00007aa3a45dc2c5  ptest xmm4, xmm4
00007aa3a45dc2ca  jnz 0x00007AA3A45DEBB2
00007aa3a45dc2d0  vmovaps xmm4, [rsp+0x50]
00007aa3a45dc2d6  movaps xmm1, xmm4
00007aa3a45dc2d9  addpd xmm1, xmm9
00007aa3a45dc2de  vcmppd xmm2, xmm1, xmm1, 0x03
00007aa3a45dc2e3  ptest xmm2, xmm2
00007aa3a45dc2e8  jnz 0x00007AA3A45DECF4
00007aa3a45dc2ee  vmovaps xmm9, [rsp+0x30]
00007aa3a45dc2f4  vpermilpd xmm9, xmm9, 0x00
00007aa3a45dc2fa  vmovaps xmm2, [rsp+0x70]
00007aa3a45dc300  vmovaps [rsp+0x50], xmm1
00007aa3a45dc306  movaps xmm4, xmm2
00007aa3a45dc309  mulpd xmm4, xmm9
00007aa3a45dc30e  vcmppd xmm1, xmm4, xmm4, 0x03
00007aa3a45dc313  ptest xmm1, xmm1
00007aa3a45dc318  jnz 0x00007AA3A45DEE35
00007aa3a45dc31e  vmovaps xmm1, [rsp+0x30]
00007aa3a45dc324  vpermilpd xmm1, xmm1, 0x00
00007aa3a45dc32a  vmovaps xmm2, [rsp+0x90]
00007aa3a45dc333  vmovaps [rsp+0x60], xmm15
00007aa3a45dc339  movaps xmm9, xmm2
00007aa3a45dc33d  mulpd xmm9, xmm1
00007aa3a45dc342  vcmppd xmm15, xmm9, xmm9, 0x03
00007aa3a45dc348  ptest xmm15, xmm15
00007aa3a45dc34e  jnz 0x00007AA3A45DEF76
00007aa3a45dc354  vmovaps xmm15, [rsp+0x80]
00007aa3a45dc35d  movaps xmm1, xmm15
00007aa3a45dc361  addpd xmm1, xmm6
00007aa3a45dc365  vcmppd xmm2, xmm1, xmm1, 0x03
00007aa3a45dc36a  ptest xmm2, xmm2
00007aa3a45dc36f  jnz 0x00007AA3A45DF0B8
00007aa3a45dc375  movaps xmm15, xmm5
00007aa3a45dc379  addpd xmm15, xmm3
00007aa3a45dc37e  vcmppd xmm6, xmm15, xmm15, 0x03
00007aa3a45dc384  ptest xmm6, xmm6
00007aa3a45dc389  jnz 0x00007AA3A45DF1F9
00007aa3a45dc38f  vmovaps xmm6, [rsp+0x30]
00007aa3a45dc395  vpermilpd xmm6, xmm6, 0x00
00007aa3a45dc39b  movaps xmm5, xmm8
00007aa3a45dc39f  mulpd xmm5, xmm6
00007aa3a45dc3a3  vcmppd xmm3, xmm5, xmm5, 0x03
00007aa3a45dc3a8  ptest xmm3, xmm3
00007aa3a45dc3ad  jnz 0x00007AA3A45DF33B
00007aa3a45dc3b3  vmovaps xmm8, [rsp+0x30]
00007aa3a45dc3b9  vpermilpd xmm8, xmm8, 0x00
00007aa3a45dc3bf  movaps xmm6, xmm10
00007aa3a45dc3c3  mulpd xmm6, xmm8
00007aa3a45dc3c8  vcmppd xmm3, xmm6, xmm6, 0x03
00007aa3a45dc3cd  ptest xmm3, xmm3
00007aa3a45dc3d2  jnz 0x00007AA3A45DF47C
00007aa3a45dc3d8  vmovaps xmm8, [rsp+0x60]
00007aa3a45dc3de  movaps xmm10, xmm8
00007aa3a45dc3e2  addpd xmm10, xmm14
00007aa3a45dc3e7  vcmppd xmm3, xmm10, xmm10, 0x03
00007aa3a45dc3ed  ptest xmm3, xmm3
00007aa3a45dc3f2  jnz 0x00007AA3A45DF5BE
00007aa3a45dc3f8  vmovaps xmm8, [rsp+0x50]
00007aa3a45dc3fe  movaps xmm14, xmm8
00007aa3a45dc402  addpd xmm14, xmm4
00007aa3a45dc407  vcmppd xmm3, xmm14, xmm14, 0x03
00007aa3a45dc40d  ptest xmm3, xmm3
00007aa3a45dc412  jnz 0x00007AA3A45DF702
00007aa3a45dc418  vmovaps xmm8, [rsp+0x40]
00007aa3a45dc41e  vpermilpd xmm8, xmm8, 0x00
00007aa3a45dc424  movaps xmm4, xmm13
00007aa3a45dc428  mulpd xmm4, xmm8
00007aa3a45dc42d  vcmppd xmm3, xmm4, xmm4, 0x03
00007aa3a45dc432  ptest xmm3, xmm3
00007aa3a45dc437  jnz 0x00007AA3A45DF845
00007aa3a45dc43d  movaps xmm13, xmm15
00007aa3a45dc441  addpd xmm13, xmm9
00007aa3a45dc446  vcmppd xmm8, xmm13, xmm13, 0x03
00007aa3a45dc44c  ptest xmm8, xmm8
00007aa3a45dc452  jnz 0x00007AA3A45DF987
00007aa3a45dc458  movaps xmm15, xmm1
00007aa3a45dc45c  addpd xmm15, xmm5
00007aa3a45dc461  vcmppd xmm9, xmm15, xmm15, 0x03
00007aa3a45dc467  ptest xmm9, xmm9
00007aa3a45dc46d  jnz 0x00007AA3A45DFACB
00007aa3a45dc473  vmovaps [rsp+0x30], xmm11
00007aa3a45dc479  vmovaps xmm1, [rsp+0x30]
00007aa3a45dc47f  por xmm11, xmm1
00007aa3a45dc484  movaps [r15+0x250], xmm11
00007aa3a45dc48c  vmovaps [rsp+0x30], xmm12
00007aa3a45dc492  vmovaps xmm1, [rsp+0x30]
00007aa3a45dc498  por xmm12, xmm1
00007aa3a45dc49d  movaps [r15+0x2A0], xmm12
00007aa3a45dc4a5  vmovaps xmm1, [rsp+0xA0]
00007aa3a45dc4ae  vmovaps xmm11, [rsp+0xA0]
00007aa3a45dc4b7  por xmm1, xmm11
00007aa3a45dc4bc  movaps [r15+0x1D0], xmm1
00007aa3a45dc4c4  lea r12, [rax+0x40]
00007aa3a45dc4c8  movups xmm1, [r13+r12*1]
00007aa3a45dc4ce  movaps [r15+0x2C0], xmm1
00007aa3a45dc4d6  vmovaps xmm11, [rsp+0x40]
00007aa3a45dc4dc  vpermilpd xmm11, xmm11, 0x00
00007aa3a45dc4e2  vmovaps xmm8, [rsp+0xE0]
00007aa3a45dc4eb  movaps xmm9, xmm8
00007aa3a45dc4ef  mulpd xmm9, xmm11
00007aa3a45dc4f4  vcmppd xmm5, xmm9, xmm9, 0x03
00007aa3a45dc4fa  ptest xmm5, xmm5
00007aa3a45dc4ff  jnz 0x00007AA3A45DFC17
00007aa3a45dc505  movaps xmm11, xmm10
00007aa3a45dc509  addpd xmm11, xmm6
00007aa3a45dc50e  vcmppd xmm8, xmm11, xmm11, 0x03
00007aa3a45dc514  ptest xmm8, xmm8
00007aa3a45dc51a  jnz 0x00007AA3A45DFD5B
00007aa3a45dc520  movaps xmm10, xmm14
00007aa3a45dc524  addpd xmm10, xmm4
00007aa3a45dc529  vcmppd xmm8, xmm10, xmm10, 0x03
00007aa3a45dc52f  ptest xmm8, xmm8
00007aa3a45dc535  jnz 0x00007AA3A45DFE9E
00007aa3a45dc53b  vmovaps xmm14, [rsp+0x40]
00007aa3a45dc541  vpermilpd xmm14, xmm14, 0x00
00007aa3a45dc547  movaps xmm8, xmm1
00007aa3a45dc54b  mulpd xmm8, xmm14
00007aa3a45dc550  vcmppd xmm6, xmm8, xmm8, 0x03
00007aa3a45dc556  ptest xmm6, xmm6
00007aa3a45dc55b  jnz 0x00007AA3A45DFFE1
00007aa3a45dc561  movaps xmm1, [r15+0x2B0]
00007aa3a45dc569  vmovaps xmm14, [rsp+0x40]
00007aa3a45dc56f  vpermilpd xmm14, xmm14, 0x00
00007aa3a45dc575  movaps xmm6, xmm1
00007aa3a45dc578  mulpd xmm6, xmm14
00007aa3a45dc57d  vcmppd xmm5, xmm6, xmm6, 0x03
00007aa3a45dc582  ptest xmm5, xmm5
00007aa3a45dc587  jnz 0x00007AA3A45E0124
00007aa3a45dc58d  vmovaps xmm1, [rsp+0x10]
00007aa3a45dc593  vpermilpd xmm1, xmm1, 0x00
00007aa3a45dc599  movaps xmm14, xmm12
00007aa3a45dc59d  mulpd xmm14, xmm1
00007aa3a45dc5a2  vcmppd xmm5, xmm14, xmm14, 0x03
00007aa3a45dc5a8  ptest xmm5, xmm5
00007aa3a45dc5ad  jnz 0x00007AA3A45E0265
00007aa3a45dc5b3  movaps xmm1, xmm13
00007aa3a45dc5b7  addpd xmm1, xmm9
00007aa3a45dc5bc  vcmppd xmm12, xmm1, xmm1, 0x03
00007aa3a45dc5c1  ptest xmm12, xmm12
00007aa3a45dc5c7  jnz 0x00007AA3A45E03A8
00007aa3a45dc5cd  vmovaps xmm13, [rsp+0x10]
00007aa3a45dc5d3  vpermilpd xmm13, xmm13, 0x00
00007aa3a45dc5d9  movaps xmm12, xmm7
00007aa3a45dc5dd  mulpd xmm12, xmm13
00007aa3a45dc5e2  vcmppd xmm9, xmm12, xmm12, 0x03
00007aa3a45dc5e8  ptest xmm9, xmm9
00007aa3a45dc5ee  jnz 0x00007AA3A45E04EA
00007aa3a45dc5f4  movaps xmm13, xmm15
00007aa3a45dc5f8  addpd xmm13, xmm8
00007aa3a45dc5fd  vcmppd xmm9, xmm13, xmm13, 0x03
00007aa3a45dc603  ptest xmm9, xmm9
00007aa3a45dc609  jnz 0x00007AA3A45E062D
00007aa3a45dc60f  movaps xmm15, [r15+0x290]
00007aa3a45dc617  vmovaps xmm9, [rsp+0x10]
00007aa3a45dc61d  vpermilpd xmm9, xmm9, 0x00
00007aa3a45dc623  movaps xmm8, xmm15
00007aa3a45dc627  mulpd xmm8, xmm9
00007aa3a45dc62c  vcmppd xmm7, xmm8, xmm8, 0x03
00007aa3a45dc632  ptest xmm7, xmm7
00007aa3a45dc637  jnz 0x00007AA3A45E0771
00007aa3a45dc63d  movaps xmm15, xmm11
00007aa3a45dc641  addpd xmm15, xmm6
00007aa3a45dc646  vcmppd xmm9, xmm15, xmm15, 0x03
00007aa3a45dc64c  ptest xmm9, xmm9
00007aa3a45dc652  jnz 0x00007AA3A45E08B5
00007aa3a45dc658  movaps xmm11, [r15+0x1E0]
00007aa3a45dc660  vmovaps xmm9, [rsp+0x10]
00007aa3a45dc666  vpermilpd xmm9, xmm9, 0x00
00007aa3a45dc66c  movaps xmm7, xmm11
00007aa3a45dc670  mulpd xmm7, xmm9
00007aa3a45dc675  vcmppd xmm6, xmm7, xmm7, 0x03
00007aa3a45dc67a  ptest xmm6, xmm6
00007aa3a45dc67f  jnz 0x00007AA3A45E09F8
00007aa3a45dc685  movaps xmm11, xmm10
00007aa3a45dc689  addpd xmm11, xmm14
00007aa3a45dc68e  vcmppd xmm9, xmm11, xmm11, 0x03
00007aa3a45dc694  ptest xmm9, xmm9
00007aa3a45dc69a  jnz 0x00007AA3A45E0B3A
00007aa3a45dc6a0  lea r12, [rax+0x70]
00007aa3a45dc6a4  movups xmm14, [r13+r12*1]
00007aa3a45dc6aa  movaps [r15+0x240], xmm14
00007aa3a45dc6b2  movaps xmm10, xmm1
00007aa3a45dc6b6  addpd xmm10, xmm12
00007aa3a45dc6bb  vcmppd xmm9, xmm10, xmm10, 0x03
00007aa3a45dc6c1  ptest xmm9, xmm9
00007aa3a45dc6c7  jnz 0x00007AA3A45E0C88
00007aa3a45dc6cd  movaps [r15+0x170], xmm10
00007aa3a45dc6d5  vmovaps xmm1, [rsp+0x20]
00007aa3a45dc6db  vpermilpd xmm1, xmm1, 0x00
00007aa3a45dc6e1  movaps xmm12, xmm14
00007aa3a45dc6e5  mulpd xmm12, xmm1
00007aa3a45dc6ea  vcmppd xmm9, xmm12, xmm12, 0x03
00007aa3a45dc6f0  ptest xmm9, xmm9
00007aa3a45dc6f6  jnz 0x00007AA3A45E0DCB
00007aa3a45dc6fc  vmovaps xmm1, [rsp+0x20]
00007aa3a45dc702  vpermilpd xmm1, xmm1, 0x00
00007aa3a45dc708  vmovaps xmm9, [rsp+0xB0]
00007aa3a45dc711  movaps xmm14, xmm9
00007aa3a45dc715  mulpd xmm14, xmm1
00007aa3a45dc71a  vcmppd xmm6, xmm14, xmm14, 0x03
00007aa3a45dc720  ptest xmm6, xmm6
00007aa3a45dc725  jnz 0x00007AA3A45E0F0E
00007aa3a45dc72b  movaps [r15+0x180], xmm14
00007aa3a45dc733  movaps xmm1, xmm13
00007aa3a45dc737  addpd xmm1, xmm8
00007aa3a45dc73c  vcmppd xmm9, xmm1, xmm1, 0x03
00007aa3a45dc741  ptest xmm9, xmm9
00007aa3a45dc747  jnz 0x00007AA3A45E1051
00007aa3a45dc74d  movaps [r15+0x210], xmm1
00007aa3a45dc755  movups xmm13, [r13+rax*1]
00007aa3a45dc75b  lea r12, [rax+0x10]
00007aa3a45dc75f  movups xmm9, [r13+r12*1]
00007aa3a45dc765  movaps [r15+0x230], xmm9
00007aa3a45dc76d  movaps xmm8, xmm15
00007aa3a45dc771  addpd xmm8, xmm7
00007aa3a45dc776  vcmppd xmm6, xmm8, xmm8, 0x03
00007aa3a45dc77c  ptest xmm6, xmm6
00007aa3a45dc781  jnz 0x00007AA3A45E11A7
00007aa3a45dc787  movaps [r15+0x130], xmm8
00007aa3a45dc78f  vmovaps xmm15, [rsp+0x20]
00007aa3a45dc795  vpermilpd xmm15, xmm15, 0x00
00007aa3a45dc79b  movaps xmm7, xmm9
00007aa3a45dc79f  mulpd xmm7, xmm15
00007aa3a45dc7a4  vcmppd xmm6, xmm7, xmm7, 0x03
00007aa3a45dc7a9  ptest xmm6, xmm6
00007aa3a45dc7ae  jnz 0x00007AA3A45E12EA
00007aa3a45dc7b4  movaps [r15+0x220], xmm7
00007aa3a45dc7bc  vmovaps xmm15, [rsp+0x20]
00007aa3a45dc7c2  vpermilpd xmm15, xmm15, 0x00
00007aa3a45dc7c8  movaps xmm9, xmm13
00007aa3a45dc7cc  mulpd xmm9, xmm15
00007aa3a45dc7d1  vcmppd xmm6, xmm9, xmm9, 0x03
00007aa3a45dc7d7  ptest xmm6, xmm6
00007aa3a45dc7dc  jnz 0x00007AA3A45E142C
00007aa3a45dc7e2  movaps xmm15, xmm11
00007aa3a45dc7e6  addpd xmm15, xmm12
00007aa3a45dc7eb  vcmppd xmm13, xmm15, xmm15, 0x03
00007aa3a45dc7f1  ptest xmm13, xmm13
00007aa3a45dc7f7  jnz 0x00007AA3A45E1570
00007aa3a45dc7fd  movaps [r15+0x140], xmm15
00007aa3a45dc805  movaps xmm13, xmm10
00007aa3a45dc809  addpd xmm13, xmm14
00007aa3a45dc80e  vcmppd xmm12, xmm13, xmm13, 0x03
00007aa3a45dc814  ptest xmm12, xmm12
00007aa3a45dc81a  jnz 0x00007AA3A45E16B4
00007aa3a45dc820  movaps [r15+0x150], xmm13
00007aa3a45dc828  movaps xmm14, xmm1
00007aa3a45dc82c  addpd xmm14, xmm7
00007aa3a45dc831  vcmppd xmm12, xmm14, xmm14, 0x03
00007aa3a45dc837  ptest xmm12, xmm12
00007aa3a45dc83d  jnz 0x00007AA3A45E17F8
00007aa3a45dc843  movaps [r15+0x160], xmm14
00007aa3a45dc84b  movaps xmm1, xmm8
00007aa3a45dc84f  addpd xmm1, xmm9
00007aa3a45dc854  vcmppd xmm12, xmm1, xmm1, 0x03
00007aa3a45dc859  ptest xmm12, xmm12
00007aa3a45dc85f  jnz 0x00007AA3A45E193A
00007aa3a45dc865  movaps [r15+0x120], xmm1
00007aa3a45dc86d  movups [r13+r14*1], xmm15
00007aa3a45dc873  lea rax, [r14+0x10]
00007aa3a45dc877  movups [r13+rax*1], xmm13
00007aa3a45dc87d  lea rax, [r14+0x20]
00007aa3a45dc881  movups [r13+rax*1], xmm14
00007aa3a45dc887  lea rax, [r14+0x30]
00007aa3a45dc88b  movups [r13+rax*1], xmm1
00007aa3a45dc891  mov eax, [r15+0x108]
00007aa3a45dc898  sahf
00007aa3a45dc899  jnz 0x00007AA3A45DC8CB
00007aa3a45dc89b  cmp dword ptr [r15+0x318], 0x00
00007aa3a45dc8a3  jz 0x00007AA3A45DB900
00007aa3a45dc8a9  nop [rax+rax*1], ax
00007aa3a45dc8b2  nop [rax+rax*1], eax
00007aa3a45dc8ba  mov eax, 0x410444
00007aa3a45dc8bf  mov [r15+0x100], rax
00007aa3a45dc8c6  jmp 0x00007AA3A43FE110
00007aa3a45dc8cb  cmp dword ptr [r15+0x318], 0x00
00007aa3a45dc8d3  jz 0x00007AA3A45D57E0
00007aa3a45dc8d9  nop [rax+rax*1], ax
00007aa3a45dc8e2  nop [rax+rax*1], eax
00007aa3a45dc8ea  mov eax, 0x410278
00007aa3a45dc8ef  mov [r15+0x100], rax
00007aa3a45dc8f6  jmp 0x00007AA3A43FE110
00007aa3a45dc8fb  int3
00007aa3a45dc8fc  call 0x00007AA3A44E27E0
00007aa3a45dc901  jmp 0x00007AA3A45DB9DF
00007aa3a45dc906  call 0x00007AA3A44E1570
00007aa3a45dc90b  jmp 0x00007AA3A45DB9E8
00007aa3a45dc910  call 0x00007AA3A44E27E0
00007aa3a45dc915  jmp 0x00007AA3A45DBA44
00007aa3a45dc91a  call 0x00007AA3A44E1570
00007aa3a45dc91f  jmp 0x00007AA3A45DBA4D
00007aa3a45dc924  call 0x00007AA3A44E27E0
00007aa3a45dc929  jmp 0x00007AA3A45DBA90
00007aa3a45dc92e  call 0x00007AA3A44E1570
00007aa3a45dc933  jmp 0x00007AA3A45DBA99
00007aa3a45dc938  call 0x00007AA3A440DC20
00007aa3a45dc93d  jmp 0x00007AA3A45DBAD8
00007aa3a45dc942  call 0x00007AA3A44D59C0
00007aa3a45dc947  jmp 0x00007AA3A45DBAEB
00007aa3a45dc94c  call 0x00007AA3A44E0E30
00007aa3a45dc951  jmp 0x00007AA3A45DBB09
00007aa3a45dc956  call 0x00007AA3A44DFBC0
00007aa3a45dc95b  jmp 0x00007AA3A45DBB13
00007aa3a45dc960  call 0x00007AA3A44DE950
00007aa3a45dc965  jmp 0x00007AA3A45DBB1D
00007aa3a45dc96a  sub rsp, 0x08
00007aa3a45dc96e  push rax
00007aa3a45dc96f  push rcx
00007aa3a45dc970  push rdx
00007aa3a45dc971  push rdi
00007aa3a45dc972  push rsi
00007aa3a45dc973  push r8
00007aa3a45dc975  push r9
00007aa3a45dc977  push r10
00007aa3a45dc979  push r11
00007aa3a45dc97b  sub rsp, 0xF0
00007aa3a45dc982  vmovaps [rsp], xmm0
00007aa3a45dc987  vmovaps [rsp+0x10], xmm1
00007aa3a45dc98d  vmovaps [rsp+0x20], xmm2
00007aa3a45dc993  vmovaps [rsp+0x30], xmm3
00007aa3a45dc999  vmovaps [rsp+0x40], xmm4
00007aa3a45dc99f  vmovaps [rsp+0x50], xmm5
00007aa3a45dc9a5  vmovaps [rsp+0x60], xmm6
00007aa3a45dc9ab  vmovaps [rsp+0x70], xmm7
00007aa3a45dc9b1  vmovaps [rsp+0x80], xmm9
00007aa3a45dc9ba  vmovaps [rsp+0x90], xmm10
00007aa3a45dc9c3  vmovaps [rsp+0xA0], xmm11
00007aa3a45dc9cc  vmovaps [rsp+0xB0], xmm12
00007aa3a45dc9d5  vmovaps [rsp+0xC0], xmm13
00007aa3a45dc9de  vmovaps [rsp+0xD0], xmm14
00007aa3a45dc9e7  vmovaps [rsp+0xE0], xmm15
00007aa3a45dc9f0  sub rsp, 0x30
00007aa3a45dc9f4  movaps [rsp], xmm8
00007aa3a45dc9f9  movaps [rsp+0x10], xmm12
00007aa3a45dc9ff  movaps [rsp+0x20], xmm15
00007aa3a45dca05  lea rdi, [rsp]
00007aa3a45dca09  mov esi, 0x00
00007aa3a45dca0e  mov rax, 0x5F551B683530
00007aa3a45dca18  call rax
00007aa3a45dca1a  movaps xmm8, [rsp]
00007aa3a45dca1f  add rsp, 0x30
00007aa3a45dca23  vmovaps xmm0, [rsp]
00007aa3a45dca28  vmovaps xmm1, [rsp+0x10]
00007aa3a45dca2e  vmovaps xmm2, [rsp+0x20]
00007aa3a45dca34  vmovaps xmm3, [rsp+0x30]
00007aa3a45dca3a  vmovaps xmm4, [rsp+0x40]
00007aa3a45dca40  vmovaps xmm5, [rsp+0x50]
00007aa3a45dca46  vmovaps xmm6, [rsp+0x60]
00007aa3a45dca4c  vmovaps xmm7, [rsp+0x70]
00007aa3a45dca52  vmovaps xmm9, [rsp+0x80]
00007aa3a45dca5b  vmovaps xmm10, [rsp+0x90]
00007aa3a45dca64  vmovaps xmm11, [rsp+0xA0]
00007aa3a45dca6d  vmovaps xmm12, [rsp+0xB0]
00007aa3a45dca76  vmovaps xmm13, [rsp+0xC0]
00007aa3a45dca7f  vmovaps xmm14, [rsp+0xD0]
00007aa3a45dca88  vmovaps xmm15, [rsp+0xE0]
00007aa3a45dca91  add rsp, 0xF0
00007aa3a45dca98  pop r11
00007aa3a45dca9a  pop r10
00007aa3a45dca9c  pop r9
00007aa3a45dca9e  pop r8
00007aa3a45dcaa0  pop rsi
00007aa3a45dcaa1  pop rdi
00007aa3a45dcaa2  pop rdx
00007aa3a45dcaa3  pop rcx
00007aa3a45dcaa4  pop rax
00007aa3a45dcaa5  add rsp, 0x08
00007aa3a45dcaa9  jmp 0x00007AA3A45DBB47
00007aa3a45dcaae  sub rsp, 0x08
00007aa3a45dcab2  push rax
00007aa3a45dcab3  push rcx
00007aa3a45dcab4  push rdx
00007aa3a45dcab5  push rdi
00007aa3a45dcab6  push rsi
00007aa3a45dcab7  push r8
00007aa3a45dcab9  push r9
00007aa3a45dcabb  push r10
00007aa3a45dcabd  push r11
00007aa3a45dcabf  sub rsp, 0xF0
00007aa3a45dcac6  vmovaps [rsp], xmm0
00007aa3a45dcacb  vmovaps [rsp+0x10], xmm1
00007aa3a45dcad1  vmovaps [rsp+0x20], xmm2
00007aa3a45dcad7  vmovaps [rsp+0x30], xmm3
00007aa3a45dcadd  vmovaps [rsp+0x40], xmm4
00007aa3a45dcae3  vmovaps [rsp+0x50], xmm5
00007aa3a45dcae9  vmovaps [rsp+0x60], xmm6
00007aa3a45dcaef  vmovaps [rsp+0x70], xmm8
00007aa3a45dcaf5  vmovaps [rsp+0x80], xmm9
00007aa3a45dcafe  vmovaps [rsp+0x90], xmm10
00007aa3a45dcb07  vmovaps [rsp+0xA0], xmm11
00007aa3a45dcb10  vmovaps [rsp+0xB0], xmm12
00007aa3a45dcb19  vmovaps [rsp+0xC0], xmm13
00007aa3a45dcb22  vmovaps [rsp+0xD0], xmm14
00007aa3a45dcb2b  vmovaps [rsp+0xE0], xmm15
00007aa3a45dcb34  sub rsp, 0x30
00007aa3a45dcb38  movaps [rsp], xmm7
00007aa3a45dcb3c  movaps [rsp+0x10], xmm9
00007aa3a45dcb42  movaps [rsp+0x20], xmm15
00007aa3a45dcb48  lea rdi, [rsp]
00007aa3a45dcb4c  mov esi, 0x00
00007aa3a45dcb51  mov rax, 0x5F551B683530
00007aa3a45dcb5b  call rax
00007aa3a45dcb5d  movaps xmm7, [rsp]
00007aa3a45dcb61  add rsp, 0x30
00007aa3a45dcb65  vmovaps xmm0, [rsp]
00007aa3a45dcb6a  vmovaps xmm1, [rsp+0x10]
00007aa3a45dcb70  vmovaps xmm2, [rsp+0x20]
00007aa3a45dcb76  vmovaps xmm3, [rsp+0x30]
00007aa3a45dcb7c  vmovaps xmm4, [rsp+0x40]
00007aa3a45dcb82  vmovaps xmm5, [rsp+0x50]
00007aa3a45dcb88  vmovaps xmm6, [rsp+0x60]
00007aa3a45dcb8e  vmovaps xmm8, [rsp+0x70]
00007aa3a45dcb94  vmovaps xmm9, [rsp+0x80]
00007aa3a45dcb9d  vmovaps xmm10, [rsp+0x90]
00007aa3a45dcba6  vmovaps xmm11, [rsp+0xA0]
00007aa3a45dcbaf  vmovaps xmm12, [rsp+0xB0]
00007aa3a45dcbb8  vmovaps xmm13, [rsp+0xC0]
00007aa3a45dcbc1  vmovaps xmm14, [rsp+0xD0]
00007aa3a45dcbca  vmovaps xmm15, [rsp+0xE0]
00007aa3a45dcbd3  add rsp, 0xF0
00007aa3a45dcbda  pop r11
00007aa3a45dcbdc  pop r10
00007aa3a45dcbde  pop r9
00007aa3a45dcbe0  pop r8
00007aa3a45dcbe2  pop rsi
00007aa3a45dcbe3  pop rdi
00007aa3a45dcbe4  pop rdx
00007aa3a45dcbe5  pop rcx
00007aa3a45dcbe6  pop rax
00007aa3a45dcbe7  add rsp, 0x08
00007aa3a45dcbeb  jmp 0x00007AA3A45DBB75
00007aa3a45dcbf0  sub rsp, 0x08
00007aa3a45dcbf4  push rax
00007aa3a45dcbf5  push rcx
00007aa3a45dcbf6  push rdx
00007aa3a45dcbf7  push rdi
00007aa3a45dcbf8  push rsi
00007aa3a45dcbf9  push r8
00007aa3a45dcbfb  push r9
00007aa3a45dcbfd  push r10
00007aa3a45dcbff  push r11
00007aa3a45dcc01  sub rsp, 0xF0
00007aa3a45dcc08  vmovaps [rsp], xmm0
00007aa3a45dcc0d  vmovaps [rsp+0x10], xmm1
00007aa3a45dcc13  vmovaps [rsp+0x20], xmm2
00007aa3a45dcc19  vmovaps [rsp+0x30], xmm3
00007aa3a45dcc1f  vmovaps [rsp+0x40], xmm4
00007aa3a45dcc25  vmovaps [rsp+0x50], xmm5
00007aa3a45dcc2b  vmovaps [rsp+0x60], xmm6
00007aa3a45dcc31  vmovaps [rsp+0x70], xmm7
00007aa3a45dcc37  vmovaps [rsp+0x80], xmm8
00007aa3a45dcc40  vmovaps [rsp+0x90], xmm10
00007aa3a45dcc49  vmovaps [rsp+0xA0], xmm11
00007aa3a45dcc52  vmovaps [rsp+0xB0], xmm12
00007aa3a45dcc5b  vmovaps [rsp+0xC0], xmm13
00007aa3a45dcc64  vmovaps [rsp+0xD0], xmm14
00007aa3a45dcc6d  vmovaps [rsp+0xE0], xmm15
00007aa3a45dcc76  sub rsp, 0x30
00007aa3a45dcc7a  movaps [rsp], xmm9
00007aa3a45dcc7f  movaps [rsp+0x10], xmm12
00007aa3a45dcc85  movaps [rsp+0x20], xmm10
00007aa3a45dcc8b  lea rdi, [rsp]
00007aa3a45dcc8f  mov esi, 0x00
00007aa3a45dcc94  mov rax, 0x5F551B683530
00007aa3a45dcc9e  call rax
00007aa3a45dcca0  movaps xmm9, [rsp]
00007aa3a45dcca5  add rsp, 0x30
00007aa3a45dcca9  vmovaps xmm0, [rsp]
00007aa3a45dccae  vmovaps xmm1, [rsp+0x10]
00007aa3a45dccb4  vmovaps xmm2, [rsp+0x20]
00007aa3a45dccba  vmovaps xmm3, [rsp+0x30]
00007aa3a45dccc0  vmovaps xmm4, [rsp+0x40]
00007aa3a45dccc6  vmovaps xmm5, [rsp+0x50]
00007aa3a45dcccc  vmovaps xmm6, [rsp+0x60]
00007aa3a45dccd2  vmovaps xmm7, [rsp+0x70]
00007aa3a45dccd8  vmovaps xmm8, [rsp+0x80]
00007aa3a45dcce1  vmovaps xmm10, [rsp+0x90]
00007aa3a45dccea  vmovaps xmm11, [rsp+0xA0]
00007aa3a45dccf3  vmovaps xmm12, [rsp+0xB0]
00007aa3a45dccfc  vmovaps xmm13, [rsp+0xC0]
00007aa3a45dcd05  vmovaps xmm14, [rsp+0xD0]
00007aa3a45dcd0e  vmovaps xmm15, [rsp+0xE0]
00007aa3a45dcd17  add rsp, 0xF0
00007aa3a45dcd1e  pop r11
00007aa3a45dcd20  pop r10
00007aa3a45dcd22  pop r9
00007aa3a45dcd24  pop r8
00007aa3a45dcd26  pop rsi
00007aa3a45dcd27  pop rdi
00007aa3a45dcd28  pop rdx
00007aa3a45dcd29  pop rcx
00007aa3a45dcd2a  pop rax
00007aa3a45dcd2b  add rsp, 0x08
00007aa3a45dcd2f  jmp 0x00007AA3A45DBB99
00007aa3a45dcd34  sub rsp, 0x08
00007aa3a45dcd38  push rax
00007aa3a45dcd39  push rcx
00007aa3a45dcd3a  push rdx
00007aa3a45dcd3b  push rdi
00007aa3a45dcd3c  push rsi
00007aa3a45dcd3d  push r8
00007aa3a45dcd3f  push r9
00007aa3a45dcd41  push r10
00007aa3a45dcd43  push r11
00007aa3a45dcd45  sub rsp, 0xF0
00007aa3a45dcd4c  vmovaps [rsp], xmm0
00007aa3a45dcd51  vmovaps [rsp+0x10], xmm1
00007aa3a45dcd57  vmovaps [rsp+0x20], xmm2
00007aa3a45dcd5d  vmovaps [rsp+0x30], xmm3
00007aa3a45dcd63  vmovaps [rsp+0x40], xmm4
00007aa3a45dcd69  vmovaps [rsp+0x50], xmm5
00007aa3a45dcd6f  vmovaps [rsp+0x60], xmm6
00007aa3a45dcd75  vmovaps [rsp+0x70], xmm7
00007aa3a45dcd7b  vmovaps [rsp+0x80], xmm8
00007aa3a45dcd84  vmovaps [rsp+0x90], xmm9
00007aa3a45dcd8d  vmovaps [rsp+0xA0], xmm11
00007aa3a45dcd96  vmovaps [rsp+0xB0], xmm12
00007aa3a45dcd9f  vmovaps [rsp+0xC0], xmm13
00007aa3a45dcda8  vmovaps [rsp+0xD0], xmm14
00007aa3a45dcdb1  vmovaps [rsp+0xE0], xmm15
00007aa3a45dcdba  sub rsp, 0x30
00007aa3a45dcdbe  movaps [rsp], xmm10
00007aa3a45dcdc3  movaps [rsp+0x10], xmm12
00007aa3a45dcdc9  movaps [rsp+0x20], xmm11
00007aa3a45dcdcf  lea rdi, [rsp]
00007aa3a45dcdd3  mov esi, 0x00
00007aa3a45dcdd8  mov rax, 0x5F551B683530
00007aa3a45dcde2  call rax
00007aa3a45dcde4  movaps xmm10, [rsp]
00007aa3a45dcde9  add rsp, 0x30
00007aa3a45dcded  vmovaps xmm0, [rsp]
00007aa3a45dcdf2  vmovaps xmm1, [rsp+0x10]
00007aa3a45dcdf8  vmovaps xmm2, [rsp+0x20]
00007aa3a45dcdfe  vmovaps xmm3, [rsp+0x30]
00007aa3a45dce04  vmovaps xmm4, [rsp+0x40]
00007aa3a45dce0a  vmovaps xmm5, [rsp+0x50]
00007aa3a45dce10  vmovaps xmm6, [rsp+0x60]
00007aa3a45dce16  vmovaps xmm7, [rsp+0x70]
00007aa3a45dce1c  vmovaps xmm8, [rsp+0x80]
00007aa3a45dce25  vmovaps xmm9, [rsp+0x90]
00007aa3a45dce2e  vmovaps xmm11, [rsp+0xA0]
00007aa3a45dce37  vmovaps xmm12, [rsp+0xB0]
00007aa3a45dce40  vmovaps xmm13, [rsp+0xC0]
00007aa3a45dce49  vmovaps xmm14, [rsp+0xD0]
00007aa3a45dce52  vmovaps xmm15, [rsp+0xE0]
00007aa3a45dce5b  add rsp, 0xF0
00007aa3a45dce62  pop r11
00007aa3a45dce64  pop r10
00007aa3a45dce66  pop r9
00007aa3a45dce68  pop r8
00007aa3a45dce6a  pop rsi
00007aa3a45dce6b  pop rdi
00007aa3a45dce6c  pop rdx
00007aa3a45dce6d  pop rcx
00007aa3a45dce6e  pop rax
00007aa3a45dce6f  add rsp, 0x08
00007aa3a45dce73  jmp 0x00007AA3A45DBBB3
00007aa3a45dce78  sub rsp, 0x08
00007aa3a45dce7c  push rax
00007aa3a45dce7d  push rcx
00007aa3a45dce7e  push rdx
00007aa3a45dce7f  push rdi
00007aa3a45dce80  push rsi
00007aa3a45dce81  push r8
00007aa3a45dce83  push r9
00007aa3a45dce85  push r10
00007aa3a45dce87  push r11
00007aa3a45dce89  sub rsp, 0xF0
00007aa3a45dce90  vmovaps [rsp], xmm0
00007aa3a45dce95  vmovaps [rsp+0x10], xmm1
00007aa3a45dce9b  vmovaps [rsp+0x20], xmm2
00007aa3a45dcea1  vmovaps [rsp+0x30], xmm3
00007aa3a45dcea7  vmovaps [rsp+0x40], xmm4
00007aa3a45dcead  vmovaps [rsp+0x50], xmm5
00007aa3a45dceb3  vmovaps [rsp+0x60], xmm7
00007aa3a45dceb9  vmovaps [rsp+0x70], xmm8
00007aa3a45dcebf  vmovaps [rsp+0x80], xmm9
00007aa3a45dcec8  vmovaps [rsp+0x90], xmm10
00007aa3a45dced1  vmovaps [rsp+0xA0], xmm11
00007aa3a45dceda  vmovaps [rsp+0xB0], xmm12
00007aa3a45dcee3  vmovaps [rsp+0xC0], xmm13
00007aa3a45dceec  vmovaps [rsp+0xD0], xmm14
00007aa3a45dcef5  vmovaps [rsp+0xE0], xmm15
00007aa3a45dcefe  sub rsp, 0x30
00007aa3a45dcf02  movaps [rsp], xmm6
00007aa3a45dcf06  movaps [rsp+0x10], xmm12
00007aa3a45dcf0c  movaps [rsp+0x20], xmm11
00007aa3a45dcf12  lea rdi, [rsp]
00007aa3a45dcf16  mov esi, 0x00
00007aa3a45dcf1b  mov rax, 0x5F551B683530
00007aa3a45dcf25  call rax
00007aa3a45dcf27  movaps xmm6, [rsp]
00007aa3a45dcf2b  add rsp, 0x30
00007aa3a45dcf2f  vmovaps xmm0, [rsp]
00007aa3a45dcf34  vmovaps xmm1, [rsp+0x10]
00007aa3a45dcf3a  vmovaps xmm2, [rsp+0x20]
00007aa3a45dcf40  vmovaps xmm3, [rsp+0x30]
00007aa3a45dcf46  vmovaps xmm4, [rsp+0x40]
00007aa3a45dcf4c  vmovaps xmm5, [rsp+0x50]
00007aa3a45dcf52  vmovaps xmm7, [rsp+0x60]
00007aa3a45dcf58  vmovaps xmm8, [rsp+0x70]
00007aa3a45dcf5e  vmovaps xmm9, [rsp+0x80]
00007aa3a45dcf67  vmovaps xmm10, [rsp+0x90]
00007aa3a45dcf70  vmovaps xmm11, [rsp+0xA0]
00007aa3a45dcf79  vmovaps xmm12, [rsp+0xB0]
00007aa3a45dcf82  vmovaps xmm13, [rsp+0xC0]
00007aa3a45dcf8b  vmovaps xmm14, [rsp+0xD0]
00007aa3a45dcf94  vmovaps xmm15, [rsp+0xE0]
00007aa3a45dcf9d  add rsp, 0xF0
00007aa3a45dcfa4  pop r11
00007aa3a45dcfa6  pop r10
00007aa3a45dcfa8  pop r9
00007aa3a45dcfaa  pop r8
00007aa3a45dcfac  pop rsi
00007aa3a45dcfad  pop rdi
00007aa3a45dcfae  pop rdx
00007aa3a45dcfaf  pop rcx
00007aa3a45dcfb0  pop rax
00007aa3a45dcfb1  add rsp, 0x08
00007aa3a45dcfb5  jmp 0x00007AA3A45DBBD4
00007aa3a45dcfba  sub rsp, 0x08
00007aa3a45dcfbe  push rax
00007aa3a45dcfbf  push rcx
00007aa3a45dcfc0  push rdx
00007aa3a45dcfc1  push rdi
00007aa3a45dcfc2  push rsi
00007aa3a45dcfc3  push r8
00007aa3a45dcfc5  push r9
00007aa3a45dcfc7  push r10
00007aa3a45dcfc9  push r11
00007aa3a45dcfcb  sub rsp, 0xF0
00007aa3a45dcfd2  vmovaps [rsp], xmm0
00007aa3a45dcfd7  vmovaps [rsp+0x10], xmm1
00007aa3a45dcfdd  vmovaps [rsp+0x20], xmm2
00007aa3a45dcfe3  vmovaps [rsp+0x30], xmm4
00007aa3a45dcfe9  vmovaps [rsp+0x40], xmm5
00007aa3a45dcfef  vmovaps [rsp+0x50], xmm6
00007aa3a45dcff5  vmovaps [rsp+0x60], xmm7
00007aa3a45dcffb  vmovaps [rsp+0x70], xmm8
00007aa3a45dd001  vmovaps [rsp+0x80], xmm9
00007aa3a45dd00a  vmovaps [rsp+0x90], xmm10
00007aa3a45dd013  vmovaps [rsp+0xA0], xmm11
00007aa3a45dd01c  vmovaps [rsp+0xB0], xmm12
00007aa3a45dd025  vmovaps [rsp+0xC0], xmm13
00007aa3a45dd02e  vmovaps [rsp+0xD0], xmm14
00007aa3a45dd037  vmovaps [rsp+0xE0], xmm15
00007aa3a45dd040  sub rsp, 0x30
00007aa3a45dd044  movaps [rsp], xmm3
00007aa3a45dd048  movaps [rsp+0x10], xmm5
00007aa3a45dd04d  movaps [rsp+0x20], xmm4
00007aa3a45dd052  lea rdi, [rsp]
00007aa3a45dd056  mov esi, 0x00
00007aa3a45dd05b  mov rax, 0x5F551B683530
00007aa3a45dd065  call rax
00007aa3a45dd067  movaps xmm3, [rsp]
00007aa3a45dd06b  add rsp, 0x30
00007aa3a45dd06f  vmovaps xmm0, [rsp]
00007aa3a45dd074  vmovaps xmm1, [rsp+0x10]
00007aa3a45dd07a  vmovaps xmm2, [rsp+0x20]
00007aa3a45dd080  vmovaps xmm4, [rsp+0x30]
00007aa3a45dd086  vmovaps xmm5, [rsp+0x40]
00007aa3a45dd08c  vmovaps xmm6, [rsp+0x50]
00007aa3a45dd092  vmovaps xmm7, [rsp+0x60]
00007aa3a45dd098  vmovaps xmm8, [rsp+0x70]
00007aa3a45dd09e  vmovaps xmm9, [rsp+0x80]
00007aa3a45dd0a7  vmovaps xmm10, [rsp+0x90]
00007aa3a45dd0b0  vmovaps xmm11, [rsp+0xA0]
00007aa3a45dd0b9  vmovaps xmm12, [rsp+0xB0]
00007aa3a45dd0c2  vmovaps xmm13, [rsp+0xC0]
00007aa3a45dd0cb  vmovaps xmm14, [rsp+0xD0]
00007aa3a45dd0d4  vmovaps xmm15, [rsp+0xE0]
00007aa3a45dd0dd  add rsp, 0xF0
00007aa3a45dd0e4  pop r11
00007aa3a45dd0e6  pop r10
00007aa3a45dd0e8  pop r9
00007aa3a45dd0ea  pop r8
00007aa3a45dd0ec  pop rsi
00007aa3a45dd0ed  pop rdi
00007aa3a45dd0ee  pop rdx
00007aa3a45dd0ef  pop rcx
00007aa3a45dd0f0  pop rax
00007aa3a45dd0f1  add rsp, 0x08
00007aa3a45dd0f5  jmp 0x00007AA3A45DBC35
00007aa3a45dd0fa  sub rsp, 0x08
00007aa3a45dd0fe  push rax
00007aa3a45dd0ff  push rcx
00007aa3a45dd100  push rdx
00007aa3a45dd101  push rdi
00007aa3a45dd102  push rsi
00007aa3a45dd103  push r8
00007aa3a45dd105  push r9
00007aa3a45dd107  push r10
00007aa3a45dd109  push r11
00007aa3a45dd10b  sub rsp, 0xF0
00007aa3a45dd112  vmovaps [rsp], xmm0
00007aa3a45dd117  vmovaps [rsp+0x10], xmm1
00007aa3a45dd11d  vmovaps [rsp+0x20], xmm2
00007aa3a45dd123  vmovaps [rsp+0x30], xmm3
00007aa3a45dd129  vmovaps [rsp+0x40], xmm4
00007aa3a45dd12f  vmovaps [rsp+0x50], xmm6
00007aa3a45dd135  vmovaps [rsp+0x60], xmm7
00007aa3a45dd13b  vmovaps [rsp+0x70], xmm8
00007aa3a45dd141  vmovaps [rsp+0x80], xmm9
00007aa3a45dd14a  vmovaps [rsp+0x90], xmm10
00007aa3a45dd153  vmovaps [rsp+0xA0], xmm11
00007aa3a45dd15c  vmovaps [rsp+0xB0], xmm12
00007aa3a45dd165  vmovaps [rsp+0xC0], xmm13
00007aa3a45dd16e  vmovaps [rsp+0xD0], xmm14
00007aa3a45dd177  vmovaps [rsp+0xE0], xmm15
00007aa3a45dd180  sub rsp, 0x30
00007aa3a45dd184  movaps [rsp], xmm5
00007aa3a45dd188  movaps [rsp+0x10], xmm8
00007aa3a45dd18e  movaps [rsp+0x20], xmm15
00007aa3a45dd194  lea rdi, [rsp]
00007aa3a45dd198  mov esi, 0x00
00007aa3a45dd19d  mov rax, 0x5F551B683530
00007aa3a45dd1a7  call rax
00007aa3a45dd1a9  movaps xmm5, [rsp]
00007aa3a45dd1ad  add rsp, 0x30
00007aa3a45dd1b1  vmovaps xmm0, [rsp]
00007aa3a45dd1b6  vmovaps xmm1, [rsp+0x10]
00007aa3a45dd1bc  vmovaps xmm2, [rsp+0x20]
00007aa3a45dd1c2  vmovaps xmm3, [rsp+0x30]
00007aa3a45dd1c8  vmovaps xmm4, [rsp+0x40]
00007aa3a45dd1ce  vmovaps xmm6, [rsp+0x50]
00007aa3a45dd1d4  vmovaps xmm7, [rsp+0x60]
00007aa3a45dd1da  vmovaps xmm8, [rsp+0x70]
00007aa3a45dd1e0  vmovaps xmm9, [rsp+0x80]
00007aa3a45dd1e9  vmovaps xmm10, [rsp+0x90]
00007aa3a45dd1f2  vmovaps xmm11, [rsp+0xA0]
00007aa3a45dd1fb  vmovaps xmm12, [rsp+0xB0]
00007aa3a45dd204  vmovaps xmm13, [rsp+0xC0]
00007aa3a45dd20d  vmovaps xmm14, [rsp+0xD0]
00007aa3a45dd216  vmovaps xmm15, [rsp+0xE0]
00007aa3a45dd21f  add rsp, 0xF0
00007aa3a45dd226  pop r11
00007aa3a45dd228  pop r10
00007aa3a45dd22a  pop r9
00007aa3a45dd22c  pop r8
00007aa3a45dd22e  pop rsi
00007aa3a45dd22f  pop rdi
00007aa3a45dd230  pop rdx
00007aa3a45dd231  pop rcx
00007aa3a45dd232  pop rax
00007aa3a45dd233  add rsp, 0x08
00007aa3a45dd237  jmp 0x00007AA3A45DBC73
00007aa3a45dd23c  sub rsp, 0x08
00007aa3a45dd240  push rax
00007aa3a45dd241  push rcx
00007aa3a45dd242  push rdx
00007aa3a45dd243  push rdi
00007aa3a45dd244  push rsi
00007aa3a45dd245  push r8
00007aa3a45dd247  push r9
00007aa3a45dd249  push r10
00007aa3a45dd24b  push r11
00007aa3a45dd24d  sub rsp, 0xF0
00007aa3a45dd254  vmovaps [rsp], xmm0
00007aa3a45dd259  vmovaps [rsp+0x10], xmm1
00007aa3a45dd25f  vmovaps [rsp+0x20], xmm2
00007aa3a45dd265  vmovaps [rsp+0x30], xmm3
00007aa3a45dd26b  vmovaps [rsp+0x40], xmm5
00007aa3a45dd271  vmovaps [rsp+0x50], xmm6
00007aa3a45dd277  vmovaps [rsp+0x60], xmm7
00007aa3a45dd27d  vmovaps [rsp+0x70], xmm8
00007aa3a45dd283  vmovaps [rsp+0x80], xmm9
00007aa3a45dd28c  vmovaps [rsp+0x90], xmm10
00007aa3a45dd295  vmovaps [rsp+0xA0], xmm11
00007aa3a45dd29e  vmovaps [rsp+0xB0], xmm12
00007aa3a45dd2a7  vmovaps [rsp+0xC0], xmm13
00007aa3a45dd2b0  vmovaps [rsp+0xD0], xmm14
00007aa3a45dd2b9  vmovaps [rsp+0xE0], xmm15
00007aa3a45dd2c2  sub rsp, 0x30
00007aa3a45dd2c6  movaps [rsp], xmm4
00007aa3a45dd2ca  movaps [rsp+0x10], xmm9
00007aa3a45dd2d0  movaps [rsp+0x20], xmm8
00007aa3a45dd2d6  lea rdi, [rsp]
00007aa3a45dd2da  mov esi, 0x00
00007aa3a45dd2df  mov rax, 0x5F551B683530
00007aa3a45dd2e9  call rax
00007aa3a45dd2eb  movaps xmm4, [rsp]
00007aa3a45dd2ef  add rsp, 0x30
00007aa3a45dd2f3  vmovaps xmm0, [rsp]
00007aa3a45dd2f8  vmovaps xmm1, [rsp+0x10]
00007aa3a45dd2fe  vmovaps xmm2, [rsp+0x20]
00007aa3a45dd304  vmovaps xmm3, [rsp+0x30]
00007aa3a45dd30a  vmovaps xmm5, [rsp+0x40]
00007aa3a45dd310  vmovaps xmm6, [rsp+0x50]
00007aa3a45dd316  vmovaps xmm7, [rsp+0x60]
00007aa3a45dd31c  vmovaps xmm8, [rsp+0x70]
00007aa3a45dd322  vmovaps xmm9, [rsp+0x80]
00007aa3a45dd32b  vmovaps xmm10, [rsp+0x90]
00007aa3a45dd334  vmovaps xmm11, [rsp+0xA0]
00007aa3a45dd33d  vmovaps xmm12, [rsp+0xB0]
00007aa3a45dd346  vmovaps xmm13, [rsp+0xC0]
00007aa3a45dd34f  vmovaps xmm14, [rsp+0xD0]
00007aa3a45dd358  vmovaps xmm15, [rsp+0xE0]
00007aa3a45dd361  add rsp, 0xF0
00007aa3a45dd368  pop r11
00007aa3a45dd36a  pop r10
00007aa3a45dd36c  pop r9
00007aa3a45dd36e  pop r8
00007aa3a45dd370  pop rsi
00007aa3a45dd371  pop rdi
00007aa3a45dd372  pop rdx
00007aa3a45dd373  pop rcx
00007aa3a45dd374  pop rax
00007aa3a45dd375  add rsp, 0x08
00007aa3a45dd379  jmp 0x00007AA3A45DBC94
00007aa3a45dd37e  sub rsp, 0x08
00007aa3a45dd382  push rax
00007aa3a45dd383  push rcx
00007aa3a45dd384  push rdx
00007aa3a45dd385  push rdi
00007aa3a45dd386  push rsi
00007aa3a45dd387  push r8
00007aa3a45dd389  push r9
00007aa3a45dd38b  push r10
00007aa3a45dd38d  push r11
00007aa3a45dd38f  sub rsp, 0xF0
00007aa3a45dd396  vmovaps [rsp], xmm0
00007aa3a45dd39b  vmovaps [rsp+0x10], xmm1
00007aa3a45dd3a1  vmovaps [rsp+0x20], xmm2
00007aa3a45dd3a7  vmovaps [rsp+0x30], xmm3
00007aa3a45dd3ad  vmovaps [rsp+0x40], xmm4
00007aa3a45dd3b3  vmovaps [rsp+0x50], xmm5
00007aa3a45dd3b9  vmovaps [rsp+0x60], xmm6
00007aa3a45dd3bf  vmovaps [rsp+0x70], xmm7
00007aa3a45dd3c5  vmovaps [rsp+0x80], xmm8
00007aa3a45dd3ce  vmovaps [rsp+0x90], xmm10
00007aa3a45dd3d7  vmovaps [rsp+0xA0], xmm11
00007aa3a45dd3e0  vmovaps [rsp+0xB0], xmm12
00007aa3a45dd3e9  vmovaps [rsp+0xC0], xmm13
00007aa3a45dd3f2  vmovaps [rsp+0xD0], xmm14
00007aa3a45dd3fb  vmovaps [rsp+0xE0], xmm15
00007aa3a45dd404  sub rsp, 0x30
00007aa3a45dd408  movaps [rsp], xmm9
00007aa3a45dd40d  movaps [rsp+0x10], xmm10
00007aa3a45dd413  movaps [rsp+0x20], xmm8
00007aa3a45dd419  lea rdi, [rsp]
00007aa3a45dd41d  mov esi, 0x00
00007aa3a45dd422  mov rax, 0x5F551B683530
00007aa3a45dd42c  call rax
00007aa3a45dd42e  movaps xmm9, [rsp]
00007aa3a45dd433  add rsp, 0x30
00007aa3a45dd437  vmovaps xmm0, [rsp]
00007aa3a45dd43c  vmovaps xmm1, [rsp+0x10]
00007aa3a45dd442  vmovaps xmm2, [rsp+0x20]
00007aa3a45dd448  vmovaps xmm3, [rsp+0x30]
00007aa3a45dd44e  vmovaps xmm4, [rsp+0x40]
00007aa3a45dd454  vmovaps xmm5, [rsp+0x50]
00007aa3a45dd45a  vmovaps xmm6, [rsp+0x60]
00007aa3a45dd460  vmovaps xmm7, [rsp+0x70]
00007aa3a45dd466  vmovaps xmm8, [rsp+0x80]
00007aa3a45dd46f  vmovaps xmm10, [rsp+0x90]
00007aa3a45dd478  vmovaps xmm11, [rsp+0xA0]
00007aa3a45dd481  vmovaps xmm12, [rsp+0xB0]
00007aa3a45dd48a  vmovaps xmm13, [rsp+0xC0]
00007aa3a45dd493  vmovaps xmm14, [rsp+0xD0]
00007aa3a45dd49c  vmovaps xmm15, [rsp+0xE0]
00007aa3a45dd4a5  add rsp, 0xF0
00007aa3a45dd4ac  pop r11
00007aa3a45dd4ae  pop r10
00007aa3a45dd4b0  pop r9
00007aa3a45dd4b2  pop r8
00007aa3a45dd4b4  pop rsi
00007aa3a45dd4b5  pop rdi
00007aa3a45dd4b6  pop rdx
00007aa3a45dd4b7  pop rcx
00007aa3a45dd4b8  pop rax
00007aa3a45dd4b9  add rsp, 0x08
00007aa3a45dd4bd  jmp 0x00007AA3A45DBCAE
00007aa3a45dd4c2  call 0x00007AA3A44B52F0
00007aa3a45dd4c7  jmp 0x00007AA3A45DBDC8
00007aa3a45dd4cc  call 0x00007AA3A44B52F0
00007aa3a45dd4d1  jmp 0x00007AA3A45DBDDE
00007aa3a45dd4d6  sub rsp, 0x08
00007aa3a45dd4da  push rax
00007aa3a45dd4db  push rcx
00007aa3a45dd4dc  push rdx
00007aa3a45dd4dd  push rdi
00007aa3a45dd4de  push rsi
00007aa3a45dd4df  push r8
00007aa3a45dd4e1  push r9
00007aa3a45dd4e3  push r10
00007aa3a45dd4e5  push r11
00007aa3a45dd4e7  sub rsp, 0xF0
00007aa3a45dd4ee  vmovaps [rsp], xmm0
00007aa3a45dd4f3  vmovaps [rsp+0x10], xmm2
00007aa3a45dd4f9  vmovaps [rsp+0x20], xmm3
00007aa3a45dd4ff  vmovaps [rsp+0x30], xmm4
00007aa3a45dd505  vmovaps [rsp+0x40], xmm5
00007aa3a45dd50b  vmovaps [rsp+0x50], xmm6
00007aa3a45dd511  vmovaps [rsp+0x60], xmm7
00007aa3a45dd517  vmovaps [rsp+0x70], xmm8
00007aa3a45dd51d  vmovaps [rsp+0x80], xmm9
00007aa3a45dd526  vmovaps [rsp+0x90], xmm10
00007aa3a45dd52f  vmovaps [rsp+0xA0], xmm11
00007aa3a45dd538  vmovaps [rsp+0xB0], xmm12
00007aa3a45dd541  vmovaps [rsp+0xC0], xmm13
00007aa3a45dd54a  vmovaps [rsp+0xD0], xmm14
00007aa3a45dd553  vmovaps [rsp+0xE0], xmm15
00007aa3a45dd55c  sub rsp, 0x30
00007aa3a45dd560  movaps [rsp], xmm1
00007aa3a45dd564  movaps [rsp+0x10], xmm6
00007aa3a45dd569  movaps [rsp+0x20], xmm15
00007aa3a45dd56f  lea rdi, [rsp]
00007aa3a45dd573  mov esi, 0x00
00007aa3a45dd578  mov rax, 0x5F551B683530
00007aa3a45dd582  call rax
00007aa3a45dd584  movaps xmm1, [rsp]
00007aa3a45dd588  add rsp, 0x30
00007aa3a45dd58c  vmovaps xmm0, [rsp]
00007aa3a45dd591  vmovaps xmm2, [rsp+0x10]
00007aa3a45dd597  vmovaps xmm3, [rsp+0x20]
00007aa3a45dd59d  vmovaps xmm4, [rsp+0x30]
00007aa3a45dd5a3  vmovaps xmm5, [rsp+0x40]
00007aa3a45dd5a9  vmovaps xmm6, [rsp+0x50]
00007aa3a45dd5af  vmovaps xmm7, [rsp+0x60]
00007aa3a45dd5b5  vmovaps xmm8, [rsp+0x70]
00007aa3a45dd5bb  vmovaps xmm9, [rsp+0x80]
00007aa3a45dd5c4  vmovaps xmm10, [rsp+0x90]
00007aa3a45dd5cd  vmovaps xmm11, [rsp+0xA0]
00007aa3a45dd5d6  vmovaps xmm12, [rsp+0xB0]
00007aa3a45dd5df  vmovaps xmm13, [rsp+0xC0]
00007aa3a45dd5e8  vmovaps xmm14, [rsp+0xD0]
00007aa3a45dd5f1  vmovaps xmm15, [rsp+0xE0]
00007aa3a45dd5fa  add rsp, 0xF0
00007aa3a45dd601  pop r11
00007aa3a45dd603  pop r10
00007aa3a45dd605  pop r9
00007aa3a45dd607  pop r8
00007aa3a45dd609  pop rsi
00007aa3a45dd60a  pop rdi
00007aa3a45dd60b  pop rdx
00007aa3a45dd60c  pop rcx
00007aa3a45dd60d  pop rax
00007aa3a45dd60e  add rsp, 0x08
00007aa3a45dd612  jmp 0x00007AA3A45DBE1B
00007aa3a45dd617  call 0x00007AA3A44C4620
00007aa3a45dd61c  jmp 0x00007AA3A45DBE28
00007aa3a45dd621  sub rsp, 0x08
00007aa3a45dd625  push rax
00007aa3a45dd626  push rcx
00007aa3a45dd627  push rdx
00007aa3a45dd628  push rdi
00007aa3a45dd629  push rsi
00007aa3a45dd62a  push r8
00007aa3a45dd62c  push r9
00007aa3a45dd62e  push r10
00007aa3a45dd630  push r11
00007aa3a45dd632  sub rsp, 0xF0
00007aa3a45dd639  vmovaps [rsp], xmm0
00007aa3a45dd63e  vmovaps [rsp+0x10], xmm1
00007aa3a45dd644  vmovaps [rsp+0x20], xmm2
00007aa3a45dd64a  vmovaps [rsp+0x30], xmm3
00007aa3a45dd650  vmovaps [rsp+0x40], xmm4
00007aa3a45dd656  vmovaps [rsp+0x50], xmm5
00007aa3a45dd65c  vmovaps [rsp+0x60], xmm6
00007aa3a45dd662  vmovaps [rsp+0x70], xmm7
00007aa3a45dd668  vmovaps [rsp+0x80], xmm8
00007aa3a45dd671  vmovaps [rsp+0x90], xmm9
00007aa3a45dd67a  vmovaps [rsp+0xA0], xmm10
00007aa3a45dd683  vmovaps [rsp+0xB0], xmm11
00007aa3a45dd68c  vmovaps [rsp+0xC0], xmm12
00007aa3a45dd695  vmovaps [rsp+0xD0], xmm13
00007aa3a45dd69e  vmovaps [rsp+0xE0], xmm15
00007aa3a45dd6a7  sub rsp, 0x30
00007aa3a45dd6ab  movaps [rsp], xmm14
00007aa3a45dd6b0  movaps [rsp+0x10], xmm4
00007aa3a45dd6b5  movaps [rsp+0x20], xmm3
00007aa3a45dd6ba  lea rdi, [rsp]
00007aa3a45dd6be  mov esi, 0x00
00007aa3a45dd6c3  mov rax, 0x5F551B683530
00007aa3a45dd6cd  call rax
00007aa3a45dd6cf  movaps xmm14, [rsp]
00007aa3a45dd6d4  add rsp, 0x30
00007aa3a45dd6d8  vmovaps xmm0, [rsp]
00007aa3a45dd6dd  vmovaps xmm1, [rsp+0x10]
00007aa3a45dd6e3  vmovaps xmm2, [rsp+0x20]
00007aa3a45dd6e9  vmovaps xmm3, [rsp+0x30]
00007aa3a45dd6ef  vmovaps xmm4, [rsp+0x40]
00007aa3a45dd6f5  vmovaps xmm5, [rsp+0x50]
00007aa3a45dd6fb  vmovaps xmm6, [rsp+0x60]
00007aa3a45dd701  vmovaps xmm7, [rsp+0x70]
00007aa3a45dd707  vmovaps xmm8, [rsp+0x80]
00007aa3a45dd710  vmovaps xmm9, [rsp+0x90]
00007aa3a45dd719  vmovaps xmm10, [rsp+0xA0]
00007aa3a45dd722  vmovaps xmm11, [rsp+0xB0]
00007aa3a45dd72b  vmovaps xmm12, [rsp+0xC0]
00007aa3a45dd734  vmovaps xmm13, [rsp+0xD0]
00007aa3a45dd73d  vmovaps xmm15, [rsp+0xE0]
00007aa3a45dd746  add rsp, 0xF0
00007aa3a45dd74d  pop r11
00007aa3a45dd74f  pop r10
00007aa3a45dd751  pop r9
00007aa3a45dd753  pop r8
00007aa3a45dd755  pop rsi
00007aa3a45dd756  pop rdi
00007aa3a45dd757  pop rdx
00007aa3a45dd758  pop rcx
00007aa3a45dd759  pop rax
00007aa3a45dd75a  add rsp, 0x08
00007aa3a45dd75e  jmp 0x00007AA3A45DBE42
00007aa3a45dd763  sub rsp, 0x08
00007aa3a45dd767  push rax
00007aa3a45dd768  push rcx
00007aa3a45dd769  push rdx
00007aa3a45dd76a  push rdi
00007aa3a45dd76b  push rsi
00007aa3a45dd76c  push r8
00007aa3a45dd76e  push r9
00007aa3a45dd770  push r10
00007aa3a45dd772  push r11
00007aa3a45dd774  sub rsp, 0xF0
00007aa3a45dd77b  vmovaps [rsp], xmm0
00007aa3a45dd780  vmovaps [rsp+0x10], xmm1
00007aa3a45dd786  vmovaps [rsp+0x20], xmm2
00007aa3a45dd78c  vmovaps [rsp+0x30], xmm3
00007aa3a45dd792  vmovaps [rsp+0x40], xmm4
00007aa3a45dd798  vmovaps [rsp+0x50], xmm5
00007aa3a45dd79e  vmovaps [rsp+0x60], xmm7
00007aa3a45dd7a4  vmovaps [rsp+0x70], xmm8
00007aa3a45dd7aa  vmovaps [rsp+0x80], xmm9
00007aa3a45dd7b3  vmovaps [rsp+0x90], xmm10
00007aa3a45dd7bc  vmovaps [rsp+0xA0], xmm11
00007aa3a45dd7c5  vmovaps [rsp+0xB0], xmm12
00007aa3a45dd7ce  vmovaps [rsp+0xC0], xmm13
00007aa3a45dd7d7  vmovaps [rsp+0xD0], xmm14
00007aa3a45dd7e0  vmovaps [rsp+0xE0], xmm15
00007aa3a45dd7e9  sub rsp, 0x30
00007aa3a45dd7ed  movaps [rsp], xmm6
00007aa3a45dd7f1  movaps [rsp+0x10], xmm9
00007aa3a45dd7f7  movaps [rsp+0x20], xmm7
00007aa3a45dd7fc  lea rdi, [rsp]
00007aa3a45dd800  mov esi, 0x00
00007aa3a45dd805  mov rax, 0x5F551B683530
00007aa3a45dd80f  call rax
00007aa3a45dd811  movaps xmm6, [rsp]
00007aa3a45dd815  add rsp, 0x30
00007aa3a45dd819  vmovaps xmm0, [rsp]
00007aa3a45dd81e  vmovaps xmm1, [rsp+0x10]
00007aa3a45dd824  vmovaps xmm2, [rsp+0x20]
00007aa3a45dd82a  vmovaps xmm3, [rsp+0x30]
00007aa3a45dd830  vmovaps xmm4, [rsp+0x40]
00007aa3a45dd836  vmovaps xmm5, [rsp+0x50]
00007aa3a45dd83c  vmovaps xmm7, [rsp+0x60]
00007aa3a45dd842  vmovaps xmm8, [rsp+0x70]
00007aa3a45dd848  vmovaps xmm9, [rsp+0x80]
00007aa3a45dd851  vmovaps xmm10, [rsp+0x90]
00007aa3a45dd85a  vmovaps xmm11, [rsp+0xA0]
00007aa3a45dd863  vmovaps xmm12, [rsp+0xB0]
00007aa3a45dd86c  vmovaps xmm13, [rsp+0xC0]
00007aa3a45dd875  vmovaps xmm14, [rsp+0xD0]
00007aa3a45dd87e  vmovaps xmm15, [rsp+0xE0]
00007aa3a45dd887  add rsp, 0xF0
00007aa3a45dd88e  pop r11
00007aa3a45dd890  pop r10
00007aa3a45dd892  pop r9
00007aa3a45dd894  pop r8
00007aa3a45dd896  pop rsi
00007aa3a45dd897  pop rdi
00007aa3a45dd898  pop rdx
00007aa3a45dd899  pop rcx
00007aa3a45dd89a  pop rax
00007aa3a45dd89b  add rsp, 0x08
00007aa3a45dd89f  jmp 0x00007AA3A45DBE5A
00007aa3a45dd8a4  sub rsp, 0x08
00007aa3a45dd8a8  push rax
00007aa3a45dd8a9  push rcx
00007aa3a45dd8aa  push rdx
00007aa3a45dd8ab  push rdi
00007aa3a45dd8ac  push rsi
00007aa3a45dd8ad  push r8
00007aa3a45dd8af  push r9
00007aa3a45dd8b1  push r10
00007aa3a45dd8b3  push r11
00007aa3a45dd8b5  sub rsp, 0xF0
00007aa3a45dd8bc  vmovaps [rsp], xmm0
00007aa3a45dd8c1  vmovaps [rsp+0x10], xmm1
00007aa3a45dd8c7  vmovaps [rsp+0x20], xmm2
00007aa3a45dd8cd  vmovaps [rsp+0x30], xmm3
00007aa3a45dd8d3  vmovaps [rsp+0x40], xmm4
00007aa3a45dd8d9  vmovaps [rsp+0x50], xmm5
00007aa3a45dd8df  vmovaps [rsp+0x60], xmm6
00007aa3a45dd8e5  vmovaps [rsp+0x70], xmm8
00007aa3a45dd8eb  vmovaps [rsp+0x80], xmm9
00007aa3a45dd8f4  vmovaps [rsp+0x90], xmm10
00007aa3a45dd8fd  vmovaps [rsp+0xA0], xmm11
00007aa3a45dd906  vmovaps [rsp+0xB0], xmm12
00007aa3a45dd90f  vmovaps [rsp+0xC0], xmm13
00007aa3a45dd918  vmovaps [rsp+0xD0], xmm14
00007aa3a45dd921  vmovaps [rsp+0xE0], xmm15
00007aa3a45dd92a  sub rsp, 0x30
00007aa3a45dd92e  movaps [rsp], xmm7
00007aa3a45dd932  movaps [rsp+0x10], xmm4
00007aa3a45dd937  movaps [rsp+0x20], xmm9
00007aa3a45dd93d  lea rdi, [rsp]
00007aa3a45dd941  mov esi, 0x00
00007aa3a45dd946  mov rax, 0x5F551B683530
00007aa3a45dd950  call rax
00007aa3a45dd952  movaps xmm7, [rsp]
00007aa3a45dd956  add rsp, 0x30
00007aa3a45dd95a  vmovaps xmm0, [rsp]
00007aa3a45dd95f  vmovaps xmm1, [rsp+0x10]
00007aa3a45dd965  vmovaps xmm2, [rsp+0x20]
00007aa3a45dd96b  vmovaps xmm3, [rsp+0x30]
00007aa3a45dd971  vmovaps xmm4, [rsp+0x40]
00007aa3a45dd977  vmovaps xmm5, [rsp+0x50]
00007aa3a45dd97d  vmovaps xmm6, [rsp+0x60]
00007aa3a45dd983  vmovaps xmm8, [rsp+0x70]
00007aa3a45dd989  vmovaps xmm9, [rsp+0x80]
00007aa3a45dd992  vmovaps xmm10, [rsp+0x90]
00007aa3a45dd99b  vmovaps xmm11, [rsp+0xA0]
00007aa3a45dd9a4  vmovaps xmm12, [rsp+0xB0]
00007aa3a45dd9ad  vmovaps xmm13, [rsp+0xC0]
00007aa3a45dd9b6  vmovaps xmm14, [rsp+0xD0]
00007aa3a45dd9bf  vmovaps xmm15, [rsp+0xE0]
00007aa3a45dd9c8  add rsp, 0xF0
00007aa3a45dd9cf  pop r11
00007aa3a45dd9d1  pop r10
00007aa3a45dd9d3  pop r9
00007aa3a45dd9d5  pop r8
00007aa3a45dd9d7  pop rsi
00007aa3a45dd9d8  pop rdi
00007aa3a45dd9d9  pop rdx
00007aa3a45dd9da  pop rcx
00007aa3a45dd9db  pop rax
00007aa3a45dd9dc  add rsp, 0x08
00007aa3a45dd9e0  jmp 0x00007AA3A45DBE87
00007aa3a45dd9e5  sub rsp, 0x08
00007aa3a45dd9e9  push rax
00007aa3a45dd9ea  push rcx
00007aa3a45dd9eb  push rdx
00007aa3a45dd9ec  push rdi
00007aa3a45dd9ed  push rsi
00007aa3a45dd9ee  push r8
00007aa3a45dd9f0  push r9
00007aa3a45dd9f2  push r10
00007aa3a45dd9f4  push r11
00007aa3a45dd9f6  sub rsp, 0xF0
00007aa3a45dd9fd  vmovaps [rsp], xmm0
00007aa3a45dda02  vmovaps [rsp+0x10], xmm1
00007aa3a45dda08  vmovaps [rsp+0x20], xmm2
00007aa3a45dda0e  vmovaps [rsp+0x30], xmm3
00007aa3a45dda14  vmovaps [rsp+0x40], xmm5
00007aa3a45dda1a  vmovaps [rsp+0x50], xmm6
00007aa3a45dda20  vmovaps [rsp+0x60], xmm7
00007aa3a45dda26  vmovaps [rsp+0x70], xmm8
00007aa3a45dda2c  vmovaps [rsp+0x80], xmm9
00007aa3a45dda35  vmovaps [rsp+0x90], xmm10
00007aa3a45dda3e  vmovaps [rsp+0xA0], xmm11
00007aa3a45dda47  vmovaps [rsp+0xB0], xmm12
00007aa3a45dda50  vmovaps [rsp+0xC0], xmm13
00007aa3a45dda59  vmovaps [rsp+0xD0], xmm14
00007aa3a45dda62  vmovaps [rsp+0xE0], xmm15
00007aa3a45dda6b  sub rsp, 0x30
00007aa3a45dda6f  movaps [rsp], xmm4
00007aa3a45dda73  movaps [rsp+0x10], xmm15
00007aa3a45dda79  movaps [rsp+0x20], xmm9
00007aa3a45dda7f  lea rdi, [rsp]
00007aa3a45dda83  mov esi, 0x00
00007aa3a45dda88  mov rax, 0x5F551B683530
00007aa3a45dda92  call rax
00007aa3a45dda94  movaps xmm4, [rsp]
00007aa3a45dda98  add rsp, 0x30
00007aa3a45dda9c  vmovaps xmm0, [rsp]
00007aa3a45ddaa1  vmovaps xmm1, [rsp+0x10]
00007aa3a45ddaa7  vmovaps xmm2, [rsp+0x20]
00007aa3a45ddaad  vmovaps xmm3, [rsp+0x30]
00007aa3a45ddab3  vmovaps xmm5, [rsp+0x40]
00007aa3a45ddab9  vmovaps xmm6, [rsp+0x50]
00007aa3a45ddabf  vmovaps xmm7, [rsp+0x60]
00007aa3a45ddac5  vmovaps xmm8, [rsp+0x70]
00007aa3a45ddacb  vmovaps xmm9, [rsp+0x80]
00007aa3a45ddad4  vmovaps xmm10, [rsp+0x90]
00007aa3a45ddadd  vmovaps xmm11, [rsp+0xA0]
00007aa3a45ddae6  vmovaps xmm12, [rsp+0xB0]
00007aa3a45ddaef  vmovaps xmm13, [rsp+0xC0]
00007aa3a45ddaf8  vmovaps xmm14, [rsp+0xD0]
00007aa3a45ddb01  vmovaps xmm15, [rsp+0xE0]
00007aa3a45ddb0a  add rsp, 0xF0
00007aa3a45ddb11  pop r11
00007aa3a45ddb13  pop r10
00007aa3a45ddb15  pop r9
00007aa3a45ddb17  pop r8
00007aa3a45ddb19  pop rsi
00007aa3a45ddb1a  pop rdi
00007aa3a45ddb1b  pop rdx
00007aa3a45ddb1c  pop rcx
00007aa3a45ddb1d  pop rax
00007aa3a45ddb1e  add rsp, 0x08
00007aa3a45ddb22  jmp 0x00007AA3A45DBEAC
00007aa3a45ddb27  call 0x00007AA3A44C4620
00007aa3a45ddb2c  jmp 0x00007AA3A45DBEB9
00007aa3a45ddb31  sub rsp, 0x08
00007aa3a45ddb35  push rax
00007aa3a45ddb36  push rcx
00007aa3a45ddb37  push rdx
00007aa3a45ddb38  push rdi
00007aa3a45ddb39  push rsi
00007aa3a45ddb3a  push r8
00007aa3a45ddb3c  push r9
00007aa3a45ddb3e  push r10
00007aa3a45ddb40  push r11
00007aa3a45ddb42  sub rsp, 0xF0
00007aa3a45ddb49  vmovaps [rsp], xmm0
00007aa3a45ddb4e  vmovaps [rsp+0x10], xmm1
00007aa3a45ddb54  vmovaps [rsp+0x20], xmm2
00007aa3a45ddb5a  vmovaps [rsp+0x30], xmm4
00007aa3a45ddb60  vmovaps [rsp+0x40], xmm5
00007aa3a45ddb66  vmovaps [rsp+0x50], xmm6
00007aa3a45ddb6c  vmovaps [rsp+0x60], xmm7
00007aa3a45ddb72  vmovaps [rsp+0x70], xmm8
00007aa3a45ddb78  vmovaps [rsp+0x80], xmm9
00007aa3a45ddb81  vmovaps [rsp+0x90], xmm10
00007aa3a45ddb8a  vmovaps [rsp+0xA0], xmm11
00007aa3a45ddb93  vmovaps [rsp+0xB0], xmm12
00007aa3a45ddb9c  vmovaps [rsp+0xC0], xmm13
00007aa3a45ddba5  vmovaps [rsp+0xD0], xmm14
00007aa3a45ddbae  vmovaps [rsp+0xE0], xmm15
00007aa3a45ddbb7  sub rsp, 0x30
00007aa3a45ddbbb  movaps [rsp], xmm3
00007aa3a45ddbbf  movaps [rsp+0x10], xmm1
00007aa3a45ddbc4  movaps [rsp+0x20], xmm9
00007aa3a45ddbca  lea rdi, [rsp]
00007aa3a45ddbce  mov esi, 0x00
00007aa3a45ddbd3  mov rax, 0x5F551B683530
00007aa3a45ddbdd  call rax
00007aa3a45ddbdf  movaps xmm3, [rsp]
00007aa3a45ddbe3  add rsp, 0x30
00007aa3a45ddbe7  vmovaps xmm0, [rsp]
00007aa3a45ddbec  vmovaps xmm1, [rsp+0x10]
00007aa3a45ddbf2  vmovaps xmm2, [rsp+0x20]
00007aa3a45ddbf8  vmovaps xmm4, [rsp+0x30]
00007aa3a45ddbfe  vmovaps xmm5, [rsp+0x40]
00007aa3a45ddc04  vmovaps xmm6, [rsp+0x50]
00007aa3a45ddc0a  vmovaps xmm7, [rsp+0x60]
00007aa3a45ddc10  vmovaps xmm8, [rsp+0x70]
00007aa3a45ddc16  vmovaps xmm9, [rsp+0x80]
00007aa3a45ddc1f  vmovaps xmm10, [rsp+0x90]
00007aa3a45ddc28  vmovaps xmm11, [rsp+0xA0]
00007aa3a45ddc31  vmovaps xmm12, [rsp+0xB0]
00007aa3a45ddc3a  vmovaps xmm13, [rsp+0xC0]
00007aa3a45ddc43  vmovaps xmm14, [rsp+0xD0]
00007aa3a45ddc4c  vmovaps xmm15, [rsp+0xE0]
00007aa3a45ddc55  add rsp, 0xF0
00007aa3a45ddc5c  pop r11
00007aa3a45ddc5e  pop r10
00007aa3a45ddc60  pop r9
00007aa3a45ddc62  pop r8
00007aa3a45ddc64  pop rsi
00007aa3a45ddc65  pop rdi
00007aa3a45ddc66  pop rdx
00007aa3a45ddc67  pop rcx
00007aa3a45ddc68  pop rax
00007aa3a45ddc69  add rsp, 0x08
00007aa3a45ddc6d  jmp 0x00007AA3A45DBEF6
00007aa3a45ddc72  sub rsp, 0x08
00007aa3a45ddc76  push rax
00007aa3a45ddc77  push rcx
00007aa3a45ddc78  push rdx
00007aa3a45ddc79  push rdi
00007aa3a45ddc7a  push rsi
00007aa3a45ddc7b  push r8
00007aa3a45ddc7d  push r9
00007aa3a45ddc7f  push r10
00007aa3a45ddc81  push r11
00007aa3a45ddc83  sub rsp, 0xF0
00007aa3a45ddc8a  vmovaps [rsp], xmm0
00007aa3a45ddc8f  vmovaps [rsp+0x10], xmm2
00007aa3a45ddc95  vmovaps [rsp+0x20], xmm3
00007aa3a45ddc9b  vmovaps [rsp+0x30], xmm4
00007aa3a45ddca1  vmovaps [rsp+0x40], xmm5
00007aa3a45ddca7  vmovaps [rsp+0x50], xmm6
00007aa3a45ddcad  vmovaps [rsp+0x60], xmm7
00007aa3a45ddcb3  vmovaps [rsp+0x70], xmm8
00007aa3a45ddcb9  vmovaps [rsp+0x80], xmm9
00007aa3a45ddcc2  vmovaps [rsp+0x90], xmm10
00007aa3a45ddccb  vmovaps [rsp+0xA0], xmm11
00007aa3a45ddcd4  vmovaps [rsp+0xB0], xmm12
00007aa3a45ddcdd  vmovaps [rsp+0xC0], xmm13
00007aa3a45ddce6  vmovaps [rsp+0xD0], xmm14
00007aa3a45ddcef  vmovaps [rsp+0xE0], xmm15
00007aa3a45ddcf8  sub rsp, 0x30
00007aa3a45ddcfc  movaps [rsp], xmm1
00007aa3a45ddd00  movaps [rsp+0x10], xmm15
00007aa3a45ddd06  movaps [rsp+0x20], xmm9
00007aa3a45ddd0c  lea rdi, [rsp]
00007aa3a45ddd10  mov esi, 0x00
00007aa3a45ddd15  mov rax, 0x5F551B683530
00007aa3a45ddd1f  call rax
00007aa3a45ddd21  movaps xmm1, [rsp]
00007aa3a45ddd25  add rsp, 0x30
00007aa3a45ddd29  vmovaps xmm0, [rsp]
00007aa3a45ddd2e  vmovaps xmm2, [rsp+0x10]
00007aa3a45ddd34  vmovaps xmm3, [rsp+0x20]
00007aa3a45ddd3a  vmovaps xmm4, [rsp+0x30]
00007aa3a45ddd40  vmovaps xmm5, [rsp+0x40]
00007aa3a45ddd46  vmovaps xmm6, [rsp+0x50]
00007aa3a45ddd4c  vmovaps xmm7, [rsp+0x60]
00007aa3a45ddd52  vmovaps xmm8, [rsp+0x70]
00007aa3a45ddd58  vmovaps xmm9, [rsp+0x80]
00007aa3a45ddd61  vmovaps xmm10, [rsp+0x90]
00007aa3a45ddd6a  vmovaps xmm11, [rsp+0xA0]
00007aa3a45ddd73  vmovaps xmm12, [rsp+0xB0]
00007aa3a45ddd7c  vmovaps xmm13, [rsp+0xC0]
00007aa3a45ddd85  vmovaps xmm14, [rsp+0xD0]
00007aa3a45ddd8e  vmovaps xmm15, [rsp+0xE0]
00007aa3a45ddd97  add rsp, 0xF0
00007aa3a45ddd9e  pop r11
00007aa3a45ddda0  pop r10
00007aa3a45ddda2  pop r9
00007aa3a45ddda4  pop r8
00007aa3a45ddda6  pop rsi
00007aa3a45ddda7  pop rdi
00007aa3a45ddda8  pop rdx
00007aa3a45ddda9  pop rcx
00007aa3a45dddaa  pop rax
00007aa3a45dddab  add rsp, 0x08
00007aa3a45dddaf  jmp 0x00007AA3A45DBF7E
00007aa3a45dddb4  call 0x00007AA3A44C4620
00007aa3a45dddb9  jmp 0x00007AA3A45DBF8B
00007aa3a45dddbe  sub rsp, 0x08
00007aa3a45dddc2  push rax
00007aa3a45dddc3  push rcx
00007aa3a45dddc4  push rdx
00007aa3a45dddc5  push rdi
00007aa3a45dddc6  push rsi
00007aa3a45dddc7  push r8
00007aa3a45dddc9  push r9
00007aa3a45dddcb  push r10
00007aa3a45dddcd  push r11
00007aa3a45dddcf  sub rsp, 0xF0
00007aa3a45dddd6  vmovaps [rsp], xmm0
00007aa3a45ddddb  vmovaps [rsp+0x10], xmm2
00007aa3a45ddde1  vmovaps [rsp+0x20], xmm3
00007aa3a45ddde7  vmovaps [rsp+0x30], xmm4
00007aa3a45ddded  vmovaps [rsp+0x40], xmm5
00007aa3a45dddf3  vmovaps [rsp+0x50], xmm6
00007aa3a45dddf9  vmovaps [rsp+0x60], xmm7
00007aa3a45dddff  vmovaps [rsp+0x70], xmm8
00007aa3a45dde05  vmovaps [rsp+0x80], xmm9
00007aa3a45dde0e  vmovaps [rsp+0x90], xmm10
00007aa3a45dde17  vmovaps [rsp+0xA0], xmm11
00007aa3a45dde20  vmovaps [rsp+0xB0], xmm12
00007aa3a45dde29  vmovaps [rsp+0xC0], xmm13
00007aa3a45dde32  vmovaps [rsp+0xD0], xmm14
00007aa3a45dde3b  vmovaps [rsp+0xE0], xmm15
00007aa3a45dde44  sub rsp, 0x30
00007aa3a45dde48  movaps [rsp], xmm1
00007aa3a45dde4c  movaps [rsp+0x10], xmm5
00007aa3a45dde51  movaps [rsp+0x20], xmm7
00007aa3a45dde56  lea rdi, [rsp]
00007aa3a45dde5a  mov esi, 0x00
00007aa3a45dde5f  mov rax, 0x5F551B683530
00007aa3a45dde69  call rax
00007aa3a45dde6b  movaps xmm1, [rsp]
00007aa3a45dde6f  add rsp, 0x30
00007aa3a45dde73  vmovaps xmm0, [rsp]
00007aa3a45dde78  vmovaps xmm2, [rsp+0x10]
00007aa3a45dde7e  vmovaps xmm3, [rsp+0x20]
00007aa3a45dde84  vmovaps xmm4, [rsp+0x30]
00007aa3a45dde8a  vmovaps xmm5, [rsp+0x40]
00007aa3a45dde90  vmovaps xmm6, [rsp+0x50]
00007aa3a45dde96  vmovaps xmm7, [rsp+0x60]
00007aa3a45dde9c  vmovaps xmm8, [rsp+0x70]
00007aa3a45ddea2  vmovaps xmm9, [rsp+0x80]
00007aa3a45ddeab  vmovaps xmm10, [rsp+0x90]
00007aa3a45ddeb4  vmovaps xmm11, [rsp+0xA0]
00007aa3a45ddebd  vmovaps xmm12, [rsp+0xB0]
00007aa3a45ddec6  vmovaps xmm13, [rsp+0xC0]
00007aa3a45ddecf  vmovaps xmm14, [rsp+0xD0]
00007aa3a45dded8  vmovaps xmm15, [rsp+0xE0]
00007aa3a45ddee1  add rsp, 0xF0
00007aa3a45ddee8  pop r11
00007aa3a45ddeea  pop r10
00007aa3a45ddeec  pop r9
00007aa3a45ddeee  pop r8
00007aa3a45ddef0  pop rsi
00007aa3a45ddef1  pop rdi
00007aa3a45ddef2  pop rdx
00007aa3a45ddef3  pop rcx
00007aa3a45ddef4  pop rax
00007aa3a45ddef5  add rsp, 0x08
00007aa3a45ddef9  jmp 0x00007AA3A45DC030
00007aa3a45ddefe  sub rsp, 0x08
00007aa3a45ddf02  push rax
00007aa3a45ddf03  push rcx
00007aa3a45ddf04  push rdx
00007aa3a45ddf05  push rdi
00007aa3a45ddf06  push rsi
00007aa3a45ddf07  push r8
00007aa3a45ddf09  push r9
00007aa3a45ddf0b  push r10
00007aa3a45ddf0d  push r11
00007aa3a45ddf0f  sub rsp, 0xF0
00007aa3a45ddf16  vmovaps [rsp], xmm0
00007aa3a45ddf1b  vmovaps [rsp+0x10], xmm1
00007aa3a45ddf21  vmovaps [rsp+0x20], xmm2
00007aa3a45ddf27  vmovaps [rsp+0x30], xmm3
00007aa3a45ddf2d  vmovaps [rsp+0x40], xmm4
00007aa3a45ddf33  vmovaps [rsp+0x50], xmm5
00007aa3a45ddf39  vmovaps [rsp+0x60], xmm6
00007aa3a45ddf3f  vmovaps [rsp+0x70], xmm8
00007aa3a45ddf45  vmovaps [rsp+0x80], xmm9
00007aa3a45ddf4e  vmovaps [rsp+0x90], xmm10
00007aa3a45ddf57  vmovaps [rsp+0xA0], xmm11
00007aa3a45ddf60  vmovaps [rsp+0xB0], xmm12
00007aa3a45ddf69  vmovaps [rsp+0xC0], xmm13
00007aa3a45ddf72  vmovaps [rsp+0xD0], xmm14
00007aa3a45ddf7b  vmovaps [rsp+0xE0], xmm15
00007aa3a45ddf84  sub rsp, 0x30
00007aa3a45ddf88  movaps [rsp], xmm7
00007aa3a45ddf8c  movaps [rsp+0x10], xmm5
00007aa3a45ddf91  movaps [rsp+0x20], xmm15
00007aa3a45ddf97  lea rdi, [rsp]
00007aa3a45ddf9b  mov esi, 0x00
00007aa3a45ddfa0  mov rax, 0x5F551B683530
00007aa3a45ddfaa  call rax
00007aa3a45ddfac  movaps xmm7, [rsp]
00007aa3a45ddfb0  add rsp, 0x30
00007aa3a45ddfb4  vmovaps xmm0, [rsp]
00007aa3a45ddfb9  vmovaps xmm1, [rsp+0x10]
00007aa3a45ddfbf  vmovaps xmm2, [rsp+0x20]
00007aa3a45ddfc5  vmovaps xmm3, [rsp+0x30]
00007aa3a45ddfcb  vmovaps xmm4, [rsp+0x40]
00007aa3a45ddfd1  vmovaps xmm5, [rsp+0x50]
00007aa3a45ddfd7  vmovaps xmm6, [rsp+0x60]
00007aa3a45ddfdd  vmovaps xmm8, [rsp+0x70]
00007aa3a45ddfe3  vmovaps xmm9, [rsp+0x80]
00007aa3a45ddfec  vmovaps xmm10, [rsp+0x90]
00007aa3a45ddff5  vmovaps xmm11, [rsp+0xA0]
00007aa3a45ddffe  vmovaps xmm12, [rsp+0xB0]
00007aa3a45de007  vmovaps xmm13, [rsp+0xC0]
00007aa3a45de010  vmovaps xmm14, [rsp+0xD0]
00007aa3a45de019  vmovaps xmm15, [rsp+0xE0]
00007aa3a45de022  add rsp, 0xF0
00007aa3a45de029  pop r11
00007aa3a45de02b  pop r10
00007aa3a45de02d  pop r9
00007aa3a45de02f  pop r8
00007aa3a45de031  pop rsi
00007aa3a45de032  pop rdi
00007aa3a45de033  pop rdx
00007aa3a45de034  pop rcx
00007aa3a45de035  pop rax
00007aa3a45de036  add rsp, 0x08
00007aa3a45de03a  jmp 0x00007AA3A45DC066
00007aa3a45de03f  call 0x00007AA3A44B52F0
00007aa3a45de044  jmp 0x00007AA3A45DC073
00007aa3a45de049  sub rsp, 0x08
00007aa3a45de04d  push rax
00007aa3a45de04e  push rcx
00007aa3a45de04f  push rdx
00007aa3a45de050  push rdi
00007aa3a45de051  push rsi
00007aa3a45de052  push r8
00007aa3a45de054  push r9
00007aa3a45de056  push r10
00007aa3a45de058  push r11
00007aa3a45de05a  sub rsp, 0xF0
00007aa3a45de061  vmovaps [rsp], xmm0
00007aa3a45de066  vmovaps [rsp+0x10], xmm1
00007aa3a45de06c  vmovaps [rsp+0x20], xmm2
00007aa3a45de072  vmovaps [rsp+0x30], xmm3
00007aa3a45de078  vmovaps [rsp+0x40], xmm4
00007aa3a45de07e  vmovaps [rsp+0x50], xmm5
00007aa3a45de084  vmovaps [rsp+0x60], xmm6
00007aa3a45de08a  vmovaps [rsp+0x70], xmm7
00007aa3a45de090  vmovaps [rsp+0x80], xmm8
00007aa3a45de099  vmovaps [rsp+0x90], xmm9
00007aa3a45de0a2  vmovaps [rsp+0xA0], xmm10
00007aa3a45de0ab  vmovaps [rsp+0xB0], xmm11
00007aa3a45de0b4  vmovaps [rsp+0xC0], xmm12
00007aa3a45de0bd  vmovaps [rsp+0xD0], xmm13
00007aa3a45de0c6  vmovaps [rsp+0xE0], xmm14
00007aa3a45de0cf  sub rsp, 0x30
00007aa3a45de0d3  movaps [rsp], xmm15
00007aa3a45de0d8  movaps [rsp+0x10], xmm5
00007aa3a45de0dd  movaps [rsp+0x20], xmm3
00007aa3a45de0e2  lea rdi, [rsp]
00007aa3a45de0e6  mov esi, 0x00
00007aa3a45de0eb  mov rax, 0x5F551B683530
00007aa3a45de0f5  call rax
00007aa3a45de0f7  movaps xmm15, [rsp]
00007aa3a45de0fc  add rsp, 0x30
00007aa3a45de100  vmovaps xmm0, [rsp]
00007aa3a45de105  vmovaps xmm1, [rsp+0x10]
00007aa3a45de10b  vmovaps xmm2, [rsp+0x20]
00007aa3a45de111  vmovaps xmm3, [rsp+0x30]
00007aa3a45de117  vmovaps xmm4, [rsp+0x40]
00007aa3a45de11d  vmovaps xmm5, [rsp+0x50]
00007aa3a45de123  vmovaps xmm6, [rsp+0x60]
00007aa3a45de129  vmovaps xmm7, [rsp+0x70]
00007aa3a45de12f  vmovaps xmm8, [rsp+0x80]
00007aa3a45de138  vmovaps xmm9, [rsp+0x90]
00007aa3a45de141  vmovaps xmm10, [rsp+0xA0]
00007aa3a45de14a  vmovaps xmm11, [rsp+0xB0]
00007aa3a45de153  vmovaps xmm12, [rsp+0xC0]
00007aa3a45de15c  vmovaps xmm13, [rsp+0xD0]
00007aa3a45de165  vmovaps xmm14, [rsp+0xE0]
00007aa3a45de16e  add rsp, 0xF0
00007aa3a45de175  pop r11
00007aa3a45de177  pop r10
00007aa3a45de179  pop r9
00007aa3a45de17b  pop r8
00007aa3a45de17d  pop rsi
00007aa3a45de17e  pop rdi
00007aa3a45de17f  pop rdx
00007aa3a45de180  pop rcx
00007aa3a45de181  pop rax
00007aa3a45de182  add rsp, 0x08
00007aa3a45de186  jmp 0x00007AA3A45DC099
00007aa3a45de18b  sub rsp, 0x08
00007aa3a45de18f  push rax
00007aa3a45de190  push rcx
00007aa3a45de191  push rdx
00007aa3a45de192  push rdi
00007aa3a45de193  push rsi
00007aa3a45de194  push r8
00007aa3a45de196  push r9
00007aa3a45de198  push r10
00007aa3a45de19a  push r11
00007aa3a45de19c  sub rsp, 0xF0
00007aa3a45de1a3  vmovaps [rsp], xmm0
00007aa3a45de1a8  vmovaps [rsp+0x10], xmm2
00007aa3a45de1ae  vmovaps [rsp+0x20], xmm3
00007aa3a45de1b4  vmovaps [rsp+0x30], xmm4
00007aa3a45de1ba  vmovaps [rsp+0x40], xmm5
00007aa3a45de1c0  vmovaps [rsp+0x50], xmm6
00007aa3a45de1c6  vmovaps [rsp+0x60], xmm7
00007aa3a45de1cc  vmovaps [rsp+0x70], xmm8
00007aa3a45de1d2  vmovaps [rsp+0x80], xmm9
00007aa3a45de1db  vmovaps [rsp+0x90], xmm10
00007aa3a45de1e4  vmovaps [rsp+0xA0], xmm11
00007aa3a45de1ed  vmovaps [rsp+0xB0], xmm12
00007aa3a45de1f6  vmovaps [rsp+0xC0], xmm13
00007aa3a45de1ff  vmovaps [rsp+0xD0], xmm14
00007aa3a45de208  vmovaps [rsp+0xE0], xmm15
00007aa3a45de211  sub rsp, 0x30
00007aa3a45de215  movaps [rsp], xmm1
00007aa3a45de219  movaps [rsp+0x10], xmm5
00007aa3a45de21e  movaps [rsp+0x20], xmm4
00007aa3a45de223  lea rdi, [rsp]
00007aa3a45de227  mov esi, 0x00
00007aa3a45de22c  mov rax, 0x5F551B683530
00007aa3a45de236  call rax
00007aa3a45de238  movaps xmm1, [rsp]
00007aa3a45de23c  add rsp, 0x30
00007aa3a45de240  vmovaps xmm0, [rsp]
00007aa3a45de245  vmovaps xmm2, [rsp+0x10]
00007aa3a45de24b  vmovaps xmm3, [rsp+0x20]
00007aa3a45de251  vmovaps xmm4, [rsp+0x30]
00007aa3a45de257  vmovaps xmm5, [rsp+0x40]
00007aa3a45de25d  vmovaps xmm6, [rsp+0x50]
00007aa3a45de263  vmovaps xmm7, [rsp+0x60]
00007aa3a45de269  vmovaps xmm8, [rsp+0x70]
00007aa3a45de26f  vmovaps xmm9, [rsp+0x80]
00007aa3a45de278  vmovaps xmm10, [rsp+0x90]
00007aa3a45de281  vmovaps xmm11, [rsp+0xA0]
00007aa3a45de28a  vmovaps xmm12, [rsp+0xB0]
00007aa3a45de293  vmovaps xmm13, [rsp+0xC0]
00007aa3a45de29c  vmovaps xmm14, [rsp+0xD0]
00007aa3a45de2a5  vmovaps xmm15, [rsp+0xE0]
00007aa3a45de2ae  add rsp, 0xF0
00007aa3a45de2b5  pop r11
00007aa3a45de2b7  pop r10
00007aa3a45de2b9  pop r9
00007aa3a45de2bb  pop r8
00007aa3a45de2bd  pop rsi
00007aa3a45de2be  pop rdi
00007aa3a45de2bf  pop rdx
00007aa3a45de2c0  pop rcx
00007aa3a45de2c1  pop rax
00007aa3a45de2c2  add rsp, 0x08
00007aa3a45de2c6  jmp 0x00007AA3A45DC0B9
00007aa3a45de2cb  sub rsp, 0x08
00007aa3a45de2cf  push rax
00007aa3a45de2d0  push rcx
00007aa3a45de2d1  push rdx
00007aa3a45de2d2  push rdi
00007aa3a45de2d3  push rsi
00007aa3a45de2d4  push r8
00007aa3a45de2d6  push r9
00007aa3a45de2d8  push r10
00007aa3a45de2da  push r11
00007aa3a45de2dc  sub rsp, 0xF0
00007aa3a45de2e3  vmovaps [rsp], xmm0
00007aa3a45de2e8  vmovaps [rsp+0x10], xmm1
00007aa3a45de2ee  vmovaps [rsp+0x20], xmm2
00007aa3a45de2f4  vmovaps [rsp+0x30], xmm3
00007aa3a45de2fa  vmovaps [rsp+0x40], xmm5
00007aa3a45de300  vmovaps [rsp+0x50], xmm6
00007aa3a45de306  vmovaps [rsp+0x60], xmm7
00007aa3a45de30c  vmovaps [rsp+0x70], xmm8
00007aa3a45de312  vmovaps [rsp+0x80], xmm9
00007aa3a45de31b  vmovaps [rsp+0x90], xmm10
00007aa3a45de324  vmovaps [rsp+0xA0], xmm11
00007aa3a45de32d  vmovaps [rsp+0xB0], xmm12
00007aa3a45de336  vmovaps [rsp+0xC0], xmm13
00007aa3a45de33f  vmovaps [rsp+0xD0], xmm14
00007aa3a45de348  vmovaps [rsp+0xE0], xmm15
00007aa3a45de351  sub rsp, 0x30
00007aa3a45de355  movaps [rsp], xmm4
00007aa3a45de359  movaps [rsp+0x10], xmm3
00007aa3a45de35e  movaps [rsp+0x20], xmm5
00007aa3a45de363  lea rdi, [rsp]
00007aa3a45de367  mov esi, 0x00
00007aa3a45de36c  mov rax, 0x5F551B683530
00007aa3a45de376  call rax
00007aa3a45de378  movaps xmm4, [rsp]
00007aa3a45de37c  add rsp, 0x30
00007aa3a45de380  vmovaps xmm0, [rsp]
00007aa3a45de385  vmovaps xmm1, [rsp+0x10]
00007aa3a45de38b  vmovaps xmm2, [rsp+0x20]
00007aa3a45de391  vmovaps xmm3, [rsp+0x30]
00007aa3a45de397  vmovaps xmm5, [rsp+0x40]
00007aa3a45de39d  vmovaps xmm6, [rsp+0x50]
00007aa3a45de3a3  vmovaps xmm7, [rsp+0x60]
00007aa3a45de3a9  vmovaps xmm8, [rsp+0x70]
00007aa3a45de3af  vmovaps xmm9, [rsp+0x80]
00007aa3a45de3b8  vmovaps xmm10, [rsp+0x90]
00007aa3a45de3c1  vmovaps xmm11, [rsp+0xA0]
00007aa3a45de3ca  vmovaps xmm12, [rsp+0xB0]
00007aa3a45de3d3  vmovaps xmm13, [rsp+0xC0]
00007aa3a45de3dc  vmovaps xmm14, [rsp+0xD0]
00007aa3a45de3e5  vmovaps xmm15, [rsp+0xE0]
00007aa3a45de3ee  add rsp, 0xF0
00007aa3a45de3f5  pop r11
00007aa3a45de3f7  pop r10
00007aa3a45de3f9  pop r9
00007aa3a45de3fb  pop r8
00007aa3a45de3fd  pop rsi
00007aa3a45de3fe  pop rdi
00007aa3a45de3ff  pop rdx
00007aa3a45de400  pop rcx
00007aa3a45de401  pop rax
00007aa3a45de402  add rsp, 0x08
00007aa3a45de406  jmp 0x00007AA3A45DC107
00007aa3a45de40b  call 0x00007AA3A44B52F0
00007aa3a45de410  jmp 0x00007AA3A45DC114
00007aa3a45de415  sub rsp, 0x08
00007aa3a45de419  push rax
00007aa3a45de41a  push rcx
00007aa3a45de41b  push rdx
00007aa3a45de41c  push rdi
00007aa3a45de41d  push rsi
00007aa3a45de41e  push r8
00007aa3a45de420  push r9
00007aa3a45de422  push r10
00007aa3a45de424  push r11
00007aa3a45de426  sub rsp, 0xF0
00007aa3a45de42d  vmovaps [rsp], xmm0
00007aa3a45de432  vmovaps [rsp+0x10], xmm1
00007aa3a45de438  vmovaps [rsp+0x20], xmm2
00007aa3a45de43e  vmovaps [rsp+0x30], xmm3
00007aa3a45de444  vmovaps [rsp+0x40], xmm4
00007aa3a45de44a  vmovaps [rsp+0x50], xmm6
00007aa3a45de450  vmovaps [rsp+0x60], xmm7
00007aa3a45de456  vmovaps [rsp+0x70], xmm8
00007aa3a45de45c  vmovaps [rsp+0x80], xmm9
00007aa3a45de465  vmovaps [rsp+0x90], xmm10
00007aa3a45de46e  vmovaps [rsp+0xA0], xmm11
00007aa3a45de477  vmovaps [rsp+0xB0], xmm12
00007aa3a45de480  vmovaps [rsp+0xC0], xmm13
00007aa3a45de489  vmovaps [rsp+0xD0], xmm14
00007aa3a45de492  vmovaps [rsp+0xE0], xmm15
00007aa3a45de49b  sub rsp, 0x30
00007aa3a45de49f  movaps [rsp], xmm5
00007aa3a45de4a3  movaps [rsp+0x10], xmm6
00007aa3a45de4a8  movaps [rsp+0x20], xmm3
00007aa3a45de4ad  lea rdi, [rsp]
00007aa3a45de4b1  mov esi, 0x00
00007aa3a45de4b6  mov rax, 0x5F551B683530
00007aa3a45de4c0  call rax
00007aa3a45de4c2  movaps xmm5, [rsp]
00007aa3a45de4c6  add rsp, 0x30
00007aa3a45de4ca  vmovaps xmm0, [rsp]
00007aa3a45de4cf  vmovaps xmm1, [rsp+0x10]
00007aa3a45de4d5  vmovaps xmm2, [rsp+0x20]
00007aa3a45de4db  vmovaps xmm3, [rsp+0x30]
00007aa3a45de4e1  vmovaps xmm4, [rsp+0x40]
00007aa3a45de4e7  vmovaps xmm6, [rsp+0x50]
00007aa3a45de4ed  vmovaps xmm7, [rsp+0x60]
00007aa3a45de4f3  vmovaps xmm8, [rsp+0x70]
00007aa3a45de4f9  vmovaps xmm9, [rsp+0x80]
00007aa3a45de502  vmovaps xmm10, [rsp+0x90]
00007aa3a45de50b  vmovaps xmm11, [rsp+0xA0]
00007aa3a45de514  vmovaps xmm12, [rsp+0xB0]
00007aa3a45de51d  vmovaps xmm13, [rsp+0xC0]
00007aa3a45de526  vmovaps xmm14, [rsp+0xD0]
00007aa3a45de52f  vmovaps xmm15, [rsp+0xE0]
00007aa3a45de538  add rsp, 0xF0
00007aa3a45de53f  pop r11
00007aa3a45de541  pop r10
00007aa3a45de543  pop r9
00007aa3a45de545  pop r8
00007aa3a45de547  pop rsi
00007aa3a45de548  pop rdi
00007aa3a45de549  pop rdx
00007aa3a45de54a  pop rcx
00007aa3a45de54b  pop rax
00007aa3a45de54c  add rsp, 0x08
00007aa3a45de550  jmp 0x00007AA3A45DC13A
00007aa3a45de555  sub rsp, 0x08
00007aa3a45de559  push rax
00007aa3a45de55a  push rcx
00007aa3a45de55b  push rdx
00007aa3a45de55c  push rdi
00007aa3a45de55d  push rsi
00007aa3a45de55e  push r8
00007aa3a45de560  push r9
00007aa3a45de562  push r10
00007aa3a45de564  push r11
00007aa3a45de566  sub rsp, 0xF0
00007aa3a45de56d  vmovaps [rsp], xmm0
00007aa3a45de572  vmovaps [rsp+0x10], xmm1
00007aa3a45de578  vmovaps [rsp+0x20], xmm2
00007aa3a45de57e  vmovaps [rsp+0x30], xmm3
00007aa3a45de584  vmovaps [rsp+0x40], xmm4
00007aa3a45de58a  vmovaps [rsp+0x50], xmm5
00007aa3a45de590  vmovaps [rsp+0x60], xmm7
00007aa3a45de596  vmovaps [rsp+0x70], xmm8
00007aa3a45de59c  vmovaps [rsp+0x80], xmm9
00007aa3a45de5a5  vmovaps [rsp+0x90], xmm10
00007aa3a45de5ae  vmovaps [rsp+0xA0], xmm11
00007aa3a45de5b7  vmovaps [rsp+0xB0], xmm12
00007aa3a45de5c0  vmovaps [rsp+0xC0], xmm13
00007aa3a45de5c9  vmovaps [rsp+0xD0], xmm14
00007aa3a45de5d2  vmovaps [rsp+0xE0], xmm15
00007aa3a45de5db  sub rsp, 0x30
00007aa3a45de5df  movaps [rsp], xmm6
00007aa3a45de5e3  movaps [rsp+0x10], xmm9
00007aa3a45de5e9  movaps [rsp+0x20], xmm1
00007aa3a45de5ee  lea rdi, [rsp]
00007aa3a45de5f2  mov esi, 0x00
00007aa3a45de5f7  mov rax, 0x5F551B683530
00007aa3a45de601  call rax
00007aa3a45de603  movaps xmm6, [rsp]
00007aa3a45de607  add rsp, 0x30
00007aa3a45de60b  vmovaps xmm0, [rsp]
00007aa3a45de610  vmovaps xmm1, [rsp+0x10]
00007aa3a45de616  vmovaps xmm2, [rsp+0x20]
00007aa3a45de61c  vmovaps xmm3, [rsp+0x30]
00007aa3a45de622  vmovaps xmm4, [rsp+0x40]
00007aa3a45de628  vmovaps xmm5, [rsp+0x50]
00007aa3a45de62e  vmovaps xmm7, [rsp+0x60]
00007aa3a45de634  vmovaps xmm8, [rsp+0x70]
00007aa3a45de63a  vmovaps xmm9, [rsp+0x80]
00007aa3a45de643  vmovaps xmm10, [rsp+0x90]
00007aa3a45de64c  vmovaps xmm11, [rsp+0xA0]
00007aa3a45de655  vmovaps xmm12, [rsp+0xB0]
00007aa3a45de65e  vmovaps xmm13, [rsp+0xC0]
00007aa3a45de667  vmovaps xmm14, [rsp+0xD0]
00007aa3a45de670  vmovaps xmm15, [rsp+0xE0]
00007aa3a45de679  add rsp, 0xF0
00007aa3a45de680  pop r11
00007aa3a45de682  pop r10
00007aa3a45de684  pop r9
00007aa3a45de686  pop r8
00007aa3a45de688  pop rsi
00007aa3a45de689  pop rdi
00007aa3a45de68a  pop rdx
00007aa3a45de68b  pop rcx
00007aa3a45de68c  pop rax
00007aa3a45de68d  add rsp, 0x08
00007aa3a45de691  jmp 0x00007AA3A45DC15E
00007aa3a45de696  sub rsp, 0x08
00007aa3a45de69a  push rax
00007aa3a45de69b  push rcx
00007aa3a45de69c  push rdx
00007aa3a45de69d  push rdi
00007aa3a45de69e  push rsi
00007aa3a45de69f  push r8
00007aa3a45de6a1  push r9
00007aa3a45de6a3  push r10
00007aa3a45de6a5  push r11
00007aa3a45de6a7  sub rsp, 0xF0
00007aa3a45de6ae  vmovaps [rsp], xmm0
00007aa3a45de6b3  vmovaps [rsp+0x10], xmm1
00007aa3a45de6b9  vmovaps [rsp+0x20], xmm2
00007aa3a45de6bf  vmovaps [rsp+0x30], xmm3
00007aa3a45de6c5  vmovaps [rsp+0x40], xmm4
00007aa3a45de6cb  vmovaps [rsp+0x50], xmm5
00007aa3a45de6d1  vmovaps [rsp+0x60], xmm6
00007aa3a45de6d7  vmovaps [rsp+0x70], xmm7
00007aa3a45de6dd  vmovaps [rsp+0x80], xmm8
00007aa3a45de6e6  vmovaps [rsp+0x90], xmm10
00007aa3a45de6ef  vmovaps [rsp+0xA0], xmm11
00007aa3a45de6f8  vmovaps [rsp+0xB0], xmm12
00007aa3a45de701  vmovaps [rsp+0xC0], xmm13
00007aa3a45de70a  vmovaps [rsp+0xD0], xmm14
00007aa3a45de713  vmovaps [rsp+0xE0], xmm15
00007aa3a45de71c  sub rsp, 0x30
00007aa3a45de720  movaps [rsp], xmm9
00007aa3a45de725  movaps [rsp+0x10], xmm3
00007aa3a45de72a  movaps [rsp+0x20], xmm1
00007aa3a45de72f  lea rdi, [rsp]
00007aa3a45de733  mov esi, 0x00
00007aa3a45de738  mov rax, 0x5F551B683530
00007aa3a45de742  call rax
00007aa3a45de744  movaps xmm9, [rsp]
00007aa3a45de749  add rsp, 0x30
00007aa3a45de74d  vmovaps xmm0, [rsp]
00007aa3a45de752  vmovaps xmm1, [rsp+0x10]
00007aa3a45de758  vmovaps xmm2, [rsp+0x20]
00007aa3a45de75e  vmovaps xmm3, [rsp+0x30]
00007aa3a45de764  vmovaps xmm4, [rsp+0x40]
00007aa3a45de76a  vmovaps xmm5, [rsp+0x50]
00007aa3a45de770  vmovaps xmm6, [rsp+0x60]
00007aa3a45de776  vmovaps xmm7, [rsp+0x70]
00007aa3a45de77c  vmovaps xmm8, [rsp+0x80]
00007aa3a45de785  vmovaps xmm10, [rsp+0x90]
00007aa3a45de78e  vmovaps xmm11, [rsp+0xA0]
00007aa3a45de797  vmovaps xmm12, [rsp+0xB0]
00007aa3a45de7a0  vmovaps xmm13, [rsp+0xC0]
00007aa3a45de7a9  vmovaps xmm14, [rsp+0xD0]
00007aa3a45de7b2  vmovaps xmm15, [rsp+0xE0]
00007aa3a45de7bb  add rsp, 0xF0
00007aa3a45de7c2  pop r11
00007aa3a45de7c4  pop r10
00007aa3a45de7c6  pop r9
00007aa3a45de7c8  pop r8
00007aa3a45de7ca  pop rsi
00007aa3a45de7cb  pop rdi
00007aa3a45de7cc  pop rdx
00007aa3a45de7cd  pop rcx
00007aa3a45de7ce  pop rax
00007aa3a45de7cf  add rsp, 0x08
00007aa3a45de7d3  jmp 0x00007AA3A45DC1AA
00007aa3a45de7d8  call 0x00007AA3A44B52F0
00007aa3a45de7dd  jmp 0x00007AA3A45DC1B7
00007aa3a45de7e2  sub rsp, 0x08
00007aa3a45de7e6  push rax
00007aa3a45de7e7  push rcx
00007aa3a45de7e8  push rdx
00007aa3a45de7e9  push rdi
00007aa3a45de7ea  push rsi
00007aa3a45de7eb  push r8
00007aa3a45de7ed  push r9
00007aa3a45de7ef  push r10
00007aa3a45de7f1  push r11
00007aa3a45de7f3  sub rsp, 0xF0
00007aa3a45de7fa  vmovaps [rsp], xmm0
00007aa3a45de7ff  vmovaps [rsp+0x10], xmm1
00007aa3a45de805  vmovaps [rsp+0x20], xmm2
00007aa3a45de80b  vmovaps [rsp+0x30], xmm3
00007aa3a45de811  vmovaps [rsp+0x40], xmm4
00007aa3a45de817  vmovaps [rsp+0x50], xmm5
00007aa3a45de81d  vmovaps [rsp+0x60], xmm6
00007aa3a45de823  vmovaps [rsp+0x70], xmm7
00007aa3a45de829  vmovaps [rsp+0x80], xmm8
00007aa3a45de832  vmovaps [rsp+0x90], xmm9
00007aa3a45de83b  vmovaps [rsp+0xA0], xmm10
00007aa3a45de844  vmovaps [rsp+0xB0], xmm11
00007aa3a45de84d  vmovaps [rsp+0xC0], xmm12
00007aa3a45de856  vmovaps [rsp+0xD0], xmm13
00007aa3a45de85f  vmovaps [rsp+0xE0], xmm14
00007aa3a45de868  sub rsp, 0x30
00007aa3a45de86c  movaps [rsp], xmm15
00007aa3a45de871  movaps [rsp+0x10], xmm3
00007aa3a45de876  movaps [rsp+0x20], xmm7
00007aa3a45de87b  lea rdi, [rsp]
00007aa3a45de87f  mov esi, 0x00
00007aa3a45de884  mov rax, 0x5F551B683530
00007aa3a45de88e  call rax
00007aa3a45de890  movaps xmm15, [rsp]
00007aa3a45de895  add rsp, 0x30
00007aa3a45de899  vmovaps xmm0, [rsp]
00007aa3a45de89e  vmovaps xmm1, [rsp+0x10]
00007aa3a45de8a4  vmovaps xmm2, [rsp+0x20]
00007aa3a45de8aa  vmovaps xmm3, [rsp+0x30]
00007aa3a45de8b0  vmovaps xmm4, [rsp+0x40]
00007aa3a45de8b6  vmovaps xmm5, [rsp+0x50]
00007aa3a45de8bc  vmovaps xmm6, [rsp+0x60]
00007aa3a45de8c2  vmovaps xmm7, [rsp+0x70]
00007aa3a45de8c8  vmovaps xmm8, [rsp+0x80]
00007aa3a45de8d1  vmovaps xmm9, [rsp+0x90]
00007aa3a45de8da  vmovaps xmm10, [rsp+0xA0]
00007aa3a45de8e3  vmovaps xmm11, [rsp+0xB0]
00007aa3a45de8ec  vmovaps xmm12, [rsp+0xC0]
00007aa3a45de8f5  vmovaps xmm13, [rsp+0xD0]
00007aa3a45de8fe  vmovaps xmm14, [rsp+0xE0]
00007aa3a45de907  add rsp, 0xF0
00007aa3a45de90e  pop r11
00007aa3a45de910  pop r10
00007aa3a45de912  pop r9
00007aa3a45de914  pop r8
00007aa3a45de916  pop rsi
00007aa3a45de917  pop rdi
00007aa3a45de918  pop rdx
00007aa3a45de919  pop rcx
00007aa3a45de91a  pop rax
00007aa3a45de91b  add rsp, 0x08
00007aa3a45de91f  jmp 0x00007AA3A45DC1E3
00007aa3a45de924  sub rsp, 0x08
00007aa3a45de928  push rax
00007aa3a45de929  push rcx
00007aa3a45de92a  push rdx
00007aa3a45de92b  push rdi
00007aa3a45de92c  push rsi
00007aa3a45de92d  push r8
00007aa3a45de92f  push r9
00007aa3a45de931  push r10
00007aa3a45de933  push r11
00007aa3a45de935  sub rsp, 0xF0
00007aa3a45de93c  vmovaps [rsp], xmm0
00007aa3a45de941  vmovaps [rsp+0x10], xmm1
00007aa3a45de947  vmovaps [rsp+0x20], xmm2
00007aa3a45de94d  vmovaps [rsp+0x30], xmm4
00007aa3a45de953  vmovaps [rsp+0x40], xmm5
00007aa3a45de959  vmovaps [rsp+0x50], xmm6
00007aa3a45de95f  vmovaps [rsp+0x60], xmm7
00007aa3a45de965  vmovaps [rsp+0x70], xmm8
00007aa3a45de96b  vmovaps [rsp+0x80], xmm9
00007aa3a45de974  vmovaps [rsp+0x90], xmm10
00007aa3a45de97d  vmovaps [rsp+0xA0], xmm11
00007aa3a45de986  vmovaps [rsp+0xB0], xmm12
00007aa3a45de98f  vmovaps [rsp+0xC0], xmm13
00007aa3a45de998  vmovaps [rsp+0xD0], xmm14
00007aa3a45de9a1  vmovaps [rsp+0xE0], xmm15
00007aa3a45de9aa  sub rsp, 0x30
00007aa3a45de9ae  movaps [rsp], xmm3
00007aa3a45de9b2  movaps [rsp+0x10], xmm1
00007aa3a45de9b7  movaps [rsp+0x20], xmm15
00007aa3a45de9bd  lea rdi, [rsp]
00007aa3a45de9c1  mov esi, 0x00
00007aa3a45de9c6  mov rax, 0x5F551B683530
00007aa3a45de9d0  call rax
00007aa3a45de9d2  movaps xmm3, [rsp]
00007aa3a45de9d6  add rsp, 0x30
00007aa3a45de9da  vmovaps xmm0, [rsp]
00007aa3a45de9df  vmovaps xmm1, [rsp+0x10]
00007aa3a45de9e5  vmovaps xmm2, [rsp+0x20]
00007aa3a45de9eb  vmovaps xmm4, [rsp+0x30]
00007aa3a45de9f1  vmovaps xmm5, [rsp+0x40]
00007aa3a45de9f7  vmovaps xmm6, [rsp+0x50]
00007aa3a45de9fd  vmovaps xmm7, [rsp+0x60]
00007aa3a45dea03  vmovaps xmm8, [rsp+0x70]
00007aa3a45dea09  vmovaps xmm9, [rsp+0x80]
00007aa3a45dea12  vmovaps xmm10, [rsp+0x90]
00007aa3a45dea1b  vmovaps xmm11, [rsp+0xA0]
00007aa3a45dea24  vmovaps xmm12, [rsp+0xB0]
00007aa3a45dea2d  vmovaps xmm13, [rsp+0xC0]
00007aa3a45dea36  vmovaps xmm14, [rsp+0xD0]
00007aa3a45dea3f  vmovaps xmm15, [rsp+0xE0]
00007aa3a45dea48  add rsp, 0xF0
00007aa3a45dea4f  pop r11
00007aa3a45dea51  pop r10
00007aa3a45dea53  pop r9
00007aa3a45dea55  pop r8
00007aa3a45dea57  pop rsi
00007aa3a45dea58  pop rdi
00007aa3a45dea59  pop rdx
00007aa3a45dea5a  pop rcx
00007aa3a45dea5b  pop rax
00007aa3a45dea5c  add rsp, 0x08
00007aa3a45dea60  jmp 0x00007AA3A45DC272
00007aa3a45dea65  call 0x00007AA3A44B52F0
00007aa3a45dea6a  jmp 0x00007AA3A45DC27C
00007aa3a45dea6f  sub rsp, 0x08
00007aa3a45dea73  push rax
00007aa3a45dea74  push rcx
00007aa3a45dea75  push rdx
00007aa3a45dea76  push rdi
00007aa3a45dea77  push rsi
00007aa3a45dea78  push r8
00007aa3a45dea7a  push r9
00007aa3a45dea7c  push r10
00007aa3a45dea7e  push r11
00007aa3a45dea80  sub rsp, 0xF0
00007aa3a45dea87  vmovaps [rsp], xmm0
00007aa3a45dea8c  vmovaps [rsp+0x10], xmm1
00007aa3a45dea92  vmovaps [rsp+0x20], xmm2
00007aa3a45dea98  vmovaps [rsp+0x30], xmm3
00007aa3a45dea9e  vmovaps [rsp+0x40], xmm4
00007aa3a45deaa4  vmovaps [rsp+0x50], xmm5
00007aa3a45deaaa  vmovaps [rsp+0x60], xmm6
00007aa3a45deab0  vmovaps [rsp+0x70], xmm7
00007aa3a45deab6  vmovaps [rsp+0x80], xmm8
00007aa3a45deabf  vmovaps [rsp+0x90], xmm9
00007aa3a45deac8  vmovaps [rsp+0xA0], xmm10
00007aa3a45dead1  vmovaps [rsp+0xB0], xmm11
00007aa3a45deada  vmovaps [rsp+0xC0], xmm12
00007aa3a45deae3  vmovaps [rsp+0xD0], xmm13
00007aa3a45deaec  vmovaps [rsp+0xE0], xmm14
00007aa3a45deaf5  sub rsp, 0x30
00007aa3a45deaf9  movaps [rsp], xmm15
00007aa3a45deafe  movaps [rsp+0x10], xmm14
00007aa3a45deb04  movaps [rsp+0x20], xmm4
00007aa3a45deb09  lea rdi, [rsp]
00007aa3a45deb0d  mov esi, 0x00
00007aa3a45deb12  mov rax, 0x5F551B683530
00007aa3a45deb1c  call rax
00007aa3a45deb1e  movaps xmm15, [rsp]
00007aa3a45deb23  add rsp, 0x30
00007aa3a45deb27  vmovaps xmm0, [rsp]
00007aa3a45deb2c  vmovaps xmm1, [rsp+0x10]
00007aa3a45deb32  vmovaps xmm2, [rsp+0x20]
00007aa3a45deb38  vmovaps xmm3, [rsp+0x30]
00007aa3a45deb3e  vmovaps xmm4, [rsp+0x40]
00007aa3a45deb44  vmovaps xmm5, [rsp+0x50]
00007aa3a45deb4a  vmovaps xmm6, [rsp+0x60]
00007aa3a45deb50  vmovaps xmm7, [rsp+0x70]
00007aa3a45deb56  vmovaps xmm8, [rsp+0x80]
00007aa3a45deb5f  vmovaps xmm9, [rsp+0x90]
00007aa3a45deb68  vmovaps xmm10, [rsp+0xA0]
00007aa3a45deb71  vmovaps xmm11, [rsp+0xB0]
00007aa3a45deb7a  vmovaps xmm12, [rsp+0xC0]
00007aa3a45deb83  vmovaps xmm13, [rsp+0xD0]
00007aa3a45deb8c  vmovaps xmm14, [rsp+0xE0]
00007aa3a45deb95  add rsp, 0xF0
00007aa3a45deb9c  pop r11
00007aa3a45deb9e  pop r10
00007aa3a45deba0  pop r9
00007aa3a45deba2  pop r8
00007aa3a45deba4  pop rsi
00007aa3a45deba5  pop rdi
00007aa3a45deba6  pop rdx
00007aa3a45deba7  pop rcx
00007aa3a45deba8  pop rax
00007aa3a45deba9  add rsp, 0x08
00007aa3a45debad  jmp 0x00007AA3A45DC2AA
00007aa3a45debb2  sub rsp, 0x08
00007aa3a45debb6  push rax
00007aa3a45debb7  push rcx
00007aa3a45debb8  push rdx
00007aa3a45debb9  push rdi
00007aa3a45debba  push rsi
00007aa3a45debbb  push r8
00007aa3a45debbd  push r9
00007aa3a45debbf  push r10
00007aa3a45debc1  push r11
00007aa3a45debc3  sub rsp, 0xF0
00007aa3a45debca  vmovaps [rsp], xmm0
00007aa3a45debcf  vmovaps [rsp+0x10], xmm1
00007aa3a45debd5  vmovaps [rsp+0x20], xmm2
00007aa3a45debdb  vmovaps [rsp+0x30], xmm3
00007aa3a45debe1  vmovaps [rsp+0x40], xmm4
00007aa3a45debe7  vmovaps [rsp+0x50], xmm5
00007aa3a45debed  vmovaps [rsp+0x60], xmm6
00007aa3a45debf3  vmovaps [rsp+0x70], xmm7
00007aa3a45debf9  vmovaps [rsp+0x80], xmm8
00007aa3a45dec02  vmovaps [rsp+0x90], xmm9
00007aa3a45dec0b  vmovaps [rsp+0xA0], xmm10
00007aa3a45dec14  vmovaps [rsp+0xB0], xmm11
00007aa3a45dec1d  vmovaps [rsp+0xC0], xmm12
00007aa3a45dec26  vmovaps [rsp+0xD0], xmm13
00007aa3a45dec2f  vmovaps [rsp+0xE0], xmm15
00007aa3a45dec38  sub rsp, 0x30
00007aa3a45dec3c  movaps [rsp], xmm14
00007aa3a45dec41  movaps [rsp+0x10], xmm2
00007aa3a45dec46  movaps [rsp+0x20], xmm1
00007aa3a45dec4b  lea rdi, [rsp]
00007aa3a45dec4f  mov esi, 0x00
00007aa3a45dec54  mov rax, 0x5F551B683530
00007aa3a45dec5e  call rax
00007aa3a45dec60  movaps xmm14, [rsp]
00007aa3a45dec65  add rsp, 0x30
00007aa3a45dec69  vmovaps xmm0, [rsp]
00007aa3a45dec6e  vmovaps xmm1, [rsp+0x10]
00007aa3a45dec74  vmovaps xmm2, [rsp+0x20]
00007aa3a45dec7a  vmovaps xmm3, [rsp+0x30]
00007aa3a45dec80  vmovaps xmm4, [rsp+0x40]
00007aa3a45dec86  vmovaps xmm5, [rsp+0x50]
00007aa3a45dec8c  vmovaps xmm6, [rsp+0x60]
00007aa3a45dec92  vmovaps xmm7, [rsp+0x70]
00007aa3a45dec98  vmovaps xmm8, [rsp+0x80]
00007aa3a45deca1  vmovaps xmm9, [rsp+0x90]
00007aa3a45decaa  vmovaps xmm10, [rsp+0xA0]
00007aa3a45decb3  vmovaps xmm11, [rsp+0xB0]
00007aa3a45decbc  vmovaps xmm12, [rsp+0xC0]
00007aa3a45decc5  vmovaps xmm13, [rsp+0xD0]
00007aa3a45decce  vmovaps xmm15, [rsp+0xE0]
00007aa3a45decd7  add rsp, 0xF0
00007aa3a45decde  pop r11
00007aa3a45dece0  pop r10
00007aa3a45dece2  pop r9
00007aa3a45dece4  pop r8
00007aa3a45dece6  pop rsi
00007aa3a45dece7  pop rdi
00007aa3a45dece8  pop rdx
00007aa3a45dece9  pop rcx
00007aa3a45decea  pop rax
00007aa3a45deceb  add rsp, 0x08
00007aa3a45decef  jmp 0x00007AA3A45DC2D0
00007aa3a45decf4  sub rsp, 0x08
00007aa3a45decf8  push rax
00007aa3a45decf9  push rcx
00007aa3a45decfa  push rdx
00007aa3a45decfb  push rdi
00007aa3a45decfc  push rsi
00007aa3a45decfd  push r8
00007aa3a45decff  push r9
00007aa3a45ded01  push r10
00007aa3a45ded03  push r11
00007aa3a45ded05  sub rsp, 0xF0
00007aa3a45ded0c  vmovaps [rsp], xmm0
00007aa3a45ded11  vmovaps [rsp+0x10], xmm2
00007aa3a45ded17  vmovaps [rsp+0x20], xmm3
00007aa3a45ded1d  vmovaps [rsp+0x30], xmm4
00007aa3a45ded23  vmovaps [rsp+0x40], xmm5
00007aa3a45ded29  vmovaps [rsp+0x50], xmm6
00007aa3a45ded2f  vmovaps [rsp+0x60], xmm7
00007aa3a45ded35  vmovaps [rsp+0x70], xmm8
00007aa3a45ded3b  vmovaps [rsp+0x80], xmm9
00007aa3a45ded44  vmovaps [rsp+0x90], xmm10
00007aa3a45ded4d  vmovaps [rsp+0xA0], xmm11
00007aa3a45ded56  vmovaps [rsp+0xB0], xmm12
00007aa3a45ded5f  vmovaps [rsp+0xC0], xmm13
00007aa3a45ded68  vmovaps [rsp+0xD0], xmm14
00007aa3a45ded71  vmovaps [rsp+0xE0], xmm15
00007aa3a45ded7a  sub rsp, 0x30
00007aa3a45ded7e  movaps [rsp], xmm1
00007aa3a45ded82  movaps [rsp+0x10], xmm4
00007aa3a45ded87  movaps [rsp+0x20], xmm9
00007aa3a45ded8d  lea rdi, [rsp]
00007aa3a45ded91  mov esi, 0x00
00007aa3a45ded96  mov rax, 0x5F551B683530
00007aa3a45deda0  call rax
00007aa3a45deda2  movaps xmm1, [rsp]
00007aa3a45deda6  add rsp, 0x30
00007aa3a45dedaa  vmovaps xmm0, [rsp]
00007aa3a45dedaf  vmovaps xmm2, [rsp+0x10]
00007aa3a45dedb5  vmovaps xmm3, [rsp+0x20]
00007aa3a45dedbb  vmovaps xmm4, [rsp+0x30]
00007aa3a45dedc1  vmovaps xmm5, [rsp+0x40]
00007aa3a45dedc7  vmovaps xmm6, [rsp+0x50]
00007aa3a45dedcd  vmovaps xmm7, [rsp+0x60]
00007aa3a45dedd3  vmovaps xmm8, [rsp+0x70]
00007aa3a45dedd9  vmovaps xmm9, [rsp+0x80]
00007aa3a45dede2  vmovaps xmm10, [rsp+0x90]
00007aa3a45dedeb  vmovaps xmm11, [rsp+0xA0]
00007aa3a45dedf4  vmovaps xmm12, [rsp+0xB0]
00007aa3a45dedfd  vmovaps xmm13, [rsp+0xC0]
00007aa3a45dee06  vmovaps xmm14, [rsp+0xD0]
00007aa3a45dee0f  vmovaps xmm15, [rsp+0xE0]
00007aa3a45dee18  add rsp, 0xF0
00007aa3a45dee1f  pop r11
00007aa3a45dee21  pop r10
00007aa3a45dee23  pop r9
00007aa3a45dee25  pop r8
00007aa3a45dee27  pop rsi
00007aa3a45dee28  pop rdi
00007aa3a45dee29  pop rdx
00007aa3a45dee2a  pop rcx
00007aa3a45dee2b  pop rax
00007aa3a45dee2c  add rsp, 0x08
00007aa3a45dee30  jmp 0x00007AA3A45DC2EE
00007aa3a45dee35  sub rsp, 0x08
00007aa3a45dee39  push rax
00007aa3a45dee3a  push rcx
00007aa3a45dee3b  push rdx
00007aa3a45dee3c  push rdi
00007aa3a45dee3d  push rsi
00007aa3a45dee3e  push r8
00007aa3a45dee40  push r9
00007aa3a45dee42  push r10
00007aa3a45dee44  push r11
00007aa3a45dee46  sub rsp, 0xF0
00007aa3a45dee4d  vmovaps [rsp], xmm0
00007aa3a45dee52  vmovaps [rsp+0x10], xmm1
00007aa3a45dee58  vmovaps [rsp+0x20], xmm2
00007aa3a45dee5e  vmovaps [rsp+0x30], xmm3
00007aa3a45dee64  vmovaps [rsp+0x40], xmm5
00007aa3a45dee6a  vmovaps [rsp+0x50], xmm6
00007aa3a45dee70  vmovaps [rsp+0x60], xmm7
00007aa3a45dee76  vmovaps [rsp+0x70], xmm8
00007aa3a45dee7c  vmovaps [rsp+0x80], xmm9
00007aa3a45dee85  vmovaps [rsp+0x90], xmm10
00007aa3a45dee8e  vmovaps [rsp+0xA0], xmm11
00007aa3a45dee97  vmovaps [rsp+0xB0], xmm12
00007aa3a45deea0  vmovaps [rsp+0xC0], xmm13
00007aa3a45deea9  vmovaps [rsp+0xD0], xmm14
00007aa3a45deeb2  vmovaps [rsp+0xE0], xmm15
00007aa3a45deebb  sub rsp, 0x30
00007aa3a45deebf  movaps [rsp], xmm4
00007aa3a45deec3  movaps [rsp+0x10], xmm2
00007aa3a45deec8  movaps [rsp+0x20], xmm9
00007aa3a45deece  lea rdi, [rsp]
00007aa3a45deed2  mov esi, 0x00
00007aa3a45deed7  mov rax, 0x5F551B683530
00007aa3a45deee1  call rax
00007aa3a45deee3  movaps xmm4, [rsp]
00007aa3a45deee7  add rsp, 0x30
00007aa3a45deeeb  vmovaps xmm0, [rsp]
00007aa3a45deef0  vmovaps xmm1, [rsp+0x10]
00007aa3a45deef6  vmovaps xmm2, [rsp+0x20]
00007aa3a45deefc  vmovaps xmm3, [rsp+0x30]
00007aa3a45def02  vmovaps xmm5, [rsp+0x40]
00007aa3a45def08  vmovaps xmm6, [rsp+0x50]
00007aa3a45def0e  vmovaps xmm7, [rsp+0x60]
00007aa3a45def14  vmovaps xmm8, [rsp+0x70]
00007aa3a45def1a  vmovaps xmm9, [rsp+0x80]
00007aa3a45def23  vmovaps xmm10, [rsp+0x90]
00007aa3a45def2c  vmovaps xmm11, [rsp+0xA0]
00007aa3a45def35  vmovaps xmm12, [rsp+0xB0]
00007aa3a45def3e  vmovaps xmm13, [rsp+0xC0]
00007aa3a45def47  vmovaps xmm14, [rsp+0xD0]
00007aa3a45def50  vmovaps xmm15, [rsp+0xE0]
00007aa3a45def59  add rsp, 0xF0
00007aa3a45def60  pop r11
00007aa3a45def62  pop r10
00007aa3a45def64  pop r9
00007aa3a45def66  pop r8
00007aa3a45def68  pop rsi
00007aa3a45def69  pop rdi
00007aa3a45def6a  pop rdx
00007aa3a45def6b  pop rcx
00007aa3a45def6c  pop rax
00007aa3a45def6d  add rsp, 0x08
00007aa3a45def71  jmp 0x00007AA3A45DC31E
00007aa3a45def76  sub rsp, 0x08
00007aa3a45def7a  push rax
00007aa3a45def7b  push rcx
00007aa3a45def7c  push rdx
00007aa3a45def7d  push rdi
00007aa3a45def7e  push rsi
00007aa3a45def7f  push r8
00007aa3a45def81  push r9
00007aa3a45def83  push r10
00007aa3a45def85  push r11
00007aa3a45def87  sub rsp, 0xF0
00007aa3a45def8e  vmovaps [rsp], xmm0
00007aa3a45def93  vmovaps [rsp+0x10], xmm1
00007aa3a45def99  vmovaps [rsp+0x20], xmm2
00007aa3a45def9f  vmovaps [rsp+0x30], xmm3
00007aa3a45defa5  vmovaps [rsp+0x40], xmm4
00007aa3a45defab  vmovaps [rsp+0x50], xmm5
00007aa3a45defb1  vmovaps [rsp+0x60], xmm6
00007aa3a45defb7  vmovaps [rsp+0x70], xmm7
00007aa3a45defbd  vmovaps [rsp+0x80], xmm8
00007aa3a45defc6  vmovaps [rsp+0x90], xmm10
00007aa3a45defcf  vmovaps [rsp+0xA0], xmm11
00007aa3a45defd8  vmovaps [rsp+0xB0], xmm12
00007aa3a45defe1  vmovaps [rsp+0xC0], xmm13
00007aa3a45defea  vmovaps [rsp+0xD0], xmm14
00007aa3a45deff3  vmovaps [rsp+0xE0], xmm15
00007aa3a45deffc  sub rsp, 0x30
00007aa3a45df000  movaps [rsp], xmm9
00007aa3a45df005  movaps [rsp+0x10], xmm2
00007aa3a45df00a  movaps [rsp+0x20], xmm1
00007aa3a45df00f  lea rdi, [rsp]
00007aa3a45df013  mov esi, 0x00
00007aa3a45df018  mov rax, 0x5F551B683530
00007aa3a45df022  call rax
00007aa3a45df024  movaps xmm9, [rsp]
00007aa3a45df029  add rsp, 0x30
00007aa3a45df02d  vmovaps xmm0, [rsp]
00007aa3a45df032  vmovaps xmm1, [rsp+0x10]
00007aa3a45df038  vmovaps xmm2, [rsp+0x20]
00007aa3a45df03e  vmovaps xmm3, [rsp+0x30]
00007aa3a45df044  vmovaps xmm4, [rsp+0x40]
00007aa3a45df04a  vmovaps xmm5, [rsp+0x50]
00007aa3a45df050  vmovaps xmm6, [rsp+0x60]
00007aa3a45df056  vmovaps xmm7, [rsp+0x70]
00007aa3a45df05c  vmovaps xmm8, [rsp+0x80]
00007aa3a45df065  vmovaps xmm10, [rsp+0x90]
00007aa3a45df06e  vmovaps xmm11, [rsp+0xA0]
00007aa3a45df077  vmovaps xmm12, [rsp+0xB0]
00007aa3a45df080  vmovaps xmm13, [rsp+0xC0]
00007aa3a45df089  vmovaps xmm14, [rsp+0xD0]
00007aa3a45df092  vmovaps xmm15, [rsp+0xE0]
00007aa3a45df09b  add rsp, 0xF0
00007aa3a45df0a2  pop r11
00007aa3a45df0a4  pop r10
00007aa3a45df0a6  pop r9
00007aa3a45df0a8  pop r8
00007aa3a45df0aa  pop rsi
00007aa3a45df0ab  pop rdi
00007aa3a45df0ac  pop rdx
00007aa3a45df0ad  pop rcx
00007aa3a45df0ae  pop rax
00007aa3a45df0af  add rsp, 0x08
00007aa3a45df0b3  jmp 0x00007AA3A45DC354
00007aa3a45df0b8  sub rsp, 0x08
00007aa3a45df0bc  push rax
00007aa3a45df0bd  push rcx
00007aa3a45df0be  push rdx
00007aa3a45df0bf  push rdi
00007aa3a45df0c0  push rsi
00007aa3a45df0c1  push r8
00007aa3a45df0c3  push r9
00007aa3a45df0c5  push r10
00007aa3a45df0c7  push r11
00007aa3a45df0c9  sub rsp, 0xF0
00007aa3a45df0d0  vmovaps [rsp], xmm0
00007aa3a45df0d5  vmovaps [rsp+0x10], xmm2
00007aa3a45df0db  vmovaps [rsp+0x20], xmm3
00007aa3a45df0e1  vmovaps [rsp+0x30], xmm4
00007aa3a45df0e7  vmovaps [rsp+0x40], xmm5
00007aa3a45df0ed  vmovaps [rsp+0x50], xmm6
00007aa3a45df0f3  vmovaps [rsp+0x60], xmm7
00007aa3a45df0f9  vmovaps [rsp+0x70], xmm8
00007aa3a45df0ff  vmovaps [rsp+0x80], xmm9
00007aa3a45df108  vmovaps [rsp+0x90], xmm10
00007aa3a45df111  vmovaps [rsp+0xA0], xmm11
00007aa3a45df11a  vmovaps [rsp+0xB0], xmm12
00007aa3a45df123  vmovaps [rsp+0xC0], xmm13
00007aa3a45df12c  vmovaps [rsp+0xD0], xmm14
00007aa3a45df135  vmovaps [rsp+0xE0], xmm15
00007aa3a45df13e  sub rsp, 0x30
00007aa3a45df142  movaps [rsp], xmm1
00007aa3a45df146  movaps [rsp+0x10], xmm15
00007aa3a45df14c  movaps [rsp+0x20], xmm6
00007aa3a45df151  lea rdi, [rsp]
00007aa3a45df155  mov esi, 0x00
00007aa3a45df15a  mov rax, 0x5F551B683530
00007aa3a45df164  call rax
00007aa3a45df166  movaps xmm1, [rsp]
00007aa3a45df16a  add rsp, 0x30
00007aa3a45df16e  vmovaps xmm0, [rsp]
00007aa3a45df173  vmovaps xmm2, [rsp+0x10]
00007aa3a45df179  vmovaps xmm3, [rsp+0x20]
00007aa3a45df17f  vmovaps xmm4, [rsp+0x30]
00007aa3a45df185  vmovaps xmm5, [rsp+0x40]
00007aa3a45df18b  vmovaps xmm6, [rsp+0x50]
00007aa3a45df191  vmovaps xmm7, [rsp+0x60]
00007aa3a45df197  vmovaps xmm8, [rsp+0x70]
00007aa3a45df19d  vmovaps xmm9, [rsp+0x80]
00007aa3a45df1a6  vmovaps xmm10, [rsp+0x90]
00007aa3a45df1af  vmovaps xmm11, [rsp+0xA0]
00007aa3a45df1b8  vmovaps xmm12, [rsp+0xB0]
00007aa3a45df1c1  vmovaps xmm13, [rsp+0xC0]
00007aa3a45df1ca  vmovaps xmm14, [rsp+0xD0]
00007aa3a45df1d3  vmovaps xmm15, [rsp+0xE0]
00007aa3a45df1dc  add rsp, 0xF0
00007aa3a45df1e3  pop r11
00007aa3a45df1e5  pop r10
00007aa3a45df1e7  pop r9
00007aa3a45df1e9  pop r8
00007aa3a45df1eb  pop rsi
00007aa3a45df1ec  pop rdi
00007aa3a45df1ed  pop rdx
00007aa3a45df1ee  pop rcx
00007aa3a45df1ef  pop rax
00007aa3a45df1f0  add rsp, 0x08
00007aa3a45df1f4  jmp 0x00007AA3A45DC375
00007aa3a45df1f9  sub rsp, 0x08
00007aa3a45df1fd  push rax
00007aa3a45df1fe  push rcx
00007aa3a45df1ff  push rdx
00007aa3a45df200  push rdi
00007aa3a45df201  push rsi
00007aa3a45df202  push r8
00007aa3a45df204  push r9
00007aa3a45df206  push r10
00007aa3a45df208  push r11
00007aa3a45df20a  sub rsp, 0xF0
00007aa3a45df211  vmovaps [rsp], xmm0
00007aa3a45df216  vmovaps [rsp+0x10], xmm1
00007aa3a45df21c  vmovaps [rsp+0x20], xmm2
00007aa3a45df222  vmovaps [rsp+0x30], xmm3
00007aa3a45df228  vmovaps [rsp+0x40], xmm4
00007aa3a45df22e  vmovaps [rsp+0x50], xmm5
00007aa3a45df234  vmovaps [rsp+0x60], xmm6
00007aa3a45df23a  vmovaps [rsp+0x70], xmm7
00007aa3a45df240  vmovaps [rsp+0x80], xmm8
00007aa3a45df249  vmovaps [rsp+0x90], xmm9
00007aa3a45df252  vmovaps [rsp+0xA0], xmm10
00007aa3a45df25b  vmovaps [rsp+0xB0], xmm11
00007aa3a45df264  vmovaps [rsp+0xC0], xmm12
00007aa3a45df26d  vmovaps [rsp+0xD0], xmm13
00007aa3a45df276  vmovaps [rsp+0xE0], xmm14
00007aa3a45df27f  sub rsp, 0x30
00007aa3a45df283  movaps [rsp], xmm15
00007aa3a45df288  movaps [rsp+0x10], xmm5
00007aa3a45df28d  movaps [rsp+0x20], xmm3
00007aa3a45df292  lea rdi, [rsp]
00007aa3a45df296  mov esi, 0x00
00007aa3a45df29b  mov rax, 0x5F551B683530
00007aa3a45df2a5  call rax
00007aa3a45df2a7  movaps xmm15, [rsp]
00007aa3a45df2ac  add rsp, 0x30
00007aa3a45df2b0  vmovaps xmm0, [rsp]
00007aa3a45df2b5  vmovaps xmm1, [rsp+0x10]
00007aa3a45df2bb  vmovaps xmm2, [rsp+0x20]
00007aa3a45df2c1  vmovaps xmm3, [rsp+0x30]
00007aa3a45df2c7  vmovaps xmm4, [rsp+0x40]
00007aa3a45df2cd  vmovaps xmm5, [rsp+0x50]
00007aa3a45df2d3  vmovaps xmm6, [rsp+0x60]
00007aa3a45df2d9  vmovaps xmm7, [rsp+0x70]
00007aa3a45df2df  vmovaps xmm8, [rsp+0x80]
00007aa3a45df2e8  vmovaps xmm9, [rsp+0x90]
00007aa3a45df2f1  vmovaps xmm10, [rsp+0xA0]
00007aa3a45df2fa  vmovaps xmm11, [rsp+0xB0]
00007aa3a45df303  vmovaps xmm12, [rsp+0xC0]
00007aa3a45df30c  vmovaps xmm13, [rsp+0xD0]
00007aa3a45df315  vmovaps xmm14, [rsp+0xE0]
00007aa3a45df31e  add rsp, 0xF0
00007aa3a45df325  pop r11
00007aa3a45df327  pop r10
00007aa3a45df329  pop r9
00007aa3a45df32b  pop r8
00007aa3a45df32d  pop rsi
00007aa3a45df32e  pop rdi
00007aa3a45df32f  pop rdx
00007aa3a45df330  pop rcx
00007aa3a45df331  pop rax
00007aa3a45df332  add rsp, 0x08
00007aa3a45df336  jmp 0x00007AA3A45DC38F
00007aa3a45df33b  sub rsp, 0x08
00007aa3a45df33f  push rax
00007aa3a45df340  push rcx
00007aa3a45df341  push rdx
00007aa3a45df342  push rdi
00007aa3a45df343  push rsi
00007aa3a45df344  push r8
00007aa3a45df346  push r9
00007aa3a45df348  push r10
00007aa3a45df34a  push r11
00007aa3a45df34c  sub rsp, 0xF0
00007aa3a45df353  vmovaps [rsp], xmm0
00007aa3a45df358  vmovaps [rsp+0x10], xmm1
00007aa3a45df35e  vmovaps [rsp+0x20], xmm2
00007aa3a45df364  vmovaps [rsp+0x30], xmm3
00007aa3a45df36a  vmovaps [rsp+0x40], xmm4
00007aa3a45df370  vmovaps [rsp+0x50], xmm6
00007aa3a45df376  vmovaps [rsp+0x60], xmm7
00007aa3a45df37c  vmovaps [rsp+0x70], xmm8
00007aa3a45df382  vmovaps [rsp+0x80], xmm9
00007aa3a45df38b  vmovaps [rsp+0x90], xmm10
00007aa3a45df394  vmovaps [rsp+0xA0], xmm11
00007aa3a45df39d  vmovaps [rsp+0xB0], xmm12
00007aa3a45df3a6  vmovaps [rsp+0xC0], xmm13
00007aa3a45df3af  vmovaps [rsp+0xD0], xmm14
00007aa3a45df3b8  vmovaps [rsp+0xE0], xmm15
00007aa3a45df3c1  sub rsp, 0x30
00007aa3a45df3c5  movaps [rsp], xmm5
00007aa3a45df3c9  movaps [rsp+0x10], xmm8
00007aa3a45df3cf  movaps [rsp+0x20], xmm6
00007aa3a45df3d4  lea rdi, [rsp]
00007aa3a45df3d8  mov esi, 0x00
00007aa3a45df3dd  mov rax, 0x5F551B683530
00007aa3a45df3e7  call rax
00007aa3a45df3e9  movaps xmm5, [rsp]
00007aa3a45df3ed  add rsp, 0x30
00007aa3a45df3f1  vmovaps xmm0, [rsp]
00007aa3a45df3f6  vmovaps xmm1, [rsp+0x10]
00007aa3a45df3fc  vmovaps xmm2, [rsp+0x20]
00007aa3a45df402  vmovaps xmm3, [rsp+0x30]
00007aa3a45df408  vmovaps xmm4, [rsp+0x40]
00007aa3a45df40e  vmovaps xmm6, [rsp+0x50]
00007aa3a45df414  vmovaps xmm7, [rsp+0x60]
00007aa3a45df41a  vmovaps xmm8, [rsp+0x70]
00007aa3a45df420  vmovaps xmm9, [rsp+0x80]
00007aa3a45df429  vmovaps xmm10, [rsp+0x90]
00007aa3a45df432  vmovaps xmm11, [rsp+0xA0]
00007aa3a45df43b  vmovaps xmm12, [rsp+0xB0]
00007aa3a45df444  vmovaps xmm13, [rsp+0xC0]
00007aa3a45df44d  vmovaps xmm14, [rsp+0xD0]
00007aa3a45df456  vmovaps xmm15, [rsp+0xE0]
00007aa3a45df45f  add rsp, 0xF0
00007aa3a45df466  pop r11
00007aa3a45df468  pop r10
00007aa3a45df46a  pop r9
00007aa3a45df46c  pop r8
00007aa3a45df46e  pop rsi
00007aa3a45df46f  pop rdi
00007aa3a45df470  pop rdx
00007aa3a45df471  pop rcx
00007aa3a45df472  pop rax
00007aa3a45df473  add rsp, 0x08
00007aa3a45df477  jmp 0x00007AA3A45DC3B3
00007aa3a45df47c  sub rsp, 0x08
00007aa3a45df480  push rax
00007aa3a45df481  push rcx
00007aa3a45df482  push rdx
00007aa3a45df483  push rdi
00007aa3a45df484  push rsi
00007aa3a45df485  push r8
00007aa3a45df487  push r9
00007aa3a45df489  push r10
00007aa3a45df48b  push r11
00007aa3a45df48d  sub rsp, 0xF0
00007aa3a45df494  vmovaps [rsp], xmm0
00007aa3a45df499  vmovaps [rsp+0x10], xmm1
00007aa3a45df49f  vmovaps [rsp+0x20], xmm2
00007aa3a45df4a5  vmovaps [rsp+0x30], xmm3
00007aa3a45df4ab  vmovaps [rsp+0x40], xmm4
00007aa3a45df4b1  vmovaps [rsp+0x50], xmm5
00007aa3a45df4b7  vmovaps [rsp+0x60], xmm7
00007aa3a45df4bd  vmovaps [rsp+0x70], xmm8
00007aa3a45df4c3  vmovaps [rsp+0x80], xmm9
00007aa3a45df4cc  vmovaps [rsp+0x90], xmm10
00007aa3a45df4d5  vmovaps [rsp+0xA0], xmm11
00007aa3a45df4de  vmovaps [rsp+0xB0], xmm12
00007aa3a45df4e7  vmovaps [rsp+0xC0], xmm13
00007aa3a45df4f0  vmovaps [rsp+0xD0], xmm14
00007aa3a45df4f9  vmovaps [rsp+0xE0], xmm15
00007aa3a45df502  sub rsp, 0x30
00007aa3a45df506  movaps [rsp], xmm6
00007aa3a45df50a  movaps [rsp+0x10], xmm10
00007aa3a45df510  movaps [rsp+0x20], xmm8
00007aa3a45df516  lea rdi, [rsp]
00007aa3a45df51a  mov esi, 0x00
00007aa3a45df51f  mov rax, 0x5F551B683530
00007aa3a45df529  call rax
00007aa3a45df52b  movaps xmm6, [rsp]
00007aa3a45df52f  add rsp, 0x30
00007aa3a45df533  vmovaps xmm0, [rsp]
00007aa3a45df538  vmovaps xmm1, [rsp+0x10]
00007aa3a45df53e  vmovaps xmm2, [rsp+0x20]
00007aa3a45df544  vmovaps xmm3, [rsp+0x30]
00007aa3a45df54a  vmovaps xmm4, [rsp+0x40]
00007aa3a45df550  vmovaps xmm5, [rsp+0x50]
00007aa3a45df556  vmovaps xmm7, [rsp+0x60]
00007aa3a45df55c  vmovaps xmm8, [rsp+0x70]
00007aa3a45df562  vmovaps xmm9, [rsp+0x80]
00007aa3a45df56b  vmovaps xmm10, [rsp+0x90]
00007aa3a45df574  vmovaps xmm11, [rsp+0xA0]
00007aa3a45df57d  vmovaps xmm12, [rsp+0xB0]
00007aa3a45df586  vmovaps xmm13, [rsp+0xC0]
00007aa3a45df58f  vmovaps xmm14, [rsp+0xD0]
00007aa3a45df598  vmovaps xmm15, [rsp+0xE0]
00007aa3a45df5a1  add rsp, 0xF0
00007aa3a45df5a8  pop r11
00007aa3a45df5aa  pop r10
00007aa3a45df5ac  pop r9
00007aa3a45df5ae  pop r8
00007aa3a45df5b0  pop rsi
00007aa3a45df5b1  pop rdi
00007aa3a45df5b2  pop rdx
00007aa3a45df5b3  pop rcx
00007aa3a45df5b4  pop rax
00007aa3a45df5b5  add rsp, 0x08
00007aa3a45df5b9  jmp 0x00007AA3A45DC3D8
00007aa3a45df5be  sub rsp, 0x08
00007aa3a45df5c2  push rax
00007aa3a45df5c3  push rcx
00007aa3a45df5c4  push rdx
00007aa3a45df5c5  push rdi
00007aa3a45df5c6  push rsi
00007aa3a45df5c7  push r8
00007aa3a45df5c9  push r9
00007aa3a45df5cb  push r10
00007aa3a45df5cd  push r11
00007aa3a45df5cf  sub rsp, 0xF0
00007aa3a45df5d6  vmovaps [rsp], xmm0
00007aa3a45df5db  vmovaps [rsp+0x10], xmm1
00007aa3a45df5e1  vmovaps [rsp+0x20], xmm2
00007aa3a45df5e7  vmovaps [rsp+0x30], xmm3
00007aa3a45df5ed  vmovaps [rsp+0x40], xmm4
00007aa3a45df5f3  vmovaps [rsp+0x50], xmm5
00007aa3a45df5f9  vmovaps [rsp+0x60], xmm6
00007aa3a45df5ff  vmovaps [rsp+0x70], xmm7
00007aa3a45df605  vmovaps [rsp+0x80], xmm8
00007aa3a45df60e  vmovaps [rsp+0x90], xmm9
00007aa3a45df617  vmovaps [rsp+0xA0], xmm11
00007aa3a45df620  vmovaps [rsp+0xB0], xmm12
00007aa3a45df629  vmovaps [rsp+0xC0], xmm13
00007aa3a45df632  vmovaps [rsp+0xD0], xmm14
00007aa3a45df63b  vmovaps [rsp+0xE0], xmm15
00007aa3a45df644  sub rsp, 0x30
00007aa3a45df648  movaps [rsp], xmm10
00007aa3a45df64d  movaps [rsp+0x10], xmm8
00007aa3a45df653  movaps [rsp+0x20], xmm14
00007aa3a45df659  lea rdi, [rsp]
00007aa3a45df65d  mov esi, 0x00
00007aa3a45df662  mov rax, 0x5F551B683530
00007aa3a45df66c  call rax
00007aa3a45df66e  movaps xmm10, [rsp]
00007aa3a45df673  add rsp, 0x30
00007aa3a45df677  vmovaps xmm0, [rsp]
00007aa3a45df67c  vmovaps xmm1, [rsp+0x10]
00007aa3a45df682  vmovaps xmm2, [rsp+0x20]
00007aa3a45df688  vmovaps xmm3, [rsp+0x30]
00007aa3a45df68e  vmovaps xmm4, [rsp+0x40]
00007aa3a45df694  vmovaps xmm5, [rsp+0x50]
00007aa3a45df69a  vmovaps xmm6, [rsp+0x60]
00007aa3a45df6a0  vmovaps xmm7, [rsp+0x70]
00007aa3a45df6a6  vmovaps xmm8, [rsp+0x80]
00007aa3a45df6af  vmovaps xmm9, [rsp+0x90]
00007aa3a45df6b8  vmovaps xmm11, [rsp+0xA0]
00007aa3a45df6c1  vmovaps xmm12, [rsp+0xB0]
00007aa3a45df6ca  vmovaps xmm13, [rsp+0xC0]
00007aa3a45df6d3  vmovaps xmm14, [rsp+0xD0]
00007aa3a45df6dc  vmovaps xmm15, [rsp+0xE0]
00007aa3a45df6e5  add rsp, 0xF0
00007aa3a45df6ec  pop r11
00007aa3a45df6ee  pop r10
00007aa3a45df6f0  pop r9
00007aa3a45df6f2  pop r8
00007aa3a45df6f4  pop rsi
00007aa3a45df6f5  pop rdi
00007aa3a45df6f6  pop rdx
00007aa3a45df6f7  pop rcx
00007aa3a45df6f8  pop rax
00007aa3a45df6f9  add rsp, 0x08
00007aa3a45df6fd  jmp 0x00007AA3A45DC3F8
00007aa3a45df702  sub rsp, 0x08
00007aa3a45df706  push rax
00007aa3a45df707  push rcx
00007aa3a45df708  push rdx
00007aa3a45df709  push rdi
00007aa3a45df70a  push rsi
00007aa3a45df70b  push r8
00007aa3a45df70d  push r9
00007aa3a45df70f  push r10
00007aa3a45df711  push r11
00007aa3a45df713  sub rsp, 0xF0
00007aa3a45df71a  vmovaps [rsp], xmm0
00007aa3a45df71f  vmovaps [rsp+0x10], xmm1
00007aa3a45df725  vmovaps [rsp+0x20], xmm2
00007aa3a45df72b  vmovaps [rsp+0x30], xmm3
00007aa3a45df731  vmovaps [rsp+0x40], xmm4
00007aa3a45df737  vmovaps [rsp+0x50], xmm5
00007aa3a45df73d  vmovaps [rsp+0x60], xmm6
00007aa3a45df743  vmovaps [rsp+0x70], xmm7
00007aa3a45df749  vmovaps [rsp+0x80], xmm8
00007aa3a45df752  vmovaps [rsp+0x90], xmm9
00007aa3a45df75b  vmovaps [rsp+0xA0], xmm10
00007aa3a45df764  vmovaps [rsp+0xB0], xmm11
00007aa3a45df76d  vmovaps [rsp+0xC0], xmm12
00007aa3a45df776  vmovaps [rsp+0xD0], xmm13
00007aa3a45df77f  vmovaps [rsp+0xE0], xmm15
00007aa3a45df788  sub rsp, 0x30
00007aa3a45df78c  movaps [rsp], xmm14
00007aa3a45df791  movaps [rsp+0x10], xmm8
00007aa3a45df797  movaps [rsp+0x20], xmm4
00007aa3a45df79c  lea rdi, [rsp]
00007aa3a45df7a0  mov esi, 0x00
00007aa3a45df7a5  mov rax, 0x5F551B683530
00007aa3a45df7af  call rax
00007aa3a45df7b1  movaps xmm14, [rsp]
00007aa3a45df7b6  add rsp, 0x30
00007aa3a45df7ba  vmovaps xmm0, [rsp]
00007aa3a45df7bf  vmovaps xmm1, [rsp+0x10]
00007aa3a45df7c5  vmovaps xmm2, [rsp+0x20]
00007aa3a45df7cb  vmovaps xmm3, [rsp+0x30]
00007aa3a45df7d1  vmovaps xmm4, [rsp+0x40]
00007aa3a45df7d7  vmovaps xmm5, [rsp+0x50]
00007aa3a45df7dd  vmovaps xmm6, [rsp+0x60]
00007aa3a45df7e3  vmovaps xmm7, [rsp+0x70]
00007aa3a45df7e9  vmovaps xmm8, [rsp+0x80]
00007aa3a45df7f2  vmovaps xmm9, [rsp+0x90]
00007aa3a45df7fb  vmovaps xmm10, [rsp+0xA0]
00007aa3a45df804  vmovaps xmm11, [rsp+0xB0]
00007aa3a45df80d  vmovaps xmm12, [rsp+0xC0]
00007aa3a45df816  vmovaps xmm13, [rsp+0xD0]
00007aa3a45df81f  vmovaps xmm15, [rsp+0xE0]
00007aa3a45df828  add rsp, 0xF0
00007aa3a45df82f  pop r11
00007aa3a45df831  pop r10
00007aa3a45df833  pop r9
00007aa3a45df835  pop r8
00007aa3a45df837  pop rsi
00007aa3a45df838  pop rdi
00007aa3a45df839  pop rdx
00007aa3a45df83a  pop rcx
00007aa3a45df83b  pop rax
00007aa3a45df83c  add rsp, 0x08
00007aa3a45df840  jmp 0x00007AA3A45DC418
00007aa3a45df845  sub rsp, 0x08
00007aa3a45df849  push rax
00007aa3a45df84a  push rcx
00007aa3a45df84b  push rdx
00007aa3a45df84c  push rdi
00007aa3a45df84d  push rsi
00007aa3a45df84e  push r8
00007aa3a45df850  push r9
00007aa3a45df852  push r10
00007aa3a45df854  push r11
00007aa3a45df856  sub rsp, 0xF0
00007aa3a45df85d  vmovaps [rsp], xmm0
00007aa3a45df862  vmovaps [rsp+0x10], xmm1
00007aa3a45df868  vmovaps [rsp+0x20], xmm2
00007aa3a45df86e  vmovaps [rsp+0x30], xmm3
00007aa3a45df874  vmovaps [rsp+0x40], xmm5
00007aa3a45df87a  vmovaps [rsp+0x50], xmm6
00007aa3a45df880  vmovaps [rsp+0x60], xmm7
00007aa3a45df886  vmovaps [rsp+0x70], xmm8
00007aa3a45df88c  vmovaps [rsp+0x80], xmm9
00007aa3a45df895  vmovaps [rsp+0x90], xmm10
00007aa3a45df89e  vmovaps [rsp+0xA0], xmm11
00007aa3a45df8a7  vmovaps [rsp+0xB0], xmm12
00007aa3a45df8b0  vmovaps [rsp+0xC0], xmm13
00007aa3a45df8b9  vmovaps [rsp+0xD0], xmm14
00007aa3a45df8c2  vmovaps [rsp+0xE0], xmm15
00007aa3a45df8cb  sub rsp, 0x30
00007aa3a45df8cf  movaps [rsp], xmm4
00007aa3a45df8d3  movaps [rsp+0x10], xmm13
00007aa3a45df8d9  movaps [rsp+0x20], xmm8
00007aa3a45df8df  lea rdi, [rsp]
00007aa3a45df8e3  mov esi, 0x00
00007aa3a45df8e8  mov rax, 0x5F551B683530
00007aa3a45df8f2  call rax
00007aa3a45df8f4  movaps xmm4, [rsp]
00007aa3a45df8f8  add rsp, 0x30
00007aa3a45df8fc  vmovaps xmm0, [rsp]
00007aa3a45df901  vmovaps xmm1, [rsp+0x10]
00007aa3a45df907  vmovaps xmm2, [rsp+0x20]
00007aa3a45df90d  vmovaps xmm3, [rsp+0x30]
00007aa3a45df913  vmovaps xmm5, [rsp+0x40]
00007aa3a45df919  vmovaps xmm6, [rsp+0x50]
00007aa3a45df91f  vmovaps xmm7, [rsp+0x60]
00007aa3a45df925  vmovaps xmm8, [rsp+0x70]
00007aa3a45df92b  vmovaps xmm9, [rsp+0x80]
00007aa3a45df934  vmovaps xmm10, [rsp+0x90]
00007aa3a45df93d  vmovaps xmm11, [rsp+0xA0]
00007aa3a45df946  vmovaps xmm12, [rsp+0xB0]
00007aa3a45df94f  vmovaps xmm13, [rsp+0xC0]
00007aa3a45df958  vmovaps xmm14, [rsp+0xD0]
00007aa3a45df961  vmovaps xmm15, [rsp+0xE0]
00007aa3a45df96a  add rsp, 0xF0
00007aa3a45df971  pop r11
00007aa3a45df973  pop r10
00007aa3a45df975  pop r9
00007aa3a45df977  pop r8
00007aa3a45df979  pop rsi
00007aa3a45df97a  pop rdi
00007aa3a45df97b  pop rdx
00007aa3a45df97c  pop rcx
00007aa3a45df97d  pop rax
00007aa3a45df97e  add rsp, 0x08
00007aa3a45df982  jmp 0x00007AA3A45DC43D
00007aa3a45df987  sub rsp, 0x08
00007aa3a45df98b  push rax
00007aa3a45df98c  push rcx
00007aa3a45df98d  push rdx
00007aa3a45df98e  push rdi
00007aa3a45df98f  push rsi
00007aa3a45df990  push r8
00007aa3a45df992  push r9
00007aa3a45df994  push r10
00007aa3a45df996  push r11
00007aa3a45df998  sub rsp, 0xF0
00007aa3a45df99f  vmovaps [rsp], xmm0
00007aa3a45df9a4  vmovaps [rsp+0x10], xmm1
00007aa3a45df9aa  vmovaps [rsp+0x20], xmm2
00007aa3a45df9b0  vmovaps [rsp+0x30], xmm3
00007aa3a45df9b6  vmovaps [rsp+0x40], xmm4
00007aa3a45df9bc  vmovaps [rsp+0x50], xmm5
00007aa3a45df9c2  vmovaps [rsp+0x60], xmm6
00007aa3a45df9c8  vmovaps [rsp+0x70], xmm7
00007aa3a45df9ce  vmovaps [rsp+0x80], xmm8
00007aa3a45df9d7  vmovaps [rsp+0x90], xmm9
00007aa3a45df9e0  vmovaps [rsp+0xA0], xmm10
00007aa3a45df9e9  vmovaps [rsp+0xB0], xmm11
00007aa3a45df9f2  vmovaps [rsp+0xC0], xmm12
00007aa3a45df9fb  vmovaps [rsp+0xD0], xmm14
00007aa3a45dfa04  vmovaps [rsp+0xE0], xmm15
00007aa3a45dfa0d  sub rsp, 0x30
00007aa3a45dfa11  movaps [rsp], xmm13
00007aa3a45dfa16  movaps [rsp+0x10], xmm15
00007aa3a45dfa1c  movaps [rsp+0x20], xmm9
00007aa3a45dfa22  lea rdi, [rsp]
00007aa3a45dfa26  mov esi, 0x00
00007aa3a45dfa2b  mov rax, 0x5F551B683530
00007aa3a45dfa35  call rax
00007aa3a45dfa37  movaps xmm13, [rsp]
00007aa3a45dfa3c  add rsp, 0x30
00007aa3a45dfa40  vmovaps xmm0, [rsp]
00007aa3a45dfa45  vmovaps xmm1, [rsp+0x10]
00007aa3a45dfa4b  vmovaps xmm2, [rsp+0x20]
00007aa3a45dfa51  vmovaps xmm3, [rsp+0x30]
00007aa3a45dfa57  vmovaps xmm4, [rsp+0x40]
00007aa3a45dfa5d  vmovaps xmm5, [rsp+0x50]
00007aa3a45dfa63  vmovaps xmm6, [rsp+0x60]
00007aa3a45dfa69  vmovaps xmm7, [rsp+0x70]
00007aa3a45dfa6f  vmovaps xmm8, [rsp+0x80]
00007aa3a45dfa78  vmovaps xmm9, [rsp+0x90]
00007aa3a45dfa81  vmovaps xmm10, [rsp+0xA0]
00007aa3a45dfa8a  vmovaps xmm11, [rsp+0xB0]
00007aa3a45dfa93  vmovaps xmm12, [rsp+0xC0]
00007aa3a45dfa9c  vmovaps xmm14, [rsp+0xD0]
00007aa3a45dfaa5  vmovaps xmm15, [rsp+0xE0]
00007aa3a45dfaae  add rsp, 0xF0
00007aa3a45dfab5  pop r11
00007aa3a45dfab7  pop r10
00007aa3a45dfab9  pop r9
00007aa3a45dfabb  pop r8
00007aa3a45dfabd  pop rsi
00007aa3a45dfabe  pop rdi
00007aa3a45dfabf  pop rdx
00007aa3a45dfac0  pop rcx
00007aa3a45dfac1  pop rax
00007aa3a45dfac2  add rsp, 0x08
00007aa3a45dfac6  jmp 0x00007AA3A45DC458
00007aa3a45dfacb  sub rsp, 0x08
00007aa3a45dfacf  push rax
00007aa3a45dfad0  push rcx
00007aa3a45dfad1  push rdx
00007aa3a45dfad2  push rdi
00007aa3a45dfad3  push rsi
00007aa3a45dfad4  push r8
00007aa3a45dfad6  push r9
00007aa3a45dfad8  push r10
00007aa3a45dfada  push r11
00007aa3a45dfadc  sub rsp, 0xF0
00007aa3a45dfae3  vmovaps [rsp], xmm0
00007aa3a45dfae8  vmovaps [rsp+0x10], xmm1
00007aa3a45dfaee  vmovaps [rsp+0x20], xmm2
00007aa3a45dfaf4  vmovaps [rsp+0x30], xmm3
00007aa3a45dfafa  vmovaps [rsp+0x40], xmm4
00007aa3a45dfb00  vmovaps [rsp+0x50], xmm5
00007aa3a45dfb06  vmovaps [rsp+0x60], xmm6
00007aa3a45dfb0c  vmovaps [rsp+0x70], xmm7
00007aa3a45dfb12  vmovaps [rsp+0x80], xmm8
00007aa3a45dfb1b  vmovaps [rsp+0x90], xmm9
00007aa3a45dfb24  vmovaps [rsp+0xA0], xmm10
00007aa3a45dfb2d  vmovaps [rsp+0xB0], xmm11
00007aa3a45dfb36  vmovaps [rsp+0xC0], xmm12
00007aa3a45dfb3f  vmovaps [rsp+0xD0], xmm13
00007aa3a45dfb48  vmovaps [rsp+0xE0], xmm14
00007aa3a45dfb51  sub rsp, 0x30
00007aa3a45dfb55  movaps [rsp], xmm15
00007aa3a45dfb5a  movaps [rsp+0x10], xmm1
00007aa3a45dfb5f  movaps [rsp+0x20], xmm5
00007aa3a45dfb64  lea rdi, [rsp]
00007aa3a45dfb68  mov esi, 0x00
00007aa3a45dfb6d  mov rax, 0x5F551B683530
00007aa3a45dfb77  call rax
00007aa3a45dfb79  movaps xmm15, [rsp]
00007aa3a45dfb7e  add rsp, 0x30
00007aa3a45dfb82  vmovaps xmm0, [rsp]
00007aa3a45dfb87  vmovaps xmm1, [rsp+0x10]
00007aa3a45dfb8d  vmovaps xmm2, [rsp+0x20]
00007aa3a45dfb93  vmovaps xmm3, [rsp+0x30]
00007aa3a45dfb99  vmovaps xmm4, [rsp+0x40]
00007aa3a45dfb9f  vmovaps xmm5, [rsp+0x50]
00007aa3a45dfba5  vmovaps xmm6, [rsp+0x60]
00007aa3a45dfbab  vmovaps xmm7, [rsp+0x70]
00007aa3a45dfbb1  vmovaps xmm8, [rsp+0x80]
00007aa3a45dfbba  vmovaps xmm9, [rsp+0x90]
00007aa3a45dfbc3  vmovaps xmm10, [rsp+0xA0]
00007aa3a45dfbcc  vmovaps xmm11, [rsp+0xB0]
00007aa3a45dfbd5  vmovaps xmm12, [rsp+0xC0]
00007aa3a45dfbde  vmovaps xmm13, [rsp+0xD0]
00007aa3a45dfbe7  vmovaps xmm14, [rsp+0xE0]
00007aa3a45dfbf0  add rsp, 0xF0
00007aa3a45dfbf7  pop r11
00007aa3a45dfbf9  pop r10
00007aa3a45dfbfb  pop r9
00007aa3a45dfbfd  pop r8
00007aa3a45dfbff  pop rsi
00007aa3a45dfc00  pop rdi
00007aa3a45dfc01  pop rdx
00007aa3a45dfc02  pop rcx
00007aa3a45dfc03  pop rax
00007aa3a45dfc04  add rsp, 0x08
00007aa3a45dfc08  jmp 0x00007AA3A45DC473
00007aa3a45dfc0d  call 0x00007AA3A44B52F0
00007aa3a45dfc12  jmp 0x00007AA3A45DC4CE
00007aa3a45dfc17  sub rsp, 0x08
00007aa3a45dfc1b  push rax
00007aa3a45dfc1c  push rcx
00007aa3a45dfc1d  push rdx
00007aa3a45dfc1e  push rdi
00007aa3a45dfc1f  push rsi
00007aa3a45dfc20  push r8
00007aa3a45dfc22  push r9
00007aa3a45dfc24  push r10
00007aa3a45dfc26  push r11
00007aa3a45dfc28  sub rsp, 0xF0
00007aa3a45dfc2f  vmovaps [rsp], xmm0
00007aa3a45dfc34  vmovaps [rsp+0x10], xmm1
00007aa3a45dfc3a  vmovaps [rsp+0x20], xmm2
00007aa3a45dfc40  vmovaps [rsp+0x30], xmm3
00007aa3a45dfc46  vmovaps [rsp+0x40], xmm4
00007aa3a45dfc4c  vmovaps [rsp+0x50], xmm5
00007aa3a45dfc52  vmovaps [rsp+0x60], xmm6
00007aa3a45dfc58  vmovaps [rsp+0x70], xmm7
00007aa3a45dfc5e  vmovaps [rsp+0x80], xmm8
00007aa3a45dfc67  vmovaps [rsp+0x90], xmm10
00007aa3a45dfc70  vmovaps [rsp+0xA0], xmm11
00007aa3a45dfc79  vmovaps [rsp+0xB0], xmm12
00007aa3a45dfc82  vmovaps [rsp+0xC0], xmm13
00007aa3a45dfc8b  vmovaps [rsp+0xD0], xmm14
00007aa3a45dfc94  vmovaps [rsp+0xE0], xmm15
00007aa3a45dfc9d  sub rsp, 0x30
00007aa3a45dfca1  movaps [rsp], xmm9
00007aa3a45dfca6  movaps [rsp+0x10], xmm8
00007aa3a45dfcac  movaps [rsp+0x20], xmm11
00007aa3a45dfcb2  lea rdi, [rsp]
00007aa3a45dfcb6  mov esi, 0x00
00007aa3a45dfcbb  mov rax, 0x5F551B683530
00007aa3a45dfcc5  call rax
00007aa3a45dfcc7  movaps xmm9, [rsp]
00007aa3a45dfccc  add rsp, 0x30
00007aa3a45dfcd0  vmovaps xmm0, [rsp]
00007aa3a45dfcd5  vmovaps xmm1, [rsp+0x10]
00007aa3a45dfcdb  vmovaps xmm2, [rsp+0x20]
00007aa3a45dfce1  vmovaps xmm3, [rsp+0x30]
00007aa3a45dfce7  vmovaps xmm4, [rsp+0x40]
00007aa3a45dfced  vmovaps xmm5, [rsp+0x50]
00007aa3a45dfcf3  vmovaps xmm6, [rsp+0x60]
00007aa3a45dfcf9  vmovaps xmm7, [rsp+0x70]
00007aa3a45dfcff  vmovaps xmm8, [rsp+0x80]
00007aa3a45dfd08  vmovaps xmm10, [rsp+0x90]
00007aa3a45dfd11  vmovaps xmm11, [rsp+0xA0]
00007aa3a45dfd1a  vmovaps xmm12, [rsp+0xB0]
00007aa3a45dfd23  vmovaps xmm13, [rsp+0xC0]
00007aa3a45dfd2c  vmovaps xmm14, [rsp+0xD0]
00007aa3a45dfd35  vmovaps xmm15, [rsp+0xE0]
00007aa3a45dfd3e  add rsp, 0xF0
00007aa3a45dfd45  pop r11
00007aa3a45dfd47  pop r10
00007aa3a45dfd49  pop r9
00007aa3a45dfd4b  pop r8
00007aa3a45dfd4d  pop rsi
00007aa3a45dfd4e  pop rdi
00007aa3a45dfd4f  pop rdx
00007aa3a45dfd50  pop rcx
00007aa3a45dfd51  pop rax
00007aa3a45dfd52  add rsp, 0x08
00007aa3a45dfd56  jmp 0x00007AA3A45DC505
00007aa3a45dfd5b  sub rsp, 0x08
00007aa3a45dfd5f  push rax
00007aa3a45dfd60  push rcx
00007aa3a45dfd61  push rdx
00007aa3a45dfd62  push rdi
00007aa3a45dfd63  push rsi
00007aa3a45dfd64  push r8
00007aa3a45dfd66  push r9
00007aa3a45dfd68  push r10
00007aa3a45dfd6a  push r11
00007aa3a45dfd6c  sub rsp, 0xF0
00007aa3a45dfd73  vmovaps [rsp], xmm0
00007aa3a45dfd78  vmovaps [rsp+0x10], xmm1
00007aa3a45dfd7e  vmovaps [rsp+0x20], xmm2
00007aa3a45dfd84  vmovaps [rsp+0x30], xmm3
00007aa3a45dfd8a  vmovaps [rsp+0x40], xmm4
00007aa3a45dfd90  vmovaps [rsp+0x50], xmm5
00007aa3a45dfd96  vmovaps [rsp+0x60], xmm6
00007aa3a45dfd9c  vmovaps [rsp+0x70], xmm7
00007aa3a45dfda2  vmovaps [rsp+0x80], xmm8
00007aa3a45dfdab  vmovaps [rsp+0x90], xmm9
00007aa3a45dfdb4  vmovaps [rsp+0xA0], xmm10
00007aa3a45dfdbd  vmovaps [rsp+0xB0], xmm12
00007aa3a45dfdc6  vmovaps [rsp+0xC0], xmm13
00007aa3a45dfdcf  vmovaps [rsp+0xD0], xmm14
00007aa3a45dfdd8  vmovaps [rsp+0xE0], xmm15
00007aa3a45dfde1  sub rsp, 0x30
00007aa3a45dfde5  movaps [rsp], xmm11
00007aa3a45dfdea  movaps [rsp+0x10], xmm10
00007aa3a45dfdf0  movaps [rsp+0x20], xmm6
00007aa3a45dfdf5  lea rdi, [rsp]
00007aa3a45dfdf9  mov esi, 0x00
00007aa3a45dfdfe  mov rax, 0x5F551B683530
00007aa3a45dfe08  call rax
00007aa3a45dfe0a  movaps xmm11, [rsp]
00007aa3a45dfe0f  add rsp, 0x30
00007aa3a45dfe13  vmovaps xmm0, [rsp]
00007aa3a45dfe18  vmovaps xmm1, [rsp+0x10]
00007aa3a45dfe1e  vmovaps xmm2, [rsp+0x20]
00007aa3a45dfe24  vmovaps xmm3, [rsp+0x30]
00007aa3a45dfe2a  vmovaps xmm4, [rsp+0x40]
00007aa3a45dfe30  vmovaps xmm5, [rsp+0x50]
00007aa3a45dfe36  vmovaps xmm6, [rsp+0x60]
00007aa3a45dfe3c  vmovaps xmm7, [rsp+0x70]
00007aa3a45dfe42  vmovaps xmm8, [rsp+0x80]
00007aa3a45dfe4b  vmovaps xmm9, [rsp+0x90]
00007aa3a45dfe54  vmovaps xmm10, [rsp+0xA0]
00007aa3a45dfe5d  vmovaps xmm12, [rsp+0xB0]
00007aa3a45dfe66  vmovaps xmm13, [rsp+0xC0]
00007aa3a45dfe6f  vmovaps xmm14, [rsp+0xD0]
00007aa3a45dfe78  vmovaps xmm15, [rsp+0xE0]
00007aa3a45dfe81  add rsp, 0xF0
00007aa3a45dfe88  pop r11
00007aa3a45dfe8a  pop r10
00007aa3a45dfe8c  pop r9
00007aa3a45dfe8e  pop r8
00007aa3a45dfe90  pop rsi
00007aa3a45dfe91  pop rdi
00007aa3a45dfe92  pop rdx
00007aa3a45dfe93  pop rcx
00007aa3a45dfe94  pop rax
00007aa3a45dfe95  add rsp, 0x08
00007aa3a45dfe99  jmp 0x00007AA3A45DC520
00007aa3a45dfe9e  sub rsp, 0x08
00007aa3a45dfea2  push rax
00007aa3a45dfea3  push rcx
00007aa3a45dfea4  push rdx
00007aa3a45dfea5  push rdi
00007aa3a45dfea6  push rsi
00007aa3a45dfea7  push r8
00007aa3a45dfea9  push r9
00007aa3a45dfeab  push r10
00007aa3a45dfead  push r11
00007aa3a45dfeaf  sub rsp, 0xF0
00007aa3a45dfeb6  vmovaps [rsp], xmm0
00007aa3a45dfebb  vmovaps [rsp+0x10], xmm1
00007aa3a45dfec1  vmovaps [rsp+0x20], xmm2
00007aa3a45dfec7  vmovaps [rsp+0x30], xmm3
00007aa3a45dfecd  vmovaps [rsp+0x40], xmm4
00007aa3a45dfed3  vmovaps [rsp+0x50], xmm5
00007aa3a45dfed9  vmovaps [rsp+0x60], xmm6
00007aa3a45dfedf  vmovaps [rsp+0x70], xmm7
00007aa3a45dfee5  vmovaps [rsp+0x80], xmm8
00007aa3a45dfeee  vmovaps [rsp+0x90], xmm9
00007aa3a45dfef7  vmovaps [rsp+0xA0], xmm11
00007aa3a45dff00  vmovaps [rsp+0xB0], xmm12
00007aa3a45dff09  vmovaps [rsp+0xC0], xmm13
00007aa3a45dff12  vmovaps [rsp+0xD0], xmm14
00007aa3a45dff1b  vmovaps [rsp+0xE0], xmm15
00007aa3a45dff24  sub rsp, 0x30
00007aa3a45dff28  movaps [rsp], xmm10
00007aa3a45dff2d  movaps [rsp+0x10], xmm14
00007aa3a45dff33  movaps [rsp+0x20], xmm4
00007aa3a45dff38  lea rdi, [rsp]
00007aa3a45dff3c  mov esi, 0x00
00007aa3a45dff41  mov rax, 0x5F551B683530
00007aa3a45dff4b  call rax
00007aa3a45dff4d  movaps xmm10, [rsp]
00007aa3a45dff52  add rsp, 0x30
00007aa3a45dff56  vmovaps xmm0, [rsp]
00007aa3a45dff5b  vmovaps xmm1, [rsp+0x10]
00007aa3a45dff61  vmovaps xmm2, [rsp+0x20]
00007aa3a45dff67  vmovaps xmm3, [rsp+0x30]
00007aa3a45dff6d  vmovaps xmm4, [rsp+0x40]
00007aa3a45dff73  vmovaps xmm5, [rsp+0x50]
00007aa3a45dff79  vmovaps xmm6, [rsp+0x60]
00007aa3a45dff7f  vmovaps xmm7, [rsp+0x70]
00007aa3a45dff85  vmovaps xmm8, [rsp+0x80]
00007aa3a45dff8e  vmovaps xmm9, [rsp+0x90]
00007aa3a45dff97  vmovaps xmm11, [rsp+0xA0]
00007aa3a45dffa0  vmovaps xmm12, [rsp+0xB0]
00007aa3a45dffa9  vmovaps xmm13, [rsp+0xC0]
00007aa3a45dffb2  vmovaps xmm14, [rsp+0xD0]
00007aa3a45dffbb  vmovaps xmm15, [rsp+0xE0]
00007aa3a45dffc4  add rsp, 0xF0
00007aa3a45dffcb  pop r11
00007aa3a45dffcd  pop r10
00007aa3a45dffcf  pop r9
00007aa3a45dffd1  pop r8
00007aa3a45dffd3  pop rsi
00007aa3a45dffd4  pop rdi
00007aa3a45dffd5  pop rdx
00007aa3a45dffd6  pop rcx
00007aa3a45dffd7  pop rax
00007aa3a45dffd8  add rsp, 0x08
00007aa3a45dffdc  jmp 0x00007AA3A45DC53B
00007aa3a45dffe1  sub rsp, 0x08
00007aa3a45dffe5  push rax
00007aa3a45dffe6  push rcx
00007aa3a45dffe7  push rdx
00007aa3a45dffe8  push rdi
00007aa3a45dffe9  push rsi
00007aa3a45dffea  push r8
00007aa3a45dffec  push r9
00007aa3a45dffee  push r10
00007aa3a45dfff0  push r11
00007aa3a45dfff2  sub rsp, 0xF0
00007aa3a45dfff9  vmovaps [rsp], xmm0
00007aa3a45dfffe  vmovaps [rsp+0x10], xmm1
00007aa3a45e0004  vmovaps [rsp+0x20], xmm2
00007aa3a45e000a  vmovaps [rsp+0x30], xmm3
00007aa3a45e0010  vmovaps [rsp+0x40], xmm4
00007aa3a45e0016  vmovaps [rsp+0x50], xmm5
00007aa3a45e001c  vmovaps [rsp+0x60], xmm6
00007aa3a45e0022  vmovaps [rsp+0x70], xmm7
00007aa3a45e0028  vmovaps [rsp+0x80], xmm9
00007aa3a45e0031  vmovaps [rsp+0x90], xmm10
00007aa3a45e003a  vmovaps [rsp+0xA0], xmm11
00007aa3a45e0043  vmovaps [rsp+0xB0], xmm12
00007aa3a45e004c  vmovaps [rsp+0xC0], xmm13
00007aa3a45e0055  vmovaps [rsp+0xD0], xmm14
00007aa3a45e005e  vmovaps [rsp+0xE0], xmm15
00007aa3a45e0067  sub rsp, 0x30
00007aa3a45e006b  movaps [rsp], xmm8
00007aa3a45e0070  movaps [rsp+0x10], xmm1
00007aa3a45e0075  movaps [rsp+0x20], xmm14
00007aa3a45e007b  lea rdi, [rsp]
00007aa3a45e007f  mov esi, 0x00
00007aa3a45e0084  mov rax, 0x5F551B683530
00007aa3a45e008e  call rax
00007aa3a45e0090  movaps xmm8, [rsp]
00007aa3a45e0095  add rsp, 0x30
00007aa3a45e0099  vmovaps xmm0, [rsp]
00007aa3a45e009e  vmovaps xmm1, [rsp+0x10]
00007aa3a45e00a4  vmovaps xmm2, [rsp+0x20]
00007aa3a45e00aa  vmovaps xmm3, [rsp+0x30]
00007aa3a45e00b0  vmovaps xmm4, [rsp+0x40]
00007aa3a45e00b6  vmovaps xmm5, [rsp+0x50]
00007aa3a45e00bc  vmovaps xmm6, [rsp+0x60]
00007aa3a45e00c2  vmovaps xmm7, [rsp+0x70]
00007aa3a45e00c8  vmovaps xmm9, [rsp+0x80]
00007aa3a45e00d1  vmovaps xmm10, [rsp+0x90]
00007aa3a45e00da  vmovaps xmm11, [rsp+0xA0]
00007aa3a45e00e3  vmovaps xmm12, [rsp+0xB0]
00007aa3a45e00ec  vmovaps xmm13, [rsp+0xC0]
00007aa3a45e00f5  vmovaps xmm14, [rsp+0xD0]
00007aa3a45e00fe  vmovaps xmm15, [rsp+0xE0]
00007aa3a45e0107  add rsp, 0xF0
00007aa3a45e010e  pop r11
00007aa3a45e0110  pop r10
00007aa3a45e0112  pop r9
00007aa3a45e0114  pop r8
00007aa3a45e0116  pop rsi
00007aa3a45e0117  pop rdi
00007aa3a45e0118  pop rdx
00007aa3a45e0119  pop rcx
00007aa3a45e011a  pop rax
00007aa3a45e011b  add rsp, 0x08
00007aa3a45e011f  jmp 0x00007AA3A45DC561
00007aa3a45e0124  sub rsp, 0x08
00007aa3a45e0128  push rax
00007aa3a45e0129  push rcx
00007aa3a45e012a  push rdx
00007aa3a45e012b  push rdi
00007aa3a45e012c  push rsi
00007aa3a45e012d  push r8
00007aa3a45e012f  push r9
00007aa3a45e0131  push r10
00007aa3a45e0133  push r11
00007aa3a45e0135  sub rsp, 0xF0
00007aa3a45e013c  vmovaps [rsp], xmm0
00007aa3a45e0141  vmovaps [rsp+0x10], xmm1
00007aa3a45e0147  vmovaps [rsp+0x20], xmm2
00007aa3a45e014d  vmovaps [rsp+0x30], xmm3
00007aa3a45e0153  vmovaps [rsp+0x40], xmm4
00007aa3a45e0159  vmovaps [rsp+0x50], xmm5
00007aa3a45e015f  vmovaps [rsp+0x60], xmm7
00007aa3a45e0165  vmovaps [rsp+0x70], xmm8
00007aa3a45e016b  vmovaps [rsp+0x80], xmm9
00007aa3a45e0174  vmovaps [rsp+0x90], xmm10
00007aa3a45e017d  vmovaps [rsp+0xA0], xmm11
00007aa3a45e0186  vmovaps [rsp+0xB0], xmm12
00007aa3a45e018f  vmovaps [rsp+0xC0], xmm13
00007aa3a45e0198  vmovaps [rsp+0xD0], xmm14
00007aa3a45e01a1  vmovaps [rsp+0xE0], xmm15
00007aa3a45e01aa  sub rsp, 0x30
00007aa3a45e01ae  movaps [rsp], xmm6
00007aa3a45e01b2  movaps [rsp+0x10], xmm1
00007aa3a45e01b7  movaps [rsp+0x20], xmm14
00007aa3a45e01bd  lea rdi, [rsp]
00007aa3a45e01c1  mov esi, 0x00
00007aa3a45e01c6  mov rax, 0x5F551B683530
00007aa3a45e01d0  call rax
00007aa3a45e01d2  movaps xmm6, [rsp]
00007aa3a45e01d6  add rsp, 0x30
00007aa3a45e01da  vmovaps xmm0, [rsp]
00007aa3a45e01df  vmovaps xmm1, [rsp+0x10]
00007aa3a45e01e5  vmovaps xmm2, [rsp+0x20]
00007aa3a45e01eb  vmovaps xmm3, [rsp+0x30]
00007aa3a45e01f1  vmovaps xmm4, [rsp+0x40]
00007aa3a45e01f7  vmovaps xmm5, [rsp+0x50]
00007aa3a45e01fd  vmovaps xmm7, [rsp+0x60]
00007aa3a45e0203  vmovaps xmm8, [rsp+0x70]
00007aa3a45e0209  vmovaps xmm9, [rsp+0x80]
00007aa3a45e0212  vmovaps xmm10, [rsp+0x90]
00007aa3a45e021b  vmovaps xmm11, [rsp+0xA0]
00007aa3a45e0224  vmovaps xmm12, [rsp+0xB0]
00007aa3a45e022d  vmovaps xmm13, [rsp+0xC0]
00007aa3a45e0236  vmovaps xmm14, [rsp+0xD0]
00007aa3a45e023f  vmovaps xmm15, [rsp+0xE0]
00007aa3a45e0248  add rsp, 0xF0
00007aa3a45e024f  pop r11
00007aa3a45e0251  pop r10
00007aa3a45e0253  pop r9
00007aa3a45e0255  pop r8
00007aa3a45e0257  pop rsi
00007aa3a45e0258  pop rdi
00007aa3a45e0259  pop rdx
00007aa3a45e025a  pop rcx
00007aa3a45e025b  pop rax
00007aa3a45e025c  add rsp, 0x08
00007aa3a45e0260  jmp 0x00007AA3A45DC58D
00007aa3a45e0265  sub rsp, 0x08
00007aa3a45e0269  push rax
00007aa3a45e026a  push rcx
00007aa3a45e026b  push rdx
00007aa3a45e026c  push rdi
00007aa3a45e026d  push rsi
00007aa3a45e026e  push r8
00007aa3a45e0270  push r9
00007aa3a45e0272  push r10
00007aa3a45e0274  push r11
00007aa3a45e0276  sub rsp, 0xF0
00007aa3a45e027d  vmovaps [rsp], xmm0
00007aa3a45e0282  vmovaps [rsp+0x10], xmm1
00007aa3a45e0288  vmovaps [rsp+0x20], xmm2
00007aa3a45e028e  vmovaps [rsp+0x30], xmm3
00007aa3a45e0294  vmovaps [rsp+0x40], xmm4
00007aa3a45e029a  vmovaps [rsp+0x50], xmm5
00007aa3a45e02a0  vmovaps [rsp+0x60], xmm6
00007aa3a45e02a6  vmovaps [rsp+0x70], xmm7
00007aa3a45e02ac  vmovaps [rsp+0x80], xmm8
00007aa3a45e02b5  vmovaps [rsp+0x90], xmm9
00007aa3a45e02be  vmovaps [rsp+0xA0], xmm10
00007aa3a45e02c7  vmovaps [rsp+0xB0], xmm11
00007aa3a45e02d0  vmovaps [rsp+0xC0], xmm12
00007aa3a45e02d9  vmovaps [rsp+0xD0], xmm13
00007aa3a45e02e2  vmovaps [rsp+0xE0], xmm15
00007aa3a45e02eb  sub rsp, 0x30
00007aa3a45e02ef  movaps [rsp], xmm14
00007aa3a45e02f4  movaps [rsp+0x10], xmm12
00007aa3a45e02fa  movaps [rsp+0x20], xmm1
00007aa3a45e02ff  lea rdi, [rsp]
00007aa3a45e0303  mov esi, 0x00
00007aa3a45e0308  mov rax, 0x5F551B683530
00007aa3a45e0312  call rax
00007aa3a45e0314  movaps xmm14, [rsp]
00007aa3a45e0319  add rsp, 0x30
00007aa3a45e031d  vmovaps xmm0, [rsp]
00007aa3a45e0322  vmovaps xmm1, [rsp+0x10]
00007aa3a45e0328  vmovaps xmm2, [rsp+0x20]
00007aa3a45e032e  vmovaps xmm3, [rsp+0x30]
00007aa3a45e0334  vmovaps xmm4, [rsp+0x40]
00007aa3a45e033a  vmovaps xmm5, [rsp+0x50]
00007aa3a45e0340  vmovaps xmm6, [rsp+0x60]
00007aa3a45e0346  vmovaps xmm7, [rsp+0x70]
00007aa3a45e034c  vmovaps xmm8, [rsp+0x80]
00007aa3a45e0355  vmovaps xmm9, [rsp+0x90]
00007aa3a45e035e  vmovaps xmm10, [rsp+0xA0]
00007aa3a45e0367  vmovaps xmm11, [rsp+0xB0]
00007aa3a45e0370  vmovaps xmm12, [rsp+0xC0]
00007aa3a45e0379  vmovaps xmm13, [rsp+0xD0]
00007aa3a45e0382  vmovaps xmm15, [rsp+0xE0]
00007aa3a45e038b  add rsp, 0xF0
00007aa3a45e0392  pop r11
00007aa3a45e0394  pop r10
00007aa3a45e0396  pop r9
00007aa3a45e0398  pop r8
00007aa3a45e039a  pop rsi
00007aa3a45e039b  pop rdi
00007aa3a45e039c  pop rdx
00007aa3a45e039d  pop rcx
00007aa3a45e039e  pop rax
00007aa3a45e039f  add rsp, 0x08
00007aa3a45e03a3  jmp 0x00007AA3A45DC5B3
00007aa3a45e03a8  sub rsp, 0x08
00007aa3a45e03ac  push rax
00007aa3a45e03ad  push rcx
00007aa3a45e03ae  push rdx
00007aa3a45e03af  push rdi
00007aa3a45e03b0  push rsi
00007aa3a45e03b1  push r8
00007aa3a45e03b3  push r9
00007aa3a45e03b5  push r10
00007aa3a45e03b7  push r11
00007aa3a45e03b9  sub rsp, 0xF0
00007aa3a45e03c0  vmovaps [rsp], xmm0
00007aa3a45e03c5  vmovaps [rsp+0x10], xmm2
00007aa3a45e03cb  vmovaps [rsp+0x20], xmm3
00007aa3a45e03d1  vmovaps [rsp+0x30], xmm4
00007aa3a45e03d7  vmovaps [rsp+0x40], xmm5
00007aa3a45e03dd  vmovaps [rsp+0x50], xmm6
00007aa3a45e03e3  vmovaps [rsp+0x60], xmm7
00007aa3a45e03e9  vmovaps [rsp+0x70], xmm8
00007aa3a45e03ef  vmovaps [rsp+0x80], xmm9
00007aa3a45e03f8  vmovaps [rsp+0x90], xmm10
00007aa3a45e0401  vmovaps [rsp+0xA0], xmm11
00007aa3a45e040a  vmovaps [rsp+0xB0], xmm12
00007aa3a45e0413  vmovaps [rsp+0xC0], xmm13
00007aa3a45e041c  vmovaps [rsp+0xD0], xmm14
00007aa3a45e0425  vmovaps [rsp+0xE0], xmm15
00007aa3a45e042e  sub rsp, 0x30
00007aa3a45e0432  movaps [rsp], xmm1
00007aa3a45e0436  movaps [rsp+0x10], xmm13
00007aa3a45e043c  movaps [rsp+0x20], xmm9
00007aa3a45e0442  lea rdi, [rsp]
00007aa3a45e0446  mov esi, 0x00
00007aa3a45e044b  mov rax, 0x5F551B683530
00007aa3a45e0455  call rax
00007aa3a45e0457  movaps xmm1, [rsp]
00007aa3a45e045b  add rsp, 0x30
00007aa3a45e045f  vmovaps xmm0, [rsp]
00007aa3a45e0464  vmovaps xmm2, [rsp+0x10]
00007aa3a45e046a  vmovaps xmm3, [rsp+0x20]
00007aa3a45e0470  vmovaps xmm4, [rsp+0x30]
00007aa3a45e0476  vmovaps xmm5, [rsp+0x40]
00007aa3a45e047c  vmovaps xmm6, [rsp+0x50]
00007aa3a45e0482  vmovaps xmm7, [rsp+0x60]
00007aa3a45e0488  vmovaps xmm8, [rsp+0x70]
00007aa3a45e048e  vmovaps xmm9, [rsp+0x80]
00007aa3a45e0497  vmovaps xmm10, [rsp+0x90]
00007aa3a45e04a0  vmovaps xmm11, [rsp+0xA0]
00007aa3a45e04a9  vmovaps xmm12, [rsp+0xB0]
00007aa3a45e04b2  vmovaps xmm13, [rsp+0xC0]
00007aa3a45e04bb  vmovaps xmm14, [rsp+0xD0]
00007aa3a45e04c4  vmovaps xmm15, [rsp+0xE0]
00007aa3a45e04cd  add rsp, 0xF0
00007aa3a45e04d4  pop r11
00007aa3a45e04d6  pop r10
00007aa3a45e04d8  pop r9
00007aa3a45e04da  pop r8
00007aa3a45e04dc  pop rsi
00007aa3a45e04dd  pop rdi
00007aa3a45e04de  pop rdx
00007aa3a45e04df  pop rcx
00007aa3a45e04e0  pop rax
00007aa3a45e04e1  add rsp, 0x08
00007aa3a45e04e5  jmp 0x00007AA3A45DC5CD
00007aa3a45e04ea  sub rsp, 0x08
00007aa3a45e04ee  push rax
00007aa3a45e04ef  push rcx
00007aa3a45e04f0  push rdx
00007aa3a45e04f1  push rdi
00007aa3a45e04f2  push rsi
00007aa3a45e04f3  push r8
00007aa3a45e04f5  push r9
00007aa3a45e04f7  push r10
00007aa3a45e04f9  push r11
00007aa3a45e04fb  sub rsp, 0xF0
00007aa3a45e0502  vmovaps [rsp], xmm0
00007aa3a45e0507  vmovaps [rsp+0x10], xmm1
00007aa3a45e050d  vmovaps [rsp+0x20], xmm2
00007aa3a45e0513  vmovaps [rsp+0x30], xmm3
00007aa3a45e0519  vmovaps [rsp+0x40], xmm4
00007aa3a45e051f  vmovaps [rsp+0x50], xmm5
00007aa3a45e0525  vmovaps [rsp+0x60], xmm6
00007aa3a45e052b  vmovaps [rsp+0x70], xmm7
00007aa3a45e0531  vmovaps [rsp+0x80], xmm8
00007aa3a45e053a  vmovaps [rsp+0x90], xmm9
00007aa3a45e0543  vmovaps [rsp+0xA0], xmm10
00007aa3a45e054c  vmovaps [rsp+0xB0], xmm11
00007aa3a45e0555  vmovaps [rsp+0xC0], xmm13
00007aa3a45e055e  vmovaps [rsp+0xD0], xmm14
00007aa3a45e0567  vmovaps [rsp+0xE0], xmm15
00007aa3a45e0570  sub rsp, 0x30
00007aa3a45e0574  movaps [rsp], xmm12
00007aa3a45e0579  movaps [rsp+0x10], xmm7
00007aa3a45e057e  movaps [rsp+0x20], xmm13
00007aa3a45e0584  lea rdi, [rsp]
00007aa3a45e0588  mov esi, 0x00
00007aa3a45e058d  mov rax, 0x5F551B683530
00007aa3a45e0597  call rax
00007aa3a45e0599  movaps xmm12, [rsp]
00007aa3a45e059e  add rsp, 0x30
00007aa3a45e05a2  vmovaps xmm0, [rsp]
00007aa3a45e05a7  vmovaps xmm1, [rsp+0x10]
00007aa3a45e05ad  vmovaps xmm2, [rsp+0x20]
00007aa3a45e05b3  vmovaps xmm3, [rsp+0x30]
00007aa3a45e05b9  vmovaps xmm4, [rsp+0x40]
00007aa3a45e05bf  vmovaps xmm5, [rsp+0x50]
00007aa3a45e05c5  vmovaps xmm6, [rsp+0x60]
00007aa3a45e05cb  vmovaps xmm7, [rsp+0x70]
00007aa3a45e05d1  vmovaps xmm8, [rsp+0x80]
00007aa3a45e05da  vmovaps xmm9, [rsp+0x90]
00007aa3a45e05e3  vmovaps xmm10, [rsp+0xA0]
00007aa3a45e05ec  vmovaps xmm11, [rsp+0xB0]
00007aa3a45e05f5  vmovaps xmm13, [rsp+0xC0]
00007aa3a45e05fe  vmovaps xmm14, [rsp+0xD0]
00007aa3a45e0607  vmovaps xmm15, [rsp+0xE0]
00007aa3a45e0610  add rsp, 0xF0
00007aa3a45e0617  pop r11
00007aa3a45e0619  pop r10
00007aa3a45e061b  pop r9
00007aa3a45e061d  pop r8
00007aa3a45e061f  pop rsi
00007aa3a45e0620  pop rdi
00007aa3a45e0621  pop rdx
00007aa3a45e0622  pop rcx
00007aa3a45e0623  pop rax
00007aa3a45e0624  add rsp, 0x08
00007aa3a45e0628  jmp 0x00007AA3A45DC5F4
00007aa3a45e062d  sub rsp, 0x08
00007aa3a45e0631  push rax
00007aa3a45e0632  push rcx
00007aa3a45e0633  push rdx
00007aa3a45e0634  push rdi
00007aa3a45e0635  push rsi
00007aa3a45e0636  push r8
00007aa3a45e0638  push r9
00007aa3a45e063a  push r10
00007aa3a45e063c  push r11
00007aa3a45e063e  sub rsp, 0xF0
00007aa3a45e0645  vmovaps [rsp], xmm0
00007aa3a45e064a  vmovaps [rsp+0x10], xmm1
00007aa3a45e0650  vmovaps [rsp+0x20], xmm2
00007aa3a45e0656  vmovaps [rsp+0x30], xmm3
00007aa3a45e065c  vmovaps [rsp+0x40], xmm4
00007aa3a45e0662  vmovaps [rsp+0x50], xmm5
00007aa3a45e0668  vmovaps [rsp+0x60], xmm6
00007aa3a45e066e  vmovaps [rsp+0x70], xmm7
00007aa3a45e0674  vmovaps [rsp+0x80], xmm8
00007aa3a45e067d  vmovaps [rsp+0x90], xmm9
00007aa3a45e0686  vmovaps [rsp+0xA0], xmm10
00007aa3a45e068f  vmovaps [rsp+0xB0], xmm11
00007aa3a45e0698  vmovaps [rsp+0xC0], xmm12
00007aa3a45e06a1  vmovaps [rsp+0xD0], xmm14
00007aa3a45e06aa  vmovaps [rsp+0xE0], xmm15
00007aa3a45e06b3  sub rsp, 0x30
00007aa3a45e06b7  movaps [rsp], xmm13
00007aa3a45e06bc  movaps [rsp+0x10], xmm15
00007aa3a45e06c2  movaps [rsp+0x20], xmm8
00007aa3a45e06c8  lea rdi, [rsp]
00007aa3a45e06cc  mov esi, 0x00
00007aa3a45e06d1  mov rax, 0x5F551B683530
00007aa3a45e06db  call rax
00007aa3a45e06dd  movaps xmm13, [rsp]
00007aa3a45e06e2  add rsp, 0x30
00007aa3a45e06e6  vmovaps xmm0, [rsp]
00007aa3a45e06eb  vmovaps xmm1, [rsp+0x10]
00007aa3a45e06f1  vmovaps xmm2, [rsp+0x20]
00007aa3a45e06f7  vmovaps xmm3, [rsp+0x30]
00007aa3a45e06fd  vmovaps xmm4, [rsp+0x40]
00007aa3a45e0703  vmovaps xmm5, [rsp+0x50]
00007aa3a45e0709  vmovaps xmm6, [rsp+0x60]
00007aa3a45e070f  vmovaps xmm7, [rsp+0x70]
00007aa3a45e0715  vmovaps xmm8, [rsp+0x80]
00007aa3a45e071e  vmovaps xmm9, [rsp+0x90]
00007aa3a45e0727  vmovaps xmm10, [rsp+0xA0]
00007aa3a45e0730  vmovaps xmm11, [rsp+0xB0]
00007aa3a45e0739  vmovaps xmm12, [rsp+0xC0]
00007aa3a45e0742  vmovaps xmm14, [rsp+0xD0]
00007aa3a45e074b  vmovaps xmm15, [rsp+0xE0]
00007aa3a45e0754  add rsp, 0xF0
00007aa3a45e075b  pop r11
00007aa3a45e075d  pop r10
00007aa3a45e075f  pop r9
00007aa3a45e0761  pop r8
00007aa3a45e0763  pop rsi
00007aa3a45e0764  pop rdi
00007aa3a45e0765  pop rdx
00007aa3a45e0766  pop rcx
00007aa3a45e0767  pop rax
00007aa3a45e0768  add rsp, 0x08
00007aa3a45e076c  jmp 0x00007AA3A45DC60F
00007aa3a45e0771  sub rsp, 0x08
00007aa3a45e0775  push rax
00007aa3a45e0776  push rcx
00007aa3a45e0777  push rdx
00007aa3a45e0778  push rdi
00007aa3a45e0779  push rsi
00007aa3a45e077a  push r8
00007aa3a45e077c  push r9
00007aa3a45e077e  push r10
00007aa3a45e0780  push r11
00007aa3a45e0782  sub rsp, 0xF0
00007aa3a45e0789  vmovaps [rsp], xmm0
00007aa3a45e078e  vmovaps [rsp+0x10], xmm1
00007aa3a45e0794  vmovaps [rsp+0x20], xmm2
00007aa3a45e079a  vmovaps [rsp+0x30], xmm3
00007aa3a45e07a0  vmovaps [rsp+0x40], xmm4
00007aa3a45e07a6  vmovaps [rsp+0x50], xmm5
00007aa3a45e07ac  vmovaps [rsp+0x60], xmm6
00007aa3a45e07b2  vmovaps [rsp+0x70], xmm7
00007aa3a45e07b8  vmovaps [rsp+0x80], xmm9
00007aa3a45e07c1  vmovaps [rsp+0x90], xmm10
00007aa3a45e07ca  vmovaps [rsp+0xA0], xmm11
00007aa3a45e07d3  vmovaps [rsp+0xB0], xmm12
00007aa3a45e07dc  vmovaps [rsp+0xC0], xmm13
00007aa3a45e07e5  vmovaps [rsp+0xD0], xmm14
00007aa3a45e07ee  vmovaps [rsp+0xE0], xmm15
00007aa3a45e07f7  sub rsp, 0x30
00007aa3a45e07fb  movaps [rsp], xmm8
00007aa3a45e0800  movaps [rsp+0x10], xmm15
00007aa3a45e0806  movaps [rsp+0x20], xmm9
00007aa3a45e080c  lea rdi, [rsp]
00007aa3a45e0810  mov esi, 0x00
00007aa3a45e0815  mov rax, 0x5F551B683530
00007aa3a45e081f  call rax
00007aa3a45e0821  movaps xmm8, [rsp]
00007aa3a45e0826  add rsp, 0x30
00007aa3a45e082a  vmovaps xmm0, [rsp]
00007aa3a45e082f  vmovaps xmm1, [rsp+0x10]
00007aa3a45e0835  vmovaps xmm2, [rsp+0x20]
00007aa3a45e083b  vmovaps xmm3, [rsp+0x30]
00007aa3a45e0841  vmovaps xmm4, [rsp+0x40]
00007aa3a45e0847  vmovaps xmm5, [rsp+0x50]
00007aa3a45e084d  vmovaps xmm6, [rsp+0x60]
00007aa3a45e0853  vmovaps xmm7, [rsp+0x70]
00007aa3a45e0859  vmovaps xmm9, [rsp+0x80]
00007aa3a45e0862  vmovaps xmm10, [rsp+0x90]
00007aa3a45e086b  vmovaps xmm11, [rsp+0xA0]
00007aa3a45e0874  vmovaps xmm12, [rsp+0xB0]
00007aa3a45e087d  vmovaps xmm13, [rsp+0xC0]
00007aa3a45e0886  vmovaps xmm14, [rsp+0xD0]
00007aa3a45e088f  vmovaps xmm15, [rsp+0xE0]
00007aa3a45e0898  add rsp, 0xF0
00007aa3a45e089f  pop r11
00007aa3a45e08a1  pop r10
00007aa3a45e08a3  pop r9
00007aa3a45e08a5  pop r8
00007aa3a45e08a7  pop rsi
00007aa3a45e08a8  pop rdi
00007aa3a45e08a9  pop rdx
00007aa3a45e08aa  pop rcx
00007aa3a45e08ab  pop rax
00007aa3a45e08ac  add rsp, 0x08
00007aa3a45e08b0  jmp 0x00007AA3A45DC63D
00007aa3a45e08b5  sub rsp, 0x08
00007aa3a45e08b9  push rax
00007aa3a45e08ba  push rcx
00007aa3a45e08bb  push rdx
00007aa3a45e08bc  push rdi
00007aa3a45e08bd  push rsi
00007aa3a45e08be  push r8
00007aa3a45e08c0  push r9
00007aa3a45e08c2  push r10
00007aa3a45e08c4  push r11
00007aa3a45e08c6  sub rsp, 0xF0
00007aa3a45e08cd  vmovaps [rsp], xmm0
00007aa3a45e08d2  vmovaps [rsp+0x10], xmm1
00007aa3a45e08d8  vmovaps [rsp+0x20], xmm2
00007aa3a45e08de  vmovaps [rsp+0x30], xmm3
00007aa3a45e08e4  vmovaps [rsp+0x40], xmm4
00007aa3a45e08ea  vmovaps [rsp+0x50], xmm5
00007aa3a45e08f0  vmovaps [rsp+0x60], xmm6
00007aa3a45e08f6  vmovaps [rsp+0x70], xmm7
00007aa3a45e08fc  vmovaps [rsp+0x80], xmm8
00007aa3a45e0905  vmovaps [rsp+0x90], xmm9
00007aa3a45e090e  vmovaps [rsp+0xA0], xmm10
00007aa3a45e0917  vmovaps [rsp+0xB0], xmm11
00007aa3a45e0920  vmovaps [rsp+0xC0], xmm12
00007aa3a45e0929  vmovaps [rsp+0xD0], xmm13
00007aa3a45e0932  vmovaps [rsp+0xE0], xmm14
00007aa3a45e093b  sub rsp, 0x30
00007aa3a45e093f  movaps [rsp], xmm15
00007aa3a45e0944  movaps [rsp+0x10], xmm11
00007aa3a45e094a  movaps [rsp+0x20], xmm6
00007aa3a45e094f  lea rdi, [rsp]
00007aa3a45e0953  mov esi, 0x00
00007aa3a45e0958  mov rax, 0x5F551B683530
00007aa3a45e0962  call rax
00007aa3a45e0964  movaps xmm15, [rsp]
00007aa3a45e0969  add rsp, 0x30
00007aa3a45e096d  vmovaps xmm0, [rsp]
00007aa3a45e0972  vmovaps xmm1, [rsp+0x10]
00007aa3a45e0978  vmovaps xmm2, [rsp+0x20]
00007aa3a45e097e  vmovaps xmm3, [rsp+0x30]
00007aa3a45e0984  vmovaps xmm4, [rsp+0x40]
00007aa3a45e098a  vmovaps xmm5, [rsp+0x50]
00007aa3a45e0990  vmovaps xmm6, [rsp+0x60]
00007aa3a45e0996  vmovaps xmm7, [rsp+0x70]
00007aa3a45e099c  vmovaps xmm8, [rsp+0x80]
00007aa3a45e09a5  vmovaps xmm9, [rsp+0x90]
00007aa3a45e09ae  vmovaps xmm10, [rsp+0xA0]
00007aa3a45e09b7  vmovaps xmm11, [rsp+0xB0]
00007aa3a45e09c0  vmovaps xmm12, [rsp+0xC0]
00007aa3a45e09c9  vmovaps xmm13, [rsp+0xD0]
00007aa3a45e09d2  vmovaps xmm14, [rsp+0xE0]
00007aa3a45e09db  add rsp, 0xF0
00007aa3a45e09e2  pop r11
00007aa3a45e09e4  pop r10
00007aa3a45e09e6  pop r9
00007aa3a45e09e8  pop r8
00007aa3a45e09ea  pop rsi
00007aa3a45e09eb  pop rdi
00007aa3a45e09ec  pop rdx
00007aa3a45e09ed  pop rcx
00007aa3a45e09ee  pop rax
00007aa3a45e09ef  add rsp, 0x08
00007aa3a45e09f3  jmp 0x00007AA3A45DC658
00007aa3a45e09f8  sub rsp, 0x08
00007aa3a45e09fc  push rax
00007aa3a45e09fd  push rcx
00007aa3a45e09fe  push rdx
00007aa3a45e09ff  push rdi
00007aa3a45e0a00  push rsi
00007aa3a45e0a01  push r8
00007aa3a45e0a03  push r9
00007aa3a45e0a05  push r10
00007aa3a45e0a07  push r11
00007aa3a45e0a09  sub rsp, 0xF0
00007aa3a45e0a10  vmovaps [rsp], xmm0
00007aa3a45e0a15  vmovaps [rsp+0x10], xmm1
00007aa3a45e0a1b  vmovaps [rsp+0x20], xmm2
00007aa3a45e0a21  vmovaps [rsp+0x30], xmm3
00007aa3a45e0a27  vmovaps [rsp+0x40], xmm4
00007aa3a45e0a2d  vmovaps [rsp+0x50], xmm5
00007aa3a45e0a33  vmovaps [rsp+0x60], xmm6
00007aa3a45e0a39  vmovaps [rsp+0x70], xmm8
00007aa3a45e0a3f  vmovaps [rsp+0x80], xmm9
00007aa3a45e0a48  vmovaps [rsp+0x90], xmm10
00007aa3a45e0a51  vmovaps [rsp+0xA0], xmm11
00007aa3a45e0a5a  vmovaps [rsp+0xB0], xmm12
00007aa3a45e0a63  vmovaps [rsp+0xC0], xmm13
00007aa3a45e0a6c  vmovaps [rsp+0xD0], xmm14
00007aa3a45e0a75  vmovaps [rsp+0xE0], xmm15
00007aa3a45e0a7e  sub rsp, 0x30
00007aa3a45e0a82  movaps [rsp], xmm7
00007aa3a45e0a86  movaps [rsp+0x10], xmm11
00007aa3a45e0a8c  movaps [rsp+0x20], xmm9
00007aa3a45e0a92  lea rdi, [rsp]
00007aa3a45e0a96  mov esi, 0x00
00007aa3a45e0a9b  mov rax, 0x5F551B683530
00007aa3a45e0aa5  call rax
00007aa3a45e0aa7  movaps xmm7, [rsp]
00007aa3a45e0aab  add rsp, 0x30
00007aa3a45e0aaf  vmovaps xmm0, [rsp]
00007aa3a45e0ab4  vmovaps xmm1, [rsp+0x10]
00007aa3a45e0aba  vmovaps xmm2, [rsp+0x20]
00007aa3a45e0ac0  vmovaps xmm3, [rsp+0x30]
00007aa3a45e0ac6  vmovaps xmm4, [rsp+0x40]
00007aa3a45e0acc  vmovaps xmm5, [rsp+0x50]
00007aa3a45e0ad2  vmovaps xmm6, [rsp+0x60]
00007aa3a45e0ad8  vmovaps xmm8, [rsp+0x70]
00007aa3a45e0ade  vmovaps xmm9, [rsp+0x80]
00007aa3a45e0ae7  vmovaps xmm10, [rsp+0x90]
00007aa3a45e0af0  vmovaps xmm11, [rsp+0xA0]
00007aa3a45e0af9  vmovaps xmm12, [rsp+0xB0]
00007aa3a45e0b02  vmovaps xmm13, [rsp+0xC0]
00007aa3a45e0b0b  vmovaps xmm14, [rsp+0xD0]
00007aa3a45e0b14  vmovaps xmm15, [rsp+0xE0]
00007aa3a45e0b1d  add rsp, 0xF0
00007aa3a45e0b24  pop r11
00007aa3a45e0b26  pop r10
00007aa3a45e0b28  pop r9
00007aa3a45e0b2a  pop r8
00007aa3a45e0b2c  pop rsi
00007aa3a45e0b2d  pop rdi
00007aa3a45e0b2e  pop rdx
00007aa3a45e0b2f  pop rcx
00007aa3a45e0b30  pop rax
00007aa3a45e0b31  add rsp, 0x08
00007aa3a45e0b35  jmp 0x00007AA3A45DC685
00007aa3a45e0b3a  sub rsp, 0x08
00007aa3a45e0b3e  push rax
00007aa3a45e0b3f  push rcx
00007aa3a45e0b40  push rdx
00007aa3a45e0b41  push rdi
00007aa3a45e0b42  push rsi
00007aa3a45e0b43  push r8
00007aa3a45e0b45  push r9
00007aa3a45e0b47  push r10
00007aa3a45e0b49  push r11
00007aa3a45e0b4b  sub rsp, 0xF0
00007aa3a45e0b52  vmovaps [rsp], xmm0
00007aa3a45e0b57  vmovaps [rsp+0x10], xmm1
00007aa3a45e0b5d  vmovaps [rsp+0x20], xmm2
00007aa3a45e0b63  vmovaps [rsp+0x30], xmm3
00007aa3a45e0b69  vmovaps [rsp+0x40], xmm4
00007aa3a45e0b6f  vmovaps [rsp+0x50], xmm5
00007aa3a45e0b75  vmovaps [rsp+0x60], xmm6
00007aa3a45e0b7b  vmovaps [rsp+0x70], xmm7
00007aa3a45e0b81  vmovaps [rsp+0x80], xmm8
00007aa3a45e0b8a  vmovaps [rsp+0x90], xmm9
00007aa3a45e0b93  vmovaps [rsp+0xA0], xmm10
00007aa3a45e0b9c  vmovaps [rsp+0xB0], xmm12
00007aa3a45e0ba5  vmovaps [rsp+0xC0], xmm13
00007aa3a45e0bae  vmovaps [rsp+0xD0], xmm14
00007aa3a45e0bb7  vmovaps [rsp+0xE0], xmm15
00007aa3a45e0bc0  sub rsp, 0x30
00007aa3a45e0bc4  movaps [rsp], xmm11
00007aa3a45e0bc9  movaps [rsp+0x10], xmm10
00007aa3a45e0bcf  movaps [rsp+0x20], xmm14
00007aa3a45e0bd5  lea rdi, [rsp]
00007aa3a45e0bd9  mov esi, 0x00
00007aa3a45e0bde  mov rax, 0x5F551B683530
00007aa3a45e0be8  call rax
00007aa3a45e0bea  movaps xmm11, [rsp]
00007aa3a45e0bef  add rsp, 0x30
00007aa3a45e0bf3  vmovaps xmm0, [rsp]
00007aa3a45e0bf8  vmovaps xmm1, [rsp+0x10]
00007aa3a45e0bfe  vmovaps xmm2, [rsp+0x20]
00007aa3a45e0c04  vmovaps xmm3, [rsp+0x30]
00007aa3a45e0c0a  vmovaps xmm4, [rsp+0x40]
00007aa3a45e0c10  vmovaps xmm5, [rsp+0x50]
00007aa3a45e0c16  vmovaps xmm6, [rsp+0x60]
00007aa3a45e0c1c  vmovaps xmm7, [rsp+0x70]
00007aa3a45e0c22  vmovaps xmm8, [rsp+0x80]
00007aa3a45e0c2b  vmovaps xmm9, [rsp+0x90]
00007aa3a45e0c34  vmovaps xmm10, [rsp+0xA0]
00007aa3a45e0c3d  vmovaps xmm12, [rsp+0xB0]
00007aa3a45e0c46  vmovaps xmm13, [rsp+0xC0]
00007aa3a45e0c4f  vmovaps xmm14, [rsp+0xD0]
00007aa3a45e0c58  vmovaps xmm15, [rsp+0xE0]
00007aa3a45e0c61  add rsp, 0xF0
00007aa3a45e0c68  pop r11
00007aa3a45e0c6a  pop r10
00007aa3a45e0c6c  pop r9
00007aa3a45e0c6e  pop r8
00007aa3a45e0c70  pop rsi
00007aa3a45e0c71  pop rdi
00007aa3a45e0c72  pop rdx
00007aa3a45e0c73  pop rcx
00007aa3a45e0c74  pop rax
00007aa3a45e0c75  add rsp, 0x08
00007aa3a45e0c79  jmp 0x00007AA3A45DC6A0
00007aa3a45e0c7e  call 0x00007AA3A44C33A0
00007aa3a45e0c83  jmp 0x00007AA3A45DC6AA
00007aa3a45e0c88  sub rsp, 0x08
00007aa3a45e0c8c  push rax
00007aa3a45e0c8d  push rcx
00007aa3a45e0c8e  push rdx
00007aa3a45e0c8f  push rdi
00007aa3a45e0c90  push rsi
00007aa3a45e0c91  push r8
00007aa3a45e0c93  push r9
00007aa3a45e0c95  push r10
00007aa3a45e0c97  push r11
00007aa3a45e0c99  sub rsp, 0xF0
00007aa3a45e0ca0  vmovaps [rsp], xmm0
00007aa3a45e0ca5  vmovaps [rsp+0x10], xmm1
00007aa3a45e0cab  vmovaps [rsp+0x20], xmm2
00007aa3a45e0cb1  vmovaps [rsp+0x30], xmm3
00007aa3a45e0cb7  vmovaps [rsp+0x40], xmm4
00007aa3a45e0cbd  vmovaps [rsp+0x50], xmm5
00007aa3a45e0cc3  vmovaps [rsp+0x60], xmm6
00007aa3a45e0cc9  vmovaps [rsp+0x70], xmm7
00007aa3a45e0ccf  vmovaps [rsp+0x80], xmm8
00007aa3a45e0cd8  vmovaps [rsp+0x90], xmm9
00007aa3a45e0ce1  vmovaps [rsp+0xA0], xmm11
00007aa3a45e0cea  vmovaps [rsp+0xB0], xmm12
00007aa3a45e0cf3  vmovaps [rsp+0xC0], xmm13
00007aa3a45e0cfc  vmovaps [rsp+0xD0], xmm14
00007aa3a45e0d05  vmovaps [rsp+0xE0], xmm15
00007aa3a45e0d0e  sub rsp, 0x30
00007aa3a45e0d12  movaps [rsp], xmm10
00007aa3a45e0d17  movaps [rsp+0x10], xmm1
00007aa3a45e0d1c  movaps [rsp+0x20], xmm12
00007aa3a45e0d22  lea rdi, [rsp]
00007aa3a45e0d26  mov esi, 0x00
00007aa3a45e0d2b  mov rax, 0x5F551B683530
00007aa3a45e0d35  call rax
00007aa3a45e0d37  movaps xmm10, [rsp]
00007aa3a45e0d3c  add rsp, 0x30
00007aa3a45e0d40  vmovaps xmm0, [rsp]
00007aa3a45e0d45  vmovaps xmm1, [rsp+0x10]
00007aa3a45e0d4b  vmovaps xmm2, [rsp+0x20]
00007aa3a45e0d51  vmovaps xmm3, [rsp+0x30]
00007aa3a45e0d57  vmovaps xmm4, [rsp+0x40]
00007aa3a45e0d5d  vmovaps xmm5, [rsp+0x50]
00007aa3a45e0d63  vmovaps xmm6, [rsp+0x60]
00007aa3a45e0d69  vmovaps xmm7, [rsp+0x70]
00007aa3a45e0d6f  vmovaps xmm8, [rsp+0x80]
00007aa3a45e0d78  vmovaps xmm9, [rsp+0x90]
00007aa3a45e0d81  vmovaps xmm11, [rsp+0xA0]
00007aa3a45e0d8a  vmovaps xmm12, [rsp+0xB0]
00007aa3a45e0d93  vmovaps xmm13, [rsp+0xC0]
00007aa3a45e0d9c  vmovaps xmm14, [rsp+0xD0]
00007aa3a45e0da5  vmovaps xmm15, [rsp+0xE0]
00007aa3a45e0dae  add rsp, 0xF0
00007aa3a45e0db5  pop r11
00007aa3a45e0db7  pop r10
00007aa3a45e0db9  pop r9
00007aa3a45e0dbb  pop r8
00007aa3a45e0dbd  pop rsi
00007aa3a45e0dbe  pop rdi
00007aa3a45e0dbf  pop rdx
00007aa3a45e0dc0  pop rcx
00007aa3a45e0dc1  pop rax
00007aa3a45e0dc2  add rsp, 0x08
00007aa3a45e0dc6  jmp 0x00007AA3A45DC6CD
00007aa3a45e0dcb  sub rsp, 0x08
00007aa3a45e0dcf  push rax
00007aa3a45e0dd0  push rcx
00007aa3a45e0dd1  push rdx
00007aa3a45e0dd2  push rdi
00007aa3a45e0dd3  push rsi
00007aa3a45e0dd4  push r8
00007aa3a45e0dd6  push r9
00007aa3a45e0dd8  push r10
00007aa3a45e0dda  push r11
00007aa3a45e0ddc  sub rsp, 0xF0
00007aa3a45e0de3  vmovaps [rsp], xmm0
00007aa3a45e0de8  vmovaps [rsp+0x10], xmm1
00007aa3a45e0dee  vmovaps [rsp+0x20], xmm2
00007aa3a45e0df4  vmovaps [rsp+0x30], xmm3
00007aa3a45e0dfa  vmovaps [rsp+0x40], xmm4
00007aa3a45e0e00  vmovaps [rsp+0x50], xmm5
00007aa3a45e0e06  vmovaps [rsp+0x60], xmm6
00007aa3a45e0e0c  vmovaps [rsp+0x70], xmm7
00007aa3a45e0e12  vmovaps [rsp+0x80], xmm8
00007aa3a45e0e1b  vmovaps [rsp+0x90], xmm9
00007aa3a45e0e24  vmovaps [rsp+0xA0], xmm10
00007aa3a45e0e2d  vmovaps [rsp+0xB0], xmm11
00007aa3a45e0e36  vmovaps [rsp+0xC0], xmm13
00007aa3a45e0e3f  vmovaps [rsp+0xD0], xmm14
00007aa3a45e0e48  vmovaps [rsp+0xE0], xmm15
00007aa3a45e0e51  sub rsp, 0x30
00007aa3a45e0e55  movaps [rsp], xmm12
00007aa3a45e0e5a  movaps [rsp+0x10], xmm14
00007aa3a45e0e60  movaps [rsp+0x20], xmm1
00007aa3a45e0e65  lea rdi, [rsp]
00007aa3a45e0e69  mov esi, 0x00
00007aa3a45e0e6e  mov rax, 0x5F551B683530
00007aa3a45e0e78  call rax
00007aa3a45e0e7a  movaps xmm12, [rsp]
00007aa3a45e0e7f  add rsp, 0x30
00007aa3a45e0e83  vmovaps xmm0, [rsp]
00007aa3a45e0e88  vmovaps xmm1, [rsp+0x10]
00007aa3a45e0e8e  vmovaps xmm2, [rsp+0x20]
00007aa3a45e0e94  vmovaps xmm3, [rsp+0x30]
00007aa3a45e0e9a  vmovaps xmm4, [rsp+0x40]
00007aa3a45e0ea0  vmovaps xmm5, [rsp+0x50]
00007aa3a45e0ea6  vmovaps xmm6, [rsp+0x60]
00007aa3a45e0eac  vmovaps xmm7, [rsp+0x70]
00007aa3a45e0eb2  vmovaps xmm8, [rsp+0x80]
00007aa3a45e0ebb  vmovaps xmm9, [rsp+0x90]
00007aa3a45e0ec4  vmovaps xmm10, [rsp+0xA0]
00007aa3a45e0ecd  vmovaps xmm11, [rsp+0xB0]
00007aa3a45e0ed6  vmovaps xmm13, [rsp+0xC0]
00007aa3a45e0edf  vmovaps xmm14, [rsp+0xD0]
00007aa3a45e0ee8  vmovaps xmm15, [rsp+0xE0]
00007aa3a45e0ef1  add rsp, 0xF0
00007aa3a45e0ef8  pop r11
00007aa3a45e0efa  pop r10
00007aa3a45e0efc  pop r9
00007aa3a45e0efe  pop r8
00007aa3a45e0f00  pop rsi
00007aa3a45e0f01  pop rdi
00007aa3a45e0f02  pop rdx
00007aa3a45e0f03  pop rcx
00007aa3a45e0f04  pop rax
00007aa3a45e0f05  add rsp, 0x08
00007aa3a45e0f09  jmp 0x00007AA3A45DC6FC
00007aa3a45e0f0e  sub rsp, 0x08
00007aa3a45e0f12  push rax
00007aa3a45e0f13  push rcx
00007aa3a45e0f14  push rdx
00007aa3a45e0f15  push rdi
00007aa3a45e0f16  push rsi
00007aa3a45e0f17  push r8
00007aa3a45e0f19  push r9
00007aa3a45e0f1b  push r10
00007aa3a45e0f1d  push r11
00007aa3a45e0f1f  sub rsp, 0xF0
00007aa3a45e0f26  vmovaps [rsp], xmm0
00007aa3a45e0f2b  vmovaps [rsp+0x10], xmm1
00007aa3a45e0f31  vmovaps [rsp+0x20], xmm2
00007aa3a45e0f37  vmovaps [rsp+0x30], xmm3
00007aa3a45e0f3d  vmovaps [rsp+0x40], xmm4
00007aa3a45e0f43  vmovaps [rsp+0x50], xmm5
00007aa3a45e0f49  vmovaps [rsp+0x60], xmm6
00007aa3a45e0f4f  vmovaps [rsp+0x70], xmm7
00007aa3a45e0f55  vmovaps [rsp+0x80], xmm8
00007aa3a45e0f5e  vmovaps [rsp+0x90], xmm9
00007aa3a45e0f67  vmovaps [rsp+0xA0], xmm10
00007aa3a45e0f70  vmovaps [rsp+0xB0], xmm11
00007aa3a45e0f79  vmovaps [rsp+0xC0], xmm12
00007aa3a45e0f82  vmovaps [rsp+0xD0], xmm13
00007aa3a45e0f8b  vmovaps [rsp+0xE0], xmm15
00007aa3a45e0f94  sub rsp, 0x30
00007aa3a45e0f98  movaps [rsp], xmm14
00007aa3a45e0f9d  movaps [rsp+0x10], xmm9
00007aa3a45e0fa3  movaps [rsp+0x20], xmm1
00007aa3a45e0fa8  lea rdi, [rsp]
00007aa3a45e0fac  mov esi, 0x00
00007aa3a45e0fb1  mov rax, 0x5F551B683530
00007aa3a45e0fbb  call rax
00007aa3a45e0fbd  movaps xmm14, [rsp]
00007aa3a45e0fc2  add rsp, 0x30
00007aa3a45e0fc6  vmovaps xmm0, [rsp]
00007aa3a45e0fcb  vmovaps xmm1, [rsp+0x10]
00007aa3a45e0fd1  vmovaps xmm2, [rsp+0x20]
00007aa3a45e0fd7  vmovaps xmm3, [rsp+0x30]
00007aa3a45e0fdd  vmovaps xmm4, [rsp+0x40]
00007aa3a45e0fe3  vmovaps xmm5, [rsp+0x50]
00007aa3a45e0fe9  vmovaps xmm6, [rsp+0x60]
00007aa3a45e0fef  vmovaps xmm7, [rsp+0x70]
00007aa3a45e0ff5  vmovaps xmm8, [rsp+0x80]
00007aa3a45e0ffe  vmovaps xmm9, [rsp+0x90]
00007aa3a45e1007  vmovaps xmm10, [rsp+0xA0]
00007aa3a45e1010  vmovaps xmm11, [rsp+0xB0]
00007aa3a45e1019  vmovaps xmm12, [rsp+0xC0]
00007aa3a45e1022  vmovaps xmm13, [rsp+0xD0]
00007aa3a45e102b  vmovaps xmm15, [rsp+0xE0]
00007aa3a45e1034  add rsp, 0xF0
00007aa3a45e103b  pop r11
00007aa3a45e103d  pop r10
00007aa3a45e103f  pop r9
00007aa3a45e1041  pop r8
00007aa3a45e1043  pop rsi
00007aa3a45e1044  pop rdi
00007aa3a45e1045  pop rdx
00007aa3a45e1046  pop rcx
00007aa3a45e1047  pop rax
00007aa3a45e1048  add rsp, 0x08
00007aa3a45e104c  jmp 0x00007AA3A45DC72B
00007aa3a45e1051  sub rsp, 0x08
00007aa3a45e1055  push rax
00007aa3a45e1056  push rcx
00007aa3a45e1057  push rdx
00007aa3a45e1058  push rdi
00007aa3a45e1059  push rsi
00007aa3a45e105a  push r8
00007aa3a45e105c  push r9
00007aa3a45e105e  push r10
00007aa3a45e1060  push r11
00007aa3a45e1062  sub rsp, 0xF0
00007aa3a45e1069  vmovaps [rsp], xmm0
00007aa3a45e106e  vmovaps [rsp+0x10], xmm2
00007aa3a45e1074  vmovaps [rsp+0x20], xmm3
00007aa3a45e107a  vmovaps [rsp+0x30], xmm4
00007aa3a45e1080  vmovaps [rsp+0x40], xmm5
00007aa3a45e1086  vmovaps [rsp+0x50], xmm6
00007aa3a45e108c  vmovaps [rsp+0x60], xmm7
00007aa3a45e1092  vmovaps [rsp+0x70], xmm8
00007aa3a45e1098  vmovaps [rsp+0x80], xmm9
00007aa3a45e10a1  vmovaps [rsp+0x90], xmm10
00007aa3a45e10aa  vmovaps [rsp+0xA0], xmm11
00007aa3a45e10b3  vmovaps [rsp+0xB0], xmm12
00007aa3a45e10bc  vmovaps [rsp+0xC0], xmm13
00007aa3a45e10c5  vmovaps [rsp+0xD0], xmm14
00007aa3a45e10ce  vmovaps [rsp+0xE0], xmm15
00007aa3a45e10d7  sub rsp, 0x30
00007aa3a45e10db  movaps [rsp], xmm1
00007aa3a45e10df  movaps [rsp+0x10], xmm13
00007aa3a45e10e5  movaps [rsp+0x20], xmm8
00007aa3a45e10eb  lea rdi, [rsp]
00007aa3a45e10ef  mov esi, 0x00
00007aa3a45e10f4  mov rax, 0x5F551B683530
00007aa3a45e10fe  call rax
00007aa3a45e1100  movaps xmm1, [rsp]
00007aa3a45e1104  add rsp, 0x30
00007aa3a45e1108  vmovaps xmm0, [rsp]
00007aa3a45e110d  vmovaps xmm2, [rsp+0x10]
00007aa3a45e1113  vmovaps xmm3, [rsp+0x20]
00007aa3a45e1119  vmovaps xmm4, [rsp+0x30]
00007aa3a45e111f  vmovaps xmm5, [rsp+0x40]
00007aa3a45e1125  vmovaps xmm6, [rsp+0x50]
00007aa3a45e112b  vmovaps xmm7, [rsp+0x60]
00007aa3a45e1131  vmovaps xmm8, [rsp+0x70]
00007aa3a45e1137  vmovaps xmm9, [rsp+0x80]
00007aa3a45e1140  vmovaps xmm10, [rsp+0x90]
00007aa3a45e1149  vmovaps xmm11, [rsp+0xA0]
00007aa3a45e1152  vmovaps xmm12, [rsp+0xB0]
00007aa3a45e115b  vmovaps xmm13, [rsp+0xC0]
00007aa3a45e1164  vmovaps xmm14, [rsp+0xD0]
00007aa3a45e116d  vmovaps xmm15, [rsp+0xE0]
00007aa3a45e1176  add rsp, 0xF0
00007aa3a45e117d  pop r11
00007aa3a45e117f  pop r10
00007aa3a45e1181  pop r9
00007aa3a45e1183  pop r8
00007aa3a45e1185  pop rsi
00007aa3a45e1186  pop rdi
00007aa3a45e1187  pop rdx
00007aa3a45e1188  pop rcx
00007aa3a45e1189  pop rax
00007aa3a45e118a  add rsp, 0x08
00007aa3a45e118e  jmp 0x00007AA3A45DC74D
00007aa3a45e1193  call 0x00007AA3A440C260
00007aa3a45e1198  jmp 0x00007AA3A45DC75B
00007aa3a45e119d  call 0x00007AA3A44BD750
00007aa3a45e11a2  jmp 0x00007AA3A45DC765
00007aa3a45e11a7  sub rsp, 0x08
00007aa3a45e11ab  push rax
00007aa3a45e11ac  push rcx
00007aa3a45e11ad  push rdx
00007aa3a45e11ae  push rdi
00007aa3a45e11af  push rsi
00007aa3a45e11b0  push r8
00007aa3a45e11b2  push r9
00007aa3a45e11b4  push r10
00007aa3a45e11b6  push r11
00007aa3a45e11b8  sub rsp, 0xF0
00007aa3a45e11bf  vmovaps [rsp], xmm0
00007aa3a45e11c4  vmovaps [rsp+0x10], xmm1
00007aa3a45e11ca  vmovaps [rsp+0x20], xmm2
00007aa3a45e11d0  vmovaps [rsp+0x30], xmm3
00007aa3a45e11d6  vmovaps [rsp+0x40], xmm4
00007aa3a45e11dc  vmovaps [rsp+0x50], xmm5
00007aa3a45e11e2  vmovaps [rsp+0x60], xmm6
00007aa3a45e11e8  vmovaps [rsp+0x70], xmm7
00007aa3a45e11ee  vmovaps [rsp+0x80], xmm9
00007aa3a45e11f7  vmovaps [rsp+0x90], xmm10
00007aa3a45e1200  vmovaps [rsp+0xA0], xmm11
00007aa3a45e1209  vmovaps [rsp+0xB0], xmm12
00007aa3a45e1212  vmovaps [rsp+0xC0], xmm13
00007aa3a45e121b  vmovaps [rsp+0xD0], xmm14
00007aa3a45e1224  vmovaps [rsp+0xE0], xmm15
00007aa3a45e122d  sub rsp, 0x30
00007aa3a45e1231  movaps [rsp], xmm8
00007aa3a45e1236  movaps [rsp+0x10], xmm15
00007aa3a45e123c  movaps [rsp+0x20], xmm7
00007aa3a45e1241  lea rdi, [rsp]
00007aa3a45e1245  mov esi, 0x00
00007aa3a45e124a  mov rax, 0x5F551B683530
00007aa3a45e1254  call rax
00007aa3a45e1256  movaps xmm8, [rsp]
00007aa3a45e125b  add rsp, 0x30
00007aa3a45e125f  vmovaps xmm0, [rsp]
00007aa3a45e1264  vmovaps xmm1, [rsp+0x10]
00007aa3a45e126a  vmovaps xmm2, [rsp+0x20]
00007aa3a45e1270  vmovaps xmm3, [rsp+0x30]
00007aa3a45e1276  vmovaps xmm4, [rsp+0x40]
00007aa3a45e127c  vmovaps xmm5, [rsp+0x50]
00007aa3a45e1282  vmovaps xmm6, [rsp+0x60]
00007aa3a45e1288  vmovaps xmm7, [rsp+0x70]
00007aa3a45e128e  vmovaps xmm9, [rsp+0x80]
00007aa3a45e1297  vmovaps xmm10, [rsp+0x90]
00007aa3a45e12a0  vmovaps xmm11, [rsp+0xA0]
00007aa3a45e12a9  vmovaps xmm12, [rsp+0xB0]
00007aa3a45e12b2  vmovaps xmm13, [rsp+0xC0]
00007aa3a45e12bb  vmovaps xmm14, [rsp+0xD0]
00007aa3a45e12c4  vmovaps xmm15, [rsp+0xE0]
00007aa3a45e12cd  add rsp, 0xF0
00007aa3a45e12d4  pop r11
00007aa3a45e12d6  pop r10
00007aa3a45e12d8  pop r9
00007aa3a45e12da  pop r8
00007aa3a45e12dc  pop rsi
00007aa3a45e12dd  pop rdi
00007aa3a45e12de  pop rdx
00007aa3a45e12df  pop rcx
00007aa3a45e12e0  pop rax
00007aa3a45e12e1  add rsp, 0x08
00007aa3a45e12e5  jmp 0x00007AA3A45DC787
00007aa3a45e12ea  sub rsp, 0x08
00007aa3a45e12ee  push rax
00007aa3a45e12ef  push rcx
00007aa3a45e12f0  push rdx
00007aa3a45e12f1  push rdi
00007aa3a45e12f2  push rsi
00007aa3a45e12f3  push r8
00007aa3a45e12f5  push r9
00007aa3a45e12f7  push r10
00007aa3a45e12f9  push r11
00007aa3a45e12fb  sub rsp, 0xF0
00007aa3a45e1302  vmovaps [rsp], xmm0
00007aa3a45e1307  vmovaps [rsp+0x10], xmm1
00007aa3a45e130d  vmovaps [rsp+0x20], xmm2
00007aa3a45e1313  vmovaps [rsp+0x30], xmm3
00007aa3a45e1319  vmovaps [rsp+0x40], xmm4
00007aa3a45e131f  vmovaps [rsp+0x50], xmm5
00007aa3a45e1325  vmovaps [rsp+0x60], xmm6
00007aa3a45e132b  vmovaps [rsp+0x70], xmm8
00007aa3a45e1331  vmovaps [rsp+0x80], xmm9
00007aa3a45e133a  vmovaps [rsp+0x90], xmm10
00007aa3a45e1343  vmovaps [rsp+0xA0], xmm11
00007aa3a45e134c  vmovaps [rsp+0xB0], xmm12
00007aa3a45e1355  vmovaps [rsp+0xC0], xmm13
00007aa3a45e135e  vmovaps [rsp+0xD0], xmm14
00007aa3a45e1367  vmovaps [rsp+0xE0], xmm15
00007aa3a45e1370  sub rsp, 0x30
00007aa3a45e1374  movaps [rsp], xmm7
00007aa3a45e1378  movaps [rsp+0x10], xmm9
00007aa3a45e137e  movaps [rsp+0x20], xmm15
00007aa3a45e1384  lea rdi, [rsp]
00007aa3a45e1388  mov esi, 0x00
00007aa3a45e138d  mov rax, 0x5F551B683530
00007aa3a45e1397  call rax
00007aa3a45e1399  movaps xmm7, [rsp]
00007aa3a45e139d  add rsp, 0x30
00007aa3a45e13a1  vmovaps xmm0, [rsp]
00007aa3a45e13a6  vmovaps xmm1, [rsp+0x10]
00007aa3a45e13ac  vmovaps xmm2, [rsp+0x20]
00007aa3a45e13b2  vmovaps xmm3, [rsp+0x30]
00007aa3a45e13b8  vmovaps xmm4, [rsp+0x40]
00007aa3a45e13be  vmovaps xmm5, [rsp+0x50]
00007aa3a45e13c4  vmovaps xmm6, [rsp+0x60]
00007aa3a45e13ca  vmovaps xmm8, [rsp+0x70]
00007aa3a45e13d0  vmovaps xmm9, [rsp+0x80]
00007aa3a45e13d9  vmovaps xmm10, [rsp+0x90]
00007aa3a45e13e2  vmovaps xmm11, [rsp+0xA0]
00007aa3a45e13eb  vmovaps xmm12, [rsp+0xB0]
00007aa3a45e13f4  vmovaps xmm13, [rsp+0xC0]
00007aa3a45e13fd  vmovaps xmm14, [rsp+0xD0]
00007aa3a45e1406  vmovaps xmm15, [rsp+0xE0]
00007aa3a45e140f  add rsp, 0xF0
00007aa3a45e1416  pop r11
00007aa3a45e1418  pop r10
00007aa3a45e141a  pop r9
00007aa3a45e141c  pop r8
00007aa3a45e141e  pop rsi
00007aa3a45e141f  pop rdi
00007aa3a45e1420  pop rdx
00007aa3a45e1421  pop rcx
00007aa3a45e1422  pop rax
00007aa3a45e1423  add rsp, 0x08
00007aa3a45e1427  jmp 0x00007AA3A45DC7B4
00007aa3a45e142c  sub rsp, 0x08
00007aa3a45e1430  push rax
00007aa3a45e1431  push rcx
00007aa3a45e1432  push rdx
00007aa3a45e1433  push rdi
00007aa3a45e1434  push rsi
00007aa3a45e1435  push r8
00007aa3a45e1437  push r9
00007aa3a45e1439  push r10
00007aa3a45e143b  push r11
00007aa3a45e143d  sub rsp, 0xF0
00007aa3a45e1444  vmovaps [rsp], xmm0
00007aa3a45e1449  vmovaps [rsp+0x10], xmm1
00007aa3a45e144f  vmovaps [rsp+0x20], xmm2
00007aa3a45e1455  vmovaps [rsp+0x30], xmm3
00007aa3a45e145b  vmovaps [rsp+0x40], xmm4
00007aa3a45e1461  vmovaps [rsp+0x50], xmm5
00007aa3a45e1467  vmovaps [rsp+0x60], xmm6
00007aa3a45e146d  vmovaps [rsp+0x70], xmm7
00007aa3a45e1473  vmovaps [rsp+0x80], xmm8
00007aa3a45e147c  vmovaps [rsp+0x90], xmm10
00007aa3a45e1485  vmovaps [rsp+0xA0], xmm11
00007aa3a45e148e  vmovaps [rsp+0xB0], xmm12
00007aa3a45e1497  vmovaps [rsp+0xC0], xmm13
00007aa3a45e14a0  vmovaps [rsp+0xD0], xmm14
00007aa3a45e14a9  vmovaps [rsp+0xE0], xmm15
00007aa3a45e14b2  sub rsp, 0x30
00007aa3a45e14b6  movaps [rsp], xmm9
00007aa3a45e14bb  movaps [rsp+0x10], xmm13
00007aa3a45e14c1  movaps [rsp+0x20], xmm15
00007aa3a45e14c7  lea rdi, [rsp]
00007aa3a45e14cb  mov esi, 0x00
00007aa3a45e14d0  mov rax, 0x5F551B683530
00007aa3a45e14da  call rax
00007aa3a45e14dc  movaps xmm9, [rsp]
00007aa3a45e14e1  add rsp, 0x30
00007aa3a45e14e5  vmovaps xmm0, [rsp]
00007aa3a45e14ea  vmovaps xmm1, [rsp+0x10]
00007aa3a45e14f0  vmovaps xmm2, [rsp+0x20]
00007aa3a45e14f6  vmovaps xmm3, [rsp+0x30]
00007aa3a45e14fc  vmovaps xmm4, [rsp+0x40]
00007aa3a45e1502  vmovaps xmm5, [rsp+0x50]
00007aa3a45e1508  vmovaps xmm6, [rsp+0x60]
00007aa3a45e150e  vmovaps xmm7, [rsp+0x70]
00007aa3a45e1514  vmovaps xmm8, [rsp+0x80]
00007aa3a45e151d  vmovaps xmm10, [rsp+0x90]
00007aa3a45e1526  vmovaps xmm11, [rsp+0xA0]
00007aa3a45e152f  vmovaps xmm12, [rsp+0xB0]
00007aa3a45e1538  vmovaps xmm13, [rsp+0xC0]
00007aa3a45e1541  vmovaps xmm14, [rsp+0xD0]
00007aa3a45e154a  vmovaps xmm15, [rsp+0xE0]
00007aa3a45e1553  add rsp, 0xF0
00007aa3a45e155a  pop r11
00007aa3a45e155c  pop r10
00007aa3a45e155e  pop r9
00007aa3a45e1560  pop r8
00007aa3a45e1562  pop rsi
00007aa3a45e1563  pop rdi
00007aa3a45e1564  pop rdx
00007aa3a45e1565  pop rcx
00007aa3a45e1566  pop rax
00007aa3a45e1567  add rsp, 0x08
00007aa3a45e156b  jmp 0x00007AA3A45DC7E2
00007aa3a45e1570  sub rsp, 0x08
00007aa3a45e1574  push rax
00007aa3a45e1575  push rcx
00007aa3a45e1576  push rdx
00007aa3a45e1577  push rdi
00007aa3a45e1578  push rsi
00007aa3a45e1579  push r8
00007aa3a45e157b  push r9
00007aa3a45e157d  push r10
00007aa3a45e157f  push r11
00007aa3a45e1581  sub rsp, 0xF0
00007aa3a45e1588  vmovaps [rsp], xmm0
00007aa3a45e158d  vmovaps [rsp+0x10], xmm1
00007aa3a45e1593  vmovaps [rsp+0x20], xmm2
00007aa3a45e1599  vmovaps [rsp+0x30], xmm3
00007aa3a45e159f  vmovaps [rsp+0x40], xmm4
00007aa3a45e15a5  vmovaps [rsp+0x50], xmm5
00007aa3a45e15ab  vmovaps [rsp+0x60], xmm6
00007aa3a45e15b1  vmovaps [rsp+0x70], xmm7
00007aa3a45e15b7  vmovaps [rsp+0x80], xmm8
00007aa3a45e15c0  vmovaps [rsp+0x90], xmm9
00007aa3a45e15c9  vmovaps [rsp+0xA0], xmm10
00007aa3a45e15d2  vmovaps [rsp+0xB0], xmm11
00007aa3a45e15db  vmovaps [rsp+0xC0], xmm12
00007aa3a45e15e4  vmovaps [rsp+0xD0], xmm13
00007aa3a45e15ed  vmovaps [rsp+0xE0], xmm14
00007aa3a45e15f6  sub rsp, 0x30
00007aa3a45e15fa  movaps [rsp], xmm15
00007aa3a45e15ff  movaps [rsp+0x10], xmm11
00007aa3a45e1605  movaps [rsp+0x20], xmm12
00007aa3a45e160b  lea rdi, [rsp]
00007aa3a45e160f  mov esi, 0x00
00007aa3a45e1614  mov rax, 0x5F551B683530
00007aa3a45e161e  call rax
00007aa3a45e1620  movaps xmm15, [rsp]
00007aa3a45e1625  add rsp, 0x30
00007aa3a45e1629  vmovaps xmm0, [rsp]
00007aa3a45e162e  vmovaps xmm1, [rsp+0x10]
00007aa3a45e1634  vmovaps xmm2, [rsp+0x20]
00007aa3a45e163a  vmovaps xmm3, [rsp+0x30]
00007aa3a45e1640  vmovaps xmm4, [rsp+0x40]
00007aa3a45e1646  vmovaps xmm5, [rsp+0x50]
00007aa3a45e164c  vmovaps xmm6, [rsp+0x60]
00007aa3a45e1652  vmovaps xmm7, [rsp+0x70]
00007aa3a45e1658  vmovaps xmm8, [rsp+0x80]
00007aa3a45e1661  vmovaps xmm9, [rsp+0x90]
00007aa3a45e166a  vmovaps xmm10, [rsp+0xA0]
00007aa3a45e1673  vmovaps xmm11, [rsp+0xB0]
00007aa3a45e167c  vmovaps xmm12, [rsp+0xC0]
00007aa3a45e1685  vmovaps xmm13, [rsp+0xD0]
00007aa3a45e168e  vmovaps xmm14, [rsp+0xE0]
00007aa3a45e1697  add rsp, 0xF0
00007aa3a45e169e  pop r11
00007aa3a45e16a0  pop r10
00007aa3a45e16a2  pop r9
00007aa3a45e16a4  pop r8
00007aa3a45e16a6  pop rsi
00007aa3a45e16a7  pop rdi
00007aa3a45e16a8  pop rdx
00007aa3a45e16a9  pop rcx
00007aa3a45e16aa  pop rax
00007aa3a45e16ab  add rsp, 0x08
00007aa3a45e16af  jmp 0x00007AA3A45DC7FD
00007aa3a45e16b4  sub rsp, 0x08
00007aa3a45e16b8  push rax
00007aa3a45e16b9  push rcx
00007aa3a45e16ba  push rdx
00007aa3a45e16bb  push rdi
00007aa3a45e16bc  push rsi
00007aa3a45e16bd  push r8
00007aa3a45e16bf  push r9
00007aa3a45e16c1  push r10
00007aa3a45e16c3  push r11
00007aa3a45e16c5  sub rsp, 0xF0
00007aa3a45e16cc  vmovaps [rsp], xmm0
00007aa3a45e16d1  vmovaps [rsp+0x10], xmm1
00007aa3a45e16d7  vmovaps [rsp+0x20], xmm2
00007aa3a45e16dd  vmovaps [rsp+0x30], xmm3
00007aa3a45e16e3  vmovaps [rsp+0x40], xmm4
00007aa3a45e16e9  vmovaps [rsp+0x50], xmm5
00007aa3a45e16ef  vmovaps [rsp+0x60], xmm6
00007aa3a45e16f5  vmovaps [rsp+0x70], xmm7
00007aa3a45e16fb  vmovaps [rsp+0x80], xmm8
00007aa3a45e1704  vmovaps [rsp+0x90], xmm9
00007aa3a45e170d  vmovaps [rsp+0xA0], xmm10
00007aa3a45e1716  vmovaps [rsp+0xB0], xmm11
00007aa3a45e171f  vmovaps [rsp+0xC0], xmm12
00007aa3a45e1728  vmovaps [rsp+0xD0], xmm14
00007aa3a45e1731  vmovaps [rsp+0xE0], xmm15
00007aa3a45e173a  sub rsp, 0x30
00007aa3a45e173e  movaps [rsp], xmm13
00007aa3a45e1743  movaps [rsp+0x10], xmm10
00007aa3a45e1749  movaps [rsp+0x20], xmm14
00007aa3a45e174f  lea rdi, [rsp]
00007aa3a45e1753  mov esi, 0x00
00007aa3a45e1758  mov rax, 0x5F551B683530
00007aa3a45e1762  call rax
00007aa3a45e1764  movaps xmm13, [rsp]
00007aa3a45e1769  add rsp, 0x30
00007aa3a45e176d  vmovaps xmm0, [rsp]
00007aa3a45e1772  vmovaps xmm1, [rsp+0x10]
00007aa3a45e1778  vmovaps xmm2, [rsp+0x20]
00007aa3a45e177e  vmovaps xmm3, [rsp+0x30]
00007aa3a45e1784  vmovaps xmm4, [rsp+0x40]
00007aa3a45e178a  vmovaps xmm5, [rsp+0x50]
00007aa3a45e1790  vmovaps xmm6, [rsp+0x60]
00007aa3a45e1796  vmovaps xmm7, [rsp+0x70]
00007aa3a45e179c  vmovaps xmm8, [rsp+0x80]
00007aa3a45e17a5  vmovaps xmm9, [rsp+0x90]
00007aa3a45e17ae  vmovaps xmm10, [rsp+0xA0]
00007aa3a45e17b7  vmovaps xmm11, [rsp+0xB0]
00007aa3a45e17c0  vmovaps xmm12, [rsp+0xC0]
00007aa3a45e17c9  vmovaps xmm14, [rsp+0xD0]
00007aa3a45e17d2  vmovaps xmm15, [rsp+0xE0]
00007aa3a45e17db  add rsp, 0xF0
00007aa3a45e17e2  pop r11
00007aa3a45e17e4  pop r10
00007aa3a45e17e6  pop r9
00007aa3a45e17e8  pop r8
00007aa3a45e17ea  pop rsi
00007aa3a45e17eb  pop rdi
00007aa3a45e17ec  pop rdx
00007aa3a45e17ed  pop rcx
00007aa3a45e17ee  pop rax
00007aa3a45e17ef  add rsp, 0x08
00007aa3a45e17f3  jmp 0x00007AA3A45DC820
00007aa3a45e17f8  sub rsp, 0x08
00007aa3a45e17fc  push rax
00007aa3a45e17fd  push rcx
00007aa3a45e17fe  push rdx
00007aa3a45e17ff  push rdi
00007aa3a45e1800  push rsi
00007aa3a45e1801  push r8
00007aa3a45e1803  push r9
00007aa3a45e1805  push r10
00007aa3a45e1807  push r11
00007aa3a45e1809  sub rsp, 0xF0
00007aa3a45e1810  vmovaps [rsp], xmm0
00007aa3a45e1815  vmovaps [rsp+0x10], xmm1
00007aa3a45e181b  vmovaps [rsp+0x20], xmm2
00007aa3a45e1821  vmovaps [rsp+0x30], xmm3
00007aa3a45e1827  vmovaps [rsp+0x40], xmm4
00007aa3a45e182d  vmovaps [rsp+0x50], xmm5
00007aa3a45e1833  vmovaps [rsp+0x60], xmm6
00007aa3a45e1839  vmovaps [rsp+0x70], xmm7
00007aa3a45e183f  vmovaps [rsp+0x80], xmm8
00007aa3a45e1848  vmovaps [rsp+0x90], xmm9
00007aa3a45e1851  vmovaps [rsp+0xA0], xmm10
00007aa3a45e185a  vmovaps [rsp+0xB0], xmm11
00007aa3a45e1863  vmovaps [rsp+0xC0], xmm12
00007aa3a45e186c  vmovaps [rsp+0xD0], xmm13
00007aa3a45e1875  vmovaps [rsp+0xE0], xmm15
00007aa3a45e187e  sub rsp, 0x30
00007aa3a45e1882  movaps [rsp], xmm14
00007aa3a45e1887  movaps [rsp+0x10], xmm1
00007aa3a45e188c  movaps [rsp+0x20], xmm7
00007aa3a45e1891  lea rdi, [rsp]
00007aa3a45e1895  mov esi, 0x00
00007aa3a45e189a  mov rax, 0x5F551B683530
00007aa3a45e18a4  call rax
00007aa3a45e18a6  movaps xmm14, [rsp]
00007aa3a45e18ab  add rsp, 0x30
00007aa3a45e18af  vmovaps xmm0, [rsp]
00007aa3a45e18b4  vmovaps xmm1, [rsp+0x10]
00007aa3a45e18ba  vmovaps xmm2, [rsp+0x20]
00007aa3a45e18c0  vmovaps xmm3, [rsp+0x30]
00007aa3a45e18c6  vmovaps xmm4, [rsp+0x40]
00007aa3a45e18cc  vmovaps xmm5, [rsp+0x50]
00007aa3a45e18d2  vmovaps xmm6, [rsp+0x60]
00007aa3a45e18d8  vmovaps xmm7, [rsp+0x70]
00007aa3a45e18de  vmovaps xmm8, [rsp+0x80]
00007aa3a45e18e7  vmovaps xmm9, [rsp+0x90]
00007aa3a45e18f0  vmovaps xmm10, [rsp+0xA0]
00007aa3a45e18f9  vmovaps xmm11, [rsp+0xB0]
00007aa3a45e1902  vmovaps xmm12, [rsp+0xC0]
00007aa3a45e190b  vmovaps xmm13, [rsp+0xD0]
00007aa3a45e1914  vmovaps xmm15, [rsp+0xE0]
00007aa3a45e191d  add rsp, 0xF0
00007aa3a45e1924  pop r11
00007aa3a45e1926  pop r10
00007aa3a45e1928  pop r9
00007aa3a45e192a  pop r8
00007aa3a45e192c  pop rsi
00007aa3a45e192d  pop rdi
00007aa3a45e192e  pop rdx
00007aa3a45e192f  pop rcx
00007aa3a45e1930  pop rax
00007aa3a45e1931  add rsp, 0x08
00007aa3a45e1935  jmp 0x00007AA3A45DC843
00007aa3a45e193a  sub rsp, 0x08
00007aa3a45e193e  push rax
00007aa3a45e193f  push rcx
00007aa3a45e1940  push rdx
00007aa3a45e1941  push rdi
00007aa3a45e1942  push rsi
00007aa3a45e1943  push r8
00007aa3a45e1945  push r9
00007aa3a45e1947  push r10
00007aa3a45e1949  push r11
00007aa3a45e194b  sub rsp, 0xF0
00007aa3a45e1952  vmovaps [rsp], xmm0
00007aa3a45e1957  vmovaps [rsp+0x10], xmm2
00007aa3a45e195d  vmovaps [rsp+0x20], xmm3
00007aa3a45e1963  vmovaps [rsp+0x30], xmm4
00007aa3a45e1969  vmovaps [rsp+0x40], xmm5
00007aa3a45e196f  vmovaps [rsp+0x50], xmm6
00007aa3a45e1975  vmovaps [rsp+0x60], xmm7
00007aa3a45e197b  vmovaps [rsp+0x70], xmm8
00007aa3a45e1981  vmovaps [rsp+0x80], xmm9
00007aa3a45e198a  vmovaps [rsp+0x90], xmm10
00007aa3a45e1993  vmovaps [rsp+0xA0], xmm11
00007aa3a45e199c  vmovaps [rsp+0xB0], xmm12
00007aa3a45e19a5  vmovaps [rsp+0xC0], xmm13
00007aa3a45e19ae  vmovaps [rsp+0xD0], xmm14
00007aa3a45e19b7  vmovaps [rsp+0xE0], xmm15
00007aa3a45e19c0  sub rsp, 0x30
00007aa3a45e19c4  movaps [rsp], xmm1
00007aa3a45e19c8  movaps [rsp+0x10], xmm8
00007aa3a45e19ce  movaps [rsp+0x20], xmm9
00007aa3a45e19d4  lea rdi, [rsp]
00007aa3a45e19d8  mov esi, 0x00
00007aa3a45e19dd  mov rax, 0x5F551B683530
00007aa3a45e19e7  call rax
00007aa3a45e19e9  movaps xmm1, [rsp]
00007aa3a45e19ed  add rsp, 0x30
00007aa3a45e19f1  vmovaps xmm0, [rsp]
00007aa3a45e19f6  vmovaps xmm2, [rsp+0x10]
00007aa3a45e19fc  vmovaps xmm3, [rsp+0x20]
00007aa3a45e1a02  vmovaps xmm4, [rsp+0x30]
00007aa3a45e1a08  vmovaps xmm5, [rsp+0x40]
00007aa3a45e1a0e  vmovaps xmm6, [rsp+0x50]
00007aa3a45e1a14  vmovaps xmm7, [rsp+0x60]
00007aa3a45e1a1a  vmovaps xmm8, [rsp+0x70]
00007aa3a45e1a20  vmovaps xmm9, [rsp+0x80]
00007aa3a45e1a29  vmovaps xmm10, [rsp+0x90]
00007aa3a45e1a32  vmovaps xmm11, [rsp+0xA0]
00007aa3a45e1a3b  vmovaps xmm12, [rsp+0xB0]
00007aa3a45e1a44  vmovaps xmm13, [rsp+0xC0]
00007aa3a45e1a4d  vmovaps xmm14, [rsp+0xD0]
00007aa3a45e1a56  vmovaps xmm15, [rsp+0xE0]
00007aa3a45e1a5f  add rsp, 0xF0
00007aa3a45e1a66  pop r11
00007aa3a45e1a68  pop r10
00007aa3a45e1a6a  pop r9
00007aa3a45e1a6c  pop r8
00007aa3a45e1a6e  pop rsi
00007aa3a45e1a6f  pop rdi
00007aa3a45e1a70  pop rdx
00007aa3a45e1a71  pop rcx
00007aa3a45e1a72  pop rax
00007aa3a45e1a73  add rsp, 0x08
00007aa3a45e1a77  jmp 0x00007AA3A45DC865
00007aa3a45e1a7c  call 0x00007AA3A44E5940
00007aa3a45e1a81  jmp 0x00007AA3A45DC873
00007aa3a45e1a86  call 0x00007AA3A440C380
00007aa3a45e1a8b  jmp 0x00007AA3A45DC87D
00007aa3a45e1a90  call 0x00007AA3A440D600
00007aa3a45e1a95  jmp 0x00007AA3A45DC887
00007aa3a45e1a9a  call 0x00007AA3A43FF540
00007aa3a45e1a9f  jmp 0x00007AA3A45DC891
00007aa3a45e1aa4  int3
00007aa3a45e1aa5  nop [rax+rax*1], ax
00007aa3a45e1aae  nop
00007aa3a45e1ab0  mov rax, [r15+0xF8]
00007aa3a45e1ab7  lea r14, [rax+0x140]
00007aa3a45e1abe  mov r12, [r13+r14*1]
00007aa3a45e1ac3  mov [r15+0xE8], r12
00007aa3a45e1aca  lea r14, [rax+0x130]
00007aa3a45e1ad1  mov r12, [r13+r14*1]
00007aa3a45e1ad6  lea r14, [rax+0x138]
00007aa3a45e1add  mov r11, [r13+r14*1]
00007aa3a45e1ae2  movq xmm1, r12
00007aa3a45e1ae7  movq xmm15, r11
00007aa3a45e1aec  movq xmm1, xmm1
00007aa3a45e1af0  movq xmm1, xmm1
00007aa3a45e1af4  movaps [r15+0x1A0], xmm1
00007aa3a45e1afc  movq xmm15, xmm15
00007aa3a45e1b01  movq xmm15, xmm15
00007aa3a45e1b06  movaps [r15+0x190], xmm15
00007aa3a45e1b0e  lea r14, [rax+0x120]
00007aa3a45e1b15  mov r12, [r13+r14*1]
00007aa3a45e1b1a  lea r14, [rax+0x128]
00007aa3a45e1b21  mov r11, [r13+r14*1]
00007aa3a45e1b26  movq xmm1, r12
00007aa3a45e1b2b  movq xmm15, r11
00007aa3a45e1b30  movq xmm1, xmm1
00007aa3a45e1b34  movq xmm1, xmm1
00007aa3a45e1b38  movaps [r15+0x1C0], xmm1
00007aa3a45e1b40  movq xmm15, xmm15
00007aa3a45e1b45  movq xmm15, xmm15
00007aa3a45e1b4a  movaps [r15+0x1B0], xmm15
00007aa3a45e1b52  lea r14, [rax+0x110]
00007aa3a45e1b59  mov r12, [r13+r14*1]
00007aa3a45e1b5e  lea r14, [rax+0x118]
00007aa3a45e1b65  mov r11, [r13+r14*1]
00007aa3a45e1b6a  movq xmm1, r12
00007aa3a45e1b6f  movq xmm15, r11
00007aa3a45e1b74  movq xmm1, xmm1
00007aa3a45e1b78  movq xmm1, xmm1
00007aa3a45e1b7c  movaps [r15+0x1E0], xmm1
00007aa3a45e1b84  movq xmm15, xmm15
00007aa3a45e1b89  movq xmm15, xmm15
00007aa3a45e1b8e  movaps [r15+0x1D0], xmm15
00007aa3a45e1b96  lea r14, [rax+0x100]
00007aa3a45e1b9d  mov r12, [r13+r14*1]
00007aa3a45e1ba2  lea r14, [rax+0x108]
00007aa3a45e1ba9  mov r11, [r13+r14*1]
00007aa3a45e1bae  movq xmm1, r12
00007aa3a45e1bb3  movq xmm15, r11
00007aa3a45e1bb8  movq xmm1, xmm1
00007aa3a45e1bbc  movq xmm1, xmm1
00007aa3a45e1bc0  movaps [r15+0x200], xmm1
00007aa3a45e1bc8  movq xmm15, xmm15
00007aa3a45e1bcd  movq xmm15, xmm15
00007aa3a45e1bd2  movaps [r15+0x1F0], xmm15
00007aa3a45e1bda  mov qword ptr [r15+0x40], 0x430000
00007aa3a45e1be2  mov r14d, 0x430510
00007aa3a45e1be8  mov r12, [r13+r14*1]
00007aa3a45e1bed  movq xmm1, r12
00007aa3a45e1bf2  lea r14, [rax+0x150]
00007aa3a45e1bf9  mov [r15+0xF8], r14
00007aa3a45e1c00  mov rax, [r15+0x50]
00007aa3a45e1c04  movups xmm15, [r13+rax*1]
00007aa3a45e1c0a  movaps [r15+0x120], xmm15
00007aa3a45e1c12  mov qword ptr [r15+0x48], 0x10
00007aa3a45e1c1a  xor eax, eax
00007aa3a45e1c1c  mov r14d, 0x10
00007aa3a45e1c22  mov r12d, 0x200
00007aa3a45e1c28  cmp r14, r12
00007aa3a45e1c2b  cmc
00007aa3a45e1c2c  lahf
00007aa3a45e1c2d  seto al
00007aa3a45e1c30  mov [r15+0x108], eax
00007aa3a45e1c37  pextrq rax, xmm15, 0x01
00007aa3a45e1c3e  movq xmm14, rax
00007aa3a45e1c43  movaps [r15+0x130], xmm14
00007aa3a45e1c4b  movq rax, xmm1
00007aa3a45e1c50  movq r14, xmm15
00007aa3a45e1c55  vmovq xmm1, rax
00007aa3a45e1c5a  vmovq xmm15, r14
00007aa3a45e1c5f  movaps xmm13, xmm1
00007aa3a45e1c63  addsd xmm13, xmm15
00007aa3a45e1c68  ucomisd xmm13, xmm13
00007aa3a45e1c6d  jp 0x00007AA3A45E1D86
00007aa3a45e1c73  movq xmm13, xmm13
00007aa3a45e1c78  movq rax, xmm13
00007aa3a45e1c7d  movq r14, xmm14
00007aa3a45e1c82  vmovq xmm1, rax
00007aa3a45e1c87  vmovq xmm15, r14
00007aa3a45e1c8c  movaps xmm14, xmm1
00007aa3a45e1c90  addsd xmm14, xmm15
00007aa3a45e1c95  ucomisd xmm14, xmm14
00007aa3a45e1c9a  jp 0x00007AA3A45E1DCE
00007aa3a45e1ca0  movq xmm14, xmm14
00007aa3a45e1ca5  movaps [r15+0x110], xmm14
00007aa3a45e1cad  mov eax, [r15+0x108]
00007aa3a45e1cb4  sahf
00007aa3a45e1cb5  jnz 0x00007AA3A45E1CE7
00007aa3a45e1cb7  cmp dword ptr [r15+0x318], 0x00
00007aa3a45e1cbf  jz 0x00007AA3A45E1FE0
00007aa3a45e1cc5  nop [rax+rax*1], ax
00007aa3a45e1cce  nop [rax+rax*1], eax
00007aa3a45e1cd6  mov eax, 0x410490
00007aa3a45e1cdb  mov [r15+0x100], rax
00007aa3a45e1ce2  jmp 0x00007AA3A43FE110
00007aa3a45e1ce7  cmp dword ptr [r15+0x318], 0x00
00007aa3a45e1cef  jz 0x00007AA3A45E1E20
00007aa3a45e1cf5  nop [rax+rax*1], ax
00007aa3a45e1cfe  nop [rax+rax*1], eax
00007aa3a45e1d06  mov eax, 0x410474
00007aa3a45e1d0b  mov [r15+0x100], rax
00007aa3a45e1d12  jmp 0x00007AA3A43FE110
00007aa3a45e1d17  int3
00007aa3a45e1d18  call 0x00007AA3A44E27E0
00007aa3a45e1d1d  jmp 0x00007AA3A45E1AC3
00007aa3a45e1d22  call 0x00007AA3A44E27E0
00007aa3a45e1d27  jmp 0x00007AA3A45E1AD6
00007aa3a45e1d2c  call 0x00007AA3A44E1570
00007aa3a45e1d31  jmp 0x00007AA3A45E1AE2
00007aa3a45e1d36  call 0x00007AA3A44E27E0
00007aa3a45e1d3b  jmp 0x00007AA3A45E1B1A
00007aa3a45e1d40  call 0x00007AA3A44E1570
00007aa3a45e1d45  jmp 0x00007AA3A45E1B26
00007aa3a45e1d4a  call 0x00007AA3A44E27E0
00007aa3a45e1d4f  jmp 0x00007AA3A45E1B5E
00007aa3a45e1d54  call 0x00007AA3A44E1570
00007aa3a45e1d59  jmp 0x00007AA3A45E1B6A
00007aa3a45e1d5e  call 0x00007AA3A44E27E0
00007aa3a45e1d63  jmp 0x00007AA3A45E1BA2
00007aa3a45e1d68  call 0x00007AA3A44E1570
00007aa3a45e1d6d  jmp 0x00007AA3A45E1BAE
00007aa3a45e1d72  call 0x00007AA3A44E27E0
00007aa3a45e1d77  jmp 0x00007AA3A45E1BED
00007aa3a45e1d7c  call 0x00007AA3A440E760
00007aa3a45e1d81  jmp 0x00007AA3A45E1C0A
00007aa3a45e1d86  ucomisd xmm1, xmm15
00007aa3a45e1d8b  jp 0x00007AA3A45E1D9A
00007aa3a45e1d8d  movaps xmm13, [0x00007AA3A41FE060]
00007aa3a45e1d95  jmp 0x00007AA3A45E1C73
00007aa3a45e1d9a  vxorps xmm0, xmm1, xmm15
00007aa3a45e1d9f  pextrw eax, xmm0, 0x03
00007aa3a45e1da4  and eax, 0x7FF8
00007aa3a45e1da9  cmp eax, 0x08
00007aa3a45e1dac  jnz 0x00007AA3A45E1C73
00007aa3a45e1db2  movq rax, xmm15
00007aa3a45e1db7  shl rax, 0x0D
00007aa3a45e1dbb  jbe 0x00007AA3A45E1C73
00007aa3a45e1dc1  vorps xmm13, xmm15, [0x00007AA3A41FE070]
00007aa3a45e1dc9  jmp 0x00007AA3A45E1C73
00007aa3a45e1dce  ucomisd xmm1, xmm15
00007aa3a45e1dd3  jp 0x00007AA3A45E1DE2
00007aa3a45e1dd5  movaps xmm14, [0x00007AA3A41FE060]
00007aa3a45e1ddd  jmp 0x00007AA3A45E1CA0
00007aa3a45e1de2  vxorps xmm0, xmm1, xmm15
00007aa3a45e1de7  pextrw eax, xmm0, 0x03
00007aa3a45e1dec  and eax, 0x7FF8
00007aa3a45e1df1  cmp eax, 0x08
00007aa3a45e1df4  jnz 0x00007AA3A45E1CA0
00007aa3a45e1dfa  movq rax, xmm15
00007aa3a45e1dff  shl rax, 0x0D
00007aa3a45e1e03  jbe 0x00007AA3A45E1CA0
00007aa3a45e1e09  vorps xmm14, xmm15, [0x00007AA3A41FE070]
00007aa3a45e1e11  jmp 0x00007AA3A45E1CA0
00007aa3a45e1e16  int3
00007aa3a45e1e17  nop [rax+rax*1], ax
00007aa3a45e1e20  mov rax, [r15+0x48]
00007aa3a45e1e24  mov r14, [r15+0x50]
00007aa3a45e1e28  lea r12, [r14+rax*1]
00007aa3a45e1e2c  movups xmm1, [r13+r12*1]
00007aa3a45e1e32  movaps [r15+0x120], xmm1
00007aa3a45e1e3a  lea r14, [rax+0x10]
00007aa3a45e1e3e  mov [r15+0x48], r14
00007aa3a45e1e42  xor eax, eax
00007aa3a45e1e44  mov r12d, 0x200
00007aa3a45e1e4a  cmp r14, r12
00007aa3a45e1e4d  cmc
00007aa3a45e1e4e  lahf
00007aa3a45e1e4f  seto al
00007aa3a45e1e52  mov [r15+0x108], eax
00007aa3a45e1e59  pextrq rax, xmm1, 0x01
00007aa3a45e1e60  movq xmm15, rax
00007aa3a45e1e65  movaps [r15+0x130], xmm15
00007aa3a45e1e6d  movaps xmm14, [r15+0x110]
00007aa3a45e1e75  movq rax, xmm14
00007aa3a45e1e7a  movq r14, xmm1
00007aa3a45e1e7f  vmovq xmm1, rax
00007aa3a45e1e84  vmovq xmm14, r14
00007aa3a45e1e89  movaps xmm13, xmm1
00007aa3a45e1e8d  addsd xmm13, xmm14
00007aa3a45e1e92  ucomisd xmm13, xmm13
00007aa3a45e1e97  jp 0x00007AA3A45E1F4C
00007aa3a45e1e9d  movq xmm13, xmm13
00007aa3a45e1ea2  movq rax, xmm13
00007aa3a45e1ea7  movq r14, xmm15
00007aa3a45e1eac  vmovq xmm1, rax
00007aa3a45e1eb1  vmovq xmm15, r14
00007aa3a45e1eb6  movaps xmm14, xmm1
00007aa3a45e1eba  addsd xmm14, xmm15
00007aa3a45e1ebf  ucomisd xmm14, xmm14
00007aa3a45e1ec4  jp 0x00007AA3A45E1F94
00007aa3a45e1eca  movq xmm14, xmm14
00007aa3a45e1ecf  movaps [r15+0x110], xmm14
00007aa3a45e1ed7  mov eax, [r15+0x108]
00007aa3a45e1ede  sahf
00007aa3a45e1edf  jnz 0x00007AA3A45E1F11
00007aa3a45e1ee1  cmp dword ptr [r15+0x318], 0x00
00007aa3a45e1ee9  jz 0x00007AA3A45E1FE0
00007aa3a45e1eef  nop [rax+rax*1], ax
00007aa3a45e1ef8  nop [rax+rax*1], eax
00007aa3a45e1f00  mov eax, 0x410490
00007aa3a45e1f05  mov [r15+0x100], rax
00007aa3a45e1f0c  jmp 0x00007AA3A43FE110
00007aa3a45e1f11  cmp dword ptr [r15+0x318], 0x00
00007aa3a45e1f19  jz 0x00007AA3A45E1E20
00007aa3a45e1f1f  nop [rax+rax*1], ax
00007aa3a45e1f28  nop [rax+rax*1], eax
00007aa3a45e1f30  mov eax, 0x410474
00007aa3a45e1f35  mov [r15+0x100], rax
00007aa3a45e1f3c  jmp 0x00007AA3A43FE110
00007aa3a45e1f41  int3
00007aa3a45e1f42  call 0x00007AA3A44B52F0
00007aa3a45e1f47  jmp 0x00007AA3A45E1E32
00007aa3a45e1f4c  ucomisd xmm1, xmm14
00007aa3a45e1f51  jp 0x00007AA3A45E1F60
00007aa3a45e1f53  movaps xmm13, [0x00007AA3A41FE060]
00007aa3a45e1f5b  jmp 0x00007AA3A45E1E9D
00007aa3a45e1f60  vxorps xmm0, xmm1, xmm14
00007aa3a45e1f65  pextrw eax, xmm0, 0x03
00007aa3a45e1f6a  and eax, 0x7FF8
00007aa3a45e1f6f  cmp eax, 0x08
00007aa3a45e1f72  jnz 0x00007AA3A45E1E9D
00007aa3a45e1f78  movq rax, xmm14
00007aa3a45e1f7d  shl rax, 0x0D
00007aa3a45e1f81  jbe 0x00007AA3A45E1E9D
00007aa3a45e1f87  vorps xmm13, xmm14, [0x00007AA3A41FE070]
00007aa3a45e1f8f  jmp 0x00007AA3A45E1E9D
00007aa3a45e1f94  ucomisd xmm1, xmm15
00007aa3a45e1f99  jp 0x00007AA3A45E1FA8
00007aa3a45e1f9b  movaps xmm14, [0x00007AA3A41FE060]
00007aa3a45e1fa3  jmp 0x00007AA3A45E1ECA
00007aa3a45e1fa8  vxorps xmm0, xmm1, xmm15
00007aa3a45e1fad  pextrw eax, xmm0, 0x03
00007aa3a45e1fb2  and eax, 0x7FF8
00007aa3a45e1fb7  cmp eax, 0x08
00007aa3a45e1fba  jnz 0x00007AA3A45E1ECA
00007aa3a45e1fc0  movq rax, xmm15
00007aa3a45e1fc5  shl rax, 0x0D
00007aa3a45e1fc9  jbe 0x00007AA3A45E1ECA
00007aa3a45e1fcf  vorps xmm14, xmm15, [0x00007AA3A41FE070]
00007aa3a45e1fd7  jmp 0x00007AA3A45E1ECA
00007aa3a45e1fdc  int3
00007aa3a45e1fdd  nop [rax], eax
00007aa3a45e1fe0  mov rax, [r15+0x40]
00007aa3a45e1fe4  lea r14, [rax+0x510]
00007aa3a45e1feb  movaps xmm1, [r15+0x110]
00007aa3a45e1ff3  movq rax, xmm1
00007aa3a45e1ff8  mov [r13+r14*1], rax
00007aa3a45e1ffd  mov rax, [r15+0xF0]
00007aa3a45e2004  mov [r15+0x100], rax
00007aa3a45e200b  jmp 0x00007AA3A45CE5C0
00007aa3a45e2010  int3
00007aa3a45e2011  call 0x00007AA3A44D5EB0
00007aa3a45e2016  jmp 0x00007AA3A45E1FFD
00007aa3a45e201b  int3
00007aa3a45e201c  nop [rax], eax
00007aa3a45e2020  mov qword ptr [r15+0x100], 0x04
00007aa3a45e202b  mov esi, 0x00
00007aa3a45e2030  mov edx, 0x09
00007aa3a45e2035  mov rdi, 0x7FFD639B73B0
00007aa3a45e203f  mov rax, 0x5F551B516970
00007aa3a45e2049  call rax
00007aa3a45e204b  cmp dword ptr [r15+0x318], 0x00
00007aa3a45e2053  jnz 0x00007AA3A43FE110
00007aa3a45e2059  jmp 0x00007AA3A43FE0A0
00007aa3a45e205e  int3
00007aa3a45e205f  int3
