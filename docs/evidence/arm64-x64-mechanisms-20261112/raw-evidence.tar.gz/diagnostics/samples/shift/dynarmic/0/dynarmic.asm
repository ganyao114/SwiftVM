00007087bd1ce69b  nop [rax+rax*1], eax
00007087bd1ce6a0  mov qword ptr [r15+0x20], 0x420060
00007087bd1ce6a8  xor eax, eax
00007087bd1ce6aa  xor r14d, r14d
00007087bd1ce6ad  shrd rax, r14, 0x0D
00007087bd1ce6b2  mov [rsp+0x10], rax
00007087bd1ce6b7  shr rax, 0x07
00007087bd1ce6bb  mov r14, [rsp+0x10]
00007087bd1ce6c0  xor r14, rax
00007087bd1ce6c3  lea rax, [r14+0x03]
00007087bd1ce6c7  mov [r15], rax
00007087bd1ce6ca  xor eax, eax
00007087bd1ce6cc  mov r14d, 0xB71B00
00007087bd1ce6d2  mov r12d, 0x01
00007087bd1ce6d8  sub r14, r12
00007087bd1ce6db  cmc
00007087bd1ce6dc  lahf
00007087bd1ce6dd  seto al
00007087bd1ce6e0  mov [r15+0x108], eax
00007087bd1ce6e7  mov [r15+0x08], r14
00007087bd1ce6eb  mov eax, [r15+0x108]
00007087bd1ce6f2  sahf
00007087bd1ce6f3  jnz 0x00007087BD1CE725
00007087bd1ce6f5  cmp dword ptr [r15+0x318], 0x00
00007087bd1ce6fd  jz 0x00007087BD1CE820
00007087bd1ce703  nop [rax+rax*1], ax
00007087bd1ce70c  nop [rax+rax*1], eax
00007087bd1ce714  mov eax, 0x410050
00007087bd1ce719  mov [r15+0x100], rax
00007087bd1ce720  jmp 0x00007087BCFFE110
00007087bd1ce725  cmp dword ptr [r15+0x318], 0x00
00007087bd1ce72d  jz 0x00007087BD1CE760
00007087bd1ce733  nop [rax+rax*1], ax
00007087bd1ce73c  nop [rax+rax*1], eax
00007087bd1ce744  mov eax, 0x41003C
00007087bd1ce749  mov [r15+0x100], rax
00007087bd1ce750  jmp 0x00007087BCFFE110
00007087bd1ce755  int3
00007087bd1ce756  int3
00007087bd1ce757  nop [rax+rax*1], ax
00007087bd1ce760  mov rax, [r15]
00007087bd1ce763  mov [rsp+0x10], rax
00007087bd1ce768  mov r14, [rsp+0x10]
00007087bd1ce76d  shrd rax, r14, 0x0D
00007087bd1ce772  mov [rsp+0x10], rax
00007087bd1ce777  shr rax, 0x07
00007087bd1ce77b  mov r14, [rsp+0x10]
00007087bd1ce780  xor r14, rax
00007087bd1ce783  lea rax, [r14+0x03]
00007087bd1ce787  mov [r15], rax
00007087bd1ce78a  mov rax, [r15+0x08]
00007087bd1ce78e  mov [rsp+0x10], rax
00007087bd1ce793  xor eax, eax
00007087bd1ce795  mov r14, [rsp+0x10]
00007087bd1ce79a  mov r12d, 0x01
00007087bd1ce7a0  sub r14, r12
00007087bd1ce7a3  cmc
00007087bd1ce7a4  lahf
00007087bd1ce7a5  seto al
00007087bd1ce7a8  mov [r15+0x108], eax
00007087bd1ce7af  mov [r15+0x08], r14
00007087bd1ce7b3  mov eax, [r15+0x108]
00007087bd1ce7ba  sahf
00007087bd1ce7bb  jnz 0x00007087BD1CE7ED
00007087bd1ce7bd  cmp dword ptr [r15+0x318], 0x00
00007087bd1ce7c5  jz 0x00007087BD1CE820
00007087bd1ce7cb  nop [rax+rax*1], ax
00007087bd1ce7d4  nop [rax+rax*1], eax
00007087bd1ce7dc  mov eax, 0x410050
00007087bd1ce7e1  mov [r15+0x100], rax
00007087bd1ce7e8  jmp 0x00007087BCFFE110
00007087bd1ce7ed  cmp dword ptr [r15+0x318], 0x00
00007087bd1ce7f5  jz 0x00007087BD1CE760
00007087bd1ce7fb  nop [rax+rax*1], ax
00007087bd1ce804  nop [rax+rax*1], eax
00007087bd1ce80c  mov eax, 0x41003C
00007087bd1ce811  mov [r15+0x100], rax
00007087bd1ce818  jmp 0x00007087BCFFE110
00007087bd1ce81d  int3
00007087bd1ce81e  int3
00007087bd1ce81f  nop
00007087bd1ce820  mov rax, [r15+0x20]
00007087bd1ce824  mov r14, [r15]
00007087bd1ce827  mov [r13+rax*1], r14
00007087bd1ce82c  mov rax, [r15+0xF0]
00007087bd1ce833  mov [r15+0x100], rax
00007087bd1ce83a  jmp 0x00007087BD1CE5C0
00007087bd1ce83f  int3
00007087bd1ce840  call 0x00007087BD00E120
00007087bd1ce845  jmp 0x00007087BD1CE82C
00007087bd1ce84a  int3
00007087bd1ce84b  nop [rax+rax*1], eax
00007087bd1ce850  mov qword ptr [r15+0x100], 0x04
00007087bd1ce85b  mov esi, 0x00
00007087bd1ce860  mov edx, 0x09
00007087bd1ce865  mov rdi, 0x7FFEC3CE5410
00007087bd1ce86f  mov rax, 0x5FB1EB2BD970
00007087bd1ce879  call rax
00007087bd1ce87b  cmp dword ptr [r15+0x318], 0x00
00007087bd1ce883  jnz 0x00007087BCFFE110
00007087bd1ce889  jmp 0x00007087BCFFE0A0
00007087bd1ce88e  int3
00007087bd1ce88f  int3
