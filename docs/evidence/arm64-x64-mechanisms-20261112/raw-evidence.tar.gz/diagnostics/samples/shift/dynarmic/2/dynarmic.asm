0000772de21ce69b  nop [rax+rax*1], eax
0000772de21ce6a0  mov qword ptr [r15+0x20], 0x420060
0000772de21ce6a8  xor eax, eax
0000772de21ce6aa  xor r14d, r14d
0000772de21ce6ad  shrd rax, r14, 0x0D
0000772de21ce6b2  mov [rsp+0x10], rax
0000772de21ce6b7  shr rax, 0x07
0000772de21ce6bb  mov r14, [rsp+0x10]
0000772de21ce6c0  xor r14, rax
0000772de21ce6c3  lea rax, [r14+0x03]
0000772de21ce6c7  mov [r15], rax
0000772de21ce6ca  xor eax, eax
0000772de21ce6cc  mov r14d, 0xB71B00
0000772de21ce6d2  mov r12d, 0x01
0000772de21ce6d8  sub r14, r12
0000772de21ce6db  cmc
0000772de21ce6dc  lahf
0000772de21ce6dd  seto al
0000772de21ce6e0  mov [r15+0x108], eax
0000772de21ce6e7  mov [r15+0x08], r14
0000772de21ce6eb  mov eax, [r15+0x108]
0000772de21ce6f2  sahf
0000772de21ce6f3  jnz 0x0000772DE21CE725
0000772de21ce6f5  cmp dword ptr [r15+0x318], 0x00
0000772de21ce6fd  jz 0x0000772DE21CE820
0000772de21ce703  nop [rax+rax*1], ax
0000772de21ce70c  nop [rax+rax*1], eax
0000772de21ce714  mov eax, 0x410050
0000772de21ce719  mov [r15+0x100], rax
0000772de21ce720  jmp 0x0000772DE1FFE110
0000772de21ce725  cmp dword ptr [r15+0x318], 0x00
0000772de21ce72d  jz 0x0000772DE21CE760
0000772de21ce733  nop [rax+rax*1], ax
0000772de21ce73c  nop [rax+rax*1], eax
0000772de21ce744  mov eax, 0x41003C
0000772de21ce749  mov [r15+0x100], rax
0000772de21ce750  jmp 0x0000772DE1FFE110
0000772de21ce755  int3
0000772de21ce756  int3
0000772de21ce757  nop [rax+rax*1], ax
0000772de21ce760  mov rax, [r15]
0000772de21ce763  mov [rsp+0x10], rax
0000772de21ce768  mov r14, [rsp+0x10]
0000772de21ce76d  shrd rax, r14, 0x0D
0000772de21ce772  mov [rsp+0x10], rax
0000772de21ce777  shr rax, 0x07
0000772de21ce77b  mov r14, [rsp+0x10]
0000772de21ce780  xor r14, rax
0000772de21ce783  lea rax, [r14+0x03]
0000772de21ce787  mov [r15], rax
0000772de21ce78a  mov rax, [r15+0x08]
0000772de21ce78e  mov [rsp+0x10], rax
0000772de21ce793  xor eax, eax
0000772de21ce795  mov r14, [rsp+0x10]
0000772de21ce79a  mov r12d, 0x01
0000772de21ce7a0  sub r14, r12
0000772de21ce7a3  cmc
0000772de21ce7a4  lahf
0000772de21ce7a5  seto al
0000772de21ce7a8  mov [r15+0x108], eax
0000772de21ce7af  mov [r15+0x08], r14
0000772de21ce7b3  mov eax, [r15+0x108]
0000772de21ce7ba  sahf
0000772de21ce7bb  jnz 0x0000772DE21CE7ED
0000772de21ce7bd  cmp dword ptr [r15+0x318], 0x00
0000772de21ce7c5  jz 0x0000772DE21CE820
0000772de21ce7cb  nop [rax+rax*1], ax
0000772de21ce7d4  nop [rax+rax*1], eax
0000772de21ce7dc  mov eax, 0x410050
0000772de21ce7e1  mov [r15+0x100], rax
0000772de21ce7e8  jmp 0x0000772DE1FFE110
0000772de21ce7ed  cmp dword ptr [r15+0x318], 0x00
0000772de21ce7f5  jz 0x0000772DE21CE760
0000772de21ce7fb  nop [rax+rax*1], ax
0000772de21ce804  nop [rax+rax*1], eax
0000772de21ce80c  mov eax, 0x41003C
0000772de21ce811  mov [r15+0x100], rax
0000772de21ce818  jmp 0x0000772DE1FFE110
0000772de21ce81d  int3
0000772de21ce81e  int3
0000772de21ce81f  nop
0000772de21ce820  mov rax, [r15+0x20]
0000772de21ce824  mov r14, [r15]
0000772de21ce827  mov [r13+rax*1], r14
0000772de21ce82c  mov rax, [r15+0xF0]
0000772de21ce833  mov [r15+0x100], rax
0000772de21ce83a  jmp 0x0000772DE21CE5C0
0000772de21ce83f  int3
0000772de21ce840  call 0x0000772DE200E120
0000772de21ce845  jmp 0x0000772DE21CE82C
0000772de21ce84a  int3
0000772de21ce84b  nop [rax+rax*1], eax
0000772de21ce850  mov qword ptr [r15+0x100], 0x04
0000772de21ce85b  mov esi, 0x00
0000772de21ce860  mov edx, 0x09
0000772de21ce865  mov rdi, 0x7FFF72CA2BE0
0000772de21ce86f  mov rax, 0x65219E5A8970
0000772de21ce879  call rax
0000772de21ce87b  cmp dword ptr [r15+0x318], 0x00
0000772de21ce883  jnz 0x0000772DE1FFE110
0000772de21ce889  jmp 0x0000772DE1FFE0A0
0000772de21ce88e  int3
0000772de21ce88f  int3
