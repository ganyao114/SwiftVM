
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/shift/swiftvm/0/0.bin:     file format binary


Disassembly of section .data:

000073c5dab00000 <.data>:
    73c5dab00000:	sub    rsp,0x10
    73c5dab00004:	mov    r13d,0x1b00
    73c5dab0000a:	mov    r14d,0xb7
    73c5dab00010:	and    r14d,0xffff
    73c5dab00017:	mov    rax,r13
    73c5dab0001a:	movabs rcx,0xffffffff0000ffff
    73c5dab00024:	and    rax,rcx
    73c5dab00027:	mov    rdx,r14
    73c5dab0002a:	shl    rdx,0x10
    73c5dab0002e:	mov    ecx,0xffff0000
    73c5dab00033:	and    rdx,rcx
    73c5dab00036:	or     rax,rdx
    73c5dab00039:	mov    r15,rax
    73c5dab0003c:	mov    QWORD PTR [r12+0x8],r15
    73c5dab00041:	mov    r13d,0x420060
    73c5dab00047:	mov    QWORD PTR [r12+0x20],r13
    73c5dab0004c:	mov    r13d,0x0
    73c5dab00052:	mov    QWORD PTR [r12],r13
    73c5dab00056:	jmp    0x73c5dab0005b
    73c5dab0005b:	mov    r13,QWORD PTR [r12]
    73c5dab0005f:	ror    r13,0xd
    73c5dab00063:	mov    r14,r13
    73c5dab00066:	shr    r14,0x7
    73c5dab0006a:	mov    rcx,r14
    73c5dab0006d:	xor    r13,rcx
    73c5dab00070:	add    r13,0x3
    73c5dab00074:	mov    QWORD PTR [r12],r13
    73c5dab00078:	mov    r13,QWORD PTR [r12+0x8]
    73c5dab0007d:	sub    r13,0x1
    73c5dab00081:	mov    QWORD PTR [r12+0x8],r13
    73c5dab00086:	mov    rcx,QWORD PTR [r12+0x380]
    73c5dab0008e:	jrcxz  0x73c5dab00095
    73c5dab00090:	jmp    0x73c5dab00106
    73c5dab00095:	jne    0x73c5dab0005b
    73c5dab0009b:	pushf
    73c5dab0009c:	pop    r11
    73c5dab0009e:	mov    QWORD PTR [rsp],r11
    73c5dab000a2:	jmp    0x73c5dab000a7
    73c5dab000a7:	mov    r13,QWORD PTR [r12+0x20]
    73c5dab000ac:	mov    r14,QWORD PTR [r12]
    73c5dab000b0:	mov    QWORD PTR [r13+0x0],r14
    73c5dab000b4:	mov    r13d,0x0
    73c5dab000ba:	mov    DWORD PTR [r12+0x32c],r13d
    73c5dab000c2:	mov    rcx,QWORD PTR [r12+0x380]
    73c5dab000ca:	jrcxz  0x73c5dab000d1
    73c5dab000cc:	jmp    0x73c5dab00195
    73c5dab000d1:	mov    r13,QWORD PTR [r12+0xf0]
    73c5dab000d9:	mov    QWORD PTR [r12+0x100],r13
    73c5dab000e1:	mov    r11,QWORD PTR [rsp]
    73c5dab000e5:	mov    QWORD PTR [r12+0x398],r11
    73c5dab000ed:	mov    rdi,QWORD PTR [r12+0x100]
    73c5dab000f5:	add    rsp,0x10
    73c5dab000f9:	movabs r11,0x5f6e4e0e80a0
    73c5dab00103:	jmp    r11
    73c5dab00106:	mov    eax,0x41004c
    73c5dab0010b:	mov    QWORD PTR [r12+0x100],rax
    73c5dab00113:	push   rdx
    73c5dab00114:	push   rsi
    73c5dab00115:	push   r10
    73c5dab00117:	push   r11
    73c5dab00119:	pushf
    73c5dab0011a:	pop    r11
    73c5dab0011c:	mov    QWORD PTR [rsp+0x20],r11
    73c5dab00121:	mov    rdx,QWORD PTR [rsp+0x20]
    73c5dab00126:	mov    r10d,edx
    73c5dab00129:	and    r10d,0xc0
    73c5dab00130:	shl    r10d,0x18
    73c5dab00134:	mov    r11d,edx
    73c5dab00137:	and    r11d,0x1
    73c5dab0013b:	shl    r11d,0x1d
    73c5dab0013f:	or     r10d,r11d
    73c5dab00142:	mov    r11d,edx
    73c5dab00145:	and    r11d,0x800
    73c5dab0014c:	shl    r11d,0x11
    73c5dab00150:	or     r10d,r11d
    73c5dab00153:	btc    r10,0x1d
    73c5dab00158:	mov    r11d,0xf0000000
    73c5dab0015e:	and    r11,r10
    73c5dab00161:	movabs rsi,0xffffffff0fffffff
    73c5dab0016b:	and    rbx,rsi
    73c5dab0016e:	or     rbx,r11
    73c5dab00171:	pop    r11
    73c5dab00173:	pop    r10
    73c5dab00175:	pop    rsi
    73c5dab00176:	pop    rdx
    73c5dab00177:	mov    QWORD PTR [r12+0x108],rbx
    73c5dab0017f:	add    rsp,0x10
    73c5dab00183:	mov    eax,0xc
    73c5dab00188:	movabs r11,0x5f6e4e0e8390
    73c5dab00192:	jmp    r11
    73c5dab00195:	mov    eax,0x410054
    73c5dab0019a:	mov    QWORD PTR [r12+0x100],rax
    73c5dab001a2:	push   rdx
    73c5dab001a3:	push   rsi
    73c5dab001a4:	push   r10
    73c5dab001a6:	push   r11
    73c5dab001a8:	mov    rdx,QWORD PTR [rsp+0x20]
    73c5dab001ad:	mov    r10d,edx
    73c5dab001b0:	and    r10d,0xc0
    73c5dab001b7:	shl    r10d,0x18
    73c5dab001bb:	mov    r11d,edx
    73c5dab001be:	and    r11d,0x1
    73c5dab001c2:	shl    r11d,0x1d
    73c5dab001c6:	or     r10d,r11d
    73c5dab001c9:	mov    r11d,edx
    73c5dab001cc:	and    r11d,0x800
    73c5dab001d3:	shl    r11d,0x11
    73c5dab001d7:	or     r10d,r11d
    73c5dab001da:	btc    r10,0x1d
    73c5dab001df:	mov    r11d,0xf0000000
    73c5dab001e5:	and    r11,r10
    73c5dab001e8:	movabs rsi,0xffffffff0fffffff
    73c5dab001f2:	and    rbx,rsi
    73c5dab001f5:	or     rbx,r11
    73c5dab001f8:	pop    r11
    73c5dab001fa:	pop    r10
    73c5dab001fc:	pop    rsi
    73c5dab001fd:	pop    rdx
    73c5dab001fe:	mov    QWORD PTR [r12+0x108],rbx
    73c5dab00206:	add    rsp,0x10
    73c5dab0020a:	mov    eax,0xc
    73c5dab0020f:	movabs r11,0x5f6e4e0e8390
    73c5dab00219:	jmp    r11
    73c5dab0021c:	nop    DWORD PTR [rax+0x0]
    73c5dab00220:	sub    rsp,0x10
    73c5dab00224:	jmp    0x73c5dab0005b
    73c5dab00229:	nop    DWORD PTR [rax+0x0]
    73c5dab00230:	sub    rsp,0x10
    73c5dab00234:	mov    r11,QWORD PTR [r12+0x398]
    73c5dab0023c:	mov    QWORD PTR [rsp],r11
    73c5dab00240:	jmp    0x73c5dab000a7
    73c5dab00245:	nop
    73c5dab00246:	nop
    73c5dab00247:	nop
