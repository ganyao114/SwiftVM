
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/shift/swiftvm/2/0.bin:     file format binary


Disassembly of section .data:

0000714dbe700000 <.data>:
    714dbe700000:	sub    rsp,0x10
    714dbe700004:	mov    r13d,0x1b00
    714dbe70000a:	mov    r14d,0xb7
    714dbe700010:	and    r14d,0xffff
    714dbe700017:	mov    rax,r13
    714dbe70001a:	movabs rcx,0xffffffff0000ffff
    714dbe700024:	and    rax,rcx
    714dbe700027:	mov    rdx,r14
    714dbe70002a:	shl    rdx,0x10
    714dbe70002e:	mov    ecx,0xffff0000
    714dbe700033:	and    rdx,rcx
    714dbe700036:	or     rax,rdx
    714dbe700039:	mov    r15,rax
    714dbe70003c:	mov    QWORD PTR [r12+0x8],r15
    714dbe700041:	mov    r13d,0x420060
    714dbe700047:	mov    QWORD PTR [r12+0x20],r13
    714dbe70004c:	mov    r13d,0x0
    714dbe700052:	mov    QWORD PTR [r12],r13
    714dbe700056:	jmp    0x714dbe70005b
    714dbe70005b:	mov    r13,QWORD PTR [r12]
    714dbe70005f:	ror    r13,0xd
    714dbe700063:	mov    r14,r13
    714dbe700066:	shr    r14,0x7
    714dbe70006a:	mov    rcx,r14
    714dbe70006d:	xor    r13,rcx
    714dbe700070:	add    r13,0x3
    714dbe700074:	mov    QWORD PTR [r12],r13
    714dbe700078:	mov    r13,QWORD PTR [r12+0x8]
    714dbe70007d:	sub    r13,0x1
    714dbe700081:	mov    QWORD PTR [r12+0x8],r13
    714dbe700086:	mov    rcx,QWORD PTR [r12+0x380]
    714dbe70008e:	jrcxz  0x714dbe700095
    714dbe700090:	jmp    0x714dbe700106
    714dbe700095:	jne    0x714dbe70005b
    714dbe70009b:	pushf
    714dbe70009c:	pop    r11
    714dbe70009e:	mov    QWORD PTR [rsp],r11
    714dbe7000a2:	jmp    0x714dbe7000a7
    714dbe7000a7:	mov    r13,QWORD PTR [r12+0x20]
    714dbe7000ac:	mov    r14,QWORD PTR [r12]
    714dbe7000b0:	mov    QWORD PTR [r13+0x0],r14
    714dbe7000b4:	mov    r13d,0x0
    714dbe7000ba:	mov    DWORD PTR [r12+0x32c],r13d
    714dbe7000c2:	mov    rcx,QWORD PTR [r12+0x380]
    714dbe7000ca:	jrcxz  0x714dbe7000d1
    714dbe7000cc:	jmp    0x714dbe700195
    714dbe7000d1:	mov    r13,QWORD PTR [r12+0xf0]
    714dbe7000d9:	mov    QWORD PTR [r12+0x100],r13
    714dbe7000e1:	mov    r11,QWORD PTR [rsp]
    714dbe7000e5:	mov    QWORD PTR [r12+0x398],r11
    714dbe7000ed:	mov    rdi,QWORD PTR [r12+0x100]
    714dbe7000f5:	add    rsp,0x10
    714dbe7000f9:	movabs r11,0x64ff15a4d0a0
    714dbe700103:	jmp    r11
    714dbe700106:	mov    eax,0x41004c
    714dbe70010b:	mov    QWORD PTR [r12+0x100],rax
    714dbe700113:	push   rdx
    714dbe700114:	push   rsi
    714dbe700115:	push   r10
    714dbe700117:	push   r11
    714dbe700119:	pushf
    714dbe70011a:	pop    r11
    714dbe70011c:	mov    QWORD PTR [rsp+0x20],r11
    714dbe700121:	mov    rdx,QWORD PTR [rsp+0x20]
    714dbe700126:	mov    r10d,edx
    714dbe700129:	and    r10d,0xc0
    714dbe700130:	shl    r10d,0x18
    714dbe700134:	mov    r11d,edx
    714dbe700137:	and    r11d,0x1
    714dbe70013b:	shl    r11d,0x1d
    714dbe70013f:	or     r10d,r11d
    714dbe700142:	mov    r11d,edx
    714dbe700145:	and    r11d,0x800
    714dbe70014c:	shl    r11d,0x11
    714dbe700150:	or     r10d,r11d
    714dbe700153:	btc    r10,0x1d
    714dbe700158:	mov    r11d,0xf0000000
    714dbe70015e:	and    r11,r10
    714dbe700161:	movabs rsi,0xffffffff0fffffff
    714dbe70016b:	and    rbx,rsi
    714dbe70016e:	or     rbx,r11
    714dbe700171:	pop    r11
    714dbe700173:	pop    r10
    714dbe700175:	pop    rsi
    714dbe700176:	pop    rdx
    714dbe700177:	mov    QWORD PTR [r12+0x108],rbx
    714dbe70017f:	add    rsp,0x10
    714dbe700183:	mov    eax,0xc
    714dbe700188:	movabs r11,0x64ff15a4d390
    714dbe700192:	jmp    r11
    714dbe700195:	mov    eax,0x410054
    714dbe70019a:	mov    QWORD PTR [r12+0x100],rax
    714dbe7001a2:	push   rdx
    714dbe7001a3:	push   rsi
    714dbe7001a4:	push   r10
    714dbe7001a6:	push   r11
    714dbe7001a8:	mov    rdx,QWORD PTR [rsp+0x20]
    714dbe7001ad:	mov    r10d,edx
    714dbe7001b0:	and    r10d,0xc0
    714dbe7001b7:	shl    r10d,0x18
    714dbe7001bb:	mov    r11d,edx
    714dbe7001be:	and    r11d,0x1
    714dbe7001c2:	shl    r11d,0x1d
    714dbe7001c6:	or     r10d,r11d
    714dbe7001c9:	mov    r11d,edx
    714dbe7001cc:	and    r11d,0x800
    714dbe7001d3:	shl    r11d,0x11
    714dbe7001d7:	or     r10d,r11d
    714dbe7001da:	btc    r10,0x1d
    714dbe7001df:	mov    r11d,0xf0000000
    714dbe7001e5:	and    r11,r10
    714dbe7001e8:	movabs rsi,0xffffffff0fffffff
    714dbe7001f2:	and    rbx,rsi
    714dbe7001f5:	or     rbx,r11
    714dbe7001f8:	pop    r11
    714dbe7001fa:	pop    r10
    714dbe7001fc:	pop    rsi
    714dbe7001fd:	pop    rdx
    714dbe7001fe:	mov    QWORD PTR [r12+0x108],rbx
    714dbe700206:	add    rsp,0x10
    714dbe70020a:	mov    eax,0xc
    714dbe70020f:	movabs r11,0x64ff15a4d390
    714dbe700219:	jmp    r11
    714dbe70021c:	nop    DWORD PTR [rax+0x0]
    714dbe700220:	sub    rsp,0x10
    714dbe700224:	jmp    0x714dbe70005b
    714dbe700229:	nop    DWORD PTR [rax+0x0]
    714dbe700230:	sub    rsp,0x10
    714dbe700234:	mov    r11,QWORD PTR [r12+0x398]
    714dbe70023c:	mov    QWORD PTR [rsp],r11
    714dbe700240:	jmp    0x714dbe7000a7
    714dbe700245:	nop
    714dbe700246:	nop
    714dbe700247:	nop
