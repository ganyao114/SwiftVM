
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/shift/swiftvm/1/0.bin:     file format binary


Disassembly of section .data:

000070f3b8700000 <.data>:
    70f3b8700000:	sub    rsp,0x10
    70f3b8700004:	mov    r13d,0x1b00
    70f3b870000a:	mov    r14d,0xb7
    70f3b8700010:	and    r14d,0xffff
    70f3b8700017:	mov    rax,r13
    70f3b870001a:	movabs rcx,0xffffffff0000ffff
    70f3b8700024:	and    rax,rcx
    70f3b8700027:	mov    rdx,r14
    70f3b870002a:	shl    rdx,0x10
    70f3b870002e:	mov    ecx,0xffff0000
    70f3b8700033:	and    rdx,rcx
    70f3b8700036:	or     rax,rdx
    70f3b8700039:	mov    r15,rax
    70f3b870003c:	mov    QWORD PTR [r12+0x8],r15
    70f3b8700041:	mov    r13d,0x420060
    70f3b8700047:	mov    QWORD PTR [r12+0x20],r13
    70f3b870004c:	mov    r13d,0x0
    70f3b8700052:	mov    QWORD PTR [r12],r13
    70f3b8700056:	jmp    0x70f3b870005b
    70f3b870005b:	mov    r13,QWORD PTR [r12]
    70f3b870005f:	ror    r13,0xd
    70f3b8700063:	mov    r14,r13
    70f3b8700066:	shr    r14,0x7
    70f3b870006a:	mov    rcx,r14
    70f3b870006d:	xor    r13,rcx
    70f3b8700070:	add    r13,0x3
    70f3b8700074:	mov    QWORD PTR [r12],r13
    70f3b8700078:	mov    r13,QWORD PTR [r12+0x8]
    70f3b870007d:	sub    r13,0x1
    70f3b8700081:	mov    QWORD PTR [r12+0x8],r13
    70f3b8700086:	mov    rcx,QWORD PTR [r12+0x380]
    70f3b870008e:	jrcxz  0x70f3b8700095
    70f3b8700090:	jmp    0x70f3b8700106
    70f3b8700095:	jne    0x70f3b870005b
    70f3b870009b:	pushf
    70f3b870009c:	pop    r11
    70f3b870009e:	mov    QWORD PTR [rsp],r11
    70f3b87000a2:	jmp    0x70f3b87000a7
    70f3b87000a7:	mov    r13,QWORD PTR [r12+0x20]
    70f3b87000ac:	mov    r14,QWORD PTR [r12]
    70f3b87000b0:	mov    QWORD PTR [r13+0x0],r14
    70f3b87000b4:	mov    r13d,0x0
    70f3b87000ba:	mov    DWORD PTR [r12+0x32c],r13d
    70f3b87000c2:	mov    rcx,QWORD PTR [r12+0x380]
    70f3b87000ca:	jrcxz  0x70f3b87000d1
    70f3b87000cc:	jmp    0x70f3b8700195
    70f3b87000d1:	mov    r13,QWORD PTR [r12+0xf0]
    70f3b87000d9:	mov    QWORD PTR [r12+0x100],r13
    70f3b87000e1:	mov    r11,QWORD PTR [rsp]
    70f3b87000e5:	mov    QWORD PTR [r12+0x398],r11
    70f3b87000ed:	mov    rdi,QWORD PTR [r12+0x100]
    70f3b87000f5:	add    rsp,0x10
    70f3b87000f9:	movabs r11,0x5e42e2c740a0
    70f3b8700103:	jmp    r11
    70f3b8700106:	mov    eax,0x41004c
    70f3b870010b:	mov    QWORD PTR [r12+0x100],rax
    70f3b8700113:	push   rdx
    70f3b8700114:	push   rsi
    70f3b8700115:	push   r10
    70f3b8700117:	push   r11
    70f3b8700119:	pushf
    70f3b870011a:	pop    r11
    70f3b870011c:	mov    QWORD PTR [rsp+0x20],r11
    70f3b8700121:	mov    rdx,QWORD PTR [rsp+0x20]
    70f3b8700126:	mov    r10d,edx
    70f3b8700129:	and    r10d,0xc0
    70f3b8700130:	shl    r10d,0x18
    70f3b8700134:	mov    r11d,edx
    70f3b8700137:	and    r11d,0x1
    70f3b870013b:	shl    r11d,0x1d
    70f3b870013f:	or     r10d,r11d
    70f3b8700142:	mov    r11d,edx
    70f3b8700145:	and    r11d,0x800
    70f3b870014c:	shl    r11d,0x11
    70f3b8700150:	or     r10d,r11d
    70f3b8700153:	btc    r10,0x1d
    70f3b8700158:	mov    r11d,0xf0000000
    70f3b870015e:	and    r11,r10
    70f3b8700161:	movabs rsi,0xffffffff0fffffff
    70f3b870016b:	and    rbx,rsi
    70f3b870016e:	or     rbx,r11
    70f3b8700171:	pop    r11
    70f3b8700173:	pop    r10
    70f3b8700175:	pop    rsi
    70f3b8700176:	pop    rdx
    70f3b8700177:	mov    QWORD PTR [r12+0x108],rbx
    70f3b870017f:	add    rsp,0x10
    70f3b8700183:	mov    eax,0xc
    70f3b8700188:	movabs r11,0x5e42e2c74390
    70f3b8700192:	jmp    r11
    70f3b8700195:	mov    eax,0x410054
    70f3b870019a:	mov    QWORD PTR [r12+0x100],rax
    70f3b87001a2:	push   rdx
    70f3b87001a3:	push   rsi
    70f3b87001a4:	push   r10
    70f3b87001a6:	push   r11
    70f3b87001a8:	mov    rdx,QWORD PTR [rsp+0x20]
    70f3b87001ad:	mov    r10d,edx
    70f3b87001b0:	and    r10d,0xc0
    70f3b87001b7:	shl    r10d,0x18
    70f3b87001bb:	mov    r11d,edx
    70f3b87001be:	and    r11d,0x1
    70f3b87001c2:	shl    r11d,0x1d
    70f3b87001c6:	or     r10d,r11d
    70f3b87001c9:	mov    r11d,edx
    70f3b87001cc:	and    r11d,0x800
    70f3b87001d3:	shl    r11d,0x11
    70f3b87001d7:	or     r10d,r11d
    70f3b87001da:	btc    r10,0x1d
    70f3b87001df:	mov    r11d,0xf0000000
    70f3b87001e5:	and    r11,r10
    70f3b87001e8:	movabs rsi,0xffffffff0fffffff
    70f3b87001f2:	and    rbx,rsi
    70f3b87001f5:	or     rbx,r11
    70f3b87001f8:	pop    r11
    70f3b87001fa:	pop    r10
    70f3b87001fc:	pop    rsi
    70f3b87001fd:	pop    rdx
    70f3b87001fe:	mov    QWORD PTR [r12+0x108],rbx
    70f3b8700206:	add    rsp,0x10
    70f3b870020a:	mov    eax,0xc
    70f3b870020f:	movabs r11,0x5e42e2c74390
    70f3b8700219:	jmp    r11
    70f3b870021c:	nop    DWORD PTR [rax+0x0]
    70f3b8700220:	sub    rsp,0x10
    70f3b8700224:	jmp    0x70f3b870005b
    70f3b8700229:	nop    DWORD PTR [rax+0x0]
    70f3b8700230:	sub    rsp,0x10
    70f3b8700234:	mov    r11,QWORD PTR [r12+0x398]
    70f3b870023c:	mov    QWORD PTR [rsp],r11
    70f3b8700240:	jmp    0x70f3b87000a7
    70f3b8700245:	nop
    70f3b8700246:	nop
    70f3b8700247:	nop
