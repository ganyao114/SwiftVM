
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/memory/swiftvm/1/0.bin:     file format binary


Disassembly of section .data:

000079a75cf00000 <.data>:
    79a75cf00000:	sub    rsp,0x10
    79a75cf00004:	mov    r11,QWORD PTR [r12+0x398]
    79a75cf0000c:	mov    QWORD PTR [rsp],r11
    79a75cf00010:	mov    r13d,0x1b00
    79a75cf00016:	mov    r14d,0xb7
    79a75cf0001c:	and    r14d,0xffff
    79a75cf00023:	mov    rax,r13
    79a75cf00026:	movabs rcx,0xffffffff0000ffff
    79a75cf00030:	and    rax,rcx
    79a75cf00033:	mov    rdx,r14
    79a75cf00036:	shl    rdx,0x10
    79a75cf0003a:	mov    ecx,0xffff0000
    79a75cf0003f:	and    rdx,rcx
    79a75cf00042:	or     rax,rdx
    79a75cf00045:	mov    r15,rax
    79a75cf00048:	mov    QWORD PTR [r12+0x8],r15
    79a75cf0004d:	mov    r13d,0x420060
    79a75cf00053:	mov    QWORD PTR [r12+0x20],r13
    79a75cf00058:	mov    r13d,0x0
    79a75cf0005e:	mov    QWORD PTR [r12],r13
    79a75cf00062:	jmp    0x79a75cf00067
    79a75cf00067:	mov    r13,QWORD PTR [r12+0x20]
    79a75cf0006c:	mov    r14,QWORD PTR [r12]
    79a75cf00070:	mov    QWORD PTR [r13+0x0],r14
    79a75cf00074:	mov    r14d,0x0
    79a75cf0007a:	mov    DWORD PTR [r12+0x32c],r14d
    79a75cf00082:	mov    r14,QWORD PTR [r13+0x0]
    79a75cf00086:	mov    QWORD PTR [r12+0x18],r14
    79a75cf0008b:	add    r14,0x3
    79a75cf0008f:	mov    QWORD PTR [r12],r14
    79a75cf00093:	mov    r13,QWORD PTR [r12+0x8]
    79a75cf00098:	sub    r13,0x1
    79a75cf0009c:	mov    QWORD PTR [r12+0x8],r13
    79a75cf000a1:	mov    rcx,QWORD PTR [r12+0x380]
    79a75cf000a9:	jrcxz  0x79a75cf000b0
    79a75cf000ab:	jmp    0x79a75cf00121
    79a75cf000b0:	pushf
    79a75cf000b1:	pop    r11
    79a75cf000b3:	mov    QWORD PTR [rsp],r11
    79a75cf000b7:	jne    0x79a75cf00067
    79a75cf000bd:	jmp    0x79a75cf000c2
    79a75cf000c2:	mov    r13,QWORD PTR [r12+0x20]
    79a75cf000c7:	mov    r14,QWORD PTR [r12]
    79a75cf000cb:	mov    QWORD PTR [r13+0x0],r14
    79a75cf000cf:	mov    r13d,0x0
    79a75cf000d5:	mov    DWORD PTR [r12+0x32c],r13d
    79a75cf000dd:	mov    rcx,QWORD PTR [r12+0x380]
    79a75cf000e5:	jrcxz  0x79a75cf000ec
    79a75cf000e7:	jmp    0x79a75cf001b0
    79a75cf000ec:	mov    r13,QWORD PTR [r12+0xf0]
    79a75cf000f4:	mov    QWORD PTR [r12+0x100],r13
    79a75cf000fc:	mov    r11,QWORD PTR [rsp]
    79a75cf00100:	mov    QWORD PTR [r12+0x398],r11
    79a75cf00108:	mov    rdi,QWORD PTR [r12+0x100]
    79a75cf00110:	add    rsp,0x10
    79a75cf00114:	movabs r11,0x5ffd2232e0a0
    79a75cf0011e:	jmp    r11
    79a75cf00121:	mov    eax,0x41004c
    79a75cf00126:	mov    QWORD PTR [r12+0x100],rax
    79a75cf0012e:	push   rdx
    79a75cf0012f:	push   rsi
    79a75cf00130:	push   r10
    79a75cf00132:	push   r11
    79a75cf00134:	pushf
    79a75cf00135:	pop    r11
    79a75cf00137:	mov    QWORD PTR [rsp+0x20],r11
    79a75cf0013c:	mov    rdx,QWORD PTR [rsp+0x20]
    79a75cf00141:	mov    r10d,edx
    79a75cf00144:	and    r10d,0xc0
    79a75cf0014b:	shl    r10d,0x18
    79a75cf0014f:	mov    r11d,edx
    79a75cf00152:	and    r11d,0x1
    79a75cf00156:	shl    r11d,0x1d
    79a75cf0015a:	or     r10d,r11d
    79a75cf0015d:	mov    r11d,edx
    79a75cf00160:	and    r11d,0x800
    79a75cf00167:	shl    r11d,0x11
    79a75cf0016b:	or     r10d,r11d
    79a75cf0016e:	btc    r10,0x1d
    79a75cf00173:	mov    r11d,0xf0000000
    79a75cf00179:	and    r11,r10
    79a75cf0017c:	movabs rsi,0xffffffff0fffffff
    79a75cf00186:	and    rbx,rsi
    79a75cf00189:	or     rbx,r11
    79a75cf0018c:	pop    r11
    79a75cf0018e:	pop    r10
    79a75cf00190:	pop    rsi
    79a75cf00191:	pop    rdx
    79a75cf00192:	mov    QWORD PTR [r12+0x108],rbx
    79a75cf0019a:	add    rsp,0x10
    79a75cf0019e:	mov    eax,0xc
    79a75cf001a3:	movabs r11,0x5ffd2232e390
    79a75cf001ad:	jmp    r11
    79a75cf001b0:	mov    eax,0x410054
    79a75cf001b5:	mov    QWORD PTR [r12+0x100],rax
    79a75cf001bd:	push   rdx
    79a75cf001be:	push   rsi
    79a75cf001bf:	push   r10
    79a75cf001c1:	push   r11
    79a75cf001c3:	mov    rdx,QWORD PTR [rsp+0x20]
    79a75cf001c8:	mov    r10d,edx
    79a75cf001cb:	and    r10d,0xc0
    79a75cf001d2:	shl    r10d,0x18
    79a75cf001d6:	mov    r11d,edx
    79a75cf001d9:	and    r11d,0x1
    79a75cf001dd:	shl    r11d,0x1d
    79a75cf001e1:	or     r10d,r11d
    79a75cf001e4:	mov    r11d,edx
    79a75cf001e7:	and    r11d,0x800
    79a75cf001ee:	shl    r11d,0x11
    79a75cf001f2:	or     r10d,r11d
    79a75cf001f5:	btc    r10,0x1d
    79a75cf001fa:	mov    r11d,0xf0000000
    79a75cf00200:	and    r11,r10
    79a75cf00203:	movabs rsi,0xffffffff0fffffff
    79a75cf0020d:	and    rbx,rsi
    79a75cf00210:	or     rbx,r11
    79a75cf00213:	pop    r11
    79a75cf00215:	pop    r10
    79a75cf00217:	pop    rsi
    79a75cf00218:	pop    rdx
    79a75cf00219:	mov    QWORD PTR [r12+0x108],rbx
    79a75cf00221:	add    rsp,0x10
    79a75cf00225:	mov    eax,0xc
    79a75cf0022a:	movabs r11,0x5ffd2232e390
    79a75cf00234:	jmp    r11
    79a75cf00237:	nop    WORD PTR [rax+rax*1+0x0]
    79a75cf00240:	sub    rsp,0x10
    79a75cf00244:	mov    r11,QWORD PTR [r12+0x398]
    79a75cf0024c:	mov    QWORD PTR [rsp],r11
    79a75cf00250:	jmp    0x79a75cf00067
    79a75cf00255:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    79a75cf00260:	sub    rsp,0x10
    79a75cf00264:	mov    r11,QWORD PTR [r12+0x398]
    79a75cf0026c:	mov    QWORD PTR [rsp],r11
    79a75cf00270:	jmp    0x79a75cf000c2
    79a75cf00275:	nop
    79a75cf00276:	nop
    79a75cf00277:	nop
