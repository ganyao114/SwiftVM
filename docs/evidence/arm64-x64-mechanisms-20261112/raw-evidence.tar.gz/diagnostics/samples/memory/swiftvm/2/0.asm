
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/memory/swiftvm/2/0.bin:     file format binary


Disassembly of section .data:

0000715e95d00000 <.data>:
    715e95d00000:	sub    rsp,0x10
    715e95d00004:	mov    r11,QWORD PTR [r12+0x398]
    715e95d0000c:	mov    QWORD PTR [rsp],r11
    715e95d00010:	mov    r13d,0x1b00
    715e95d00016:	mov    r14d,0xb7
    715e95d0001c:	and    r14d,0xffff
    715e95d00023:	mov    rax,r13
    715e95d00026:	movabs rcx,0xffffffff0000ffff
    715e95d00030:	and    rax,rcx
    715e95d00033:	mov    rdx,r14
    715e95d00036:	shl    rdx,0x10
    715e95d0003a:	mov    ecx,0xffff0000
    715e95d0003f:	and    rdx,rcx
    715e95d00042:	or     rax,rdx
    715e95d00045:	mov    r15,rax
    715e95d00048:	mov    QWORD PTR [r12+0x8],r15
    715e95d0004d:	mov    r13d,0x420060
    715e95d00053:	mov    QWORD PTR [r12+0x20],r13
    715e95d00058:	mov    r13d,0x0
    715e95d0005e:	mov    QWORD PTR [r12],r13
    715e95d00062:	jmp    0x715e95d00067
    715e95d00067:	mov    r13,QWORD PTR [r12+0x20]
    715e95d0006c:	mov    r14,QWORD PTR [r12]
    715e95d00070:	mov    QWORD PTR [r13+0x0],r14
    715e95d00074:	mov    r14d,0x0
    715e95d0007a:	mov    DWORD PTR [r12+0x32c],r14d
    715e95d00082:	mov    r14,QWORD PTR [r13+0x0]
    715e95d00086:	mov    QWORD PTR [r12+0x18],r14
    715e95d0008b:	add    r14,0x3
    715e95d0008f:	mov    QWORD PTR [r12],r14
    715e95d00093:	mov    r13,QWORD PTR [r12+0x8]
    715e95d00098:	sub    r13,0x1
    715e95d0009c:	mov    QWORD PTR [r12+0x8],r13
    715e95d000a1:	mov    rcx,QWORD PTR [r12+0x380]
    715e95d000a9:	jrcxz  0x715e95d000b0
    715e95d000ab:	jmp    0x715e95d00121
    715e95d000b0:	pushf
    715e95d000b1:	pop    r11
    715e95d000b3:	mov    QWORD PTR [rsp],r11
    715e95d000b7:	jne    0x715e95d00067
    715e95d000bd:	jmp    0x715e95d000c2
    715e95d000c2:	mov    r13,QWORD PTR [r12+0x20]
    715e95d000c7:	mov    r14,QWORD PTR [r12]
    715e95d000cb:	mov    QWORD PTR [r13+0x0],r14
    715e95d000cf:	mov    r13d,0x0
    715e95d000d5:	mov    DWORD PTR [r12+0x32c],r13d
    715e95d000dd:	mov    rcx,QWORD PTR [r12+0x380]
    715e95d000e5:	jrcxz  0x715e95d000ec
    715e95d000e7:	jmp    0x715e95d001b0
    715e95d000ec:	mov    r13,QWORD PTR [r12+0xf0]
    715e95d000f4:	mov    QWORD PTR [r12+0x100],r13
    715e95d000fc:	mov    r11,QWORD PTR [rsp]
    715e95d00100:	mov    QWORD PTR [r12+0x398],r11
    715e95d00108:	mov    rdi,QWORD PTR [r12+0x100]
    715e95d00110:	add    rsp,0x10
    715e95d00114:	movabs r11,0x557439dcc0a0
    715e95d0011e:	jmp    r11
    715e95d00121:	mov    eax,0x41004c
    715e95d00126:	mov    QWORD PTR [r12+0x100],rax
    715e95d0012e:	push   rdx
    715e95d0012f:	push   rsi
    715e95d00130:	push   r10
    715e95d00132:	push   r11
    715e95d00134:	pushf
    715e95d00135:	pop    r11
    715e95d00137:	mov    QWORD PTR [rsp+0x20],r11
    715e95d0013c:	mov    rdx,QWORD PTR [rsp+0x20]
    715e95d00141:	mov    r10d,edx
    715e95d00144:	and    r10d,0xc0
    715e95d0014b:	shl    r10d,0x18
    715e95d0014f:	mov    r11d,edx
    715e95d00152:	and    r11d,0x1
    715e95d00156:	shl    r11d,0x1d
    715e95d0015a:	or     r10d,r11d
    715e95d0015d:	mov    r11d,edx
    715e95d00160:	and    r11d,0x800
    715e95d00167:	shl    r11d,0x11
    715e95d0016b:	or     r10d,r11d
    715e95d0016e:	btc    r10,0x1d
    715e95d00173:	mov    r11d,0xf0000000
    715e95d00179:	and    r11,r10
    715e95d0017c:	movabs rsi,0xffffffff0fffffff
    715e95d00186:	and    rbx,rsi
    715e95d00189:	or     rbx,r11
    715e95d0018c:	pop    r11
    715e95d0018e:	pop    r10
    715e95d00190:	pop    rsi
    715e95d00191:	pop    rdx
    715e95d00192:	mov    QWORD PTR [r12+0x108],rbx
    715e95d0019a:	add    rsp,0x10
    715e95d0019e:	mov    eax,0xc
    715e95d001a3:	movabs r11,0x557439dcc390
    715e95d001ad:	jmp    r11
    715e95d001b0:	mov    eax,0x410054
    715e95d001b5:	mov    QWORD PTR [r12+0x100],rax
    715e95d001bd:	push   rdx
    715e95d001be:	push   rsi
    715e95d001bf:	push   r10
    715e95d001c1:	push   r11
    715e95d001c3:	mov    rdx,QWORD PTR [rsp+0x20]
    715e95d001c8:	mov    r10d,edx
    715e95d001cb:	and    r10d,0xc0
    715e95d001d2:	shl    r10d,0x18
    715e95d001d6:	mov    r11d,edx
    715e95d001d9:	and    r11d,0x1
    715e95d001dd:	shl    r11d,0x1d
    715e95d001e1:	or     r10d,r11d
    715e95d001e4:	mov    r11d,edx
    715e95d001e7:	and    r11d,0x800
    715e95d001ee:	shl    r11d,0x11
    715e95d001f2:	or     r10d,r11d
    715e95d001f5:	btc    r10,0x1d
    715e95d001fa:	mov    r11d,0xf0000000
    715e95d00200:	and    r11,r10
    715e95d00203:	movabs rsi,0xffffffff0fffffff
    715e95d0020d:	and    rbx,rsi
    715e95d00210:	or     rbx,r11
    715e95d00213:	pop    r11
    715e95d00215:	pop    r10
    715e95d00217:	pop    rsi
    715e95d00218:	pop    rdx
    715e95d00219:	mov    QWORD PTR [r12+0x108],rbx
    715e95d00221:	add    rsp,0x10
    715e95d00225:	mov    eax,0xc
    715e95d0022a:	movabs r11,0x557439dcc390
    715e95d00234:	jmp    r11
    715e95d00237:	nop    WORD PTR [rax+rax*1+0x0]
    715e95d00240:	sub    rsp,0x10
    715e95d00244:	mov    r11,QWORD PTR [r12+0x398]
    715e95d0024c:	mov    QWORD PTR [rsp],r11
    715e95d00250:	jmp    0x715e95d00067
    715e95d00255:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    715e95d00260:	sub    rsp,0x10
    715e95d00264:	mov    r11,QWORD PTR [r12+0x398]
    715e95d0026c:	mov    QWORD PTR [rsp],r11
    715e95d00270:	jmp    0x715e95d000c2
    715e95d00275:	nop
    715e95d00276:	nop
    715e95d00277:	nop
