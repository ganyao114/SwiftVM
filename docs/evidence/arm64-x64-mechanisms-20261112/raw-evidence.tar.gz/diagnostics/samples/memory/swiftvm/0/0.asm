
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/memory/swiftvm/0/0.bin:     file format binary


Disassembly of section .data:

000071c9c3b00000 <.data>:
    71c9c3b00000:	sub    rsp,0x10
    71c9c3b00004:	mov    r11,QWORD PTR [r12+0x398]
    71c9c3b0000c:	mov    QWORD PTR [rsp],r11
    71c9c3b00010:	mov    r13d,0x1b00
    71c9c3b00016:	mov    r14d,0xb7
    71c9c3b0001c:	and    r14d,0xffff
    71c9c3b00023:	mov    rax,r13
    71c9c3b00026:	movabs rcx,0xffffffff0000ffff
    71c9c3b00030:	and    rax,rcx
    71c9c3b00033:	mov    rdx,r14
    71c9c3b00036:	shl    rdx,0x10
    71c9c3b0003a:	mov    ecx,0xffff0000
    71c9c3b0003f:	and    rdx,rcx
    71c9c3b00042:	or     rax,rdx
    71c9c3b00045:	mov    r15,rax
    71c9c3b00048:	mov    QWORD PTR [r12+0x8],r15
    71c9c3b0004d:	mov    r13d,0x420060
    71c9c3b00053:	mov    QWORD PTR [r12+0x20],r13
    71c9c3b00058:	mov    r13d,0x0
    71c9c3b0005e:	mov    QWORD PTR [r12],r13
    71c9c3b00062:	jmp    0x71c9c3b00067
    71c9c3b00067:	mov    r13,QWORD PTR [r12+0x20]
    71c9c3b0006c:	mov    r14,QWORD PTR [r12]
    71c9c3b00070:	mov    QWORD PTR [r13+0x0],r14
    71c9c3b00074:	mov    r14d,0x0
    71c9c3b0007a:	mov    DWORD PTR [r12+0x32c],r14d
    71c9c3b00082:	mov    r14,QWORD PTR [r13+0x0]
    71c9c3b00086:	mov    QWORD PTR [r12+0x18],r14
    71c9c3b0008b:	add    r14,0x3
    71c9c3b0008f:	mov    QWORD PTR [r12],r14
    71c9c3b00093:	mov    r13,QWORD PTR [r12+0x8]
    71c9c3b00098:	sub    r13,0x1
    71c9c3b0009c:	mov    QWORD PTR [r12+0x8],r13
    71c9c3b000a1:	mov    rcx,QWORD PTR [r12+0x380]
    71c9c3b000a9:	jrcxz  0x71c9c3b000b0
    71c9c3b000ab:	jmp    0x71c9c3b00121
    71c9c3b000b0:	pushf
    71c9c3b000b1:	pop    r11
    71c9c3b000b3:	mov    QWORD PTR [rsp],r11
    71c9c3b000b7:	jne    0x71c9c3b00067
    71c9c3b000bd:	jmp    0x71c9c3b000c2
    71c9c3b000c2:	mov    r13,QWORD PTR [r12+0x20]
    71c9c3b000c7:	mov    r14,QWORD PTR [r12]
    71c9c3b000cb:	mov    QWORD PTR [r13+0x0],r14
    71c9c3b000cf:	mov    r13d,0x0
    71c9c3b000d5:	mov    DWORD PTR [r12+0x32c],r13d
    71c9c3b000dd:	mov    rcx,QWORD PTR [r12+0x380]
    71c9c3b000e5:	jrcxz  0x71c9c3b000ec
    71c9c3b000e7:	jmp    0x71c9c3b001b0
    71c9c3b000ec:	mov    r13,QWORD PTR [r12+0xf0]
    71c9c3b000f4:	mov    QWORD PTR [r12+0x100],r13
    71c9c3b000fc:	mov    r11,QWORD PTR [rsp]
    71c9c3b00100:	mov    QWORD PTR [r12+0x398],r11
    71c9c3b00108:	mov    rdi,QWORD PTR [r12+0x100]
    71c9c3b00110:	add    rsp,0x10
    71c9c3b00114:	movabs r11,0x5d02a5b3e0a0
    71c9c3b0011e:	jmp    r11
    71c9c3b00121:	mov    eax,0x41004c
    71c9c3b00126:	mov    QWORD PTR [r12+0x100],rax
    71c9c3b0012e:	push   rdx
    71c9c3b0012f:	push   rsi
    71c9c3b00130:	push   r10
    71c9c3b00132:	push   r11
    71c9c3b00134:	pushf
    71c9c3b00135:	pop    r11
    71c9c3b00137:	mov    QWORD PTR [rsp+0x20],r11
    71c9c3b0013c:	mov    rdx,QWORD PTR [rsp+0x20]
    71c9c3b00141:	mov    r10d,edx
    71c9c3b00144:	and    r10d,0xc0
    71c9c3b0014b:	shl    r10d,0x18
    71c9c3b0014f:	mov    r11d,edx
    71c9c3b00152:	and    r11d,0x1
    71c9c3b00156:	shl    r11d,0x1d
    71c9c3b0015a:	or     r10d,r11d
    71c9c3b0015d:	mov    r11d,edx
    71c9c3b00160:	and    r11d,0x800
    71c9c3b00167:	shl    r11d,0x11
    71c9c3b0016b:	or     r10d,r11d
    71c9c3b0016e:	btc    r10,0x1d
    71c9c3b00173:	mov    r11d,0xf0000000
    71c9c3b00179:	and    r11,r10
    71c9c3b0017c:	movabs rsi,0xffffffff0fffffff
    71c9c3b00186:	and    rbx,rsi
    71c9c3b00189:	or     rbx,r11
    71c9c3b0018c:	pop    r11
    71c9c3b0018e:	pop    r10
    71c9c3b00190:	pop    rsi
    71c9c3b00191:	pop    rdx
    71c9c3b00192:	mov    QWORD PTR [r12+0x108],rbx
    71c9c3b0019a:	add    rsp,0x10
    71c9c3b0019e:	mov    eax,0xc
    71c9c3b001a3:	movabs r11,0x5d02a5b3e390
    71c9c3b001ad:	jmp    r11
    71c9c3b001b0:	mov    eax,0x410054
    71c9c3b001b5:	mov    QWORD PTR [r12+0x100],rax
    71c9c3b001bd:	push   rdx
    71c9c3b001be:	push   rsi
    71c9c3b001bf:	push   r10
    71c9c3b001c1:	push   r11
    71c9c3b001c3:	mov    rdx,QWORD PTR [rsp+0x20]
    71c9c3b001c8:	mov    r10d,edx
    71c9c3b001cb:	and    r10d,0xc0
    71c9c3b001d2:	shl    r10d,0x18
    71c9c3b001d6:	mov    r11d,edx
    71c9c3b001d9:	and    r11d,0x1
    71c9c3b001dd:	shl    r11d,0x1d
    71c9c3b001e1:	or     r10d,r11d
    71c9c3b001e4:	mov    r11d,edx
    71c9c3b001e7:	and    r11d,0x800
    71c9c3b001ee:	shl    r11d,0x11
    71c9c3b001f2:	or     r10d,r11d
    71c9c3b001f5:	btc    r10,0x1d
    71c9c3b001fa:	mov    r11d,0xf0000000
    71c9c3b00200:	and    r11,r10
    71c9c3b00203:	movabs rsi,0xffffffff0fffffff
    71c9c3b0020d:	and    rbx,rsi
    71c9c3b00210:	or     rbx,r11
    71c9c3b00213:	pop    r11
    71c9c3b00215:	pop    r10
    71c9c3b00217:	pop    rsi
    71c9c3b00218:	pop    rdx
    71c9c3b00219:	mov    QWORD PTR [r12+0x108],rbx
    71c9c3b00221:	add    rsp,0x10
    71c9c3b00225:	mov    eax,0xc
    71c9c3b0022a:	movabs r11,0x5d02a5b3e390
    71c9c3b00234:	jmp    r11
    71c9c3b00237:	nop    WORD PTR [rax+rax*1+0x0]
    71c9c3b00240:	sub    rsp,0x10
    71c9c3b00244:	mov    r11,QWORD PTR [r12+0x398]
    71c9c3b0024c:	mov    QWORD PTR [rsp],r11
    71c9c3b00250:	jmp    0x71c9c3b00067
    71c9c3b00255:	data16 data16 nop WORD PTR [rax+rax*1+0x0]
    71c9c3b00260:	sub    rsp,0x10
    71c9c3b00264:	mov    r11,QWORD PTR [r12+0x398]
    71c9c3b0026c:	mov    QWORD PTR [rsp],r11
    71c9c3b00270:	jmp    0x71c9c3b000c2
    71c9c3b00275:	nop
    71c9c3b00276:	nop
    71c9c3b00277:	nop
