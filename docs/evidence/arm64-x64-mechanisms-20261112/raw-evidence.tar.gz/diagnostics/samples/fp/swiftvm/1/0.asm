
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/fp/swiftvm/1/0.bin:     file format binary


Disassembly of section .data:

00007ca3af900000 <.data>:
    7ca3af900000:	sub    rsp,0x150
    7ca3af900007:	mov    r11,QWORD PTR [r12+0x398]
    7ca3af90000f:	mov    QWORD PTR [rsp],r11
    7ca3af900013:	cmp    DWORD PTR [r12+0x310],0x0
    7ca3af90001c:	je     0x7ca3af9000ac
    7ca3af900022:	push   rdx
    7ca3af900023:	push   rsi
    7ca3af900024:	push   r10
    7ca3af900026:	push   r11
    7ca3af900028:	mov    rdx,QWORD PTR [rsp+0x20]
    7ca3af90002d:	mov    r10d,edx
    7ca3af900030:	and    r10d,0xc0
    7ca3af900037:	shl    r10d,0x18
    7ca3af90003b:	mov    r11d,edx
    7ca3af90003e:	and    r11d,0x1
    7ca3af900042:	shl    r11d,0x1d
    7ca3af900046:	or     r10d,r11d
    7ca3af900049:	mov    r11d,edx
    7ca3af90004c:	and    r11d,0x800
    7ca3af900053:	shl    r11d,0x11
    7ca3af900057:	or     r10d,r11d
    7ca3af90005a:	btc    r10,0x1d
    7ca3af90005f:	mov    r11d,0xf0000000
    7ca3af900065:	and    r11,r10
    7ca3af900068:	movabs rsi,0xffffffff0fffffff
    7ca3af900072:	and    rbx,rsi
    7ca3af900075:	or     rbx,r11
    7ca3af900078:	pop    r11
    7ca3af90007a:	pop    r10
    7ca3af90007c:	pop    rsi
    7ca3af90007d:	pop    rdx
    7ca3af90007e:	mov    QWORD PTR [r12+0x108],rbx
    7ca3af900086:	mov    eax,0x410028
    7ca3af90008b:	mov    QWORD PTR [r12+0x100],rax
    7ca3af900093:	add    rsp,0x150
    7ca3af90009a:	mov    eax,0x3
    7ca3af90009f:	movabs r11,0x5c90fc940390
    7ca3af9000a9:	jmp    r11
    7ca3af9000ac:	mov    r13d,0x4240
    7ca3af9000b2:	mov    r14d,0xf
    7ca3af9000b8:	and    r14d,0xffff
    7ca3af9000bf:	mov    rax,r13
    7ca3af9000c2:	movabs rcx,0xffffffff0000ffff
    7ca3af9000cc:	and    rax,rcx
    7ca3af9000cf:	mov    rdx,r14
    7ca3af9000d2:	shl    rdx,0x10
    7ca3af9000d6:	mov    ecx,0xffff0000
    7ca3af9000db:	and    rdx,rcx
    7ca3af9000de:	or     rax,rdx
    7ca3af9000e1:	mov    r15,rax
    7ca3af9000e4:	mov    QWORD PTR [r12+0x8],r15
    7ca3af9000e9:	mov    r13d,0x420060
    7ca3af9000ef:	mov    QWORD PTR [r12+0x20],r13
    7ca3af9000f4:	mov    r13d,0x0
    7ca3af9000fa:	mov    QWORD PTR [r12],r13
    7ca3af9000fe:	mov    r13d,0x0
    7ca3af900104:	movabs r14,0x3ff0000000000000
    7ca3af90010e:	mov    QWORD PTR [r12+0x110],r14
    7ca3af900116:	mov    QWORD PTR [r12+0x118],r13
    7ca3af90011e:	mov    r13d,0x0
    7ca3af900124:	movabs r14,0x3ff8000000000000
    7ca3af90012e:	mov    QWORD PTR [r12+0x120],r14
    7ca3af900136:	mov    QWORD PTR [r12+0x128],r13
    7ca3af90013e:	jmp    0x7ca3af900143
    7ca3af900143:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    7ca3af90014d:	movdqa xmm2,xmm0
    7ca3af900151:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    7ca3af90015b:	movdqa xmm3,xmm0
    7ca3af90015f:	stmxcsr DWORD PTR [rsp+0x110]
    7ca3af900167:	mov    DWORD PTR [rsp+0x114],0x1f80
    7ca3af900172:	ldmxcsr DWORD PTR [rsp+0x114]
    7ca3af90017a:	movdqa xmm0,xmm2
    7ca3af90017e:	movdqa xmm1,xmm3
    7ca3af900182:	movq   rax,xmm0
    7ca3af900187:	add    rax,rax
    7ca3af90018a:	je     0x7ca3af9001a0
    7ca3af90018c:	shr    rax,0x35
    7ca3af900190:	sub    eax,0x201
    7ca3af900195:	cmp    eax,0x3fc
    7ca3af90019a:	ja     0x7ca3af900298
    7ca3af9001a0:	movq   rax,xmm1
    7ca3af9001a5:	add    rax,rax
    7ca3af9001a8:	je     0x7ca3af9001be
    7ca3af9001aa:	shr    rax,0x35
    7ca3af9001ae:	sub    eax,0x201
    7ca3af9001b3:	cmp    eax,0x3fc
    7ca3af9001b8:	ja     0x7ca3af900298
    7ca3af9001be:	movq   xmm0,xmm0
    7ca3af9001c2:	movq   xmm1,xmm1
    7ca3af9001c6:	addsd  xmm0,xmm1
    7ca3af9001ca:	movdqa xmm4,xmm0
    7ca3af9001ce:	movdqa xmm0,xmm4
    7ca3af9001d2:	movdqu XMMWORD PTR [r12+0x110],xmm0
    7ca3af9001dc:	mov    r13,QWORD PTR [r12+0x8]
    7ca3af9001e1:	stmxcsr DWORD PTR [rsp+0x114]
    7ca3af9001e9:	ldmxcsr DWORD PTR [rsp+0x110]
    7ca3af9001f1:	mov    r11d,DWORD PTR [rsp+0x114]
    7ca3af9001f9:	shr    r11d,1
    7ca3af9001fc:	and    r11d,0x10
    7ca3af900200:	or     DWORD PTR [r12+0x314],r11d
    7ca3af900208:	sub    r13,0x1
    7ca3af90020c:	mov    QWORD PTR [r12+0x8],r13
    7ca3af900211:	mov    rcx,QWORD PTR [r12+0x380]
    7ca3af900219:	jrcxz  0x7ca3af900220
    7ca3af90021b:	jmp    0x7ca3af90039e
    7ca3af900220:	jne    0x7ca3af900143
    7ca3af900226:	pushf
    7ca3af900227:	pop    r11
    7ca3af900229:	mov    QWORD PTR [rsp],r11
    7ca3af90022d:	jmp    0x7ca3af900232
    7ca3af900232:	mov    r13,QWORD PTR [r12+0x20]
    7ca3af900237:	mov    r14,QWORD PTR [r12+0x110]
    7ca3af90023f:	mov    QWORD PTR [r13+0x0],r14
    7ca3af900243:	mov    r13d,0x0
    7ca3af900249:	mov    DWORD PTR [r12+0x32c],r13d
    7ca3af900251:	mov    rcx,QWORD PTR [r12+0x380]
    7ca3af900259:	jrcxz  0x7ca3af900260
    7ca3af90025b:	jmp    0x7ca3af900430
    7ca3af900260:	mov    r13,QWORD PTR [r12+0xf0]
    7ca3af900268:	mov    QWORD PTR [r12+0x100],r13
    7ca3af900270:	mov    r11,QWORD PTR [rsp]
    7ca3af900274:	mov    QWORD PTR [r12+0x398],r11
    7ca3af90027c:	mov    rdi,QWORD PTR [r12+0x100]
    7ca3af900284:	add    rsp,0x150
    7ca3af90028b:	movabs r11,0x5c90fc9400a0
    7ca3af900295:	jmp    r11
    7ca3af900298:	movdqa xmm0,xmm2
    7ca3af90029c:	movdqa xmm1,xmm3
    7ca3af9002a0:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    7ca3af9002a9:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    7ca3af9002b2:	call   0x7ca3af9002c0
    7ca3af9002b7:	jmp    0x7ca3af9001ca
    7ca3af9002bc:	nop    DWORD PTR [rax+0x0]
    7ca3af9002c0:	sub    rsp,0x8
    7ca3af9002c4:	stmxcsr DWORD PTR [rsp+0x124]
    7ca3af9002cc:	ldmxcsr DWORD PTR [rsp+0x120]
    7ca3af9002d4:	mov    r11d,DWORD PTR [rsp+0x124]
    7ca3af9002dc:	shr    r11d,1
    7ca3af9002df:	and    r11d,0x10
    7ca3af9002e3:	or     DWORD PTR [r12+0x314],r11d
    7ca3af9002eb:	mov    QWORD PTR [r12+0x378],0x3
    7ca3af9002f7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    7ca3af9002fd:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    7ca3af900303:	mov    QWORD PTR [r12+0x108],rbx
    7ca3af90030b:	stmxcsr DWORD PTR [r12-0x28]
    7ca3af900311:	ldmxcsr DWORD PTR [r12-0x38]
    7ca3af900317:	lea    rdi,[rsp+0x110]
    7ca3af90031f:	lea    rsi,[rsp+0xf0]
    7ca3af900327:	lea    rdx,[rsp+0x100]
    7ca3af90032f:	mov    ecx,0xc
    7ca3af900334:	mov    r8d,0x0
    7ca3af90033a:	lea    r9,[r12+0x314]
    7ca3af900342:	movabs r11,0x5c90fc7ab1b0
    7ca3af90034c:	call   r11
    7ca3af90034f:	ldmxcsr DWORD PTR [r12-0x28]
    7ca3af900355:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    7ca3af90035b:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    7ca3af900361:	mov    rbx,QWORD PTR [r12+0x108]
    7ca3af900369:	mov    QWORD PTR [r12+0x378],0x2
    7ca3af900375:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    7ca3af90037e:	stmxcsr DWORD PTR [rsp+0x120]
    7ca3af900386:	mov    DWORD PTR [rsp+0x124],0x1f80
    7ca3af900391:	ldmxcsr DWORD PTR [rsp+0x124]
    7ca3af900399:	add    rsp,0x8
    7ca3af90039d:	ret
    7ca3af90039e:	mov    eax,0x41004c
    7ca3af9003a3:	mov    QWORD PTR [r12+0x100],rax
    7ca3af9003ab:	push   rdx
    7ca3af9003ac:	push   rsi
    7ca3af9003ad:	push   r10
    7ca3af9003af:	push   r11
    7ca3af9003b1:	pushf
    7ca3af9003b2:	pop    r11
    7ca3af9003b4:	mov    QWORD PTR [rsp+0x20],r11
    7ca3af9003b9:	mov    rdx,QWORD PTR [rsp+0x20]
    7ca3af9003be:	mov    r10d,edx
    7ca3af9003c1:	and    r10d,0xc0
    7ca3af9003c8:	shl    r10d,0x18
    7ca3af9003cc:	mov    r11d,edx
    7ca3af9003cf:	and    r11d,0x1
    7ca3af9003d3:	shl    r11d,0x1d
    7ca3af9003d7:	or     r10d,r11d
    7ca3af9003da:	mov    r11d,edx
    7ca3af9003dd:	and    r11d,0x800
    7ca3af9003e4:	shl    r11d,0x11
    7ca3af9003e8:	or     r10d,r11d
    7ca3af9003eb:	btc    r10,0x1d
    7ca3af9003f0:	mov    r11d,0xf0000000
    7ca3af9003f6:	and    r11,r10
    7ca3af9003f9:	movabs rsi,0xffffffff0fffffff
    7ca3af900403:	and    rbx,rsi
    7ca3af900406:	or     rbx,r11
    7ca3af900409:	pop    r11
    7ca3af90040b:	pop    r10
    7ca3af90040d:	pop    rsi
    7ca3af90040e:	pop    rdx
    7ca3af90040f:	mov    QWORD PTR [r12+0x108],rbx
    7ca3af900417:	add    rsp,0x150
    7ca3af90041e:	mov    eax,0xc
    7ca3af900423:	movabs r11,0x5c90fc940390
    7ca3af90042d:	jmp    r11
    7ca3af900430:	mov    eax,0x410054
    7ca3af900435:	mov    QWORD PTR [r12+0x100],rax
    7ca3af90043d:	push   rdx
    7ca3af90043e:	push   rsi
    7ca3af90043f:	push   r10
    7ca3af900441:	push   r11
    7ca3af900443:	mov    rdx,QWORD PTR [rsp+0x20]
    7ca3af900448:	mov    r10d,edx
    7ca3af90044b:	and    r10d,0xc0
    7ca3af900452:	shl    r10d,0x18
    7ca3af900456:	mov    r11d,edx
    7ca3af900459:	and    r11d,0x1
    7ca3af90045d:	shl    r11d,0x1d
    7ca3af900461:	or     r10d,r11d
    7ca3af900464:	mov    r11d,edx
    7ca3af900467:	and    r11d,0x800
    7ca3af90046e:	shl    r11d,0x11
    7ca3af900472:	or     r10d,r11d
    7ca3af900475:	btc    r10,0x1d
    7ca3af90047a:	mov    r11d,0xf0000000
    7ca3af900480:	and    r11,r10
    7ca3af900483:	movabs rsi,0xffffffff0fffffff
    7ca3af90048d:	and    rbx,rsi
    7ca3af900490:	or     rbx,r11
    7ca3af900493:	pop    r11
    7ca3af900495:	pop    r10
    7ca3af900497:	pop    rsi
    7ca3af900498:	pop    rdx
    7ca3af900499:	mov    QWORD PTR [r12+0x108],rbx
    7ca3af9004a1:	add    rsp,0x150
    7ca3af9004a8:	mov    eax,0xc
    7ca3af9004ad:	movabs r11,0x5c90fc940390
    7ca3af9004b7:	jmp    r11
    7ca3af9004ba:	nop    WORD PTR [rax+rax*1+0x0]
    7ca3af9004c0:	sub    rsp,0x150
    7ca3af9004c7:	mov    r11,QWORD PTR [r12+0x398]
    7ca3af9004cf:	mov    QWORD PTR [rsp],r11
    7ca3af9004d3:	cmp    DWORD PTR [r12+0x310],0x0
    7ca3af9004dc:	je     0x7ca3af90056c
    7ca3af9004e2:	push   rdx
    7ca3af9004e3:	push   rsi
    7ca3af9004e4:	push   r10
    7ca3af9004e6:	push   r11
    7ca3af9004e8:	mov    rdx,QWORD PTR [rsp+0x20]
    7ca3af9004ed:	mov    r10d,edx
    7ca3af9004f0:	and    r10d,0xc0
    7ca3af9004f7:	shl    r10d,0x18
    7ca3af9004fb:	mov    r11d,edx
    7ca3af9004fe:	and    r11d,0x1
    7ca3af900502:	shl    r11d,0x1d
    7ca3af900506:	or     r10d,r11d
    7ca3af900509:	mov    r11d,edx
    7ca3af90050c:	and    r11d,0x800
    7ca3af900513:	shl    r11d,0x11
    7ca3af900517:	or     r10d,r11d
    7ca3af90051a:	btc    r10,0x1d
    7ca3af90051f:	mov    r11d,0xf0000000
    7ca3af900525:	and    r11,r10
    7ca3af900528:	movabs rsi,0xffffffff0fffffff
    7ca3af900532:	and    rbx,rsi
    7ca3af900535:	or     rbx,r11
    7ca3af900538:	pop    r11
    7ca3af90053a:	pop    r10
    7ca3af90053c:	pop    rsi
    7ca3af90053d:	pop    rdx
    7ca3af90053e:	mov    QWORD PTR [r12+0x108],rbx
    7ca3af900546:	mov    eax,0x410044
    7ca3af90054b:	mov    QWORD PTR [r12+0x100],rax
    7ca3af900553:	add    rsp,0x150
    7ca3af90055a:	mov    eax,0x3
    7ca3af90055f:	movabs r11,0x5c90fc940390
    7ca3af900569:	jmp    r11
    7ca3af90056c:	jmp    0x7ca3af900143
    7ca3af900571:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    7ca3af900580:	sub    rsp,0x150
    7ca3af900587:	mov    r11,QWORD PTR [r12+0x398]
    7ca3af90058f:	mov    QWORD PTR [rsp],r11
    7ca3af900593:	cmp    DWORD PTR [r12+0x310],0x0
    7ca3af90059c:	je     0x7ca3af90062c
    7ca3af9005a2:	push   rdx
    7ca3af9005a3:	push   rsi
    7ca3af9005a4:	push   r10
    7ca3af9005a6:	push   r11
    7ca3af9005a8:	mov    rdx,QWORD PTR [rsp+0x20]
    7ca3af9005ad:	mov    r10d,edx
    7ca3af9005b0:	and    r10d,0xc0
    7ca3af9005b7:	shl    r10d,0x18
    7ca3af9005bb:	mov    r11d,edx
    7ca3af9005be:	and    r11d,0x1
    7ca3af9005c2:	shl    r11d,0x1d
    7ca3af9005c6:	or     r10d,r11d
    7ca3af9005c9:	mov    r11d,edx
    7ca3af9005cc:	and    r11d,0x800
    7ca3af9005d3:	shl    r11d,0x11
    7ca3af9005d7:	or     r10d,r11d
    7ca3af9005da:	btc    r10,0x1d
    7ca3af9005df:	mov    r11d,0xf0000000
    7ca3af9005e5:	and    r11,r10
    7ca3af9005e8:	movabs rsi,0xffffffff0fffffff
    7ca3af9005f2:	and    rbx,rsi
    7ca3af9005f5:	or     rbx,r11
    7ca3af9005f8:	pop    r11
    7ca3af9005fa:	pop    r10
    7ca3af9005fc:	pop    rsi
    7ca3af9005fd:	pop    rdx
    7ca3af9005fe:	mov    QWORD PTR [r12+0x108],rbx
    7ca3af900606:	mov    eax,0x410050
    7ca3af90060b:	mov    QWORD PTR [r12+0x100],rax
    7ca3af900613:	add    rsp,0x150
    7ca3af90061a:	mov    eax,0x3
    7ca3af90061f:	movabs r11,0x5c90fc940390
    7ca3af900629:	jmp    r11
    7ca3af90062c:	jmp    0x7ca3af900232
    7ca3af900631:	nop
    7ca3af900632:	nop
    7ca3af900633:	nop
