
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/fp/swiftvm/2/0.bin:     file format binary


Disassembly of section .data:

0000727d4db00000 <.data>:
    727d4db00000:	sub    rsp,0x150
    727d4db00007:	mov    r11,QWORD PTR [r12+0x398]
    727d4db0000f:	mov    QWORD PTR [rsp],r11
    727d4db00013:	cmp    DWORD PTR [r12+0x310],0x0
    727d4db0001c:	je     0x727d4db000ac
    727d4db00022:	push   rdx
    727d4db00023:	push   rsi
    727d4db00024:	push   r10
    727d4db00026:	push   r11
    727d4db00028:	mov    rdx,QWORD PTR [rsp+0x20]
    727d4db0002d:	mov    r10d,edx
    727d4db00030:	and    r10d,0xc0
    727d4db00037:	shl    r10d,0x18
    727d4db0003b:	mov    r11d,edx
    727d4db0003e:	and    r11d,0x1
    727d4db00042:	shl    r11d,0x1d
    727d4db00046:	or     r10d,r11d
    727d4db00049:	mov    r11d,edx
    727d4db0004c:	and    r11d,0x800
    727d4db00053:	shl    r11d,0x11
    727d4db00057:	or     r10d,r11d
    727d4db0005a:	btc    r10,0x1d
    727d4db0005f:	mov    r11d,0xf0000000
    727d4db00065:	and    r11,r10
    727d4db00068:	movabs rsi,0xffffffff0fffffff
    727d4db00072:	and    rbx,rsi
    727d4db00075:	or     rbx,r11
    727d4db00078:	pop    r11
    727d4db0007a:	pop    r10
    727d4db0007c:	pop    rsi
    727d4db0007d:	pop    rdx
    727d4db0007e:	mov    QWORD PTR [r12+0x108],rbx
    727d4db00086:	mov    eax,0x410028
    727d4db0008b:	mov    QWORD PTR [r12+0x100],rax
    727d4db00093:	add    rsp,0x150
    727d4db0009a:	mov    eax,0x3
    727d4db0009f:	movabs r11,0x5977cba64390
    727d4db000a9:	jmp    r11
    727d4db000ac:	mov    r13d,0x4240
    727d4db000b2:	mov    r14d,0xf
    727d4db000b8:	and    r14d,0xffff
    727d4db000bf:	mov    rax,r13
    727d4db000c2:	movabs rcx,0xffffffff0000ffff
    727d4db000cc:	and    rax,rcx
    727d4db000cf:	mov    rdx,r14
    727d4db000d2:	shl    rdx,0x10
    727d4db000d6:	mov    ecx,0xffff0000
    727d4db000db:	and    rdx,rcx
    727d4db000de:	or     rax,rdx
    727d4db000e1:	mov    r15,rax
    727d4db000e4:	mov    QWORD PTR [r12+0x8],r15
    727d4db000e9:	mov    r13d,0x420060
    727d4db000ef:	mov    QWORD PTR [r12+0x20],r13
    727d4db000f4:	mov    r13d,0x0
    727d4db000fa:	mov    QWORD PTR [r12],r13
    727d4db000fe:	mov    r13d,0x0
    727d4db00104:	movabs r14,0x3ff0000000000000
    727d4db0010e:	mov    QWORD PTR [r12+0x110],r14
    727d4db00116:	mov    QWORD PTR [r12+0x118],r13
    727d4db0011e:	mov    r13d,0x0
    727d4db00124:	movabs r14,0x3ff8000000000000
    727d4db0012e:	mov    QWORD PTR [r12+0x120],r14
    727d4db00136:	mov    QWORD PTR [r12+0x128],r13
    727d4db0013e:	jmp    0x727d4db00143
    727d4db00143:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    727d4db0014d:	movdqa xmm2,xmm0
    727d4db00151:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    727d4db0015b:	movdqa xmm3,xmm0
    727d4db0015f:	stmxcsr DWORD PTR [rsp+0x110]
    727d4db00167:	mov    DWORD PTR [rsp+0x114],0x1f80
    727d4db00172:	ldmxcsr DWORD PTR [rsp+0x114]
    727d4db0017a:	movdqa xmm0,xmm2
    727d4db0017e:	movdqa xmm1,xmm3
    727d4db00182:	movq   rax,xmm0
    727d4db00187:	add    rax,rax
    727d4db0018a:	je     0x727d4db001a0
    727d4db0018c:	shr    rax,0x35
    727d4db00190:	sub    eax,0x201
    727d4db00195:	cmp    eax,0x3fc
    727d4db0019a:	ja     0x727d4db00298
    727d4db001a0:	movq   rax,xmm1
    727d4db001a5:	add    rax,rax
    727d4db001a8:	je     0x727d4db001be
    727d4db001aa:	shr    rax,0x35
    727d4db001ae:	sub    eax,0x201
    727d4db001b3:	cmp    eax,0x3fc
    727d4db001b8:	ja     0x727d4db00298
    727d4db001be:	movq   xmm0,xmm0
    727d4db001c2:	movq   xmm1,xmm1
    727d4db001c6:	addsd  xmm0,xmm1
    727d4db001ca:	movdqa xmm4,xmm0
    727d4db001ce:	movdqa xmm0,xmm4
    727d4db001d2:	movdqu XMMWORD PTR [r12+0x110],xmm0
    727d4db001dc:	mov    r13,QWORD PTR [r12+0x8]
    727d4db001e1:	stmxcsr DWORD PTR [rsp+0x114]
    727d4db001e9:	ldmxcsr DWORD PTR [rsp+0x110]
    727d4db001f1:	mov    r11d,DWORD PTR [rsp+0x114]
    727d4db001f9:	shr    r11d,1
    727d4db001fc:	and    r11d,0x10
    727d4db00200:	or     DWORD PTR [r12+0x314],r11d
    727d4db00208:	sub    r13,0x1
    727d4db0020c:	mov    QWORD PTR [r12+0x8],r13
    727d4db00211:	mov    rcx,QWORD PTR [r12+0x380]
    727d4db00219:	jrcxz  0x727d4db00220
    727d4db0021b:	jmp    0x727d4db0039e
    727d4db00220:	jne    0x727d4db00143
    727d4db00226:	pushf
    727d4db00227:	pop    r11
    727d4db00229:	mov    QWORD PTR [rsp],r11
    727d4db0022d:	jmp    0x727d4db00232
    727d4db00232:	mov    r13,QWORD PTR [r12+0x20]
    727d4db00237:	mov    r14,QWORD PTR [r12+0x110]
    727d4db0023f:	mov    QWORD PTR [r13+0x0],r14
    727d4db00243:	mov    r13d,0x0
    727d4db00249:	mov    DWORD PTR [r12+0x32c],r13d
    727d4db00251:	mov    rcx,QWORD PTR [r12+0x380]
    727d4db00259:	jrcxz  0x727d4db00260
    727d4db0025b:	jmp    0x727d4db00430
    727d4db00260:	mov    r13,QWORD PTR [r12+0xf0]
    727d4db00268:	mov    QWORD PTR [r12+0x100],r13
    727d4db00270:	mov    r11,QWORD PTR [rsp]
    727d4db00274:	mov    QWORD PTR [r12+0x398],r11
    727d4db0027c:	mov    rdi,QWORD PTR [r12+0x100]
    727d4db00284:	add    rsp,0x150
    727d4db0028b:	movabs r11,0x5977cba640a0
    727d4db00295:	jmp    r11
    727d4db00298:	movdqa xmm0,xmm2
    727d4db0029c:	movdqa xmm1,xmm3
    727d4db002a0:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    727d4db002a9:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    727d4db002b2:	call   0x727d4db002c0
    727d4db002b7:	jmp    0x727d4db001ca
    727d4db002bc:	nop    DWORD PTR [rax+0x0]
    727d4db002c0:	sub    rsp,0x8
    727d4db002c4:	stmxcsr DWORD PTR [rsp+0x124]
    727d4db002cc:	ldmxcsr DWORD PTR [rsp+0x120]
    727d4db002d4:	mov    r11d,DWORD PTR [rsp+0x124]
    727d4db002dc:	shr    r11d,1
    727d4db002df:	and    r11d,0x10
    727d4db002e3:	or     DWORD PTR [r12+0x314],r11d
    727d4db002eb:	mov    QWORD PTR [r12+0x378],0x3
    727d4db002f7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    727d4db002fd:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    727d4db00303:	mov    QWORD PTR [r12+0x108],rbx
    727d4db0030b:	stmxcsr DWORD PTR [r12-0x28]
    727d4db00311:	ldmxcsr DWORD PTR [r12-0x38]
    727d4db00317:	lea    rdi,[rsp+0x110]
    727d4db0031f:	lea    rsi,[rsp+0xf0]
    727d4db00327:	lea    rdx,[rsp+0x100]
    727d4db0032f:	mov    ecx,0xc
    727d4db00334:	mov    r8d,0x0
    727d4db0033a:	lea    r9,[r12+0x314]
    727d4db00342:	movabs r11,0x5977cb8cf1b0
    727d4db0034c:	call   r11
    727d4db0034f:	ldmxcsr DWORD PTR [r12-0x28]
    727d4db00355:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    727d4db0035b:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    727d4db00361:	mov    rbx,QWORD PTR [r12+0x108]
    727d4db00369:	mov    QWORD PTR [r12+0x378],0x2
    727d4db00375:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    727d4db0037e:	stmxcsr DWORD PTR [rsp+0x120]
    727d4db00386:	mov    DWORD PTR [rsp+0x124],0x1f80
    727d4db00391:	ldmxcsr DWORD PTR [rsp+0x124]
    727d4db00399:	add    rsp,0x8
    727d4db0039d:	ret
    727d4db0039e:	mov    eax,0x41004c
    727d4db003a3:	mov    QWORD PTR [r12+0x100],rax
    727d4db003ab:	push   rdx
    727d4db003ac:	push   rsi
    727d4db003ad:	push   r10
    727d4db003af:	push   r11
    727d4db003b1:	pushf
    727d4db003b2:	pop    r11
    727d4db003b4:	mov    QWORD PTR [rsp+0x20],r11
    727d4db003b9:	mov    rdx,QWORD PTR [rsp+0x20]
    727d4db003be:	mov    r10d,edx
    727d4db003c1:	and    r10d,0xc0
    727d4db003c8:	shl    r10d,0x18
    727d4db003cc:	mov    r11d,edx
    727d4db003cf:	and    r11d,0x1
    727d4db003d3:	shl    r11d,0x1d
    727d4db003d7:	or     r10d,r11d
    727d4db003da:	mov    r11d,edx
    727d4db003dd:	and    r11d,0x800
    727d4db003e4:	shl    r11d,0x11
    727d4db003e8:	or     r10d,r11d
    727d4db003eb:	btc    r10,0x1d
    727d4db003f0:	mov    r11d,0xf0000000
    727d4db003f6:	and    r11,r10
    727d4db003f9:	movabs rsi,0xffffffff0fffffff
    727d4db00403:	and    rbx,rsi
    727d4db00406:	or     rbx,r11
    727d4db00409:	pop    r11
    727d4db0040b:	pop    r10
    727d4db0040d:	pop    rsi
    727d4db0040e:	pop    rdx
    727d4db0040f:	mov    QWORD PTR [r12+0x108],rbx
    727d4db00417:	add    rsp,0x150
    727d4db0041e:	mov    eax,0xc
    727d4db00423:	movabs r11,0x5977cba64390
    727d4db0042d:	jmp    r11
    727d4db00430:	mov    eax,0x410054
    727d4db00435:	mov    QWORD PTR [r12+0x100],rax
    727d4db0043d:	push   rdx
    727d4db0043e:	push   rsi
    727d4db0043f:	push   r10
    727d4db00441:	push   r11
    727d4db00443:	mov    rdx,QWORD PTR [rsp+0x20]
    727d4db00448:	mov    r10d,edx
    727d4db0044b:	and    r10d,0xc0
    727d4db00452:	shl    r10d,0x18
    727d4db00456:	mov    r11d,edx
    727d4db00459:	and    r11d,0x1
    727d4db0045d:	shl    r11d,0x1d
    727d4db00461:	or     r10d,r11d
    727d4db00464:	mov    r11d,edx
    727d4db00467:	and    r11d,0x800
    727d4db0046e:	shl    r11d,0x11
    727d4db00472:	or     r10d,r11d
    727d4db00475:	btc    r10,0x1d
    727d4db0047a:	mov    r11d,0xf0000000
    727d4db00480:	and    r11,r10
    727d4db00483:	movabs rsi,0xffffffff0fffffff
    727d4db0048d:	and    rbx,rsi
    727d4db00490:	or     rbx,r11
    727d4db00493:	pop    r11
    727d4db00495:	pop    r10
    727d4db00497:	pop    rsi
    727d4db00498:	pop    rdx
    727d4db00499:	mov    QWORD PTR [r12+0x108],rbx
    727d4db004a1:	add    rsp,0x150
    727d4db004a8:	mov    eax,0xc
    727d4db004ad:	movabs r11,0x5977cba64390
    727d4db004b7:	jmp    r11
    727d4db004ba:	nop    WORD PTR [rax+rax*1+0x0]
    727d4db004c0:	sub    rsp,0x150
    727d4db004c7:	mov    r11,QWORD PTR [r12+0x398]
    727d4db004cf:	mov    QWORD PTR [rsp],r11
    727d4db004d3:	cmp    DWORD PTR [r12+0x310],0x0
    727d4db004dc:	je     0x727d4db0056c
    727d4db004e2:	push   rdx
    727d4db004e3:	push   rsi
    727d4db004e4:	push   r10
    727d4db004e6:	push   r11
    727d4db004e8:	mov    rdx,QWORD PTR [rsp+0x20]
    727d4db004ed:	mov    r10d,edx
    727d4db004f0:	and    r10d,0xc0
    727d4db004f7:	shl    r10d,0x18
    727d4db004fb:	mov    r11d,edx
    727d4db004fe:	and    r11d,0x1
    727d4db00502:	shl    r11d,0x1d
    727d4db00506:	or     r10d,r11d
    727d4db00509:	mov    r11d,edx
    727d4db0050c:	and    r11d,0x800
    727d4db00513:	shl    r11d,0x11
    727d4db00517:	or     r10d,r11d
    727d4db0051a:	btc    r10,0x1d
    727d4db0051f:	mov    r11d,0xf0000000
    727d4db00525:	and    r11,r10
    727d4db00528:	movabs rsi,0xffffffff0fffffff
    727d4db00532:	and    rbx,rsi
    727d4db00535:	or     rbx,r11
    727d4db00538:	pop    r11
    727d4db0053a:	pop    r10
    727d4db0053c:	pop    rsi
    727d4db0053d:	pop    rdx
    727d4db0053e:	mov    QWORD PTR [r12+0x108],rbx
    727d4db00546:	mov    eax,0x410044
    727d4db0054b:	mov    QWORD PTR [r12+0x100],rax
    727d4db00553:	add    rsp,0x150
    727d4db0055a:	mov    eax,0x3
    727d4db0055f:	movabs r11,0x5977cba64390
    727d4db00569:	jmp    r11
    727d4db0056c:	jmp    0x727d4db00143
    727d4db00571:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    727d4db00580:	sub    rsp,0x150
    727d4db00587:	mov    r11,QWORD PTR [r12+0x398]
    727d4db0058f:	mov    QWORD PTR [rsp],r11
    727d4db00593:	cmp    DWORD PTR [r12+0x310],0x0
    727d4db0059c:	je     0x727d4db0062c
    727d4db005a2:	push   rdx
    727d4db005a3:	push   rsi
    727d4db005a4:	push   r10
    727d4db005a6:	push   r11
    727d4db005a8:	mov    rdx,QWORD PTR [rsp+0x20]
    727d4db005ad:	mov    r10d,edx
    727d4db005b0:	and    r10d,0xc0
    727d4db005b7:	shl    r10d,0x18
    727d4db005bb:	mov    r11d,edx
    727d4db005be:	and    r11d,0x1
    727d4db005c2:	shl    r11d,0x1d
    727d4db005c6:	or     r10d,r11d
    727d4db005c9:	mov    r11d,edx
    727d4db005cc:	and    r11d,0x800
    727d4db005d3:	shl    r11d,0x11
    727d4db005d7:	or     r10d,r11d
    727d4db005da:	btc    r10,0x1d
    727d4db005df:	mov    r11d,0xf0000000
    727d4db005e5:	and    r11,r10
    727d4db005e8:	movabs rsi,0xffffffff0fffffff
    727d4db005f2:	and    rbx,rsi
    727d4db005f5:	or     rbx,r11
    727d4db005f8:	pop    r11
    727d4db005fa:	pop    r10
    727d4db005fc:	pop    rsi
    727d4db005fd:	pop    rdx
    727d4db005fe:	mov    QWORD PTR [r12+0x108],rbx
    727d4db00606:	mov    eax,0x410050
    727d4db0060b:	mov    QWORD PTR [r12+0x100],rax
    727d4db00613:	add    rsp,0x150
    727d4db0061a:	mov    eax,0x3
    727d4db0061f:	movabs r11,0x5977cba64390
    727d4db00629:	jmp    r11
    727d4db0062c:	jmp    0x727d4db00232
    727d4db00631:	nop
    727d4db00632:	nop
    727d4db00633:	nop
