
/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112/final-samples/fp/swiftvm/0/0.bin:     file format binary


Disassembly of section .data:

0000733acad00000 <.data>:
    733acad00000:	sub    rsp,0x150
    733acad00007:	mov    r11,QWORD PTR [r12+0x398]
    733acad0000f:	mov    QWORD PTR [rsp],r11
    733acad00013:	cmp    DWORD PTR [r12+0x310],0x0
    733acad0001c:	je     0x733acad000ac
    733acad00022:	push   rdx
    733acad00023:	push   rsi
    733acad00024:	push   r10
    733acad00026:	push   r11
    733acad00028:	mov    rdx,QWORD PTR [rsp+0x20]
    733acad0002d:	mov    r10d,edx
    733acad00030:	and    r10d,0xc0
    733acad00037:	shl    r10d,0x18
    733acad0003b:	mov    r11d,edx
    733acad0003e:	and    r11d,0x1
    733acad00042:	shl    r11d,0x1d
    733acad00046:	or     r10d,r11d
    733acad00049:	mov    r11d,edx
    733acad0004c:	and    r11d,0x800
    733acad00053:	shl    r11d,0x11
    733acad00057:	or     r10d,r11d
    733acad0005a:	btc    r10,0x1d
    733acad0005f:	mov    r11d,0xf0000000
    733acad00065:	and    r11,r10
    733acad00068:	movabs rsi,0xffffffff0fffffff
    733acad00072:	and    rbx,rsi
    733acad00075:	or     rbx,r11
    733acad00078:	pop    r11
    733acad0007a:	pop    r10
    733acad0007c:	pop    rsi
    733acad0007d:	pop    rdx
    733acad0007e:	mov    QWORD PTR [r12+0x108],rbx
    733acad00086:	mov    eax,0x410028
    733acad0008b:	mov    QWORD PTR [r12+0x100],rax
    733acad00093:	add    rsp,0x150
    733acad0009a:	mov    eax,0x3
    733acad0009f:	movabs r11,0x5e4a9f6ce390
    733acad000a9:	jmp    r11
    733acad000ac:	mov    r13d,0x4240
    733acad000b2:	mov    r14d,0xf
    733acad000b8:	and    r14d,0xffff
    733acad000bf:	mov    rax,r13
    733acad000c2:	movabs rcx,0xffffffff0000ffff
    733acad000cc:	and    rax,rcx
    733acad000cf:	mov    rdx,r14
    733acad000d2:	shl    rdx,0x10
    733acad000d6:	mov    ecx,0xffff0000
    733acad000db:	and    rdx,rcx
    733acad000de:	or     rax,rdx
    733acad000e1:	mov    r15,rax
    733acad000e4:	mov    QWORD PTR [r12+0x8],r15
    733acad000e9:	mov    r13d,0x420060
    733acad000ef:	mov    QWORD PTR [r12+0x20],r13
    733acad000f4:	mov    r13d,0x0
    733acad000fa:	mov    QWORD PTR [r12],r13
    733acad000fe:	mov    r13d,0x0
    733acad00104:	movabs r14,0x3ff0000000000000
    733acad0010e:	mov    QWORD PTR [r12+0x110],r14
    733acad00116:	mov    QWORD PTR [r12+0x118],r13
    733acad0011e:	mov    r13d,0x0
    733acad00124:	movabs r14,0x3ff8000000000000
    733acad0012e:	mov    QWORD PTR [r12+0x120],r14
    733acad00136:	mov    QWORD PTR [r12+0x128],r13
    733acad0013e:	jmp    0x733acad00143
    733acad00143:	movdqu xmm0,XMMWORD PTR [r12+0x110]
    733acad0014d:	movdqa xmm2,xmm0
    733acad00151:	movdqu xmm0,XMMWORD PTR [r12+0x120]
    733acad0015b:	movdqa xmm3,xmm0
    733acad0015f:	stmxcsr DWORD PTR [rsp+0x110]
    733acad00167:	mov    DWORD PTR [rsp+0x114],0x1f80
    733acad00172:	ldmxcsr DWORD PTR [rsp+0x114]
    733acad0017a:	movdqa xmm0,xmm2
    733acad0017e:	movdqa xmm1,xmm3
    733acad00182:	movq   rax,xmm0
    733acad00187:	add    rax,rax
    733acad0018a:	je     0x733acad001a0
    733acad0018c:	shr    rax,0x35
    733acad00190:	sub    eax,0x201
    733acad00195:	cmp    eax,0x3fc
    733acad0019a:	ja     0x733acad00298
    733acad001a0:	movq   rax,xmm1
    733acad001a5:	add    rax,rax
    733acad001a8:	je     0x733acad001be
    733acad001aa:	shr    rax,0x35
    733acad001ae:	sub    eax,0x201
    733acad001b3:	cmp    eax,0x3fc
    733acad001b8:	ja     0x733acad00298
    733acad001be:	movq   xmm0,xmm0
    733acad001c2:	movq   xmm1,xmm1
    733acad001c6:	addsd  xmm0,xmm1
    733acad001ca:	movdqa xmm4,xmm0
    733acad001ce:	movdqa xmm0,xmm4
    733acad001d2:	movdqu XMMWORD PTR [r12+0x110],xmm0
    733acad001dc:	mov    r13,QWORD PTR [r12+0x8]
    733acad001e1:	stmxcsr DWORD PTR [rsp+0x114]
    733acad001e9:	ldmxcsr DWORD PTR [rsp+0x110]
    733acad001f1:	mov    r11d,DWORD PTR [rsp+0x114]
    733acad001f9:	shr    r11d,1
    733acad001fc:	and    r11d,0x10
    733acad00200:	or     DWORD PTR [r12+0x314],r11d
    733acad00208:	sub    r13,0x1
    733acad0020c:	mov    QWORD PTR [r12+0x8],r13
    733acad00211:	mov    rcx,QWORD PTR [r12+0x380]
    733acad00219:	jrcxz  0x733acad00220
    733acad0021b:	jmp    0x733acad0039e
    733acad00220:	jne    0x733acad00143
    733acad00226:	pushf
    733acad00227:	pop    r11
    733acad00229:	mov    QWORD PTR [rsp],r11
    733acad0022d:	jmp    0x733acad00232
    733acad00232:	mov    r13,QWORD PTR [r12+0x20]
    733acad00237:	mov    r14,QWORD PTR [r12+0x110]
    733acad0023f:	mov    QWORD PTR [r13+0x0],r14
    733acad00243:	mov    r13d,0x0
    733acad00249:	mov    DWORD PTR [r12+0x32c],r13d
    733acad00251:	mov    rcx,QWORD PTR [r12+0x380]
    733acad00259:	jrcxz  0x733acad00260
    733acad0025b:	jmp    0x733acad00430
    733acad00260:	mov    r13,QWORD PTR [r12+0xf0]
    733acad00268:	mov    QWORD PTR [r12+0x100],r13
    733acad00270:	mov    r11,QWORD PTR [rsp]
    733acad00274:	mov    QWORD PTR [r12+0x398],r11
    733acad0027c:	mov    rdi,QWORD PTR [r12+0x100]
    733acad00284:	add    rsp,0x150
    733acad0028b:	movabs r11,0x5e4a9f6ce0a0
    733acad00295:	jmp    r11
    733acad00298:	movdqa xmm0,xmm2
    733acad0029c:	movdqa xmm1,xmm3
    733acad002a0:	movdqu XMMWORD PTR [rsp+0xe0],xmm0
    733acad002a9:	movdqu XMMWORD PTR [rsp+0xf0],xmm1
    733acad002b2:	call   0x733acad002c0
    733acad002b7:	jmp    0x733acad001ca
    733acad002bc:	nop    DWORD PTR [rax+0x0]
    733acad002c0:	sub    rsp,0x8
    733acad002c4:	stmxcsr DWORD PTR [rsp+0x124]
    733acad002cc:	ldmxcsr DWORD PTR [rsp+0x120]
    733acad002d4:	mov    r11d,DWORD PTR [rsp+0x124]
    733acad002dc:	shr    r11d,1
    733acad002df:	and    r11d,0x10
    733acad002e3:	or     DWORD PTR [r12+0x314],r11d
    733acad002eb:	mov    QWORD PTR [r12+0x378],0x3
    733acad002f7:	movdqu XMMWORD PTR [rsp+0x20],xmm2
    733acad002fd:	movdqu XMMWORD PTR [rsp+0x30],xmm3
    733acad00303:	mov    QWORD PTR [r12+0x108],rbx
    733acad0030b:	stmxcsr DWORD PTR [r12-0x28]
    733acad00311:	ldmxcsr DWORD PTR [r12-0x38]
    733acad00317:	lea    rdi,[rsp+0x110]
    733acad0031f:	lea    rsi,[rsp+0xf0]
    733acad00327:	lea    rdx,[rsp+0x100]
    733acad0032f:	mov    ecx,0xc
    733acad00334:	mov    r8d,0x0
    733acad0033a:	lea    r9,[r12+0x314]
    733acad00342:	movabs r11,0x5e4a9f5391b0
    733acad0034c:	call   r11
    733acad0034f:	ldmxcsr DWORD PTR [r12-0x28]
    733acad00355:	movdqu xmm2,XMMWORD PTR [rsp+0x20]
    733acad0035b:	movdqu xmm3,XMMWORD PTR [rsp+0x30]
    733acad00361:	mov    rbx,QWORD PTR [r12+0x108]
    733acad00369:	mov    QWORD PTR [r12+0x378],0x2
    733acad00375:	movdqu xmm0,XMMWORD PTR [rsp+0x110]
    733acad0037e:	stmxcsr DWORD PTR [rsp+0x120]
    733acad00386:	mov    DWORD PTR [rsp+0x124],0x1f80
    733acad00391:	ldmxcsr DWORD PTR [rsp+0x124]
    733acad00399:	add    rsp,0x8
    733acad0039d:	ret
    733acad0039e:	mov    eax,0x41004c
    733acad003a3:	mov    QWORD PTR [r12+0x100],rax
    733acad003ab:	push   rdx
    733acad003ac:	push   rsi
    733acad003ad:	push   r10
    733acad003af:	push   r11
    733acad003b1:	pushf
    733acad003b2:	pop    r11
    733acad003b4:	mov    QWORD PTR [rsp+0x20],r11
    733acad003b9:	mov    rdx,QWORD PTR [rsp+0x20]
    733acad003be:	mov    r10d,edx
    733acad003c1:	and    r10d,0xc0
    733acad003c8:	shl    r10d,0x18
    733acad003cc:	mov    r11d,edx
    733acad003cf:	and    r11d,0x1
    733acad003d3:	shl    r11d,0x1d
    733acad003d7:	or     r10d,r11d
    733acad003da:	mov    r11d,edx
    733acad003dd:	and    r11d,0x800
    733acad003e4:	shl    r11d,0x11
    733acad003e8:	or     r10d,r11d
    733acad003eb:	btc    r10,0x1d
    733acad003f0:	mov    r11d,0xf0000000
    733acad003f6:	and    r11,r10
    733acad003f9:	movabs rsi,0xffffffff0fffffff
    733acad00403:	and    rbx,rsi
    733acad00406:	or     rbx,r11
    733acad00409:	pop    r11
    733acad0040b:	pop    r10
    733acad0040d:	pop    rsi
    733acad0040e:	pop    rdx
    733acad0040f:	mov    QWORD PTR [r12+0x108],rbx
    733acad00417:	add    rsp,0x150
    733acad0041e:	mov    eax,0xc
    733acad00423:	movabs r11,0x5e4a9f6ce390
    733acad0042d:	jmp    r11
    733acad00430:	mov    eax,0x410054
    733acad00435:	mov    QWORD PTR [r12+0x100],rax
    733acad0043d:	push   rdx
    733acad0043e:	push   rsi
    733acad0043f:	push   r10
    733acad00441:	push   r11
    733acad00443:	mov    rdx,QWORD PTR [rsp+0x20]
    733acad00448:	mov    r10d,edx
    733acad0044b:	and    r10d,0xc0
    733acad00452:	shl    r10d,0x18
    733acad00456:	mov    r11d,edx
    733acad00459:	and    r11d,0x1
    733acad0045d:	shl    r11d,0x1d
    733acad00461:	or     r10d,r11d
    733acad00464:	mov    r11d,edx
    733acad00467:	and    r11d,0x800
    733acad0046e:	shl    r11d,0x11
    733acad00472:	or     r10d,r11d
    733acad00475:	btc    r10,0x1d
    733acad0047a:	mov    r11d,0xf0000000
    733acad00480:	and    r11,r10
    733acad00483:	movabs rsi,0xffffffff0fffffff
    733acad0048d:	and    rbx,rsi
    733acad00490:	or     rbx,r11
    733acad00493:	pop    r11
    733acad00495:	pop    r10
    733acad00497:	pop    rsi
    733acad00498:	pop    rdx
    733acad00499:	mov    QWORD PTR [r12+0x108],rbx
    733acad004a1:	add    rsp,0x150
    733acad004a8:	mov    eax,0xc
    733acad004ad:	movabs r11,0x5e4a9f6ce390
    733acad004b7:	jmp    r11
    733acad004ba:	nop    WORD PTR [rax+rax*1+0x0]
    733acad004c0:	sub    rsp,0x150
    733acad004c7:	mov    r11,QWORD PTR [r12+0x398]
    733acad004cf:	mov    QWORD PTR [rsp],r11
    733acad004d3:	cmp    DWORD PTR [r12+0x310],0x0
    733acad004dc:	je     0x733acad0056c
    733acad004e2:	push   rdx
    733acad004e3:	push   rsi
    733acad004e4:	push   r10
    733acad004e6:	push   r11
    733acad004e8:	mov    rdx,QWORD PTR [rsp+0x20]
    733acad004ed:	mov    r10d,edx
    733acad004f0:	and    r10d,0xc0
    733acad004f7:	shl    r10d,0x18
    733acad004fb:	mov    r11d,edx
    733acad004fe:	and    r11d,0x1
    733acad00502:	shl    r11d,0x1d
    733acad00506:	or     r10d,r11d
    733acad00509:	mov    r11d,edx
    733acad0050c:	and    r11d,0x800
    733acad00513:	shl    r11d,0x11
    733acad00517:	or     r10d,r11d
    733acad0051a:	btc    r10,0x1d
    733acad0051f:	mov    r11d,0xf0000000
    733acad00525:	and    r11,r10
    733acad00528:	movabs rsi,0xffffffff0fffffff
    733acad00532:	and    rbx,rsi
    733acad00535:	or     rbx,r11
    733acad00538:	pop    r11
    733acad0053a:	pop    r10
    733acad0053c:	pop    rsi
    733acad0053d:	pop    rdx
    733acad0053e:	mov    QWORD PTR [r12+0x108],rbx
    733acad00546:	mov    eax,0x410044
    733acad0054b:	mov    QWORD PTR [r12+0x100],rax
    733acad00553:	add    rsp,0x150
    733acad0055a:	mov    eax,0x3
    733acad0055f:	movabs r11,0x5e4a9f6ce390
    733acad00569:	jmp    r11
    733acad0056c:	jmp    0x733acad00143
    733acad00571:	data16 data16 data16 data16 data16 data16 nop WORD PTR [rax+rax*1+0x0]
    733acad00580:	sub    rsp,0x150
    733acad00587:	mov    r11,QWORD PTR [r12+0x398]
    733acad0058f:	mov    QWORD PTR [rsp],r11
    733acad00593:	cmp    DWORD PTR [r12+0x310],0x0
    733acad0059c:	je     0x733acad0062c
    733acad005a2:	push   rdx
    733acad005a3:	push   rsi
    733acad005a4:	push   r10
    733acad005a6:	push   r11
    733acad005a8:	mov    rdx,QWORD PTR [rsp+0x20]
    733acad005ad:	mov    r10d,edx
    733acad005b0:	and    r10d,0xc0
    733acad005b7:	shl    r10d,0x18
    733acad005bb:	mov    r11d,edx
    733acad005be:	and    r11d,0x1
    733acad005c2:	shl    r11d,0x1d
    733acad005c6:	or     r10d,r11d
    733acad005c9:	mov    r11d,edx
    733acad005cc:	and    r11d,0x800
    733acad005d3:	shl    r11d,0x11
    733acad005d7:	or     r10d,r11d
    733acad005da:	btc    r10,0x1d
    733acad005df:	mov    r11d,0xf0000000
    733acad005e5:	and    r11,r10
    733acad005e8:	movabs rsi,0xffffffff0fffffff
    733acad005f2:	and    rbx,rsi
    733acad005f5:	or     rbx,r11
    733acad005f8:	pop    r11
    733acad005fa:	pop    r10
    733acad005fc:	pop    rsi
    733acad005fd:	pop    rdx
    733acad005fe:	mov    QWORD PTR [r12+0x108],rbx
    733acad00606:	mov    eax,0x410050
    733acad0060b:	mov    QWORD PTR [r12+0x100],rax
    733acad00613:	add    rsp,0x150
    733acad0061a:	mov    eax,0x3
    733acad0061f:	movabs r11,0x5e4a9f6ce390
    733acad00629:	jmp    r11
    733acad0062c:	jmp    0x733acad00232
    733acad00631:	nop
    733acad00632:	nop
    733acad00633:	nop
