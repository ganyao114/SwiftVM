000073dddadce69b  nop [rax+rax*1], eax
000073dddadce6a0  mov qword ptr [r15+0x20], 0x420060
000073dddadce6a8  mov qword ptr [r15], 0x00
000073dddadce6af  vmovaps xmm1, [0x000073DDDA9FE010]
000073dddadce6b7  movq xmm1, xmm1
000073dddadce6bb  vmovaps xmm15, [0x000073DDDA9FE020]
000073dddadce6c3  movq xmm15, xmm15
000073dddadce6c8  movaps [r15+0x120], xmm15
000073dddadce6d0  movq rax, xmm1
000073dddadce6d5  movq r14, xmm15
000073dddadce6da  vmovq xmm1, rax
000073dddadce6df  vmovq xmm15, r14
000073dddadce6e4  movaps xmm14, xmm1
000073dddadce6e8  addsd xmm14, xmm15
000073dddadce6ed  ucomisd xmm14, xmm14
000073dddadce6f2  jp 0x000073DDDADCE791
000073dddadce6f8  movq xmm14, xmm14
000073dddadce6fd  movaps [r15+0x110], xmm14
000073dddadce705  xor eax, eax
000073dddadce707  mov r14d, 0xF4240
000073dddadce70d  mov r12d, 0x01
000073dddadce713  sub r14, r12
000073dddadce716  cmc
000073dddadce717  lahf
000073dddadce718  seto al
000073dddadce71b  mov [r15+0x108], eax
000073dddadce722  mov [r15+0x08], r14
000073dddadce726  mov eax, [r15+0x108]
000073dddadce72d  sahf
000073dddadce72e  jnz 0x000073DDDADCE760
000073dddadce730  cmp dword ptr [r15+0x318], 0x00
000073dddadce738  jz 0x000073DDDADCE910
000073dddadce73e  nop [rax+rax*1], ax
000073dddadce747  nop [rax+rax*1], eax
000073dddadce74f  mov eax, 0x410050
000073dddadce754  mov [r15+0x100], rax
000073dddadce75b  jmp 0x000073DDDABFE110
000073dddadce760  cmp dword ptr [r15+0x318], 0x00
000073dddadce768  jz 0x000073DDDADCE7E0
000073dddadce76e  nop [rax+rax*1], ax
000073dddadce777  nop [rax+rax*1], eax
000073dddadce77f  mov eax, 0x410044
000073dddadce784  mov [r15+0x100], rax
000073dddadce78b  jmp 0x000073DDDABFE110
000073dddadce790  int3
000073dddadce791  ucomisd xmm1, xmm15
000073dddadce796  jp 0x000073DDDADCE7A5
000073dddadce798  movaps xmm14, [0x000073DDDA9FE030]
000073dddadce7a0  jmp 0x000073DDDADCE6F8
000073dddadce7a5  vxorps xmm0, xmm1, xmm15
000073dddadce7aa  pextrw eax, xmm0, 0x03
000073dddadce7af  and eax, 0x7FF8
000073dddadce7b4  cmp eax, 0x08
000073dddadce7b7  jnz 0x000073DDDADCE6F8
000073dddadce7bd  movq rax, xmm15
000073dddadce7c2  shl rax, 0x0D
000073dddadce7c6  jbe 0x000073DDDADCE6F8
000073dddadce7cc  vorps xmm14, xmm15, [0x000073DDDA9FE040]
000073dddadce7d4  jmp 0x000073DDDADCE6F8
000073dddadce7d9  int3
000073dddadce7da  nop [rax+rax*1], ax
000073dddadce7e0  movaps xmm1, [r15+0x110]
000073dddadce7e8  movq rax, xmm1
000073dddadce7ed  movaps xmm1, [r15+0x120]
000073dddadce7f5  movq r14, xmm1
000073dddadce7fa  vmovq xmm1, rax
000073dddadce7ff  vmovq xmm15, r14
000073dddadce804  movaps xmm14, xmm1
000073dddadce808  addsd xmm14, xmm15
000073dddadce80d  ucomisd xmm14, xmm14
000073dddadce812  jp 0x000073DDDADCE8B9
000073dddadce818  movq xmm14, xmm14
000073dddadce81d  movaps [r15+0x110], xmm14
000073dddadce825  mov rax, [r15+0x08]
000073dddadce829  mov [rsp+0x10], rax
000073dddadce82e  xor eax, eax
000073dddadce830  mov r14, [rsp+0x10]
000073dddadce835  mov r12d, 0x01
000073dddadce83b  sub r14, r12
000073dddadce83e  cmc
000073dddadce83f  lahf
000073dddadce840  seto al
000073dddadce843  mov [r15+0x108], eax
000073dddadce84a  mov [r15+0x08], r14
000073dddadce84e  mov eax, [r15+0x108]
000073dddadce855  sahf
000073dddadce856  jnz 0x000073DDDADCE888
000073dddadce858  cmp dword ptr [r15+0x318], 0x00
000073dddadce860  jz 0x000073DDDADCE910
000073dddadce866  nop [rax+rax*1], ax
000073dddadce86f  nop [rax+rax*1], eax
000073dddadce877  mov eax, 0x410050
000073dddadce87c  mov [r15+0x100], rax
000073dddadce883  jmp 0x000073DDDABFE110
000073dddadce888  cmp dword ptr [r15+0x318], 0x00
000073dddadce890  jz 0x000073DDDADCE7E0
000073dddadce896  nop [rax+rax*1], ax
000073dddadce89f  nop [rax+rax*1], eax
000073dddadce8a7  mov eax, 0x410044
000073dddadce8ac  mov [r15+0x100], rax
000073dddadce8b3  jmp 0x000073DDDABFE110
000073dddadce8b8  int3
000073dddadce8b9  ucomisd xmm1, xmm15
000073dddadce8be  jp 0x000073DDDADCE8CD
000073dddadce8c0  movaps xmm14, [0x000073DDDA9FE030]
000073dddadce8c8  jmp 0x000073DDDADCE818
000073dddadce8cd  vxorps xmm0, xmm1, xmm15
000073dddadce8d2  pextrw eax, xmm0, 0x03
000073dddadce8d7  and eax, 0x7FF8
000073dddadce8dc  cmp eax, 0x08
000073dddadce8df  jnz 0x000073DDDADCE818
000073dddadce8e5  movq rax, xmm15
000073dddadce8ea  shl rax, 0x0D
000073dddadce8ee  jbe 0x000073DDDADCE818
000073dddadce8f4  vorps xmm14, xmm15, [0x000073DDDA9FE040]
000073dddadce8fc  jmp 0x000073DDDADCE818
000073dddadce901  int3
000073dddadce902  nop [rax+rax*1], ax
000073dddadce90b  nop [rax+rax*1], eax
000073dddadce910  mov rax, [r15+0x20]
000073dddadce914  movaps xmm1, [r15+0x110]
000073dddadce91c  movq r14, xmm1
000073dddadce921  mov [r13+rax*1], r14
000073dddadce926  mov rax, [r15+0xF0]
000073dddadce92d  mov [r15+0x100], rax
000073dddadce934  jmp 0x000073DDDADCE5C0
000073dddadce939  int3
000073dddadce93a  call 0x000073DDDAC0E120
000073dddadce93f  jmp 0x000073DDDADCE926
000073dddadce944  int3
000073dddadce945  nop [rax+rax*1], ax
000073dddadce94e  nop
000073dddadce950  mov qword ptr [r15+0x100], 0x04
000073dddadce95b  mov esi, 0x00
000073dddadce960  mov edx, 0x09
000073dddadce965  mov rdi, 0x7FFF178D4F90
000073dddadce96f  mov rax, 0x5789010CA970
000073dddadce979  call rax
000073dddadce97b  cmp dword ptr [r15+0x318], 0x00
000073dddadce983  jnz 0x000073DDDABFE110
000073dddadce989  jmp 0x000073DDDABFE0A0
000073dddadce98e  int3
000073dddadce98f  int3
