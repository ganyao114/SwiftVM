from pathlib import Path
import subprocess,json,time,hashlib,os
W=Path('/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112')
records=[]
for script,log in [('measure-final.py','final-bench.log'),('measure-compile.py','compile-program.log'),('measure-pmu.py','final-pmu.log'),('measure-samples.py','final-samples.log'),('measure-supplementary.py','supplementary.log'),('measure-confirmation.py','confirmation.log')]:
 start=time.time()
 print('starting',script,flush=True)
 with (W/log).open('w') as f: result=subprocess.run(['python3',str(W/script)],stdout=f,stderr=f)
 records.append({'script':script,'source_sha256':hashlib.sha256((W/script).read_bytes()).hexdigest(),'start_unix':start,'end_unix':time.time(),'exit_code':result.returncode})
 (W/'measurement-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 if result.returncode:
  print((W/log).read_text()[-4000:],flush=True)
  raise SystemExit(result.returncode)
 print('completed',script,flush=True)
for probe,samples in [('scaling',3),('domain-probe',9)]:
 for sample in range(samples):
  with (W/f'{probe}-final-{sample}.jsonl').open('w') as f:
   subprocess.run(['taskset','-c','2',str(W/probe)],stdout=f,check=True)
 print('completed',probe,flush=True)
print('ALL MEASUREMENTS COMPLETE',flush=True)
