from pathlib import Path
import json,subprocess,statistics,os
W=Path('/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112');os.sched_setaffinity(0,{2})
root=Path('/mnt/d/Dev/SwiftVM');guest=root/'build/wsl-arm-x64/compiled-programs/arm64';expected=bytes.fromhex(json.loads((W/'initial-implementation/final-programs-summary.json').read_text())['programs']['arm64']['expected_hex'])
runners={'baseline':W/'baseline_linux','candidate':W/'final_linux'};rows={k:[] for k in runners}
for sample in range(31):
 order=['candidate','baseline'] if sample%2 else ['baseline','candidate']
 for key in order:
  p=subprocess.run([str(runners[key]),'--scope','function','--engine','jit','--pin-slots','0',str(guest)],capture_output=True,timeout=90);assert not p.returncode and p.stdout==expected,p.stderr[-1500:]
  row=next(json.loads(s) for s in p.stderr.decode().splitlines() if 'measurement_kind' in s);assert not row['interpreted_steps'] and not row['fallbacks'];rows[key].append(row)
 med={k:{field:statistics.median(r[field] for r in v) for field in ['compile_ns','frontend_ns','optimize_ns','backend_ns','publication_ns','compile_attempts','native_bytes','code_units_published']} for k,v in rows.items()}
 result={'samples':sample+1,'runners':{k:str(v) for k,v in runners.items()},'measurements':rows,'medians':med};(W/'compile-program-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(med,flush=True)
