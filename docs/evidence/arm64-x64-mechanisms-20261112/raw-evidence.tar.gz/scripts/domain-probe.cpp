#include "runtime/arch/arm64/numeric.h"
#include "runtime/execution/vm.h"
#include "runtime/platform/linux/host_runtime.h"
#include <array>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <elf.h>
#include <stdexcept>
#include <vector>

namespace ex = swift::runtime::execution;
namespace arm = swift::runtime::arm64;
using Clock = std::chrono::steady_clock;

std::vector<std::uint8_t> Image() {
    constexpr std::array<std::uint32_t, 5> instructions{
        0xb100053f, 0x1e622820, 0x1e622803, 0x1e620824, 0xd65f03c0};
    Elf64_Ehdr header{};
    std::memcpy(header.e_ident, ELFMAG, SELFMAG);
    header.e_ident[EI_CLASS] = ELFCLASS64;
    header.e_ident[EI_DATA] = ELFDATA2LSB;
    header.e_ident[EI_VERSION] = EV_CURRENT;
    header.e_type = ET_EXEC;
    header.e_machine = EM_AARCH64;
    header.e_version = EV_CURRENT;
    header.e_entry = 0x400000 + sizeof(header) + sizeof(Elf64_Phdr);
    header.e_phoff = sizeof(header);
    header.e_ehsize = sizeof(header);
    header.e_phentsize = sizeof(Elf64_Phdr);
    header.e_phnum = 1;
    Elf64_Phdr segment{};
    segment.p_type = PT_LOAD;
    segment.p_flags = PF_R | PF_X;
    segment.p_vaddr = segment.p_paddr = 0x400000;
    segment.p_filesz = segment.p_memsz = sizeof(header) + sizeof(segment) + sizeof(instructions);
    segment.p_align = 4096;
    std::vector<std::uint8_t> image(segment.p_filesz);
    std::memcpy(image.data(), &header, sizeof(header));
    std::memcpy(image.data() + sizeof(header), &segment, sizeof(segment));
    std::memcpy(image.data() + sizeof(header) + sizeof(segment), instructions.data(), sizeof(instructions));
    return image;
}

void Run(const char* name, const std::vector<unsigned>& domains) {
    ex::RuntimeOptions options;
    options.scope = swift::runtime::ir::Scope::Function;
    ex::RuntimeStats stats;
    swift::runtime::platform::HostRuntime host{false};
    ex::VM vm{options, stats, host.Bind()};
    vm.PrepareGuest(Image(), "domain-probe.elf");
    const auto entry = vm.ArmState().pc, stack = vm.ArmState().gprs[31];
    std::printf("{\"sequence\":\"%s\",\"steps\":[", name);
    unsigned step{};
    for (unsigned pass = 0; pass < 2; ++pass) {
        for (unsigned domain : domains) {
            auto& state = vm.ArmState();
            state.fpcr = arm::FPCRForDomain(domain);
            state.fpsr = 0x08000000;
            state.gprs[9] = UINT64_MAX;
            state.gprs[30] = 0;
            state.packed_flags = (std::uint64_t{1} << 55) | 0x25;
            const std::uint64_t left = pass ? 0x7ff0000000000042 : 0x3ff0000000000000;
            const std::uint64_t right = domain & 1 ? 1 : 0x3ca0000000000000;
            std::memcpy(state.q[1], &left, 8);
            std::memcpy(state.q[2], &right, 8);
            const auto first = arm::EvaluateBinaryFP(left, right, 64, 2, state.fpcr);
            const auto second = arm::EvaluateBinaryFP(first.value, right, 64, 2, state.fpcr);
            const auto third = arm::EvaluateBinaryFP(left, right, 64, 0, state.fpcr);
            const auto before = stats;
            const auto start = Clock::now();
            vm.CallGuest(entry, stack, 0);
            const auto elapsed = std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now() - start).count();
            for (const auto [reg, expected] : std::array{
                     std::pair{0u, first.value}, std::pair{3u, second.value}, std::pair{4u, third.value}}) {
                std::array<std::uint64_t, 2> actual;
                std::memcpy(actual.data(), state.q[reg], 16);
                if (actual != std::array{expected, std::uint64_t{0}}) throw std::runtime_error("FP result");
            }
            if (state.fpsr != (0x08000000 | first.exceptions | second.exceptions | third.exceptions) ||
                state.packed_flags != ((std::uint64_t{1} << 55) | 0x60000025) || stats.fallbacks ||
                stats.interpreted_steps || (pass && stats.compile_attempts != before.compile_attempts))
                throw std::runtime_error("FP state or warm compilation");
            std::printf("%s{\"pass\":%u,\"domain\":%u,\"run_ns\":%llu,\"compile_attempts\":%llu,"
                        "\"compile_ns\":%llu,\"frontend_ns\":%llu,\"optimize_ns\":%llu,\"backend_ns\":%llu,"
                        "\"publication_ns\":%llu,\"native_bytes\":%llu,\"domains_created\":%llu,"
                        "\"switches\":%llu,\"switch_ns\":%llu}", step++ ? "," : "", pass, domain,
                        (unsigned long long)elapsed, (unsigned long long)stats.compile_attempts,
                        (unsigned long long)stats.compile_request_ns, (unsigned long long)stats.frontend_ns,
                        (unsigned long long)stats.optimize_ns, (unsigned long long)stats.backend_ns,
                        (unsigned long long)stats.publication_ns, (unsigned long long)stats.native_bytes,
                        (unsigned long long)stats.fp_domains_created, (unsigned long long)stats.fp_domain_switches,
                        (unsigned long long)stats.fp_domain_switch_ns);
        }
    }
    if (!vm.Close().Complete()) throw std::runtime_error("VM close");
    std::printf("],\"output_verified\":true}\n");
}

int main() {
    try {
        Run("default", std::vector<unsigned>(32, 0));
        Run("nondefault", std::vector<unsigned>(32, 31));
        std::vector<unsigned> alternating, all;
        for (unsigned i = 0; i < 32; ++i) {
            alternating.push_back(i % 2 ? 31 : 0);
            all.push_back(i);
        }
        Run("alternating", alternating);
        Run("all", all);
    } catch (const std::exception& error) {
        std::fprintf(stderr, "%s\n", error.what());
        return 1;
    }
}
