from pathlib import Path
import json,os,subprocess,shutil,hashlib
W=Path('/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112');corpus=W/'x86-corpus';corpus.mkdir(exist_ok=True)
for group in ['x86-inventory-gaps','x86-x87-mmx']:
 for p in (Path('/mnt/d/Dev/SwiftVM/tools/correctness/native-corpus')/group).glob('*.svmcase'):shutil.copy2(p,corpus/(group+'-'+p.name))
os.sched_setaffinity(0,{8})
for scope in ['block','function']:
 out=W/'x86-baseline'/scope;out.mkdir(parents=True,exist_ok=True)
 config={'backend':'x64','scope':scope,'target':'known','optimize':True,'pin':True,'compile_only':False};(out/'config.json').write_text(json.dumps(config))
 with (out/'worker.log').open('w') as f:
  p=subprocess.run([str(W/'baseline_correctness'),'worker','--input-dir',str(corpus),'--output-dir',str(out/'actual'),'--config',str(out/'config.json')],stdout=f,stderr=f,timeout=300)
 print(scope,p.returncode,len(list((out/'actual').glob('*.json'))),flush=True)
