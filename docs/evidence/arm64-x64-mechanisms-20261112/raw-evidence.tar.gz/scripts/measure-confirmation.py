from pathlib import Path
import json,os,statistics,sys
W=Path('/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112');O=Path('/home/proton/.cache/SwiftVM/dynarmic-bench-20261111')
sys.path.insert(0,'/mnt/d/Dev/SwiftVM/tools');import bench_dynarmic as b
os.sched_setaffinity(0,{2})
guests=json.loads((W/'final-bench-summary.json').read_text())['workloads']
runners={'baseline':W/'baseline_compare','candidate':W/'final_compare','dynarmic':O/'runners/dynarmic_arm64_compare_bench'}
result={'reason':'large paired dispersion in the first SHA and matrix timing series','samples':31,'warm_repeats':9,'affinity':[2],'runners':{k:{'path':str(v),'sha256':b.digest(v)} for k,v in runners.items()},'workloads':{}}
for name in ['compute-sha','compute-matrix','compute-matrix-scalar']:
 rows={k:[] for k in runners}
 for sample in range(31):
  order=list(runners);order=order[sample%3:]+order[:sample%3]
  if sample%2:order.reverse()
  for key in order:
   rows[key].append(b.launch(runners[key],{'engine':'dynarmic' if key=='dynarmic' else 'swiftvm','scope':'block' if key=='dynarmic' else 'function','pins':0},guests[name]['guest'],9))
 result['workloads'][name]={'measurements':rows,'medians_ns':{k:statistics.median(x['warm_median_ns'] for x in v) for k,v in rows.items()},'paired':b.distribution([a['warm_median_ns']/c['warm_median_ns'] for a,c in zip(rows['candidate'],rows['baseline'])])}
 (W/'confirmation-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(name,result['workloads'][name]['medians_ns'],result['workloads'][name]['paired'],flush=True)
