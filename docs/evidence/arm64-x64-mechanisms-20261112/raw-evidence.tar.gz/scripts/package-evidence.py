from pathlib import Path
import hashlib
import json
import platform
import shutil
import subprocess
import tarfile

ROOT = Path('/mnt/d/Dev/SwiftVM')
WORK = Path('/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112')
DEST = ROOT / 'docs/evidence/arm64-x64-mechanisms-20261112'
PRIOR = Path('/home/proton/.cache/SwiftVM/wsl-arm-x64-20261111')
OPT4 = Path('/home/proton/.cache/SwiftVM/arm64-x64-opt4-20261111')
DYN = Path('/home/proton/.cache/SwiftVM/dynarmic-bench-20261111')


def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


subprocess.run(['git', '-c', 'core.autocrlf=true', '-C', str(ROOT), 'diff', '--check'], check=True)
patch = subprocess.check_output(['git', '-c', 'core.autocrlf=true', '-C', str(ROOT), 'diff', '--binary', 'HEAD'])
(WORK / 'source.patch').write_bytes(patch)
tracked = subprocess.check_output(['git', '-c', 'core.autocrlf=true', '-C', str(ROOT), 'ls-files', '-z'], text=True).split('\0')
new = subprocess.check_output(['git', '-c', 'core.autocrlf=true', '-C', str(ROOT), 'ls-files', '--others', '--exclude-standard', '-z'], text=True).split('\0')
source_paths = sorted({name for name in tracked + new if name and
                       (name.startswith(('source/', 'benchmarks/', 'tools/', 'cmake/')) or
                        name == 'CMakeLists.txt') and (ROOT / name).is_file()})
source_hashes = {name: digest(ROOT / name) for name in source_paths}
write(WORK / 'source-sha256.json', source_hashes)
new_sources = [name for name in new if name and name.startswith(('source/', 'benchmarks/', 'tools/'))
               and (ROOT / name).is_file()]

runners = {}
for name in ['baseline_compare', 'baseline_correctness', 'baseline_linux', 'baseline_aot',
             'final_compare', 'final_correctness', 'final_linux', 'final_aot', 'scaling', 'domain-probe']:
    path = WORK / name
    runners[name] = {'path': str(path), 'sha256': digest(path), 'bytes': path.stat().st_size}
for name, path in [('baseline_probe', OPT4 / 'final-pmu/swiftvm_gap_probe'),
                   ('candidate_probe', WORK / 'final-pmu/swiftvm_gap_probe'),
                   ('dynarmic_probe', WORK / 'final-pmu/dynarmic_gap_probe'),
                   ('dynarmic_compare', DYN / 'runners/dynarmic_arm64_compare_bench')]:
    runners[name] = {'path': str(path), 'sha256': digest(path), 'bytes': path.stat().st_size}

build_commands = {}
for target in ['svm_arm64_compare_bench', 'svm_rebuild_linux', 'svm_aot', 'svm_correctness']:
    build_commands[target] = subprocess.check_output(
        ['ninja', '-t', 'commands', target], cwd=ROOT / 'build/host', text=True).splitlines()[-1]
write(WORK / 'build-commands.json', build_commands)
shutil.copy2(ROOT / 'build/host/CMakeCache.txt', WORK / 'CMakeCache.txt')
provenance = {
    'git_head': subprocess.check_output(['git', '-c', 'core.autocrlf=true', '-C', str(ROOT), 'rev-parse', 'HEAD'], text=True).strip(),
    'source_state': 'current dirty workspace including the preserved previous four optimizations',
    'code_build_id_header': (WORK / 'code_build_id.h').read_text(),
    'source_patch_sha256': digest(WORK / 'source.patch'),
    'source_hash_file': 'source/source-sha256.json',
    'new_source_files': new_sources,
    'runners': runners,
    'environment': {
        'platform': platform.platform(),
        'compiler': subprocess.check_output(['c++', '--version'], text=True).splitlines()[0],
        'cmake': subprocess.check_output(['cmake', '--version'], text=True).splitlines()[0],
        'ninja': subprocess.check_output(['ninja', '--version'], text=True).strip(),
        'cpu': next(line.split(':', 1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines()
                    if line.startswith('model name')),
        'build': 'Release with SVM_ENABLE_IPO=ON',
        'measurement_affinity': [2],
        'wsl_distribution': 'ProtonHM'},
    'reference': {
        'dynarmic_commit': subprocess.check_output(['git', '-C', str(DYN / 'dynarmic'), 'rev-parse', 'HEAD'], text=True).strip()
                          if (DYN / 'dynarmic/.git').exists() else '9d4582339990d4eae53f1dc7160686920fc2075c',
        'qemu': {name: {'path': str(PRIOR / 'qemu-packages/root/usr/bin' / name),
                        'sha256': digest(PRIOR / 'qemu-packages/root/usr/bin' / name)}
                 for name in ['qemu-aarch64', 'qemu-arm']}},
    'validation': {'arm_native_agreements': 57168, 'x86_baseline_full_outcomes_equal': 1278,
                   'ctest_passed': 31, 'ctest_skipped': 7, 'full_program_configurations': 24},
    'reproduction': {'root': str(ROOT), 'work': str(WORK),
                     'build': ['cmake', '--build', str(ROOT / 'build/host'), '-j', '8'],
                     'test_environment': {'SVM_TEST_SCRATCH': str(WORK / 'test-scratch')}}}
write(WORK / 'provenance.json', provenance)

archive = DEST / 'raw-evidence.tar.gz'
index = []
seen = set()


def add(path, name):
    name = str(name)
    if name in seen:
        return
    seen.add(name)
    if path.is_dir():
        children = sorted(item for item in path.rglob('*') if item.is_file() and
                          'native-corpus' not in item.relative_to(path).parts)
        total = 0
        for item in children:
            target = str(Path(name) / item.relative_to(path))
            tar.add(item, arcname=target, recursive=False)
            total += item.stat().st_size
        index.append({'name': name, 'files': len(children), 'uncompressed_bytes': total})
    elif path.is_file():
        tar.add(path, arcname=name, recursive=False)
        index.append({'name': name, 'files': 1, 'uncompressed_bytes': path.stat().st_size})
    else:
        raise RuntimeError(f'missing evidence {path}')


with tarfile.open(archive, 'w:gz', compresslevel=6) as tar:
    add(WORK / 'provenance.json', 'provenance.json')
    add(DEST / 'summary.json', 'results/summary.json')
    for path in sorted(DEST.glob('*-hot-paths.txt')):
        add(path, Path('results') / path.name)
    for name in ['source.patch', 'source-sha256.json', 'CMakeCache.txt', 'build-commands.json', 'code_build_id.h']:
        add(WORK / name, Path('source') / name)
    for name in new_sources:
        add(ROOT / name, Path('source/new-files') / name)
    for path in sorted(WORK.glob('*.py')):
        add(path, Path('scripts') / path.name)
    for name in ['scaling.cpp', 'domain-probe.cpp', 'scaling-build.json', 'domain-probe-build.json',
                 'final-binaries.json', 'ctest-command.json', 'measurement-commands.json']:
        add(WORK / name, Path('scripts') / name)
    for name, entry in runners.items():
        add(Path(entry['path']), Path('runners') / name)
    for name in ['qemu-aarch64', 'qemu-arm']:
        add(PRIOR / 'qemu-packages/root/usr/bin' / name, Path('runners') / name)
    for name in ['final-bench-summary.json', 'final-pmu-summary.json', 'sample-runs.json',
                 'compile-program-summary.json', 'final-programs-summary.json', 'final-correctness-summary.json',
                 'x86-regression-summary.json', 'x86-block-raw-diff.json', 'x86-function-raw-diff.json',
                 'supplementary-summary.json', 'confirmation-summary.json', 'scaling-final-summary.json',
                 'fp-domains-summary.json', 'static-instructions.json', 'hot-paths.json',
                 'validated-ctest.xml', 'validated-ctest.log', 'final-correctness.log', 'x86-final.log',
                 'final-programs.log', 'final-bench.log', 'final-pmu.log', 'final-samples.log',
                 'compile-program.log', 'supplementary.log', 'confirmation.log', 'final-build9.log',
                 'drvfs-ctest.xml', 'drvfs-ctest.log']:
        add(WORK / name, Path('results') / name)
    for pattern in ['scaling-final-*.jsonl', 'domain-probe-final-*.jsonl']:
        for path in sorted(WORK.glob(pattern)):
            add(path, Path('results') / path.name)
    add(WORK / 'final-pmu', 'diagnostics/pmu')
    add(WORK / 'final-samples', 'diagnostics/samples')
    add(WORK / 'final-correctness-v4', 'correctness/arm-actual')
    add(WORK / 'x86-final-v4', 'correctness/x86-actual')
    add(WORK / 'x86-baseline', 'correctness/x86-baseline')
    add(WORK / 'x86-corpus', 'correctness/x86-corpus')
    for name, path in [('basic-arm64-corpus', PRIOR / 'corpus/arm64'),
                       ('basic-arm32-corpus', PRIOR / 'corpus/arm32'),
                       ('basic-arm64-oracle', PRIOR / 'post-fp-matrix/oracle/arm64'),
                       ('basic-arm32-oracle', PRIOR / 'post-fp-matrix/oracle/arm32'),
                       ('fp-corpus', PRIOR / 'fp-corpus'), ('fp-oracle', PRIOR / 'fp-validation/oracle'),
                       ('neon-corpus', OPT4 / 'neon-corpus'), ('neon-oracle', OPT4 / 'neon-oracle')]:
        add(path, Path('correctness') / name)
    guests = json.loads((WORK / 'final-bench-summary.json').read_text())['workloads']
    for name, row in guests.items():
        add(Path(row['guest']['path']), Path('guests/benchmarks') / name)
    for isa in ['arm64', 'arm32', 'thumb']:
        add(ROOT / 'build/wsl-arm-x64/compiled-programs' / isa, Path('guests/full-programs') / isa)
        add(WORK / f'release-verified-{isa}.aot', Path('persistence') / f'{isa}.aot')
        add(WORK / f'release-verified-cache-{isa}', Path('persistence') / f'cache-{isa}')
    for stage in ['initial-implementation', 'tuned-implementation', 'before-narrow-flags-fix']:
        for path in sorted((WORK / stage).glob('*')):
            if path.is_file() and (path.name.endswith('summary.json') or path.name.endswith('.log')):
                add(path, Path('intermediate') / stage / path.name)
    for name in ['flags_compare', 'flags_correctness', 'flags_linux', 'flags-smoke.json', 'flags-ctest3.log']:
        add(WORK / name, Path('intermediate/flags') / name)
    for name in ['arm64-x64-mechanism-optimization-plan-2026-11-12.md',
                 'arm64-x64-mechanism-optimization-results-2026-11-12.md']:
        add(ROOT / 'docs' / name, Path('documents') / name)

shutil.copy2(WORK / 'validated-ctest.xml', DEST / 'validated-ctest.xml')
write(DEST / 'archive-index.json', index)
manifest = {'provenance': provenance,
            'archive': {'path': archive.name, 'sha256': digest(archive), 'bytes': archive.stat().st_size},
            'files': {path.name: {'sha256': digest(path), 'bytes': path.stat().st_size}
                      for path in sorted(DEST.iterdir()) if path.is_file() and path.name != 'manifest.json'}}
write(DEST / 'manifest.json', manifest)
print(json.dumps({'archive_bytes': archive.stat().st_size, 'archive_sha256': manifest['archive']['sha256'],
                  'groups': len(index), 'raw_files': sum(row['files'] for row in index)}))
