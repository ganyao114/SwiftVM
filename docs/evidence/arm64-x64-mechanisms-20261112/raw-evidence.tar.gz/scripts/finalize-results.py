from pathlib import Path
import collections
import hashlib
import json
import platform
import re
import statistics
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = Path('/mnt/d/Dev/SwiftVM')
WORK = Path('/home/proton/.cache/SwiftVM/arm64-x64-mechanisms-20261112')
DEST = ROOT / 'docs/evidence/arm64-x64-mechanisms-20261112'
sys.path.insert(0, str(ROOT / 'tools'))
import bench_dynarmic as bench
import summarize_dynarmic_gap as diagnostic


def read(name):
    return json.loads((WORK / name).read_text())


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def table(headers, rows):
    return '\n'.join(['| ' + ' | '.join(headers) + ' |',
                      '| ' + ' | '.join(['---'] * len(headers)) + ' |'] +
                     ['| ' + ' | '.join(map(str, row)) + ' |' for row in rows])


DEST.mkdir(parents=True, exist_ok=True)
correctness = read('final-correctness-summary.json')
assert sum(row['total'] for row in correctness['configs'].values()) == 57168
assert all(row['failures'] == 0 and row['native_executed'] == row['total']
           for row in correctness['configs'].values())
x86 = {scope: read(f'x86-{scope}-raw-diff.json') for scope in ['block', 'function']}
assert all(row['total'] == 639 and not row['mismatches'] for row in x86.values())
programs = read('final-programs-summary.json')
assert set(programs['programs']) == {'arm64', 'arm32', 'thumb'}
assert all(len(row['runs']) == 8 for row in programs['programs'].values())
xml = ET.parse(WORK / 'validated-ctest.xml').getroot()
cases = list(xml.iter('testcase'))
skipped = [row.attrib['name'] for row in cases if row.find('skipped') is not None]
assert len(cases) == 38 and len(skipped) == 7
assert not list(xml.iter('failure')) and not list(xml.iter('error'))

measurements = read('final-bench-summary.json')
pmu = read('final-pmu-summary.json')
compile_cost = read('compile-program-summary.json')
supplementary = read('supplementary-summary.json')
confirmation = read('confirmation-summary.json')
for workload in measurements['workloads'].values():
    assert bench.digest(Path(workload['guest']['path'])) == workload['guest']['sha256']
    for rows in workload['measurements'].values():
        assert len(rows) == 31
        assert all(row['output_verified'] and row['warm_cache_verified'] for row in rows)
        assert all(row['fallbacks'] == row['interpreted_steps'] == row['data_callbacks'] == 0 for row in rows)
for workload in pmu['workloads'].values():
    for rows in workload['measurements'].values():
        assert len(rows) == 7
        for row in rows:
            assert all(counter['enabled_ns'] == counter['running_ns'] and counter['running_ns'] > 0
                       for counter in row['pmu'])

sample_runs = read('sample-runs.json')
profile_input = {'configs': {key: {'engine': key} for key in ['swiftvm', 'dynarmic']},
                 'workloads': {}}
for name, engines in sample_runs.items():
    profile_input['workloads'][name] = {'measurements': {}}
    for key, rows in engines.items():
        assert len(rows) == 3
        profile_input['workloads'][name]['measurements'][key] = [
            {'output_directory': row['directory']} for row in rows]
write(WORK / 'final-pmu/profile-summary.json', profile_input)
profile = diagnostic.profile_summary(WORK / 'final-pmu')
assert all(row['lost'] == 0 for engines in profile.values() for row in engines.values())

scaling_groups = collections.defaultdict(list)
for path in sorted(WORK.glob('scaling-final-*.jsonl')):
    for line in path.read_text().splitlines():
        row = json.loads(line)
        assert row['output_verified']
        row['median_compile_ns'] = statistics.median(row['sequence_ns']) / row['requests_per_sample']
        scaling_groups[(row['kind'], row['count'])].append(row)
scaling = {'processes': 3, 'affinity': [2], 'workloads': {}}
for (kind, count), rows in scaling_groups.items():
    assert len(rows) == 3
    scaling['workloads'].setdefault(kind, []).append({
        'count': count,
        'median_compile_ns': statistics.median(row['median_compile_ns'] for row in rows),
        'processes': rows})
write(WORK / 'scaling-final-summary.json', scaling)

domain_groups = collections.defaultdict(list)
for path in sorted(WORK.glob('domain-probe-final-*.jsonl')):
    for line in path.read_text().splitlines():
        row = json.loads(line)
        assert row['output_verified']
        domain_groups[row['sequence']].append(row)
domains = {'processes': 9, 'affinity': [2], 'sequences': {}}
domain_fields = ['compile_attempts', 'compile_ns', 'frontend_ns', 'optimize_ns', 'backend_ns',
                 'publication_ns', 'native_bytes', 'domains_created', 'switches', 'switch_ns']
for key, rows in domain_groups.items():
    assert len(rows) == 9
    medians = {field: statistics.median(row['steps'][-1][field] for row in rows) for field in domain_fields}
    medians['second_pass_additional_compiles'] = [
        row['steps'][-1]['compile_attempts'] - row['steps'][31]['compile_attempts'] for row in rows]
    assert not any(medians['second_pass_additional_compiles'])
    domains['sequences'][key] = {'medians': medians, 'processes': rows}
write(WORK / 'fp-domains-summary.json', domains)

static = {}
hot_paths = {}
for name in measurements['workloads']:
    static[name] = {}
    for key in ['baseline', 'candidate']:
        folder = WORK / 'final-pmu/records' / name / key / '0'
        counts = collections.Counter()
        for line in (folder / 'maps.tsv').read_text().splitlines():
            unit, start, size, pc = line.split()
            instructions = diagnostic.disassemble(folder / f'{unit}.bin')
            counts.update(text.split()[0] for address, text in instructions)
            if name not in ['integer', 'memory', 'shift']:
                continue
            entries = dict(instructions)
            next_pc = {instructions[i][0]: instructions[i + 1][0] for i in range(len(instructions) - 1)}
            loops = [(address, int(match[1], 16)) for address, text in instructions
                     if (match := re.match(r'(?:jne|je)\s+0x([0-9a-f]+)$', text)) and int(match[1], 16) < address]
            if not loops:
                continue
            end, begin = min(loops)
            walked = []
            cursor = begin
            for step in range(256):
                text = entries[cursor]
                walked.append((cursor, text))
                if cursor == end:
                    break
                event = re.match(r'(je|jrcxz)\s+0x([0-9a-f]+)$', text)
                cursor = int(event[2], 16) if event else next_pc[cursor]
            else:
                raise RuntimeError('hot path did not converge')
            hot_paths.setdefault(name, {})[key] = {'instructions': len(walked), 'unit': unit,
                                                  'path': walked}
        static[name][key] = dict(counts)
write(WORK / 'static-instructions.json', static)
write(WORK / 'hot-paths.json', hot_paths)
for name in ['integer', 'memory', 'shift']:
    expected = {'integer': (37, 13), 'memory': (37, 18), 'shift': (40, 14)}[name]
    assert tuple(hot_paths[name][key]['instructions'] for key in ['baseline', 'candidate']) == expected
    lines = []
    for key, entry in hot_paths[name].items():
        lines.append(f'{key}, {entry["instructions"]} instructions per taken iteration')
        begin = entry['path'][0][0]
        lines.extend(f'+{address - begin:04x}  {text}' for address, text in entry['path'])
        lines.append('')
    (DEST / f'{name}-hot-paths.txt').write_text('\n'.join(lines) + '\n')

summary = {
    'code_build_id': read('final-binaries.json')['code_build_id'],
    'baseline': 'frozen previous-four-optimization runners',
    'correctness': {'arm': correctness, 'x86_raw': x86,
                    'ctest': {'passed': 31, 'skipped': skipped, 'failed': 0},
                    'programs': programs},
    'ordinary': {key: value for key, value in measurements.items() if key != 'workloads'},
    'warm_workloads': {name: {key: value for key, value in row.items() if key != 'measurements'}
                       for name, row in measurements['workloads'].items()},
    'pmu': {name: row['medians'] for name, row in pmu['workloads'].items()},
    'compile': compile_cost['medians'],
    'compile_paired': bench.distribution([a['compile_ns'] / b['compile_ns'] for a, b in
                        zip(compile_cost['measurements']['candidate'], compile_cost['measurements']['baseline'])]),
    'supplementary': {name: {key: {field: value for field, value in row.items() if field != 'measurements'}
                            for key, row in groups.items()}
                      for name, groups in supplementary['workloads'].items()},
    'confirmation': {name: {key: value for key, value in row.items() if key != 'measurements'}
                     for name, row in confirmation['workloads'].items()},
    'profiles': profile,
    'scaling': {name: [{'count': row['count'], 'median_compile_ns': row['median_compile_ns'],
                        'native_bytes': row['processes'][0]['native_bytes'],
                        'actual_spills': row['processes'][0]['actual_spills'],
                        'shared_stubs': row['processes'][0]['shared_stubs']}
                       for row in rows] for name, rows in scaling['workloads'].items()},
    'fp_domains': {name: row['medians'] for name, row in domains['sequences'].items()},
    'hot_paths': hot_paths,
    'static_instructions': static}
write(DEST / 'summary.json', summary)

names = {'integer': '整数', 'memory': '访存', 'shift': '移位', 'fp': '浮点', 'compute': '综合计算',
         'fp-u8': '浮点展开 ×8', 'compute-matrix': '向量矩阵', 'compute-matrix-scalar': '标量矩阵',
         'compute-sha': 'SHA', 'compute-sort': '排序'}
bench_rows = []
for name, row in measurements['workloads'].items():
    values = row['medians_ns']
    baseline, candidate, dynarmic = [values[key] for key in ['baseline', 'candidate', 'dynarmic']]
    paired = row['candidate_over']['baseline']
    bench_rows.append([names[name], f'{baseline / 1e6:.3f}', f'{candidate / 1e6:.3f}',
                       f'{dynarmic / 1e6:.3f}', f'{100 * (1 - candidate / baseline):.1f}%',
                       f'{candidate / dynarmic:.2f}×', f'{paired["median"]:.3f} [{paired["q1"]:.3f}, {paired["q3"]:.3f}]'])
blocks = {'BENCH_TABLE': table(['负载', '基线 ms', '候选 ms', 'Dynarmic ms', '耗时降低',
                              '候选／Dynarmic', '配对候选／基线中位数 [Q1, Q3]'], bench_rows)}
blocks['CONFIRMATION_TABLE'] = table(['追加负载', '基线 ms', '候选 ms', 'Dynarmic ms', '配对中位数 [Q1, Q3]'], [
    [names[name], *[f'{row["medians_ns"][key] / 1e6:.3f}' for key in ['baseline', 'candidate', 'dynarmic']],
     f'{row["paired"]["median"]:.3f} [{row["paired"]["q1"]:.3f}, {row["paired"]["q3"]:.3f}]']
    for name, row in confirmation['workloads'].items()])
blocks['PMU_TABLE'] = table(['循环', '基线指令／轮', '候选指令／轮', 'Dynarmic 指令／轮', '候选分支／轮'], [
    [names[name], *[f'{pmu["workloads"][name]["medians"][key]["instructions"] / 12000000:.2f}'
                    for key in ['baseline', 'candidate', 'dynarmic']],
     f'{pmu["workloads"][name]["medians"]["candidate"]["branches"] / 12000000:.2f}']
    for name in ['integer', 'memory', 'shift']])
profile_total = sum(row['samples'] for engines in profile.values() for row in engines.values())
blocks['SAMPLE_SUMMARY'] = (f'CPU-clock IP 采样覆盖 8 个负载、2 个引擎，各 3 个进程、每进程 60 次热执行，'
                          f'合计 {profile_total:,} 个样本，丢失数为零。分类摘要、进程映射与生成代码一起归档。')
stages = {'compile_ns': 'compile 总量', 'frontend_ns': 'Frontend', 'optimize_ns': 'Optimize',
          'backend_ns': 'Backend', 'publication_ns': 'Publication', 'native_bytes': 'native bytes'}
compile_rows = []
for field, label in stages.items():
    baseline = compile_cost['medians']['baseline'][field]
    candidate = compile_cost['medians']['candidate'][field]
    divisor = 1 if field == 'native_bytes' else 1000
    compile_rows.append([label, f'{baseline:,}' if field == 'native_bytes' else f'{baseline / divisor:.3f}',
                         f'{candidate:,}' if field == 'native_bytes' else f'{candidate / divisor:.3f}',
                         f'{100 * (candidate / baseline - 1):+.1f}%'])
blocks['COMPILE_TABLE'] = table(['阶段，时间单位 μs', '基线', '候选', '变化'], compile_rows)
blocks['SCALING_TABLE'] = table(['输入', 'N μs', '2N μs', '4N μs', '4N／N'], [
    [name, *[f'{row["median_compile_ns"] / 1000:.2f}' for row in rows],
     f'{rows[-1]["median_compile_ns"] / rows[0]["median_compile_ns"]:.2f}×']
    for name, rows in scaling['workloads'].items()])
blocks['DOMAIN_TABLE'] = table(['序列', '编译版本数', '第二遍新增编译', '代码字节', '域目录数', '切换次数', '累计 reset μs'], [
    [name, int(row['medians']['compile_attempts']), 0, int(row['medians']['native_bytes']),
     int(row['medians']['domains_created']), int(row['medians']['switches']),
     f'{row["medians"]["switch_ns"] / 1000:.3f}']
    for name, row in domains['sequences'].items()])
blocks['BUILD_ID'] = ('最终 `CodeBuildId` 为 `' +
                      re.search(r'"([0-9a-f]+)"', read('final-binaries.json')['code_build_id'])[1] +
                      '`。基线与候选 runner 的完整 SHA-256、源码文件哈希和实际构建参数记录在清单中。')
document = ROOT / 'docs/arm64-x64-mechanism-optimization-results-2026-11-12.md'
text = document.read_text()
for key, content in blocks.items():
    marker = '<!-- ' + key + ' -->'
    if marker in text:
        assert text.count(marker) == 1, marker
        text = text.replace(marker, content)
    else:
        assert content in text, f'result section differs from measurements: {key}'
document.write_text(text)
print('validated summaries, disassembly and final result document written')
